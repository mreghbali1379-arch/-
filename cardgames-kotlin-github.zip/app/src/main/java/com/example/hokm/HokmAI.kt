package com.example.hokm

import java.util.Random

/** a card played in this round, with what was on the table when it was played (for the inference about the hidden hands) */
class AiPlay(val seat: Int, val c: Card, val led: Int, val len: Int, val bs: Int, val bc: Card?)

/**
 * The strong robot of the Hokm games for 3, 5 and 6 players, built like the four-player robot (Engine4):
 *  - it counts the cards and knows which suits a player has shown he does not have,
 *  - it deals the hidden cards to the others many times, giving more weight to the deals that agree with how they played
 *    (a player who did not win a trick he could have won, or who did not cut when he could, probably did not hold those cards),
 *  - near the end of the round it solves the rest exactly (alpha-beta search; the others are taken as playing against its side),
 *  - before that it plays every candidate out with a good policy, and the value of the end of a round is its points as in the real game,
 *  - equal cards (next to each other in rank, with the cards between them gone) are tried once.
 * Nothing is random: the deals are made from a generator that is seeded by the situation, so the same situation always gives the same card.
 */
class HokmAI(private val n: Int, private val kind: Int, private val trump: Int, private val hakem: Int) {
    private val teams = HokmN.teamsOf(kind)
    private fun teamOf(seat: Int): Int = when (kind) { 62 -> seat % 2; 63 -> seat % 3; else -> seat }
    private val sim = HokmSim(n, kind, trump, hakem)
    private var rnd = Random(1L)
    private var sizeR = 0                 // the tricks of a round

    private fun id(c: Card) = c.s * 20 + c.r
    private fun sid(i: Int) = i / 20

    private fun seedOf(a: List<Int>): Long {
        var h = -3750763034362895579L
        for (p in a) h = (h xor p.toLong()) * 1099511628211L
        return h
    }

    // ------------------------------------------------------------------ the value of a round

    /** 0..1 for the side [my] when the side [winner] won the round: its points as in the real game (kot 2 or 3, bam = the whole game) */
    private fun valueOf(winner: Int, kot: Boolean, bam: Boolean, my: Int): Double {
        val p = if (bam) 7 else HokmRules.gain(kot, winner == teamOf(hakem))
        return if (winner == my) 0.5 + p / 14.0 else 0.5 - p / 14.0
    }

    /** all the tricks are played and nobody reached 7: the side with most tricks */
    private fun finalValue(tw: IntArray, my: Int): Double {
        var mx = 0; for (t in 0 until teams) mx = Math.max(mx, tw[t])
        if (tw[my] == mx) {
            var cnt = 0; for (t in 0 until teams) if (tw[t] == mx) cnt++
            return if (cnt == 1) valueOf(my, false, false, my) else 0.5
        }
        var w = 0; for (t in 0 until teams) if (tw[t] == mx) { w = t; break }
        return valueOf(w, false, false, my)
    }

    // ------------------------------------------------------------------ playing out with the policy

    private fun rollout(hands: Array<MutableList<Card>>, trickIn: List<TC>, first: Int, seenIn: BooleanArray, tw0: IntArray, kt0: Int, my: Int): Double {
        val seen = seenIn.copyOf(); val tw = tw0.copyOf(); var kt = kt0
        var trick = ArrayList(trickIn); var seat = first
        var guard = 0
        while (guard++ < 600) {
            while (trick.size < n) {
                val h = hands[seat]
                if (h.isEmpty()) return finalValue(tw, my)
                val c = sim.policy(seat, h, trick, seen)
                h.remove(c); seen[id(c)] = true
                trick.add(TC(seat, c))
                seat = (seat + 1) % n
            }
            val w = HokmRules.winnerOf(trick, trump)
            tw[teamOf(w.seat)]++
            var hs = -1
            for (t in 0 until teams) if (tw[t] >= 7) { hs = t; break }
            if (hs >= 0) {
                var oz = true; for (t in 0 until teams) if (t != hs && tw[t] != 0) oz = false
                if (oz && kt < 0) kt = hs
                if (!oz || tw[hs] == sizeR) return valueOf(hs, kt == hs || tw[hs] == sizeR, tw[hs] == sizeR, my)
            }
            trick = ArrayList(); seat = w.seat
            if (hands[seat].isEmpty()) return finalValue(tw, my)
        }
        return finalValue(tw, my)
    }

    // ------------------------------------------------------------------ the exact search

    private class Abort : RuntimeException()
    private var nodes = 0
    private var limit = 0

    private fun beatsI(a: Int, b: Int): Boolean = if (sid(a) == sid(b)) a % 20 > b % 20 else sid(a) == trump && sid(b) != trump

    private fun solve(hh: Array<IntArray>, ts: IntArray, ti: IntArray, tn: Int, turn: Int, tw: IntArray, kt: Int, my: Int, alIn: Double, beIn: Double): Double {
        var al = alIn; var be = beIn
        if (++nodes > limit) throw Abort()
        if (tn == n) {
            var b = 0
            for (i in 1 until n) if (beatsI(ti[i], ti[b])) b = i
            val ws = ts[b]
            val tw2 = tw.copyOf(); tw2[teamOf(ws)]++
            var kt2 = kt
            var hs = -1
            for (t in 0 until teams) if (tw2[t] >= 7) { hs = t; break }
            if (hs >= 0) {
                var oz = true; for (t in 0 until teams) if (t != hs && tw2[t] != 0) oz = false
                if (oz && kt2 < 0) kt2 = hs
                if (!oz || tw2[hs] == sizeR) return valueOf(hs, kt2 == hs || tw2[hs] == sizeR, tw2[hs] == sizeR, my)
            }
            if (hh[ws].isEmpty()) return finalValue(tw2, my)
            return solve(hh, IntArray(n), IntArray(n), 0, ws, tw2, kt2, my, al, be)
        }
        val hand = hh[turn]
        var legal: IntArray = hand
        if (tn > 0) {
            val led = sid(ti[0])
            val f = hand.filter { sid(it) == led }
            if (f.isNotEmpty()) legal = f.toIntArray()
        }
        if (legal.isEmpty()) return finalValue(tw, my)
        // the order of the moves: the cards that win the trick first (the cheapest), then the others from the lowest
        var bid = -1
        if (tn > 0) { bid = ti[0]; for (i in 1 until tn) if (beatsI(ti[i], bid)) bid = ti[i] }
        val order = legal.toList().sortedBy { c ->
            if (bid >= 0 && beatsI(c, bid)) (c % 20) + (if (sid(c) == trump) 50 else 0) else 1000 + (c % 20) + (if (sid(c) == trump) 50 else 0)
        }
        val mx = teamOf(turn) == my
        var best = if (mx) -9.0 else 9.0
        for (c in order) {
            hh[turn] = hand.filter { it != c }.toIntArray()
            ts[tn] = turn; ti[tn] = c
            val r = solve(hh, ts, ti, tn + 1, (turn + 1) % n, tw, kt, my, al, be)
            hh[turn] = hand
            if (mx) { if (r > best) best = r; if (best > al) al = best } else { if (r < best) best = r; if (best < be) be = best }
            if (al >= be) break
        }
        return best
    }

    private fun exactValue(hs: Array<MutableList<Card>>, seat: Int, c: Card, trick: List<TC>, tw: IntArray, kt: Int, my: Int, lim: Int): Double? {
        val hh = Array(n) { p -> hs[p].map { id(it) }.toIntArray() }
        val cid = id(c)
        hh[seat] = hh[seat].filter { it != cid }.toIntArray()
        val ts = IntArray(n); val ti = IntArray(n)
        for ((i, t) in trick.withIndex()) { ts[i] = t.seat; ti[i] = id(t.c) }
        ts[trick.size] = seat; ti[trick.size] = cid
        nodes = 0; limit = lim
        return try { solve(hh, ts, ti, trick.size + 1, (seat + 1) % n, tw, kt, my, -9.0, 9.0) } catch (e: Abort) { null }
    }

    // ------------------------------------------------------------------ the hidden cards

    /** the hidden cards dealt to the others; nobody gets a suit he has shown he does not have */
    private fun deal(unseen: List<Card>, need: IntArray, seat: Int, voids: Array<BooleanArray>): Array<MutableList<Card>> {
        val hands = Array(n) { ArrayList<Card>() as MutableList<Card> }
        val rest = need.copyOf()
        val cards = ArrayList(unseen); java.util.Collections.shuffle(cards, rnd)
        val order = cards.sortedBy { c -> (0 until n).count { it != seat && !voids[it][c.s] } }
        for (c in order) {
            var tot = 0
            val ok = ArrayList<Int>()
            for (s in 0 until n) if (s != seat && rest[s] > 0 && !voids[s][c.s]) { ok.add(s); tot += rest[s] }
            if (ok.isEmpty()) for (s in 0 until n) if (s != seat && rest[s] > 0) { ok.add(s); tot += rest[s] }
            if (ok.isEmpty()) break
            var r = rnd.nextInt(tot)
            var pick = ok[0]
            for (s in ok) { if (r < rest[s]) { pick = s; break }; r -= rest[s] }
            hands[pick].add(c); rest[pick]--
        }
        return hands
    }

    /** how well a deal agrees with the way the others played (1 = fully) */
    private fun weightOf(hs: Array<MutableList<Card>>, s: Int, plays: List<AiPlay>): Double {
        var w = 1.0
        for (i in plays.indices) {
            val e = plays[i]; val x = e.seat
            val bc = e.bc
            if (x == s || e.len == 0 || bc == null) continue
            val hand = ArrayList<Card>(hs[x])
            for (k in i until plays.size) if (plays[k].seat == x) hand.add(plays[k].c)
            val pwin = e.bs != x && e.bs >= 0 && teamOf(e.bs) == teamOf(x)
            if (e.c.s == e.led) {
                val wins = !pwin && HokmRules.beats(e.c, bc, trump)
                if (hand.any { it.s == e.led && it.r < e.c.r && (if (wins) HokmRules.beats(it, bc, trump) else true) }) w *= 0.3
            } else if (e.c.s != trump && !pwin && hand.any { it.s == trump && HokmRules.beats(it, bc, trump) }) {
                w *= 0.2
            }
        }
        return w
    }

    // ------------------------------------------------------------------ the decision

    /**
     * the card for [seat]: [deck] = all the cards of this game, [seenIn] = the cards played so far in this round (the trick included),
     * [counts] = how many cards each seat holds, [voids] = suits a seat has shown it does not have, [plays] = the cards of this round in order
     */
    fun choose(seat: Int, myHand: List<Card>, trick: List<TC>, seenIn: BooleanArray, deck: List<Card>, counts: IntArray,
               voids: Array<BooleanArray>, tricksWon: IntArray, kt: Int, roundSize: Int, plays: List<AiPlay>): Card {
        val legal = HokmRules.legal(myHand, trick)
        if (legal.size == 1) return legal[0]
        sizeR = roundSize
        val inTrick = HashSet<Int>(); for (t in trick) inTrick.add(id(t.c))
        val inert = { x: Int, r: Int -> myHand.any { it.s == x && it.r == r } || (seenIn[x * 20 + r] && !inTrick.contains(x * 20 + r)) }
        val cand = legal.filter { c -> !legal.any { d -> d.s == c.s && d.r < c.r && (d.r + 1 until c.r).all { r -> inert(c.s, r) } } }
            .sortedBy { it.s * 20 + it.r }
        if (cand.size == 1) return cand[0]
        val unseen = deck.filter { c -> !seenIn[id(c)] && myHand.none { it.s == c.s && it.r == c.r } && trick.none { it.c.s == c.s && it.c.r == c.r } }
            .sortedBy { id(it) }
        val my = teamOf(seat)
        val seedParts = ArrayList<Int>()
        for (c in myHand.sortedBy { id(it) }) seedParts.add(id(c))
        seedParts.add(-1); for (t in trick) { seedParts.add(t.seat); seedParts.add(id(t.c)) }
        seedParts.add(-2); for (p in plays) seedParts.add(id(p.c)); seedParts.add(trump)
        rnd = Random(seedOf(seedParts))
        val cardsLeft = myHand.size
        val exact = cardsLeft <= Math.max(2, 12 / n)
        val samples = if (exact) 24 else Math.max(40, Math.min(200, 4200 / cand.size))
        val lastSeat = trick.size == n - 1
        val best0 = if (trick.isNotEmpty()) HokmRules.winnerOf(trick, trump) else null
        val partnerWins = best0 != null && best0.seat != seat && teamOf(best0.seat) == my
        val bias = { c: Card ->
            if (!lastSeat || best0 == null) 0.0 else {
                val cw = HokmRules.beats(c, best0.c, trump)
                var p = 0.0
                if (partnerWins && cw) p += 0.012
                if (partnerWins && c.s == trump && best0.c.s != trump) p += 0.012
                if (!partnerWins && !cw && c.s == trick[0].c.s && legal.any { HokmRules.beats(it, best0.c, trump) }) p += 0.012
                p
            }
        }
        val score = DoubleArray(cand.size)
        for (k in 0 until samples) {
            val dealt = deal(unseen, counts, seat, voids)
            val hands = Array(n) { i -> if (i == seat) ArrayList(myHand) as MutableList<Card> else dealt[i] }
            var lr = 1.0
            if (seat != hakem && trump >= 0 && hakem in 0 until n) lr = Math.sqrt(Engine4.HK_LR[Math.min(13, hands[hakem].count { it.s == trump })])
            val w = weightOf(hands, seat, plays) * lr
            for ((ci, c) in cand.withIndex()) {
                var v: Double? = null
                if (exact) v = exactValue(hands, seat, c, trick, tricksWon, kt, my, 3500)
                if (v == null) {
                    val hs2 = Array(n) { i -> ArrayList(hands[i]) as MutableList<Card> }
                    hs2[seat].remove(c)
                    val tr = ArrayList(trick); tr.add(TC(seat, c))
                    val sn = seenIn.copyOf(); sn[id(c)] = true
                    v = rollout(hs2, tr, (seat + 1) % n, sn, tricksWon, kt, my)
                }
                score[ci] += w * (v - 0.0008 * (c.r / 14.0 + (if (c.s == trump) 0.3 else 0.0)) - bias(c))
            }
        }
        var bi = 0
        for (i in cand.indices) if (score[i] > score[bi]) bi = i
        return cand[bi]
    }

    // ------------------------------------------------------------------ the trump

    /** a whole round played out from the start with the policy; [leader] leads the first trick */
    private fun playOut(hands: Array<MutableList<Card>>, leader: Int, my: Int, size: Int): Double {
        sizeR = size
        return rollout(Array(n) { ArrayList(hands[it]) as MutableList<Card> }, emptyList(), leader, BooleanArray(80), IntArray(6), -1, my)
    }

    /** the trump for the hakem [seat] who holds [first] of the cards: the same deals are played out with every suit as the trump */
    fun chooseTrump(seat: Int, first: List<Card>, deck: List<Card>, size: Int): Int {
        val unseen = deck.filter { c -> first.none { it.s == c.s && it.r == c.r } }.sortedBy { id(it) }
        val my = teamOf(seat)
        val parts = ArrayList<Int>(); for (c in first.sortedBy { id(it) }) parts.add(id(c)); parts.add(n); parts.add(kind)
        rnd = Random(seedOf(parts))
        val samples = 180
        val worlds = ArrayList<Array<MutableList<Card>>>()
        for (k in 0 until samples) {
            val sh = ArrayList(unseen); java.util.Collections.shuffle(sh, rnd)
            val hands = Array(n) { ArrayList<Card>() as MutableList<Card> }
            hands[seat].addAll(first)
            var p = 0
            for (x in 0 until size - first.size) hands[seat].add(sh[p++])
            for (o in 0 until n) if (o != seat) for (x in 0 until size) hands[o].add(sh[p++])
            worlds.add(hands)
        }
        var bestS = 0; var bestV = -1e9
        for (s in 0 until 4) {
            val ai = HokmAI(n, kind, s, hakem)
            var tot = 0.0
            for (w in worlds) tot += ai.playOut(w, seat, my, size)
            // a very small preference for the suit in which the hakem holds more cards (equal values must not be broken by the order of the suits)
            tot += 0.01 * first.count { it.s == s }
            if (tot > bestV) { bestV = tot; bestS = s }
        }
        return bestS
    }
}
