package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue

/**
 * Hokm for 3, 5 and 6 players (against robots; every player plays for himself, except in the six-player game
 * which is two teams of three or three teams of two).
 *  3 players: one 2 (the 2 of diamonds) is taken out, 17 cards each (5 + 4 + 4 + 4)
 *  5 players: two 2s are taken out, 10 cards each (5 + 5)
 *  6 players: all four 2s are taken out, 8 cards each (4 + 4)
 * The rules are those of the four-player Hokm: the hakem is the one who gets the first ace and chooses the trump
 * after his first cards; the first side to take 7 tricks wins the round (1 point); if the others have no trick
 * then it is a kot (2 points, 3 against the hakem), all the tricks is a bam (the game); when the hakem's side loses
 * the round the next player becomes hakem; the first side to 7 points wins the game.
 */
class HokmN(private val act: MainActivity, private val app: App) {
    companion object {
        /** kinds: 3 = three players, 5 = five players, 62 = six players in two teams of three, 63 = six players in three teams of two */
        fun players(kind: Int): Int = if (kind > 10) kind / 10 else kind
        fun teamsOf(kind: Int): Int = when (kind) { 62 -> 2; 63 -> 3; else -> players(kind) }
        fun title(kind: Int): String = when (kind) {
            3 -> "سه نفره"; 5 -> "پنج نفره"; 62 -> "شش نفره، دو تیم سه نفره"; else -> "شش نفره، سه تیم دو نفره"
        }
        /** the chips a person needs: the stake, shared by the people of his team */
        fun need(kind: Int, st: Int): Int = Math.max(1, st / (players(kind) / teamsOf(kind)))
        const val TARGET = 7

        fun guideDialog(dlg: Dialogs) {
            dlg.list("راهنمای حکم ۳، ۵ و ۶ نفره", TOPICS.map { t -> t.first to { dlg.message(t.first + "\n\n" + t.second) } }, "بستن")
        }

        val TOPICS = listOf(
            "حکم سه نفره" to "هر نفر برای خودش بازی می‌کند. پیش از بازی یک ۲ (دوی خشت) از دسته بیرون می‌رود تا ۵۱ برگ بماند. حاکم را اولین آس تعیین می‌کند. برگ‌ها یک سری ۵ تایی و سه سری ۴ تایی داده می‌شود تا هر نفر ۱۷ برگ داشته باشد. حاکم پس از دیدن ۵ برگ اولش حکم را انتخاب می‌کند.",
            "حکم پنج نفره" to "هر نفر برای خودش بازی می‌کند. دو تا از ۲ها بیرون می‌رود تا ۵۰ برگ بماند. برگ‌ها در دو سری ۵ تایی داده می‌شود و هر نفر ۱۰ برگ می‌گیرد. حاکم پس از دیدن ۵ برگ اولش حکم را انتخاب می‌کند. این حالت کمتر پیش می‌آید.",
            "حکم شش نفره" to "هر چهار ۲ بیرون می‌رود تا ۴۸ برگ بماند و به هر نفر ۸ برگ (دو سری ۴ تایی) برسد. دو حالت دارد: دو تیم سه نفره (هم‌تیمی‌ها یکی در میان می‌نشینند) یا سه تیم دو نفره (هم‌تیمی هر نفر روبه‌روی اوست). حاکم پس از دیدن ۴ برگ اولش حکم را انتخاب می‌کند.",
            "امتیاز و برد" to "درست مثل حکم چهار نفره. هر کس باید رنگ برگ اول را بازی کند و اگر نداشت می‌تواند حکم یا هر برگ دیگری بیندازد. بیشترین برگ حکم یا بالاترین برگ همان رنگ دست را می‌برد. نفر یا تیمی که زودتر به ۷ دست برسد، آن دور را می‌برد و یک امتیاز می‌گیرد. اگر در آن لحظه بقیه هیچ دستی نداشته باشند، کوت است (۲ امتیاز؛ اگر حاکم ببازد، حاکم‌کوت ۳ امتیاز). اگر کسی همهٔ دست‌ها را ببرد، بام یا پر بام است و بازی را می‌برد. اگر حاکم دور را ببازد، نفر بعدی حاکم می‌شود. اولین نفر یا تیمی که به ۷ امتیاز برسد بازی را می‌برد. در بازی‌های ۳، ۵ و ۶ نفره ممکن است کسی به ۷ دست نرسد؛ آن‌وقت بیشترین دست‌ها دور را می‌برد و اگر برابر شد، کسی که زودتر به آن تعداد دست رسیده است.",
            "ژتون" to "ژتون هر بازیکن را پیش از بازی تایپ می‌کنید. برنده از هر بازنده همین مقدار می‌گیرد؛ در بازی شش نفره مبلغ بین هم‌تیمی‌ها تقسیم می‌شود. ربات‌ها ژتون نامحدود دارند."
        )
    }

    private val NM = Names.IR_NAMES

    // ---- options and state ----
    private var kind = 3
    private var n = 3
    private var teams = 3
    private var stake = 1000
    private var names: List<String> = emptyList()
    private var pts = IntArray(6)                       // rounds won per team
    private var hakem = -1
    private var trump = -1
    private var hands: Array<MutableList<Card>> = Array(6) { ArrayList<Card>() }
    @Volatile private var trick: MutableList<TC> = ArrayList()
    private var tricksWon = IntArray(6)                 // tricks of this round per team
    private var seen = HashSet<Int>()                   // cards already played in this round
    private val void = Array(6) { BooleanArray(4) }     // void[seat][suit]: the seat did not follow that suit, so he has none
    private var turn = -1
    private var msg = ""
    private val logLines = ArrayList<String>()

    // ---- several phones: "solo" (robots only), "host" (runs the game) or "client" (shows the table and sends its moves)
    @JvmField var role = "solo"
    @JvmField var roomCode = ""
    @Volatile @JvmField var resuming = false           // a saved game was loaded and the host waits for the players to come back
    private var lastSave = ""
    private var syncSv = ""                            // the host's last save (guest side): used to take over if the host drops out
    private var succSeat = -1
    val isSucc: Boolean get() = role == "client" && syncSv.isNotEmpty() && me == succSeat
    private var me = 0                                 // my seat (the host and a solo player sit at 0)
    private val remote = BooleanArray(6)
    private val cidOf = IntArray(6) { -1 }
    private val idOf = Array(6) { "" }
    private val ansQ = Array(6) { LinkedBlockingQueue<String>() }
    @Volatile private var waitSeat = -1
    @Volatile private var waitTrump = false
    private var net: NetHn? = null
    private fun isRemote(s: Int) = role == "host" && remote[s]

    @Volatile private var alive = false
    @Volatile var started = false
    private var worker: Thread? = null
    private val moveQ = LinkedBlockingQueue<String>()
    @Volatile private var myTurn = false
    @Volatile private var choosingTrump = false
    @Volatile private var held = false                 // a player dropped out: the host's game waits until he presses "ادامه بازی" (as in Hokm)
    private var holdTxt = ""
    @Volatile private var winSeat = -1                 // the seat that took the trick which is still on the table (gold border)

    // ---- views ----
    private val ov = FrameLayout(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)
    private lateinit var gameV: LinearLayout
    private lateinit var topTr: TextView
    private lateinit var topHk: TextView
    private lateinit var topSc: TextView
    private lateinit var topTk: TextView
    private lateinit var msgTv: TextView
    private lateinit var tableBox: LinearLayout
    private lateinit var seatLayer: FrameLayout          // the players, around the round table
    private lateinit var mid: FrameLayout                // the cards of the trick, in the middle of the table
    private var roundW = 0
    private var roundH = 0
    private lateinit var handBox: LinearLayout
    private lateinit var ctl: LinearLayout
    private lateinit var logTv: TextView
    private val pBox = arrayOfNulls<LinearLayout>(6)
    private var screen = "setup"
    private var lastMsg = ""

    private fun teamOf(seat: Int): Int = when (kind) { 62 -> seat % 2; 63 -> seat % 3; else -> seat }
    private fun handSize(): Int = when (n) { 3 -> 17; 5 -> 10; else -> 8 }
    private fun teamName(t: Int): String = (0 until n).filter { teamOf(it) == t }.joinToString(" و ") { names[it] }

    // ------------------------------------------------------------------ shell

    fun show(start: String, ad: ((NetHn) -> Unit)? = null) {
        ov.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ov.setBackgroundColor(Px.bg)
        ov.isClickable = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        val sc = ScrollView(act)
        sc.isFillViewport = true
        sc.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.addView(sc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        app.menuShown(false)
        act.onBack = { back() }
        if (start == "resume") showSaves()
        else if (start == "blank") { }
        else if (start == "adopt") { val nt = NetHn(act, app, this); net = nt; ad?.invoke(nt) }
        else if (start == "net") { val nt = NetHn(act, app, this); net = nt; nt.show() }
        else startNew(start.toIntOrNull() ?: 3)
    }

    fun close(notify: Boolean = true) {
        if (notify && role == "host") sendAll(JSONObject().put("t", "end").put("m", "میزبان بازی را بست."))
        stopGame()
        net?.close(); net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
        app.menuShown(true)
        app.syncBg()
    }

    private fun back(): Boolean {
        if (screen == "net" && net?.back() == true) return true
        if (screen == "game") { gameMenu(); return true }
        net?.leave(); close()
        return true
    }

    private fun ui(f: () -> Unit) { act.runOnUiThread { try { f() } catch (e: Exception) { } } }

    private fun uiWait(f: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) { try { f() } catch (e: Exception) { }; return }
        val l = CountDownLatch(1)
        act.runOnUiThread { try { f() } catch (e: Exception) { }; l.countDown() }
        l.await()
    }

    // ---- the played card flies from the player's seat to the table (as in the other Hokm games)

    private fun loc(v: View): IntArray { val a = IntArray(2); v.getLocationInWindow(a); return a }

    private fun cellOf(seat: Int): View? {
        return if (seat == me) null else pBox[seat]
    }

    /** a copy of a picture flies from one view to another and shrinks (the trick goes to its winner) */
    private fun flyCopy(src: View, dst: View?, delay: Long) {
        val d = (src as? ImageView)?.drawable ?: return
        val o = loc(ov); val a = loc(src)
        val iv = ImageView(act)
        iv.setImageDrawable(d.constantState?.newDrawable() ?: d)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val w = src.width; val h = src.height
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        iv.x = (a[0] - o[0]).toFloat(); iv.y = (a[1] - o[1]).toFloat()
        val tx: Float; val ty: Float
        if (dst != null) { val t = loc(dst); tx = t[0] - o[0] + (dst.width - w) / 2f; ty = t[1] - o[1] + (dst.height - h) / 2f }
        else { tx = (ov.width - w) / 2f; ty = ov.height - h * 1.6f }       // my own seat: the bottom of the screen
        iv.animate().x(tx).y(ty).alpha(0f).scaleX(0.6f).scaleY(0.6f)
            .setStartDelay(Anim.ad(delay)).setDuration(Anim.ad(380L))
            .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** the cards on the table go to the player who took the trick */
    private fun collectTrick(seat: Int) {
        if (!::mid.isInitialized) return
        val dst = cellOf(seat)
        for (i in 0 until mid.childCount) {
            val slot = mid.getChildAt(i) as? FrameLayout ?: continue
            val v = slot.getChildAt(0) ?: continue
            flyCopy(v, dst, 60L * i)
            slot.visibility = View.INVISIBLE
        }
    }

    /** the dealt cards fly from the middle of the table to every player (as in Hokm) */
    private fun flyDeal() {
        if (!::mid.isInitialized || !::handBox.isInitialized) return
        val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back)) ?: return
        val o = loc(ov); val m = loc(mid)
        val w = Px.dp(30); val h = Px.dp(42)
        var k = 0
        for (round in 0 until 2) for (sd in 0 until n) {
            val dst: View = (if (sd == me) handBox else cellOf(sd)) ?: continue
            val iv = ImageView(act)
            iv.setImageBitmap(bmp)
            iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
            ov.addView(iv, lp)
            iv.x = m[0] - o[0] + mid.width / 2f - w / 2f; iv.y = m[1] - o[1] + mid.height / 2f - h / 2f
            val t = loc(dst)
            iv.animate().x(t[0] - o[0] + dst.width / 2f - w / 2f).y(t[1] - o[1] + dst.height / 2f - h / 2f).alpha(0.2f)
                .setStartDelay(Anim.ad(60L * k)).setDuration(Anim.ad(300L))
                .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
            k++
        }
    }

    private fun dealFx() { ui { flyDeal() }; if (role == "host") sendAll(JSONObject().put("t", "dealfx")) }

    private fun flyPlay(seat: Int, c: Card) {
        if (!::mid.isInitialized || !::handBox.isInitialized) return
        val o = loc(ov); val t = loc(mid)
        val w = Px.dp(46); val h = Px.dp(64)
        val bmp = Assets.bitmap(act, Assets.cardPath(c)) ?: return
        val iv = ImageView(act)
        iv.setImageBitmap(bmp)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        val src = cellOf(seat)
        val sx: Float; val sy: Float
        if (src != null) { val a = loc(src); sx = a[0] - o[0] + (src.width - w) / 2f; sy = a[1] - o[1] + (src.height - h) / 2f }
        else { val a = loc(handBox); sx = a[0] - o[0] + handBox.width / 2f - w / 2f; sy = (a[1] - o[1]).toFloat() }
        iv.x = sx; iv.y = sy
        // as in the two-player Hokm: the card starts small and faint, a little turned, and grows into its place;
        // the card sound is started early (CSO) so that its peak falls at the moment the card lands
        val rot0 = Math.round((Math.random() - 0.5) * 22).toFloat()
        iv.scaleX = 0.55f; iv.scaleY = 0.55f; iv.alpha = 0.35f; iv.rotation = rot0
        iv.animate().x(t[0] - o[0] + mid.width / 2f - w / 2f).y(t[1] - o[1] + mid.height / 2f - h / 2f)
            .scaleX(1f).scaleY(1f).alpha(1f).rotation(0f)
            .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0.8f, 0.2f, 1f))
            .setDuration(Anim.ad(360L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
        Sched.later(Math.max(0, Anim.ad(360L).toInt() - Sound.CSO)) { Sound.cardSnd() }
    }

    fun tv(t: String, size: Float = 15f, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun setScreen(name: String, v: View) { screen = name; content.removeAllViews(); content.addView(v) }

    fun heading(t: String): TextView {
        val h = tv(t, 26f, Px.tx, true)
        h.gravity = Gravity.CENTER
        h.setPadding(0, Px.dp(12), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) h.isAccessibilityHeading = true
        return h
    }

    fun mbtn(t: String, f: () -> Unit): View {
        val b = app.dlg.btn(t, true, f)
        val l = LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    // ------------------------------------------------------------------ start, chips and saved games

    /** chips: false (and a message) when the person cannot take part with this stake */
    private fun checkStake(k: Int, st: Int): Boolean {
        if (Prefs.wallet < Bist21.MIN_PLAY) { app.dlg.message(Bist21.BROKE); return false }
        if (st < 1) { app.dlg.message("ژتون هر بازیکن را به‌صورت عدد و دست‌کم ۱ تایپ کنید."); return false }
        val nd = need(k, st)
        if (Prefs.wallet < nd) {
            app.dlg.message("ژتون شما برای این مبلغ کافی نیست (ژتون شما: " + Cards.fa(Prefs.wallet) + "؛ دست‌کم " + Cards.fa(nd) + " لازم است). مبلغ کمتری انتخاب کنید.")
            return false
        }
        return true
    }

    private fun startNew(k: Int) {
        role = "solo"; me = 0; for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
        kind = k; n = players(k); teams = teamsOf(k); stake = app.hokmStake
        if (!checkStake(k, stake)) { close(); return }
        val rob = NM.shuffled().filter { it != Prefs.name }.take(n - 1)
        names = listOf(if (Prefs.name.isEmpty()) "شما" else Prefs.name) + rob
        pts = IntArray(6); hakem = -1
        startGame()
    }

    private fun saveJson(): JSONObject {
        val nm = JSONArray(); for (x in names) nm.put(x)
        val sc = JSONArray(); for (x in pts) sc.put(x)
        val ids = JSONArray(); for (i in 0 until n) ids.put(if (role == "host" && i == me) Prefs.devId() else idOf[i])
        return JSONObject().put("kind", kind).put("stake", stake).put("names", nm).put("pts", sc).put("hakem", hakem).put("ids", ids)
    }

    private fun saveAuto() {
        try {
            lastSave = saveJson().toString()
            if (role == "solo") SavesHn.put("auto", false, lastSave)
            else if (role == "host") { SavesHn.put("autoM", true, lastSave); sendSync() }
        } catch (e: Exception) { }
    }

    private fun manualSave() {
        if (!started) return
        SavesHn.put("m" + System.currentTimeMillis(), role == "host", saveJson().toString())
        app.dlg.message("بازی ذخیره شد.")
    }

    private fun showSaves() {
        val l = SavesHn.all(false)
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("بازی‌های قبلی"))
        if (l.isEmpty()) v.addView(tv("بازی ذخیره‌شده‌ای نیست.", 15f))
        for (e in l) v.addView(mbtn(SavesHn.describe(e)) {
            app.dlg.list(SavesHn.describe(e), listOf(
                "ادامه بازی" to { resumeFrom(e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { SavesHn.del(e.id); showSaves() }) }
            ), "بستن")
        })
        v.addView(mbtn("بازگشت") { close() })
        setScreen("saves", v)
    }

    /** closes this screen but keeps the links: the lobby has changed to another game (the other game takes the phones over) */
    fun detach() {
        stopGame()
        net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
    }

    /** the host page of the main menu uses this game: its settings and players are shown there; this game's own screen opens when the game starts */
    fun hostInPage(room: String, name: String, ps: List<HandPeer>, box: LinearLayout, plist: LinearLayout, infoTv: TextView, k: Int) {
        val nt = NetHn(act, app, this); net = nt
        nt.adoptHostInPage(room, name, ps, box, plist, infoTv, k)
    }
    fun hostStartFromPage() { net?.startFromPage() }
    fun hostState(): Triple<String, String, List<HandPeer>>? = net?.handoff()
    fun ensureHostShown() { show("blank") }

    /** a saved game chosen in the common list of saved games (against the robots) */
    fun resumeExternal(e: SavesHn.E) { show("blank"); resumeFrom(e) }
    fun resumeMultiExternal(e: SavesHn.E) { show("net"); net?.resumeSaved(e) }

    private fun resumeFrom(e: SavesHn.E) {
        try {
            val j = JSONObject(e.data)
            kind = j.getInt("kind"); n = players(kind); teams = teamsOf(kind); stake = j.optInt("stake", 1000)
            if (!checkStake(kind, stake)) return
            role = "solo"; me = 0; for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
            val nm = j.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
            if (Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            val sc = j.getJSONArray("pts"); pts = IntArray(6) { if (it < sc.length()) sc.getInt(it) else 0 }
            hakem = j.optInt("hakem", -1)
            startGame()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده خراب است.") }
    }

    // ------------------------------------------------------------------ speaking, pacing, sounds

    private fun ann(t: String) {
        val d = Spk.slot(t, 0L)
        Sched.laterRaw(d) { speak(t) }
    }

    private fun speak(t: String) {
        if (!Prefs.a11y) return
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logTv.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    private fun idle(): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now())
    private fun say(m: String) { ui { logLines.add(m); ann(m); render() }; if (role == "host") sendAll(JSONObject().put("t", "say").put("m", m)) }
    private fun localSay(m: String) { ui { logLines.add(m); ann(m); render() } }
    private fun draw() { ui { render() }; if (role == "host") sendStates() }
    private fun bannerAll(t: String) { ui { banner(t) }; if (role == "host") sendAll(JSONObject().put("t", "ban").put("m", t)) }
    private fun soundWait(): Long = Math.max(0L, Math.min(4000L, Sound.sq() - Sched.now()))
    private fun pace(ms: Long) {
        Thread.sleep(Math.max(Math.max(Anim.ad(ms), idle()), soundWait()))
        while (held && alive) Thread.sleep(300)      // paused: waiting for the host to press "ادامه بازی"
    }

    private fun startHold(t: String) {
        if (role != "host") return
        held = true
        holdTxt = t + " بازی متوقف است. برای ادامه، دکمه‌ی «ادامه بازی» را بزنید."
        ui { ann(holdTxt) }
        sendAll(JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
        draw()
    }

    private fun resumeHold() {
        if (!held) return
        held = false; holdTxt = ""
        sendAll(JSONObject().put("t", "hold").put("on", false))
        say("بازی ادامه پیدا کرد.")
    }
    private fun sndSeat(seat: Int, name: String) {
        if (seat == me) Sched.post { Sound.game(name) }
        else if (isRemote(seat)) net?.send(cidOf[seat], JSONObject().put("t", "snd").put("n", name))
    }
    private fun snd(name: String) { Sched.post { Sound.game(name) }; if (role == "host") sendAll(JSONObject().put("t", "snd").put("n", name)) }

    private fun banner(text: String) {
        val e = TextView(act)
        e.text = text; e.textSize = 26f; e.setTextColor(0xFFFFE36B.toInt()); e.setTypeface(e.typeface, Typeface.BOLD)
        e.gravity = Gravity.CENTER
        e.setPadding(Px.dp(22), Px.dp(14), Px.dp(22), Px.dp(14))
        e.background = Px.rounded(0xCC000000.toInt(), 16, 2, Px.GOLD)
        e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        e.alpha = 0f; e.scaleX = 0.5f; e.scaleY = 0.5f
        ov.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        e.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(Anim.ad(250L)).withEndAction {
            e.animate().alpha(0f).setStartDelay(Anim.ad(1300L)).setDuration(Anim.ad(350L)).withEndAction { try { ov.removeView(e) } catch (x: Exception) { } }.start()
        }.start()
    }

    // ------------------------------------------------------------------ the game screen

    private fun startGame() {
        stopGame()
        held = false; holdTxt = ""
        logLines.clear(); lastMsg = ""
        for (i in 0 until 6) hands[i] = ArrayList()
        Spk.reset()
        buildGameView()
        started = true; alive = true
        val t = Thread { try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { } }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun stopGame() { alive = false; myTurn = false; choosingTrump = false; worker?.interrupt(); worker = null; moveQ.clear() }

    private fun kv(label: String, value: String, valueColor: Int? = null): CharSequence {
        val sb = android.text.SpannableStringBuilder(label)
        val st = sb.length
        sb.append(value)
        sb.setSpan(android.text.style.StyleSpan(Typeface.BOLD), st, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (valueColor != null) sb.setSpan(android.text.style.ForegroundColorSpan(valueColor), st, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun applyBg() {
        val bmp = if (Prefs.bg > 0) Assets.bitmap(act, Assets.bgPath(Prefs.bg)) else null
        tableBox.background = if (bmp != null) CoverDrawable(bmp, 0x1F000000) else Px.rounded(Px.FELT, 16)
        tableBox.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, Px.dp(16).toFloat()) }
        }
        tableBox.clipToOutline = true
    }

    private fun buildGameView() {
        gameV = LinearLayout(act); gameV.orientation = LinearLayout.VERTICAL
        val more = LinearLayout(act); more.orientation = LinearLayout.HORIZONTAL
        more.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val mb = TextView(act)
        mb.text = "⋮"; mb.textSize = 26f; mb.setTextColor(Color.WHITE); mb.gravity = Gravity.CENTER
        mb.background = Px.rounded(0x59000000, 20)
        mb.contentDescription = "گزینه‌های بیشتر"
        mb.isClickable = true; mb.isFocusable = true
        mb.setOnClickListener { gameMenu() }
        more.addView(mb, LinearLayout.LayoutParams(Px.dp(40), Px.dp(40)))
        gameV.addView(more)
        // the line of numbers at the top, as in Hokm
        val top = FlowLayout(act, Px.dp(10), Px.dp(2))
        topTr = tv("", 14f); topHk = tv("", 14f); topSc = tv("", 14f); topTk = tv("", 14f)
        for (t in listOf(topTr, topHk, topSc, topTk)) top.addView(t)
        gameV.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin = Px.dp(6) })
        // the table: the other players around, the played cards in the middle, my box at the bottom
        tableBox = LinearLayout(act); tableBox.orientation = LinearLayout.VERTICAL
        tableBox.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        // a round table: the players sit around it, the cards of the trick lie in the middle
        roundW = Math.min(act.resources.displayMetrics.widthPixels - Px.dp(32), Px.dp(400))
        roundH = Px.dp(320)
        val roundBox = FrameLayout(act)
        roundBox.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val felt = View(act)
        felt.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(0x33000000); it.setStroke(Px.dp(2), 0x55FFE36B) }
        felt.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        roundBox.addView(felt, FrameLayout.LayoutParams((roundW * 0.74).toInt(), (roundH * 0.64).toInt(), Gravity.CENTER))
        seatLayer = FrameLayout(act)
        roundBox.addView(seatLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        mid = FrameLayout(act)
        mid.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        roundBox.addView(mid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tableBox.addView(roundBox, LinearLayout.LayoutParams(roundW, roundH).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        for (i in 0 until 6) {
            val b = LinearLayout(act); b.orientation = LinearLayout.VERTICAL; b.gravity = Gravity.CENTER
            b.layoutDirection = View.LAYOUT_DIRECTION_RTL
            pBox[i] = b
        }
        gameV.addView(tableBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        applyBg()
        val msgBox = LinearLayout(act); msgBox.orientation = LinearLayout.VERTICAL; msgBox.gravity = Gravity.CENTER_HORIZONTAL
        msgBox.minimumHeight = Px.dp(44)
        msgTv = tv("", 14f); msgTv.gravity = Gravity.CENTER
        msgBox.addView(msgTv)
        gameV.addView(msgBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8); it.bottomMargin = Px.dp(8) })
        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL; ctl.gravity = Gravity.CENTER_HORIZONTAL
        gameV.addView(ctl)
        logTv = tv("", 13f, 0xFFE8DCC4.toInt())
        gameV.addView(logTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(6) })
        handBox = LinearLayout(act); handBox.orientation = LinearLayout.VERTICAL; handBox.gravity = Gravity.CENTER_HORIZONTAL
        gameV.addView(handBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        setScreen("game", gameV)
    }

    /** where the card of the player at relative position [rel] (0 = me) lies in the middle of the table */
    private fun midGravity(rel: Int): Int {
        if (rel == 0) return Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        val others = n - 1
        // the others from my left to my right: the first on the left edge, the last on the right edge, the rest on top
        return when {
            others == 1 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            rel == 1 -> Gravity.LEFT or Gravity.CENTER_VERTICAL
            rel == others -> Gravity.RIGHT or Gravity.CENTER_VERTICAL
            else -> Gravity.TOP or (if (others == 3 || rel == (others + 1) / 2) Gravity.CENTER_HORIZONTAL else if (rel < (others + 1) / 2) Gravity.LEFT else Gravity.RIGHT)
        }
    }

    private fun render() {
        if (screen != "game" || !::topTr.isInitialized) return
        val red = trump == 1 || trump == 2
        topTr.text = kv("حکم: ", if (trump < 0) "—" else Cards.SU[trump] + " " + Cards.SN[trump], if (red) 0xFFEE3344.toInt() else null)
        topHk.text = kv("حاکم: ", if (hakem in 0 until n) names[hakem] else "—")
        topSc.text = android.text.SpannableStringBuilder("امتیاز: ").also { sb ->
            for (t in 0 until teams) { if (t > 0) sb.append(" | "); sb.append(teamName(t) + " "); sb.append(kv("", Cards.fa(pts[t]))) }
            sb.append("  — ژتون شما " + Cards.fa(Prefs.wallet))
        }
        topTk.text = android.text.SpannableStringBuilder("این دست: ").also { sb ->
            for (t in 0 until teams) { if (t > 0) sb.append(" - "); sb.append(kv("", Cards.fa(tricksWon[t]))) }
        }
        msgTv.text = msg
        if (msg.isNotEmpty() && msg != lastMsg) { lastMsg = msg; ann(msg) }
        val rug = Prefs.bg > 0
        val dt = ArrayList(trick)
        // the players sit around the round table: I am at the bottom, the others follow clockwise (my left first)
        seatLayer.removeAllViews()
        for (rel in 0 until n) {
            val i = (me + rel) % n
            val p = pBox[i]!!
            p.removeAllViews()
            val act_ = turn == i
            val pc = dt.firstOrNull { it.seat == i }
            val nt = TextView(act)
            val mate = if (teams < n && i != me && teamOf(i) == teamOf(me)) " (یار)" else ""
            nt.text = (if (i == me) names[i] else names[i] + mate) + (if (i == hakem) " 👑" else "")
            nt.textSize = 11f
            nt.setTextColor(if (act_) 0xFFFFE36B.toInt() else Color.WHITE)
            if (act_) nt.setTypeface(nt.typeface, Typeface.BOLD)
            nt.setPadding(Px.dp(6), Px.dp(2), Px.dp(6), Px.dp(2))
            nt.background = Px.rounded(if (rug) 0x99000000.toInt() else 0x33000000, 8)
            if (Prefs.a11y && pc != null) nt.contentDescription = nt.text.toString() + ": " + Cards.cname(pc.c)
            p.addView(Av.view(act, if (i == me) Av.me() else names[i], if (n > 4) 34 else 44, act_ || (choosingTrump && hakem == i), act_))
            p.addView(nt)
            if (i != me) p.addView(app.fanView(hands[i].size, true))
            p.contentDescription = if (i == me) "" else names[i] + mate + (if (i == hakem) "، حاکم" else "") + "، " + Cards.fa(hands[i].size) + " برگ در دست"
            (p.parent as? ViewGroup)?.removeView(p)
            p.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            val th = Math.PI / 2 + 2 * Math.PI * rel / n          // 0 = bottom, then clockwise (left, top, right)
            val rx = roundW / 2.0 - p.measuredWidth / 2.0 - Px.dp(2)
            val ry = roundH / 2.0 - p.measuredHeight / 2.0 - Px.dp(2)
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.LEFT)
            lp.leftMargin = Math.max(0, (roundW / 2.0 + rx * Math.cos(th) - p.measuredWidth / 2.0).toInt())
            lp.topMargin = Math.max(0, (roundH / 2.0 + ry * Math.sin(th) - p.measuredHeight / 2.0).toInt())
            seatLayer.addView(p, lp)
        }
        // the cards played in this trick lie towards the player who played them
        mid.removeAllViews()
        for (t in dt) {
            val slot = FrameLayout(act)
            if (winSeat == t.seat && dt.size >= n) slot.background = Px.rounded(Color.TRANSPARENT, 6, 3, Px.GOLD)
            val rel = (t.seat - me + n) % n
            val cw = Px.dp(if (n > 4) 40 else 46)
            slot.addView(app.cardImage(t.c, cw))
            val th = Math.PI / 2 + 2 * Math.PI * rel / n
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.LEFT)
            lp.leftMargin = (roundW / 2.0 + roundW * 0.22 * Math.cos(th) - cw / 2.0).toInt()
            lp.topMargin = (roundH / 2.0 + roundH * 0.18 * Math.sin(th) - cw * 0.7).toInt()
            mid.addView(slot, lp)
        }
        // my hand
        handBox.removeAllViews()
        val led = if (trick.isEmpty()) -1 else trick[0].c.s
        val myHand = Cards.sorted2(hands[me])
        val hasLed = led >= 0 && myHand.any { it.s == led }
        val w = FlowLayout(act, Px.dp(4), Px.dp(4))
        for (c in myHand) {
            val legal = myTurn && (!hasLed || c.s == led)
            val b = FrameLayout(act)
            b.addView(app.cardImage(c, Px.dp(if (hands[me].size > 10) 42 else 50)))
            b.contentDescription = Cards.cname(c) + (if (c.s == trump) "، حکم" else "") + (if (!myTurn || legal) "" else "، قابل بازی نیست")
            b.isFocusable = true
            if (legal) { b.isClickable = true; b.background = Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD); b.setOnClickListener { playCard(c) } }
            else if (myTurn) b.alpha = 0.45f
            w.addView(b)
        }
        handBox.addView(w)
        // the pause bar (host: with the button), then the trump choice
        ctl.removeAllViews()
        if (held && holdTxt.isNotEmpty()) {
            ctl.addView(tv(holdTxt, 14f, 0xFFFFE36B.toInt()))
            if (role == "host") ctl.addView(app.dlg.btn("ادامه بازی", true) { resumeHold() })
        }
        if (choosingTrump) {
            ctl.addView(tv("حکم را انتخاب کنید:", 14f, Color.WHITE))
            for (sd in 0 until 4) ctl.addView(app.dlg.btn(Cards.SU[sd] + " " + Cards.SN[sd], true) { if (choosingTrump) { if (role == "client") { choosingTrump = false; net?.toHost(JSONObject().put("t", "ans").put("m", "t" + sd)) } else moveQ.offer("t" + sd) } })
        }
        logTv.text = if (Prefs.a11y) logLines.takeLast(6).joinToString("\n") else ""
    }

    private fun playCard(c: Card) {
        if (!myTurn) return
        if (held && role == "host") { ann("بازی متوقف است؛ ابتدا «ادامه بازی» را بزنید."); return }
        val i = hands[me].indexOf(c)
        if (i < 0) return
        myTurn = false
        if (role == "client") net?.toHost(JSONObject().put("t", "ans").put("m", "c" + i)) else moveQ.offer("c" + i)
        render()
    }

    // ------------------------------------------------------------------ menu inside the game

    private fun gameMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("بازگشت به بازی" to { })
        if (role != "client") items.add("بازی جدید" to { app.dlg.confirm("بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.", { newGame() }) })
        items.add("تغییر نام" to { renameAsk() })
        if (role == "host") {
            if ((1 until n).any { !remote[it] }) items.add("افزودن بازیکن" to { addAsk() })
            if ((1 until n).any { remote[it] }) {
                items.add("حذف بازیکن" to { kickAsk() })
                items.add("انتقال میزبانی" to { xferAsk() })
            }
        }
        if (role != "client") items.add("ذخیرهٔ بازی" to { manualSave() })
        items.add(("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) to { app.a11yToggle() })
        items.add("سرعت انیمیشن" to { app.animSpeedAsk() })
        items.add("تنظیمات صدا" to { app.dlg.sound() })
        items.add("تنظیمات تصویر زمینه" to { app.dlg.cards("bg") { } })
        items.add("تنظیمات پشت کارت" to { app.dlg.cards("back") { render() } })
        items.add("راهنما" to { guideDialog(app.dlg) })
        items.add("خروج از بازی" to {
            if (role == "host") exitHostAsk()
            else app.dlg.confirm((if (role == "solo") "از بازی خارج می‌شوید؟ بازی تا پایان دور قبل ذخیره شده است." else "از بازی خارج می‌شوید؟"), { net?.leave(); close() })
        })
        app.dlg.list("گزینه‌های بیشتر", items, "بستن")
    }

    private fun newGame() {
        stopGame()
        try { SavesHn.del("auto") } catch (e: Exception) { }
        if (role == "host") {      // the same table starts from zero
            pts = IntArray(6); hakem = -1
            lastSave = saveJson().toString()
            startGame()
            sendSync()
            return
        }
        val k = kind
        close()
        app.openHn(k.toString())
    }

    private fun renameAsk() {
        app.dlg.nameAsk(true) { v ->
            val nm = v.trim()
            if (nm.isNotEmpty()) { Prefs.name = nm; val l = names.toMutableList(); l[me] = nm; names = l; draw() }
        }
    }

    // ------------------------------------------------------------------ the game (worker thread)

    private fun outSuits(): List<Int> = when (n) { 3 -> listOf(2); 5 -> listOf(2, 3); else -> listOf(0, 1, 2, 3) }

    /** the 2s taken out of the pack appear in the middle of the table, are shown one after the other and put aside (as in the two-player Hokm) */
    private fun flyAside(out: List<Card>): Long {
        if (!::mid.isInitialized || mid.width == 0) { Sound.cardSnd(); return Anim.ad(600L) }
        val o = loc(ov); val m = loc(mid)
        val w = Px.dp(52); val h = Px.dp(76)
        val cx = m[0] - o[0] + mid.width / 2f; val cy = m[1] - o[1] + mid.height / 2f
        val px = m[0] - o[0] + Px.dp(30).toFloat(); val py = m[1] - o[1] + Px.dp(40).toFloat()
        val gap = Px.dp(58)
        val ap = Anim.ad(260L); val ho = Anim.ad(550L); val fl = Anim.ad(650L)
        var tot = 0L
        out.forEachIndexed { i, cd ->
            val bmp = Assets.bitmap(act, Assets.cardPath(cd)) ?: return@forEachIndexed
            val d = Anim.ad(420L) * i
            tot = Math.max(tot, d + ap + ho + fl + Anim.ad(160L))
            val iv = ImageView(act)
            iv.setImageBitmap(bmp)
            iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
            ov.addView(iv, lp)
            iv.x = cx + (i - (out.size - 1) / 2f) * gap - w / 2f; iv.y = cy - h / 2f
            iv.alpha = 0f; iv.scaleX = 0.5f; iv.scaleY = 0.5f
            val rot = (if (i % 2 == 1) 1f else -1f) * 12f
            Sched.later(Math.max(0L, d + ap + ho + fl - Sound.CSO)) { Sound.cardSnd() }
            iv.animate().setStartDelay(d).alpha(1f).scaleX(1.1f).scaleY(1.1f).setDuration(ap).withEndAction {
                iv.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(Anim.ad(120L)).withEndAction {
                    iv.animate().setStartDelay(ho).x(px - w / 2f).y(py - h / 2f).scaleX(0.4f).scaleY(0.4f).rotation(rot)
                        .setInterpolator(android.view.animation.PathInterpolator(0.42f, 0f, 0.58f, 1f)).setDuration(fl).withEndAction {
                            iv.animate().setStartDelay(0).alpha(0f).setDuration(Anim.ad(160L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
                        }.start()
                }.start()
            }.start()
        }
        return tot
    }

    private fun asideStart() {
        val out = outSuits().map { Card(it, 2) }
        val ids = JSONArray(); out.forEach { ids.put(Cards.idc(it)) }
        val nm = out.size
        say((if (nm == 1) "یک کارت دو" else Cards.fa(nm) + " کارت دو") + " کنار گذاشته شد.")
        if (role == "host") sendAll(JSONObject().put("t", "aside").put("c", ids))
        var tot = 0L
        uiWait { tot = flyAside(out) }
        pace(tot + Anim.ad(100L))
    }

    private fun loop() {
        if (hakem < 0 && (0 until 6).all { pts[it] == 0 }) { asideStart(); if (!alive) return }
        while (alive) {
            playRound()
            if (!alive) return
            val best = (0 until teams).maxByOrNull { pts[it] } ?: 0
            if (pts[best] >= TARGET) { finish(best); return }
            saveAuto()
        }
    }

    /** the deck of this game: the 2s that are not played are taken out (diamonds first, then clubs, hearts, spades) */
    private fun deckCards(): MutableList<Card> {
        val out = when (n) { 3 -> listOf(2); 5 -> listOf(2, 3); else -> listOf(0, 1, 2, 3) }
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 2..14) if (!(r == 2 && out.contains(s))) d.add(Card(s, r))
        return d
    }
    private fun buildDeck(): MutableList<Card> = Cards.shuf(deckCards())

    private fun playRound() {
        msg = ""; trump = -1; trick = ArrayList(); seen = HashSet()
        for (v in void) java.util.Arrays.fill(v, false)
        java.util.Arrays.fill(tricksWon, 0)
        for (i in 0 until 6) hands[i] = ArrayList()
        turn = -1
        val deck = buildDeck()
        snd("shuffle"); say("دسته بُر خورد."); draw(); pace(1000)
        if (hakem < 0) findHakem()
        if (!alive) return
        // the first series, then the hakem chooses the trump
        val first = if (n == 6) 4 else 5
        val size = handSize()
        val series = if (n == 5) 5 else 4
        var di = 0
        for (k in 0 until n) { val s = (hakem + k) % n; for (x in 0 until first) hands[s].add(deck[di++]) }
        snd("deal4a"); dealFx(); msg = names[hakem] + " حاکم است"; say(names[hakem] + " حاکم است و برگ‌های اول را دیده است."); draw(); pace(900)
        chooseTrump()
        if (!alive) return
        while (hands[hakem].size < size) {
            for (k in 0 until n) { val s = (hakem + k) % n; val give = Math.min(series, size - hands[s].size); for (x in 0 until give) hands[s].add(deck[di++]) }
        }
        snd("deal4b"); dealFx(); say("بقیهٔ برگ‌ها پخش شد."); draw(); pace(900)
        // the tricks: exactly as in the four-player Hokm. The first side to reach 7 tricks wins the round; if the others have
        // no trick at that moment it is a kot (the round goes on: it ends when another side takes a trick, or as a bam when
        // the side takes all the tricks).
        var leader = hakem
        var lastWinnerTeam = -1
        var kt = -1
        var winSide = -1
        val reachedAt = IntArray(6)          // the trick at which a side got its present number of tricks
        for (t in 0 until size) {
            if (!alive) return
            val w = playTrick(leader)
            lastWinnerTeam = teamOf(w)
            tricksWon[lastWinnerTeam]++
            reachedAt[lastWinnerTeam] = t
            leader = w
            val hs = (0 until teams).firstOrNull { tricksWon[it] >= 7 } ?: -1
            if (hs >= 0) {
                val othersZero = (0 until teams).all { it == hs || tricksWon[it] == 0 }
                if (othersZero && kt < 0) kt = hs
                if (!othersZero || tricksWon[hs] == size) { winSide = hs; break }
            }
        }
        if (winSide < 0) {      // nobody reached 7 (possible with 3, 5 and 6 players): the side with most tricks; in a tie the one who reached that number first
            val mx = tricksWon.take(teams).maxOrNull() ?: 0
            val tied = (0 until teams).filter { tricksWon[it] == mx }
            winSide = tied.minByOrNull { reachedAt[it] } ?: tied[0]
        }
        val t = winSide
        val hk = teamOf(hakem)
        val bam = tricksWon[t] == size
        val kot = bam || kt == t
        val gain = if (kot) (if (t == hk) 2 else 3) else 1
        pts[t] += gain
        if (bam) pts[t] = Math.max(pts[t], TARGET)
        val gm = pts[t] >= TARGET
        val meWon = t == teamOf(me)
        val bn = if (t == hk) "بام" else "پر بام"
        val m = if (bam) (teamName(t) + " " + bn + " کرد و بازی را برد!")
            else if (gm) (teamName(t) + " بازی را برد!")
            else (teamName(t) + " این دست را برد" + (if (kot) (if (t == hk) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)") else " (۱ امتیاز)") + ".")
        say(m)
        if (!gm) for (sd in 0 until n) if (sd == me || isRemote(sd)) { val w = teamOf(sd) == t; sndSeat(sd, if (kot) (if (w) "kwin" else "klose") else (if (w) "win" else "lose")) }
        bannerAll(if (bam) bn + "!" else if (kot) (if (t == hk) "کوت!" else "حاکم‌کوت!") else teamName(t) + " دور را برد")
        draw(); pace(if (gm) 800 else 1800)
        if (t != hk) hakem = (hakem + 1) % n
    }

    /** cards are dealt face up one by one: the first ace makes its owner the hakem */
    private fun findHakem() {
        val d = buildDeck()
        for ((i, c) in d.withIndex()) {
            if (!alive) return
            val s = i % n
            msg = names[s] + ": " + Cards.cname(c)
            if (role == "host") sendAll(JSONObject().put("t", "mv").put("seat", s).put("c", Cards.idc(c)))
            uiWait { flyPlay(s, c) }
            Thread.sleep(Anim.ad(360L))
            trick = arrayListOf(TC(s, c))                 // the dealt card lies near the player (as in the draw of Hokm)
            ui { logLines.add(msg); ann(msg); render() }
            if (role == "host") sendStates()
            pace(450)
            if (c.r == 14) { hakem = s; winSeat = s; say(names[s] + " آس آورد و حاکم شد."); draw(); pace(900); winSeat = -1; trick = ArrayList(); draw(); return }
        }
        hakem = 0
    }

    private fun robotTrump(h: List<Card>): Int {
        var best = 0; var bs = -1.0
        for (sd in 0 until 4) {
            val cs = h.filter { it.s == sd }
            val sc = cs.sumOf { when (it.r) { 14 -> 5.0; 13 -> 4.0; 12 -> 3.0; 11 -> 2.0; 10 -> 1.5; else -> 0.5 } } + 2.5 * cs.size + (if (cs.size >= 4) 2.0 else 0.0)
            if (sc > bs) { bs = sc; best = sd }
        }
        return best
    }

    private fun chooseTrump() {
        var picked = -1
        if (hakem == me) {
            choosingTrump = true; msg = "شما حاکم هستید؛ حکم را انتخاب کنید."; draw()
            while (picked < 0 && alive) { val a = moveQ.take(); while (held && alive) Thread.sleep(300); if (a.startsWith("t")) picked = a.substring(1).toIntOrNull() ?: -1 }
            choosingTrump = false
        } else if (isRemote(hakem)) {      // the hakem is a person on another phone
            msg = names[hakem] + " حکم را انتخاب می‌کند"
            ansQ[hakem].clear(); waitSeat = hakem; waitTrump = true; draw()
            while (picked < 0 && alive) {
                val a = ansQ[hakem].take()
                if (a != "drop") while (held && alive) Thread.sleep(300)
                if (a == "drop") break
                if (a.startsWith("t")) { val v = a.substring(1).toIntOrNull() ?: -1; if (v in 0..3) picked = v }
            }
            waitSeat = -1; waitTrump = false
        }
        if (picked !in 0..3) {
            // the trump is chosen by playing whole rounds out with every suit as the trump
            picked = try { HokmSim(n, kind, 0, hakem).chooseTrump(hakem, ArrayList(hands[hakem]), deckCards(), handSize()) } catch (e: Exception) { robotTrump(hands[hakem]) }
            pace(700)
        }
        trump = picked
        val m = names[hakem] + " حکم را " + Cards.SN[trump] + " گذاشت."
        say(m); bannerAll("حکم: " + Cards.SU[trump] + " " + Cards.SN[trump])
        draw(); pace(900)
    }

    private fun beats(a: Card, b: Card): Boolean =
        if (a.s == b.s) a.r > b.r else (a.s == trump && b.s != trump)

    private fun winnerOf(t: List<TC>): TC {
        var w = t[0]
        for (p in t) if (beats(p.c, w.c)) w = p
        return w
    }

    private fun playTrick(leader: Int): Int {
        trick = ArrayList()
        for (k in 0 until n) {
            if (!alive) return leader
            val seat = (leader + k) % n
            turn = seat
            var c: Card? = null
            if (isRemote(seat)) {
                msg = "نوبت " + names[seat]
                while (c == null && alive) {
                    ansQ[seat].clear(); waitSeat = seat; draw()
                    val a = ansQ[seat].take()
                    if (a != "drop") while (held && alive) Thread.sleep(300)
                    if (a == "drop") break
                    if (a.startsWith("c")) {
                        val i = a.substring(1).toIntOrNull() ?: -1
                        if (i in hands[seat].indices) {
                            val pk = hands[seat][i]
                            val led = if (trick.isEmpty()) -1 else trick[0].c.s
                            if (!(led >= 0 && pk.s != led && hands[seat].any { it.s == led })) c = pk
                        }
                    }
                }
                waitSeat = -1
                if (c == null) { draw(); pace(600); c = botCard(seat) }      // he left: a robot plays his card
            } else if (seat == me) {
                msg = "نوبت شماست"; myTurn = true; draw()
                var pick: Card? = null
                while (pick == null && alive) {
                    val a = moveQ.take()
                    while (held && alive) Thread.sleep(300)
                    if (a.startsWith("c")) { val i = a.substring(1).toInt(); if (i in hands[me].indices) pick = hands[me][i] }
                    if (pick != null) {
                        val led = if (trick.isEmpty()) -1 else trick[0].c.s
                        if (led >= 0 && pick.s != led && hands[me].any { it.s == led }) { pick = null; myTurn = true; draw() }
                    }
                }
                myTurn = false
                c = pick ?: return leader
            } else {
                msg = "نوبت " + names[seat]; draw(); pace(600)
                c = botCard(seat)
            }
            val card = c ?: return leader
            if (trick.isNotEmpty() && card.s != trick[0].c.s) void[seat][trick[0].c.s] = true
            if (role == "host") sendAll(JSONObject().put("t", "mv").put("seat", seat).put("c", Cards.idc(card)))
            uiWait { flyPlay(seat, card) }
            Thread.sleep(Anim.ad(360L))
            hands[seat].remove(card)
            val nt = ArrayList(trick); nt.add(TC(seat, card)); trick = nt
            seen.add(Cards.idc(card))
            say(names[seat] + ": " + Cards.cname(card)); draw(); pace(500)
        }
        val w = winnerOf(trick)
        turn = -1
        msg = names[w.seat] + " دست را برد"
        winSeat = w.seat
        for (sd in 0 until n) if (sd == me || isRemote(sd)) sndSeat(sd, if (teamOf(sd) == teamOf(w.seat)) "trick" else "tlose")
        draw(); pace(1100)
        if (role == "host") sendAll(JSONObject().put("t", "col").put("seat", w.seat))
        uiWait { collectTrick(w.seat) }
        Thread.sleep(Anim.ad(450L))
        winSeat = -1
        trick = ArrayList(); draw()
        return w.seat
    }

    // ---- the robots
    // A robot tries each card it may play on many random deals of the cards nobody has shown (every opponent keeps
    // the number of cards he has and none in a suit he did not follow); every player of the simulation plays by the
    // rule policy below, and the card that wins the round most often is chosen.

    private fun isTop(h: List<Card>, c: Card, sn: Set<Int>): Boolean =
        (c.r + 1..14).all { r -> sn.contains(c.s * 20 + r) || h.any { it.s == c.s && it.r == r } }

    /** the rule policy: the card [seat] plays holding [h] when [tr] is already on the table */
    private fun policy(seat: Int, h: List<Card>, tr: List<TC>, sn: Set<Int>): Card {
        if (tr.isEmpty()) return leadPolicy(seat, h, sn)
        val led = tr[0].c.s
        val following = h.any { it.s == led }
        val legal = if (following) h.filter { it.s == led } else h.toList()
        val my = teamOf(seat)
        val w = winnerOf(tr)
        val partnerWins = teamOf(w.seat) == my
        if (following) {
            if (partnerWins) return legal.minByOrNull { it.r }!!
            val beat = legal.filter { beats(it, w.c) }.sortedBy { it.r }
            return if (beat.isNotEmpty()) beat[0] else legal.minByOrNull { it.r }!!
        }
        val trumps = h.filter { it.s == trump }
        val others = h.filter { it.s != trump }
        if (partnerWins) return (if (others.isNotEmpty()) others else h).minByOrNull { it.r }!!
        if (trumps.isNotEmpty()) {
            val bt = trumps.filter { beats(it, w.c) }.sortedBy { it.r }
            if (bt.isNotEmpty()) return bt[0]
        }
        return (if (others.isNotEmpty()) others else h).minByOrNull { it.r }!!
    }

    private fun leadPolicy(seat: Int, h: List<Card>, sn: Set<Int>): Card {
        val nonTrump = h.filter { it.s != trump }
        val tops = nonTrump.filter { isTop(h, it, sn) }.sortedByDescending { it.r }
        if (tops.isNotEmpty()) return tops[0]
        val tr = h.filter { it.s == trump }
        if (tr.isNotEmpty() && teamOf(seat) == teamOf(hakem)) {
            val topTr = tr.filter { isTop(h, it, sn) }
            if (topTr.isNotEmpty()) return topTr.maxByOrNull { it.r }!!
        }
        if (nonTrump.isNotEmpty()) {
            val longest = nonTrump.groupBy { it.s }.maxByOrNull { it.value.size }!!.value
            return longest.minByOrNull { it.r }!!
        }
        return tr.minByOrNull { it.r }!!
    }

    /** a random deal of the unseen cards to the other players, with the known numbers of cards and voids */
    private fun sampleHands(seat: Int, unseen: List<Card>): Array<MutableList<Card>> {
        val need = IntArray(n) { if (it == seat) 0 else hands[it].size }
        for (attempt in 0 until 12) {
            val pool = unseen.shuffled()
            val out = Array(n) { ArrayList<Card>() as MutableList<Card> }
            var ok = true
            for (c in pool) {
                val cand = (0 until n).filter { it != seat && out[it].size < need[it] && !void[it][c.s] }
                if (cand.isEmpty()) { ok = false; break }
                out[cand[(Math.random() * cand.size).toInt()]].add(c)
            }
            if (ok) return out
        }
        val pool = unseen.shuffled()
        val out = Array(n) { ArrayList<Card>() as MutableList<Card> }
        var k = 0
        for (sd in 0 until n) if (sd != seat) for (x in 0 until need[sd]) if (k < pool.size) out[sd].add(pool[k++])
        return out
    }

    /** play [first] now and then the rest of the round by the policy: 1 plus a little when [seat]'s side wins the round */
    private fun rollout(seat: Int, first: Card, dealt: Array<MutableList<Card>>): Double {
        val hs = Array(n) { ArrayList<Card>(dealt[it]) }
        hs[seat] = ArrayList(hands[seat]); hs[seat].remove(first)
        var tr = ArrayList(trick)
        val sn = HashSet(seen)
        val tw = tricksWon.copyOf()
        val reached = IntArray(6)
        var cnt = 0
        tr.add(TC(seat, first)); sn.add(Cards.idc(first))
        var winSide = -1
        while (true) {
            while (tr.size < n) {
                val s2 = (tr[0].seat + tr.size) % n
                val c2 = policy(s2, hs[s2], tr, sn)
                hs[s2].remove(c2); tr.add(TC(s2, c2)); sn.add(Cards.idc(c2))
            }
            val w = winnerOf(tr)
            val ws = teamOf(w.seat)
            tw[ws]++; reached[ws] = ++cnt
            val h7 = (0 until teams).firstOrNull { tw[it] >= 7 } ?: -1
            if (h7 >= 0) {
                val oz = (0 until teams).all { it == h7 || tw[it] == 0 }
                if (!oz || tw[h7] == handSize()) { winSide = h7; break }
            }
            if (hs[w.seat].isEmpty()) break
            tr = ArrayList()
            val c0 = policy(w.seat, hs[w.seat], tr, sn)
            hs[w.seat].remove(c0); tr.add(TC(w.seat, c0)); sn.add(Cards.idc(c0))
        }
        if (winSide < 0) {
            val mx = tw.take(teams).maxOrNull() ?: 0
            val tied = (0 until teams).filter { tw[it] == mx }
            winSide = tied.minByOrNull { reached[it] } ?: tied[0]
        }
        val mt = teamOf(seat)
        return (if (winSide == mt) 1.0 else 0.0) + 0.02 * tw[mt]
    }

    private fun botCard(seat: Int): Card {
        val h = hands[seat]
        val led = if (trick.isEmpty()) -1 else trick[0].c.s
        val legal = if (led >= 0 && h.any { it.s == led }) h.filter { it.s == led } else h.toList()
        if (legal.size <= 1) return legal[0]
        try {      // the stronger robot (HokmSim): more deals, card counting, voids
            val arr = BooleanArray(80); for (cid in seen) if (cid in 0 until 80) arr[cid] = true
            val cnt = IntArray(6) { hands[it].size }
            return HokmSim(n, kind, trump, hakem).choose(seat, ArrayList(h), ArrayList(trick), arr, deckCards(), cnt, void, tricksWon)
        } catch (e: Exception) { }
        try {
            val unseen = deckCards().filter { c -> !seen.contains(Cards.idc(c)) && h.none { x -> x.s == c.s && x.r == c.r } }
            val iters = Math.max(30, Math.min(120, 1500 / legal.size))
            val sums = DoubleArray(legal.size)
            for (k in 0 until iters) {
                val d = sampleHands(seat, unseen)
                for ((i, c) in legal.withIndex()) sums[i] += rollout(seat, c, d)
            }
            val bi = sums.indices.maxByOrNull { sums[it] } ?: 0
            return legal[bi]
        } catch (e: Exception) {
            return policy(seat, h, trick, seen)
        }
    }

    private fun chipText(d: Int): String = "ژتون شما " + Cards.fa(Math.abs(d)) + (if (d >= 0) " اضافه شد" else " کم شد") + ". ژتون شما: " + Cards.fa(Prefs.wallet)

    private fun finish(best: Int) {
        val size = n / teams
        say(teamName(best) + " بازی را برد.")
        for (seat in 0 until n) {
            if (seat != me && !isRemote(seat)) continue
            val won = teamOf(seat) == best
            val d = if (won) Math.max(1, stake * (teams - 1) / size) else -Math.max(1, stake / size)
            if (seat == me) {
                Prefs.wallet = Prefs.wallet + d
                ui { banner(if (won) "بردید!" else "باختید!") }
                Sched.post { Sound.game(if (won) "fwin" else "flose") }
                localSay(chipText(d))
            } else net?.send(cidOf[seat], JSONObject().put("t", "fin").put("w", won).put("d", d))
        }
        try { SavesHn.del("auto"); SavesHn.del("autoM") } catch (e: Exception) { }
        if (role != "client") {
            Thread.sleep(Anim.ad(3500L))
            ui { app.dlg.confirm("بازی تمام شد. بازی جدید شروع شود؟", { newGame() }) }
        }
    }

    // ------------------------------------------------------------------ several phones

    private fun cardOf(id: Int) = Card(id / 20, id % 20)

    private fun sendAll(j: JSONObject) { for (sd in 0 until n) if (remote[sd]) net?.send(cidOf[sd], j) }

    fun hasSeat(cid: Int): Boolean = cidOf.indexOf(cid) >= 0

    /** what seat [seat] sees: its own hand, the table, the counts of the others */
    private fun snapFor(seat: Int, mt: Boolean, ct: Boolean): JSONObject {
        val nm = JSONArray(); for (x in names) nm.put(x)
        val pj = JSONArray(); for (t in 0 until teams) pj.put(pts[t])
        val tw = JSONArray(); for (t in 0 until teams) tw.put(tricksWon[t])
        val hd = JSONArray(); for (c in ArrayList(hands[seat])) hd.put(Cards.idc(c))
        val cn = JSONArray(); for (i in 0 until n) cn.put(hands[i].size)
        val tk = JSONArray(); for (p in ArrayList(trick)) tk.put(JSONArray().put(p.seat).put(Cards.idc(p.c)))
        val m = if (mt) "نوبت شماست" else if (ct) "شما حاکم هستید؛ حکم را انتخاب کنید."
            else if (msg.startsWith("نوبت شما") || msg.startsWith("شما حاکم")) (if (turn in 0 until n) "نوبت " + names[turn] else if (hakem in 0 until n) names[hakem] + " حکم را انتخاب می‌کند" else "")
            else msg
        return JSONObject().put("t", "st").put("me", seat).put("kind", kind).put("stake", stake).put("hakem", hakem).put("trump", trump)
            .put("turn", turn).put("names", nm).put("pts", pj).put("tw", tw).put("hand", hd).put("cnt", cn).put("trick", tk)
            .put("mt", mt).put("ct", ct).put("msg", m).put("win", winSeat)
    }

    private fun sendStates() {
        for (sd in 0 until n) if (remote[sd]) net?.send(cidOf[sd], snapFor(sd, waitSeat == sd && !waitTrump, waitSeat == sd && waitTrump))
    }

    private fun startMsg(seat: Int): JSONObject = JSONObject().put("t", "start").put("me", seat)

    /** the host starts a game: seats 1.. are the phones that joined, the other seats are robots */
    fun startHostGame(ps: List<NetHn.Peer>, k: Int, st: Int) {
        role = "host"; me = 0; kind = k; n = players(k); teams = teamsOf(k); stake = st
        for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
        val nm = ArrayList<String>()
        nm.add(if (Prefs.name.isEmpty()) "شما" else Prefs.name)
        for ((i, p) in ps.withIndex()) { nm.add(p.name); remote[i + 1] = true; cidOf[i + 1] = p.cid; idOf[i + 1] = p.id }
        for (x in NM.shuffled()) { if (nm.size >= n) break; if (!nm.contains(x)) nm.add(x) }
        names = nm
        pts = IntArray(6); hakem = -1
        for (sd in 1 until n) if (remote[sd]) net?.send(cidOf[sd], startMsg(sd))
        lastSave = saveJson().toString()
        startGame()
        sendSync()
    }

    /** the last save goes to every guest: if the host drops out, the first guest takes over from it */
    private fun sendSync() {
        if (role != "host" || lastSave.isEmpty()) return
        val succ = (1 until n).firstOrNull { remote[it] } ?: return
        sendAll(JSONObject().put("t", "sync").put("sv", lastSave).put("succ", succ))
    }

    fun adoptFromSync() {
        val nt = net
        if (nt == null || syncSv.isEmpty()) { showReconnect(); return }
        try {
            nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
            stopGame(); started = false
            resumeHostGame(JSONObject(syncSv), true)
        } catch (e: Exception) { showReconnect() }
    }

    // ---- a saved multi-phone game, or a game handed over by the old host

    /** load a save: the host waits until the players are back (they are known by their device ids) */
    fun resumeHostGame(j: JSONObject, handedOver: Boolean) {
        try {
            kind = j.getInt("kind"); n = players(kind); teams = teamsOf(kind); stake = j.optInt("stake", 1000)
            val nm = j.getJSONArray("names"); val sc = j.getJSONArray("pts"); val ids = j.optJSONArray("ids")
            var k = 0
            if (handedOver && ids != null) for (i in 0 until n) if (ids.optString(i) == Prefs.devId()) k = i
            names = List(n) { nm.getString((it + k) % n) }
            val old = IntArray(6) { if (it < sc.length()) sc.getInt(it) else 0 }
            val np = IntArray(6)
            for (sd in 0 until n) np[teamOf(sd)] = old[teamOf((sd + k) % n)]       // the teams keep their points when the seats turn around
            pts = np
            val oh = j.optInt("hakem", -1)
            hakem = if (oh < 0) -1 else ((oh - k) % n + n) % n
            for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
            if (ids != null) for (i in 0 until n) idOf[i] = ids.optString((i + k) % n)
            idOf[0] = ""                                  // this phone is the host
            if (Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            role = "host"; me = 0; resuming = true; started = false
            showResumeLobby()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده خراب است."); net?.leave(); close() }
    }

    private fun showResumeLobby() {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("ادامهٔ بازی ذخیره‌شده"))
        v.addView(tv("بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند و بازی «" + (if (Prefs.name.isEmpty()) "میزبان" else Prefs.name) + "» را انتخاب کنند. وقتی آماده بودید «ادامه بازی» را بزنید؛ جای کسانی که نیامده‌اند ربات بازی می‌کند.", 15f))
        for (i in 1 until n) {
            val st = if (remote[i]) "وصل شد" else if (idOf[i].isNotEmpty()) "منتظر است" else "ربات"
            v.addView(tv(names[i] + " — " + st, 15f))
        }
        v.addView(mbtn("ادامه بازی") {
            resuming = false
            for (sd in 1 until n) if (remote[sd]) net?.send(cidOf[sd], startMsg(sd))
            lastSave = saveJson().toString()
            startGame()
            sendSync()
        })
        v.addView(mbtn("لغو") { net?.leave(); close() })
        setScreen("net", v)
    }

    /** the saved multi-phone games (from the lobby): the one who taps becomes the host */
    fun showMultiSaves() { net?.showSaved() }

    private fun xferTo(seat: Int) {
        val cid = cidOf[seat]
        if (cid < 0 || lastSave.isEmpty()) return
        net?.send(cid, JSONObject().put("t", "xfer").put("sv", lastSave))
        Sched.laterRaw(1200) { act.runOnUiThread { net?.leave(); close(false) } }
    }

    private fun exitHostAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.confirm("از بازی خارج می‌شوید؟", { net?.leave(); close() }); return }
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (sd in seats) items.add(("میزبانی را به «" + names[sd] + "» بدهم و خارج شوم (دور فعلی از نو پخش می‌شود)") to { xferTo(sd) })
        items.add("بازی را ببندم (برای همه تمام می‌شود)" to { net?.leave(); close() })
        app.dlg.list("قبل از رفتن", items, "بستن")
    }

    fun onGuestDrop(cid: Int) {
        val sd = cidOf.indexOf(cid)
        if (sd < 1) return
        remote[sd] = false; cidOf[sd] = -1
        ansQ[sd].offer("drop")
        if (resuming) { ui { showResumeLobby() }; return }
        if (started) { say(names[sd] + " قطع شد و ربات جای او آمد."); startHold(names[sd] + " قطع شد و ربات جای او آمد.") }
    }

    /** a phone that sat here before says hello again: it takes its seat back. true when it was one of ours */
    fun onGuestHello(cid: Int, id: String): Boolean {
        if ((!started && !resuming) || role != "host" || id.isEmpty()) return false
        for (sd in 1 until n) if (idOf[sd] == id) {
            remote[sd] = true; cidOf[sd] = cid
            if (resuming) { ui { showResumeLobby() }; return true }
            net?.send(cid, startMsg(sd))
            if (held) net?.send(cid, JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
            say(names[sd] + " به بازی برگشت.")
            sendStates()
            sendSync()
            return true
        }
        return false
    }

    fun onGuestMsg(cid: Int, m: JSONObject) {
        val sd = cidOf.indexOf(cid)
        if (sd >= 1 && m.optString("t") == "ans") ansQ[sd].offer(m.optString("m"))
    }

    fun netNote(t: String) { localSay(t) }

    /** the connection to the host dropped during a game */
    fun showReconnect() {
        if (screen != "game" || role != "client") return
        val t = "اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید از بازی کنار هستید. در حال اتصال دوباره..."
        ui {
            ctl.removeAllViews()
            ctl.addView(tv(t, 14f, Color.WHITE))
            ctl.addView(app.dlg.btn("اتصال دوباره", false) { net?.reconnect() })
            ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
            ann(t)
        }
        myTurn = false
    }

    /** the host's messages, on the guest phone */
    fun onHostMsg(m: JSONObject) {
        when (m.optString("t")) {
            "start" -> {
                role = "client"; me = m.optInt("me", 1)
                if (screen != "game") { ui { stopGame(); logLines.clear(); lastMsg = ""; Spk.reset(); Sound.resetQueue(); started = true } }
            }
            "st" -> {
                role = "client"
                if (screen != "game" || !started) {
                    stopGame(); logLines.clear(); lastMsg = ""; Spk.reset(); Sound.resetQueue()
                    me = m.optInt("me", me); kind = m.getInt("kind"); n = players(kind); teams = teamsOf(kind)
                    val nm = m.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
                    buildGameView(); started = true
                }
                applySnap(m)
            }
            "say" -> localSay(m.optString("m"))
            "hold" -> { held = m.optBoolean("on"); holdTxt = if (held) m.optString("x") else ""; ui { if (held) ann(holdTxt); render() } }
            "mv" -> { val sd = m.optInt("seat"); val cd = cardOf(m.optInt("c")); ui { flyPlay(sd, cd) } }
            "col" -> { val sd = m.optInt("seat"); ui { collectTrick(sd) } }
            "dealfx" -> ui { flyDeal() }
            "aside" -> { val a = m.optJSONArray("c"); if (a != null) { val l = List(a.length()) { cardOf(a.getInt(it)) }; ui { flyAside(l) } } }
            "sync" -> { syncSv = m.optString("sv"); succSeat = m.optInt("succ", -1) }
            "snd" -> Sched.post { Sound.game(m.optString("n")) }
            "ban" -> ui { banner(m.optString("m")) }
            "fin" -> {
                val won = m.optBoolean("w"); val d = m.optInt("d")
                Prefs.wallet = Prefs.wallet + d
                ui { banner(if (won) "بردید!" else "باختید!") }
                Sched.post { Sound.game(if (won) "fwin" else "flose") }
                localSay(chipText(d))
                myTurn = false; choosingTrump = false
            }
            "xfer" -> {
                val nt = net ?: return
                nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
                stopGame(); started = false
                resumeHostGame(JSONObject(m.getString("sv")), true)
            }
            "end" -> { app.dlg.message(m.optString("m", "بازی تمام شد.")); net?.leave(); close() }
        }
    }

    private fun applySnap(m: JSONObject) {
        ui {
            me = m.optInt("me", me); kind = m.optInt("kind", kind); n = players(kind); teams = teamsOf(kind); stake = m.optInt("stake", stake)
            val nm = m.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
            val pj = m.getJSONArray("pts"); pts = IntArray(6) { if (it < pj.length()) pj.getInt(it) else 0 }
            val tw = m.getJSONArray("tw"); tricksWon = IntArray(6) { if (it < tw.length()) tw.getInt(it) else 0 }
            hakem = m.optInt("hakem", -1); trump = m.optInt("trump", -1); turn = m.optInt("turn", -1)
            val cn = m.getJSONArray("cnt"); val hd = m.getJSONArray("hand")
            for (i in 0 until 6) hands[i] = if (i == me) ArrayList<Card>().also { l -> for (k in 0 until hd.length()) l.add(cardOf(hd.getInt(k))) }
                else ArrayList<Card>().also { l -> for (k in 0 until (if (i < cn.length()) cn.getInt(i) else 0)) l.add(Card(0, 2)) }
            val tk = m.getJSONArray("trick")
            trick = ArrayList<TC>().also { l -> for (k in 0 until tk.length()) { val e = tk.getJSONArray(k); l.add(TC(e.getInt(0), cardOf(e.getInt(1)))) } }
            msg = m.optString("msg")
            myTurn = m.optBoolean("mt"); choosingTrump = m.optBoolean("ct"); winSeat = m.optInt("win", -1)
            render()
        }
    }

    // ---- the host's menu: add, remove and hand over

    private fun addAsk() {
        val nt = net ?: return
        val seats = (1 until n).filter { !remote[it] }
        if (seats.isEmpty()) { app.dlg.message("جای خالی نیست."); return }
        val w = nt.waiting()
        if (w.isEmpty()) { app.dlg.message("گوشی منتظری نیست. بازیکن باید «به بازی دیگری می‌پیوندم» را بزند و بازی شما را انتخاب کند."); return }
        fun pickSeat(cid: Int, nm: String) {
            if (seats.size == 1) { addPlayer(cid, seats[0]); return }
            app.dlg.list("«" + nm + "» جای کدام بازیکن یا ربات بنشیند؟", seats.map { x -> names[x] to { addPlayer(cid, x) } }, "بستن")
        }
        if (w.size == 1) pickSeat(w[0].first, w[0].second)
        else app.dlg.list("کدام گوشی اضافه شود؟", w.map { (cid, nm) -> nm to { pickSeat(cid, nm) } }, "بستن")
    }

    private fun addPlayer(cid: Int, seat: Int) {
        val info = net?.peerInfo(cid) ?: return
        if (remote[seat]) return
        val nd = need(kind, stake)
        if (info.wallet < nd) { app.dlg.message("«" + info.name + "» ژتون کافی ندارد (دست‌کم " + Cards.fa(nd) + " لازم است) و نمی‌تواند وارد بازی شود."); return }
        remote[seat] = true; cidOf[seat] = cid; idOf[seat] = info.id
        val l = names.toMutableList(); l[seat] = info.name; names = l
        net?.send(cid, startMsg(seat))
        say(info.name + " به بازی پیوست.")
        sendStates(); sendSync()
    }

    private fun kickAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { sd: Int -> app.dlg.confirm("«" + names[sd] + "» از بازی حذف شود؟ ربات جای او بازی می‌کند.", { kickPlayer(sd) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("کدام بازیکن حذف شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }

    private fun kickPlayer(sd: Int) {
        if (!remote[sd]) return
        net?.send(cidOf[sd], JSONObject().put("t", "end").put("m", "میزبان شما را از بازی حذف کرد."))
        remote[sd] = false; cidOf[sd] = -1; idOf[sd] = ""
        ansQ[sd].offer("drop")
        say(names[sd] + " از بازی حذف شد و ربات جای او آمد.")
        sendSync()
    }

    private fun xferAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { sd: Int -> app.dlg.confirm("میزبانی به «" + names[sd] + "» داده شود و شما از بازی خارج شوید؟ دور فعلی از نو پخش می‌شود.", { xferTo(sd) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("میزبانی به چه کسی داده شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }
}
