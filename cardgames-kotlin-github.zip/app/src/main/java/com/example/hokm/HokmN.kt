package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue

/**
 * Hokm for 3, 5 and 6 players (against robots; every player plays for himself, except in the six-player game
 * which is two teams of three or three teams of two).
 *  3 players: one 2 (the 2 of diamonds) is taken out, 17 cards each (5 + 4 + 4 + 4)
 *  5 players: two 2s are taken out, 10 cards each (5 + 5)
 *  6 players: all four 2s are taken out, 8 cards each (4 + 4)
 * The rules are those of the four-player Hokm: the hakem is the one who gets the first ace and chooses the trump
 * after his first cards; the first side to take 7 tricks wins the round (1 point); if the others have no trick
 * then it is a kot (2 points, 3 against the hakem), all the tricks is a bam (the game); when the hakem's side loses
 * the round the next player becomes hakem; the first side to 7 points wins the game.
 */
class HokmN(private val act: MainActivity, private val app: App) {
    companion object {
        /** kinds: 3 = three players, 5 = five players, 62 = six players in two teams of three, 63 = six players in three teams of two */
        fun players(kind: Int): Int = if (kind > 10) kind / 10 else kind
        /** the title of seat [s] for the host who sits at the bottom (seat 0), as the seat titles of the four-player game */
        fun seatTitle(kind: Int, s: Int): String {
            val n = players(kind)
            val tm = { x: Int -> when (kind) { 62 -> x % 2; 63 -> x % 3; else -> x } }
            val rel = if (n == 2) "روبه‌رو" else if (s == 1) "سمت چپ شما" else if (s == n - 1) "سمت راست شما" else "روبه‌روی شما سمت " + (if (s <= n / 2) "چپ" else "راست")
            return (if (tm(s) == tm(0)) "یار شما" else "حریف") + " (" + rel + ")"
        }
        fun teamsOf(kind: Int): Int = when (kind) { 62 -> 2; 63 -> 3; else -> players(kind) }
        fun title(kind: Int): String = when (kind) {
            3 -> "سه نفره"; 5 -> "پنج نفره"; 62 -> "شش نفره، دو تیم سه نفره"; else -> "شش نفره، سه تیم دو نفره"
        }
        /** the chips a person needs: the stake (everybody puts the same stake in, whatever the number of players) */
        fun need(kind: Int, st: Long): Long = st
        const val TARGET = 7
    }

    private val NM = Names.IR_NAMES

    // ---- options and state ----
    private var kind = 3
    private var n = 3
    private var teams = 3
    private var stake = 100000L
    private var names: List<String> = emptyList()
    private var pts = IntArray(6)                       // rounds won per team
    private var hakem = -1
    /** the six-player game: partners by the draw of the aces (true) or by the seating alone (false) */
    private var pdraw = true
    private var trump = -1
    private var hands: Array<MutableList<Card>> = Array(6) { ArrayList<Card>() }
    @Volatile private var trick: MutableList<TC> = ArrayList()
    private var tricksWon = IntArray(6)                 // tricks of this round per team
    private var seen = HashSet<Int>()                   // cards already played in this round
    private val void = Array(6) { BooleanArray(4) }     // void[seat][suit]: the seat did not follow that suit, so he has none
    private var turn = -1
    private var msg = ""
    @Volatile private var msgF: ((Int) -> String)? = null     // the message as each seat sees it (the guests get theirs)
    @Volatile private var shown: List<TC> = ArrayList()       // the finished trick that still lies on the table (as flow.shown of the four-player game)
    private var lastMf: ((Int) -> String)? = null
    private var lastWinnerTeam = -1
    private var asideN = 0                                // the cards put aside from the pack: a pile on the table (as in the two-player game)
    private val plays = ArrayList<AiPlay>()               // the cards of this round in order (what the robots infer from)

    // ---- several phones: "solo" (robots only), "host" (runs the game) or "client" (shows the table and sends its moves)
    @JvmField var role = "solo"
    @JvmField var roomCode = ""
    @Volatile @JvmField var resuming = false           // a saved game was loaded and the host waits for the players to come back
    private var lastSave = ""
    private var syncSv = ""                            // the host's last save (guest side): used to take over if the host drops out
    private var succSeat = -1
    val isSucc: Boolean get() = role == "client" && syncSv.isNotEmpty() && me == succSeat
    private var me = 0                                 // my seat (the host and a solo player sit at 0)
    private val remote = BooleanArray(6)
    private val cidOf = IntArray(6) { -1 }
    private val idOf = Array(6) { "" }
    private val ansQ = Array(6) { LinkedBlockingQueue<String>() }
    @Volatile private var waitSeat = -1
    @Volatile private var waitTrump = false
    private var net: NetHn? = null
    private fun isRemote(s: Int) = role == "host" && remote[s]

    @Volatile private var alive = false
    @Volatile var started = false
    private var worker: Thread? = null
    private val moveQ = LinkedBlockingQueue<String>()
    @Volatile private var myTurn = false
    @Volatile private var choosingTrump = false
    @Volatile private var held = false                 // a player dropped out: the host's game waits until he presses "ادامه بازی" (as in Hokm)
    private var holdTxt = ""
    @Volatile private var winSeat = -1                 // the seat that took the trick which is still on the table (gold border)

    // ---- views ----
    private val ov = FrameLayout(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)
    private lateinit var gameV: LinearLayout
    private lateinit var topTr: TextView
    private lateinit var topHk: TextView
    private lateinit var topSc: TextView
    private lateinit var topTk: TextView
    private lateinit var msgTv: TextView
    private lateinit var msgBox: LinearLayout
    private lateinit var holdBar: LinearLayout
    private lateinit var holdTv: TextView
    private lateinit var holdBtn: View
    private var keepNg = false                             // the "بازی جدید" button is on the screen (as keepMsg of the four-player game)
    private lateinit var tableBox: LinearLayout
    private lateinit var seatLayer: FrameLayout          // the players, around the round table
    private lateinit var mid: FrameLayout                // the cards of the trick, in the middle of the table
    private var roundW = 0
    private var roundH = 0
    private lateinit var handBox: LinearLayout
    private lateinit var ctl: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var logBox: LinearLayout
    private val pBox = arrayOfNulls<LinearLayout>(6)
    private var screen = "setup"

    private fun teamOf(seat: Int): Int = when (kind) { 62 -> seat % 2; 63 -> seat % 3; else -> seat }
    private fun handSize(): Int = when (n) { 3 -> 17; 5 -> 10; else -> 8 }
    private fun teamName(t: Int): String = (0 until n).filter { teamOf(it) == t }.joinToString(" و ") { names[it] }

    // ------------------------------------------------------------------ shell

    fun show(start: String, ad: ((NetHn) -> Unit)? = null) {
        ov.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ov.setBackgroundColor(Px.bg)
        ov.isClickable = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        val sc = ScrollView(act)
        sc.isFillViewport = true
        sc.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.addView(sc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        app.menuShown(false)
        Fx.raise()
        act.onBack = { back() }
        if (start == "resume") showSaves()
        else if (start == "blank") { }
        else if (start == "adopt") { val nt = NetHn(act, app, this); net = nt; ad?.invoke(nt) }
        else if (start == "net") { val nt = NetHn(act, app, this); net = nt; nt.show() }
        else startNew(start.toIntOrNull() ?: 3)
    }

    fun close(notify: Boolean = true) {
        if (notify && role == "host") sendAll(JSONObject().put("t", "end").put("m", "میزبان بازی را بست."))
        stopGame()
        net?.close(); net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
        app.menuShown(true)
        app.syncBg()
    }

    private fun back(): Boolean {
        if (screen == "net" && net?.back() == true) return true
        if (screen == "game") {
            if (role == "client") app.dlg.confirm("از بازی چندگوشی خارج می‌شوید؟ ربات جای شما بازی می‌کند.", { net?.leave(); close() })
            else app.dlg.confirm("بازی فعلی از بین می‌رود. به مرحله‌ی قبل برگردیم؟", { newGame() })
            return true
        }
        net?.leave(); close()
        return true
    }

    private fun ui(f: () -> Unit) { act.runOnUiThread { try { f() } catch (e: Exception) { } } }

    private fun uiWait(f: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) { try { f() } catch (e: Exception) { }; return }
        val l = CountDownLatch(1)
        act.runOnUiThread { try { f() } catch (e: Exception) { }; l.countDown() }
        l.await()
    }

    // ---- the played card flies from the player's seat to the table (as in the other Hokm games)

    private fun loc(v: View): IntArray { val a = IntArray(2); v.getLocationInWindow(a); return a }

    private fun cellOf(seat: Int): View? {
        return if (seat == me) null else pBox[seat]
    }

    /** a copy of a picture flies from one view to another and shrinks (the trick goes to its winner) */
    private fun flyCopy(src: View, dst: View?, delay: Long) {
        val d = (src as? ImageView)?.drawable ?: return
        val o = loc(ov); val a = loc(src)
        val iv = ImageView(act)
        iv.setImageDrawable(d.constantState?.newDrawable() ?: d)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val w = src.width; val h = src.height
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        iv.x = (a[0] - o[0]).toFloat(); iv.y = (a[1] - o[1]).toFloat()
        val tx: Float; val ty: Float
        if (dst != null) { val t = loc(dst); tx = t[0] - o[0] + (dst.width - w) / 2f; ty = t[1] - o[1] + (dst.height - h) / 2f }
        else { tx = (ov.width - w) / 2f; ty = ov.height - h * 1.6f }       // my own seat: the bottom of the screen
        iv.animate().x(tx).y(ty).alpha(0f).scaleX(0.6f).scaleY(0.6f)
            .setStartDelay(Anim.ad(delay)).setDuration(Anim.ad(380L))
            .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** the cards on the table go to the player who took the trick */
    private fun collectTrick(seat: Int) {
        if (!::mid.isInitialized) return
        val dst = cellOf(seat)
        for (i in 0 until mid.childCount) {
            val slot = mid.getChildAt(i) as? FrameLayout ?: continue
            val v = slot.getChildAt(0) ?: continue
            flyCopy(v, dst, 60L * i)
            slot.visibility = View.INVISIBLE
        }
    }

    /** the dealt cards fly from the middle of the table to every player (as in Hokm) */
    // ---- dealing: the cards fly from the middle with the timing of Deal, as in the four-player game
    private val handViews = ArrayList<View>()
    private var fxHn = -1
    private var fxHand: Set<Int> = emptySet()
    private var fxCnt = IntArray(6)
    /** the keys of my first cards (dealt before the trump was chosen by another player), as Fx.first5 in the four-player game */
    private var first5N: Set<Int>? = null

    private fun key1(c: Card) = c.s * 20 + c.r
    private fun fanImgs(v: ViewGroup?): List<View> {
        if (v == null) return emptyList()
        for (i in 0 until v.childCount) { val c = v.getChildAt(i); if (c.tag == "fan" && c is ViewGroup) return (0 until c.childCount).map { c.getChildAt(it) } }
        return emptyList()
    }
    private fun planFly(id: String, v: View?, from: android.graphics.PointF?, pl: Deal.Plan, dur: Long, sc: Float, rot: Float = 0f) {
        Fx.fly(id, v, from, dur, sc, rot, pl.o ?: 0.35f, pl.delay, false, pl.snd)
    }
    /** while another player chooses the trump my own cards are shown face down (as in the four-player game) */
    private fun hidesHand(): Boolean = trump < 0 && hakem in 0 until n && hakem != me && hands[me].isNotEmpty()

    private fun postFx() {
        val hn = Fx.hn
        val same = fxHn == hn
        if (!same) first5N = null
        val mine = Cards.sorted2(hands[me])
        if (!same && trump >= 0) {      // a game that is already in progress (resumed, or a guest who came back): nothing is dealt again
            fxHn = hn; fxHand = if (hidesHand()) emptySet() else mine.map { key1(it) }.toSet(); fxCnt = IntArray(6) { hands[it].size }
            postTable(true)
            return
        }
        val ctr = Fx.center(mid)
        val hk = if (hakem in 0 until n) hakem else 0
        for (i in 0 until n) if (i != me) {
            val ims = fanImgs(pBox[i]); val c0 = if (same) fxCnt[i] else 0; val nw = ims.size - c0
            val dur = Anim.ad(320L)
            for (j in ims.indices) {
                val id = hn.toString() + "f" + i + "-" + j
                if (j >= c0 || Fx.has(id)) planFly(id, ims[j], ctr, Deal.dl(j - c0, (i - hk + n) % n, n, Deal.part(n, nw), nw, dur), dur, 0.4f)
            }
        }
        val hidden = hidesHand()
        if (hidden) {
            val ims = fanImgs(handBox); val dur = Anim.ad(320L)
            ims.forEachIndexed { j, im ->
                val id = hn.toString() + "b" + j
                if (!same || fxCnt[me] == 0 || Fx.has(id)) planFly(id, im, ctr, Deal.dl(j, (me - hk + n) % n, n, Deal.part(n, ims.size), ims.size, dur), dur, 0.4f)
            }
            first5N = mine.map { key1(it) }.toSet()
        } else if (handViews.size == mine.size) {
            val prev = if (same) fxHand else emptySet()
            val f5 = first5N
            val nws = mine.filter { !prev.contains(key1(it)) && !(f5 != null && hakem != me && f5.contains(key1(it))) }
            val dur = Anim.ad(340L)
            mine.forEachIndexed { i, c ->
                val kk = key1(c); val id = hn.toString() + "h" + kk; val isNew = !prev.contains(kk)
                if (isNew && f5 != null && hakem != me && f5.contains(kk)) {
                    Fx.fly(id, handViews[i], ctr, Anim.ad(280).toLong(), 0.55f, 0f, 0.35f, i * Anim.ad(40).toLong(), true, false)
                } else if (isNew || Fx.has(id)) {
                    val k = nws.indexOf(c)
                    planFly(id, handViews[i], ctr, Deal.dl(if (k < 0) 0 else k, (me - hk + n) % n, n, Deal.part(n, nws.size), nws.size, dur), dur, 0.4f, Fx.rotOf(kk))
                }
            }
        }
        fxHn = hn; fxHand = if (hidden) emptySet() else mine.map { key1(it) }.toSet(); fxCnt = IntArray(6) { hands[it].size }
        postTable(false)
    }


    // ---- the cards on the table: they fly in from their player (with the hand), and a finished trick is taken by its winner
    // one second later - the same effects as the two- and four-player game (post4)
    private var tbGen = -1
    private var tbMid: List<Int> = emptyList()
    private var tbColl = ""
    private var tbCollDone = ""

    private fun tableSrc(seat: Int): android.graphics.PointF? = if (seat == me) Fx.center(handBox) else Fx.center(pBox[seat])

    private fun postTable(prime: Boolean) {
        if (!::mid.isInitialized) return
        val dt = ArrayList(if (trick.isNotEmpty()) trick else shown)
        val keys = dt.map { key1(it.c) }
        val same = tbGen == Sched.GEN && !prime
        val hn = Fx.hn
        for ((i, t) in dt.withIndex()) {
            val kk = key1(t.c); val id = hn.toString() + "t" + kk; val isNew = same && !tbMid.contains(kk)
            if (isNew || Fx.has(id)) {
                val sc = (mid.getChildAt(i) as? FrameLayout)?.getChildAt(0); val s0 = tableSrc(t.seat)
                Fx.fly(id, sc, s0, Anim.ad(360L), 0.5f, Fx.rotOf(kk), snd = isNew)
                if (isNew) Fx.handFx(id, s0, Fx.center(sc), if (t.seat == me) Av.me() else names[t.seat])
            }
        }
        if (dt.size == n && winSeat >= 0) {
            val ck = hn.toString() + "c" + keys.joinToString(".")
            if (prime) tbColl = ck
            if (tbCollDone == ck) { for (i in 0 until dt.size) mid.getChildAt(i)?.visibility = View.INVISIBLE }
            else if (tbColl != ck) {
                tbColl = ck
                Sched.later(Anim.ad(1000L)) {
                    if (tbColl != ck || winSeat < 0) return@later
                    tbCollDone = ck
                    Fx.takeAway((0 until dt.size).map { (mid.getChildAt(it) as? FrameLayout)?.getChildAt(0) }, tableSrc(winSeat), Anim.ad(520L))
                }
            }
        }
        tbGen = Sched.GEN; tbMid = keys
    }

    private fun flyPlay(seat: Int, c: Card) {
        if (!::mid.isInitialized || !::handBox.isInitialized) return
        val o = loc(ov); val t = loc(mid)
        val w = Px.dp(46); val h = Px.dp(64)
        val bmp = Assets.bitmap(act, Assets.cardPath(c)) ?: return
        val iv = ImageView(act)
        iv.setImageBitmap(bmp)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        val src = cellOf(seat)
        val sx: Float; val sy: Float
        if (src != null) { val a = loc(src); sx = a[0] - o[0] + (src.width - w) / 2f; sy = a[1] - o[1] + (src.height - h) / 2f }
        else { val a = loc(handBox); sx = a[0] - o[0] + handBox.width / 2f - w / 2f; sy = (a[1] - o[1]).toFloat() }
        iv.x = sx; iv.y = sy
        // as in the two-player Hokm: the card starts small and faint, a little turned, and grows into its place;
        // the card sound is started early (CSO) so that its peak falls at the moment the card lands
        val rot0 = Math.round((Math.random() - 0.5) * 22).toFloat()
        iv.scaleX = 0.55f; iv.scaleY = 0.55f; iv.alpha = 0.35f; iv.rotation = rot0
        iv.animate().x(t[0] - o[0] + mid.width / 2f - w / 2f).y(t[1] - o[1] + mid.height / 2f - h / 2f)
            .scaleX(1f).scaleY(1f).alpha(1f).rotation(0f)
            .setInterpolator(android.view.animation.PathInterpolator(0.2f, 0.8f, 0.2f, 1f))
            .setDuration(Anim.ad(360L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
        Sched.later(Math.max(0, Anim.ad(360L).toInt() - Sound.CSO)) { Sound.cardSnd() }
    }

    fun tv(t: String, size: Float = 15f, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun setScreen(name: String, v: View) { screen = name; content.removeAllViews(); content.addView(v) }

    fun heading(t: String): TextView {
        val h = tv(t, 26f, Px.tx, true)
        h.gravity = Gravity.CENTER
        h.setPadding(0, Px.dp(12), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) h.isAccessibilityHeading = true
        return h
    }

    fun mbtn(t: String, f: () -> Unit): View {
        val b = app.dlg.btn(t, true, f)
        val l = LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    // ------------------------------------------------------------------ start, chips and saved games

    /** chips: false (and a message) when the person cannot take part with this stake */
    private fun checkStake(k: Int, st: Long): Boolean {
        if (Prefs.wallet < Bist21.MIN_PLAY) { app.dlg.message(Bist21.BROKE); return false }
        if (st < 1L) { app.dlg.message("ژتون هر بازیکن را به‌صورت عدد و دست‌کم ۱ تایپ کنید."); return false }
        val nd = need(k, st)
        if (Prefs.wallet < nd) {
            app.dlg.message("ژتون شما برای این مبلغ کافی نیست (ژتون شما: " + Cards.fa(Prefs.wallet) + "؛ دست‌کم " + Cards.fa(nd) + " لازم است). مبلغ کمتری انتخاب کنید.")
            return false
        }
        return true
    }

    private fun startNew(k: Int) {
        pdraw = true
        role = "solo"; me = 0; for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
        kind = k; n = players(k); teams = teamsOf(k); stake = app.hokmStake
        if (!checkStake(k, stake)) { close(); return }
        val rob = NM.shuffled().filter { it != Prefs.name }.take(n - 1)
        names = listOf(if (Prefs.name.isEmpty()) "شما" else Prefs.name) + rob
        pts = IntArray(6); hakem = -1
        startGame()
    }

    private fun saveJson(): JSONObject {
        val nm = JSONArray(); for (x in names) nm.put(x)
        val sc = JSONArray(); for (x in pts) sc.put(x)
        val ids = JSONArray(); for (i in 0 until n) ids.put(if (role == "host" && i == me) Prefs.devId() else idOf[i])
        return JSONObject().put("kind", kind).put("pdraw", pdraw).put("stake", stake).put("names", nm).put("pts", sc).put("hakem", hakem).put("ids", ids)
    }

    private fun saveAuto() {
        try {
            lastSave = saveJson().toString()      // nothing is saved to the list by itself; the host's last state is only handed to the guests
            if (role == "host") sendSync()
        } catch (e: Exception) { }
    }

    private fun manualSave() {
        if (!started) return
        SavesHn.put("m" + System.currentTimeMillis(), role == "host", saveJson().toString())
        app.dlg.list(if (role == "host") "بازی ذخیره شد. هر وقت خواستید از «بازی‌های قبلی» در بخش «بازی با چند گوشی» ادامه‌اش دهید." else "بازی ذخیره شد. هر وقت خواستید از «ایجاد بازی» ← «بازی با ربات» ← «بازی‌های قبلی» ادامه‌اش دهید.", emptyList(), "باشه")
    }

    private fun showSaves() {
        val l = SavesHn.all(false)
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("بازی‌های قبلی"))
        if (l.isEmpty()) v.addView(tv("بازی ذخیره‌شده‌ای نیست.", 15f))
        for (e in l) v.addView(mbtn(SavesHn.describe(e)) {
            app.dlg.list(SavesHn.describe(e), listOf(
                "ادامه بازی" to { resumeFrom(e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { SavesHn.del(e.id); showSaves() }) }
            ), "بستن")
        })
        v.addView(mbtn("بازگشت") { close() })
        setScreen("saves", v)
    }

    /** closes this screen but keeps the links: the lobby has changed to another game (the other game takes the phones over) */
    fun detach() {
        stopGame()
        net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
    }

    /** the host page of the main menu uses this game: its settings and players are shown there; this game's own screen opens when the game starts */
    fun hostInPage(room: String, name: String, ps: List<HandPeer>, box: LinearLayout, plist: LinearLayout, infoTv: TextView, k: Int) {
        val nt = NetHn(act, app, this); net = nt
        nt.adoptHostInPage(room, name, ps, box, plist, infoTv, k)
    }
    fun hostStartFromPage() { net?.startFromPage() }
    fun seatBack(): Boolean = net?.seatBack() ?: false
    fun hostState(): Triple<String, String, List<HandPeer>>? = net?.handoff()
    fun ensureHostShown() { show("blank") }

    /** a saved game chosen in the common list of saved games (against the robots) */
    fun resumeExternal(e: SavesHn.E) { show("blank"); resumeFrom(e) }
    fun resumeMultiExternal(e: SavesHn.E) { show("net"); net?.resumeSaved(e) }

    private fun resumeFrom(e: SavesHn.E) {
        try {
            val j = JSONObject(e.data)
            kind = j.getInt("kind"); pdraw = j.optBoolean("pdraw", true); n = players(kind); teams = teamsOf(kind); stake = j.optLong("stake", 100000L)
            if (!checkStake(kind, stake)) return
            role = "solo"; me = 0; for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
            val nm = j.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
            if (Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            val sc = j.getJSONArray("pts"); pts = IntArray(6) { if (it < sc.length()) sc.getInt(it) else 0 }
            hakem = j.optInt("hakem", -1)
            startGame()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده خراب است.") }
    }

    // ------------------------------------------------------------------ speaking, pacing, sounds

    private fun speak(t: String) {
        if (!Prefs.a11y) return
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logBox.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    /** a line of the log: shown for a few seconds and read by the screen reader (logNow of the four-player game) */
    private fun logNow(t: String) {
        if (!Prefs.a11y || !::logBox.isInitialized) return
        val d = tv(t, 13f)
        d.setPadding(0, Px.dp(3), 0, Px.dp(3))
        logBox.addView(d)
        speak(t)
        Sched.laterRaw(6000) { try { logBox.removeView(d) } catch (e: Exception) { } }
        while (logBox.childCount > 12) logBox.removeViewAt(0)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }
    private fun clearLog() { ui { if (::logBox.isInitialized) logBox.removeAllViews() } }

    /** log(t, min) of the four-player game: the line waits until the speech before it is done */
    private fun log(t: String, min: Long = 0L) {
        val d = Spk.slot(t, min)
        if (d > 0) Sched.later(d) { ui { logNow(t) } } else ui { logNow(t) }
    }
    private fun ann(t: String) { log(t) }

    private fun setMsg(t: String) { msg = t; msgF = null }
    private fun setMsgF(f: (Int) -> String) { msgF = f; msg = f(me) }
    private fun msgFor(seat: Int): String = msgF?.invoke(seat) ?: msg

    /** how the seat [s] is called by the seat [p]: "شما", the partner with (یار), or the name (who of the four-player game) */
    private fun who(s: Int, p: Int): String {
        val b = names[s]
        return if (s == p) "شما" else if (teams < n && teamOf(s) == teamOf(p)) "$b (یار)" else b
    }
    private fun lab(s: Int): String = who(s, me)

    /** a line for everybody, each seat gets its own wording; [skip] = the seat that does not get it (pub of the four-player game) */
    private fun pub(f: (Int) -> String, skip: Int = -1, clr: Boolean = false, min: Long = 0L) {
        if (clr) clearLog()
        if (skip != me) log(f(me), min)
        if (role == "host") for (sd in 0 until n) if (remote[sd] && sd != skip) net?.send(cidOf[sd], JSONObject().put("t", "log").put("x", f(sd)).put("clr", clr))
    }
    private fun pubTo(seat: Int, t: String) {
        if (seat == me) log(t) else if (isRemote(seat)) net?.send(cidOf[seat], JSONObject().put("t", "log").put("x", t).put("clr", false))
    }

    private fun idle(): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now())
    private fun say(m: String) { log(m); if (role == "host") sendAll(JSONObject().put("t", "say").put("m", m)) }
    private fun localSay(m: String) { log(m) }
    private fun draw() { ui { render() }; if (role == "host") sendStates() }
    private fun bannerAll(t: String) { ui { banner(t) }; if (role == "host") sendAll(JSONObject().put("t", "ban").put("m", t)) }
    private fun soundWait(): Long = Math.max(0L, Math.min(4000L, Sound.sq() - Sched.now()))
    private fun pace(ms: Long) {
        Thread.sleep(Math.max(Math.max(Anim.ad(ms), idle()), soundWait()))
        while (held && alive) Thread.sleep(300)      // paused: waiting for the host to press "ادامه بازی"
    }

    private fun startHold(t: String) {
        if (role != "host") return
        held = true
        holdTxt = t + " بازی متوقف است. برای ادامه، دکمه‌ی «ادامه بازی» را بزنید."
        ui { ann(holdTxt) }
        sendAll(JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
        draw()
    }

    private fun resumeHold() {
        if (!held) return
        held = false; holdTxt = ""
        sendAll(JSONObject().put("t", "hold").put("on", false))
        say("بازی ادامه پیدا کرد.")
    }
    private fun sndSeat(seat: Int, name: String) {
        if (seat == me) Sched.post { Sound.game(name) }
        else if (isRemote(seat)) net?.send(cidOf[seat], JSONObject().put("t", "snd").put("n", name))
    }
    private fun snd(name: String) { Sched.post { Sound.game(name) }; if (role == "host") sendAll(JSONObject().put("t", "snd").put("n", name)) }

    private fun banner(text: String) {
        val e = TextView(act)
        e.text = text; e.textSize = 26f; e.setTextColor(0xFFFFE36B.toInt()); e.setTypeface(e.typeface, Typeface.BOLD)
        e.gravity = Gravity.CENTER
        e.setPadding(Px.dp(22), Px.dp(14), Px.dp(22), Px.dp(14))
        e.background = Px.rounded(0xCC000000.toInt(), 16, 2, Px.GOLD)
        e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        e.alpha = 0f; e.scaleX = 0.5f; e.scaleY = 0.5f
        ov.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        e.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(Anim.ad(250L)).withEndAction {
            e.animate().alpha(0f).setStartDelay(Anim.ad(1300L)).setDuration(Anim.ad(350L)).withEndAction { try { ov.removeView(e) } catch (x: Exception) { } }.start()
        }.start()
    }

    // ------------------------------------------------------------------ the game screen

    private fun startGame() {
        resetChipVote()
        stopGame()
        held = false; holdTxt = ""
        shown = ArrayList(); msgF = null
        for (i in 0 until 6) hands[i] = ArrayList()
        Spk.reset()
        buildGameView()
        started = true; alive = true
        val t = Thread { try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { } }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun stopGame() { alive = false; myTurn = false; choosingTrump = false; worker?.interrupt(); worker = null; moveQ.clear() }

    private fun kv(label: String, value: String, valueColor: Int? = null): CharSequence {
        val sb = android.text.SpannableStringBuilder(label)
        val st = sb.length
        sb.append(value)
        sb.setSpan(android.text.style.StyleSpan(Typeface.BOLD), st, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (valueColor != null) sb.setSpan(android.text.style.ForegroundColorSpan(valueColor), st, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun applyBg() {
        val bmp = if (Prefs.bg > 0) Assets.bitmap(act, Assets.bgPath(Prefs.bg)) else null
        tableBox.background = if (bmp != null) CoverDrawable(bmp, 0x1F000000) else Px.rounded(Px.FELT, 16)
        tableBox.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, Px.dp(16).toFloat()) }
        }
        tableBox.clipToOutline = true
    }

    private fun buildGameView() {
        gameV = LinearLayout(act); gameV.orientation = LinearLayout.VERTICAL
        val more = LinearLayout(act); more.orientation = LinearLayout.HORIZONTAL
        more.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val mb = TextView(act)
        mb.text = "⋮"; mb.textSize = 26f; mb.setTextColor(Color.WHITE); mb.gravity = Gravity.CENTER
        mb.background = Px.rounded(0x59000000, 20)
        mb.contentDescription = "گزینه‌های بیشتر"
        mb.isClickable = true; mb.isFocusable = true
        mb.setOnClickListener { gameMenu() }
        more.addView(mb, LinearLayout.LayoutParams(Px.dp(40), Px.dp(40)))
        gameV.addView(more)
        // the line of numbers at the top, as in Hokm
        val top = FlowLayout(act, Px.dp(10), Px.dp(2))
        topTr = tv("", 14f); topHk = tv("", 14f); topSc = tv("", 14f); topTk = tv("", 14f)
        for (t in listOf(topTr, topHk, topSc, topTk)) top.addView(t)
        gameV.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin = Px.dp(6) })
        // the table: the other players around, the played cards in the middle, my box at the bottom
        tableBox = LinearLayout(act); tableBox.orientation = LinearLayout.VERTICAL
        tableBox.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        // a round table: the players sit around it, the cards of the trick lie in the middle
        roundW = Math.min(act.resources.displayMetrics.widthPixels - Px.dp(32), Px.dp(400))
        roundH = Px.dp(320)
        val roundBox = FrameLayout(act)
        roundBox.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val felt = View(act)
        felt.background = GradientDrawable().also { it.shape = GradientDrawable.OVAL; it.setColor(0x33000000); it.setStroke(Px.dp(2), 0x55FFE36B) }
        felt.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        roundBox.addView(felt, FrameLayout.LayoutParams((roundW * 0.74).toInt(), (roundH * 0.64).toInt(), Gravity.CENTER))
        seatLayer = FrameLayout(act)
        roundBox.addView(seatLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        mid = FrameLayout(act)   // the played cards stay readable by the screen reader: each card says who played it ("name: card")
        roundBox.addView(mid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tableBox.addView(roundBox, LinearLayout.LayoutParams(roundW, roundH).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        for (i in 0 until 6) {
            val b = LinearLayout(act); b.orientation = LinearLayout.VERTICAL; b.gravity = Gravity.CENTER
            b.layoutDirection = View.LAYOUT_DIRECTION_RTL
            pBox[i] = b
        }
        gameV.addView(tableBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        applyBg()
        keepNg = false
        msgBox = LinearLayout(act); msgBox.orientation = LinearLayout.VERTICAL; msgBox.gravity = Gravity.CENTER_HORIZONTAL
        msgBox.minimumHeight = Px.dp(44)
        msgTv = tv("", 14f); msgTv.gravity = Gravity.CENTER
        msgBox.addView(msgTv)
        gameV.addView(msgBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8); it.bottomMargin = Px.dp(8) })
        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL; ctl.gravity = Gravity.CENTER_HORIZONTAL
        gameV.addView(ctl)
        logScroll = ScrollView(act)
        logScroll.background = Px.rounded(0x11000000, 8)
        logScroll.setPadding(Px.dp(6), Px.dp(6), Px.dp(6), Px.dp(6))
        logBox = LinearLayout(act); logBox.orientation = LinearLayout.VERTICAL
        logScroll.addView(logBox)
        gameV.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(140)).also { it.topMargin = Px.dp(6); it.bottomMargin = Px.dp(6) })
        logScroll.visibility = View.GONE
        handBox = LinearLayout(act); handBox.orientation = LinearLayout.VERTICAL; handBox.gravity = Gravity.CENTER_HORIZONTAL
        gameV.addView(handBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        setScreen("game", gameV)
        buildHoldBar()
        applyA11y()
    }

    /** the bar at the bottom of the screen while the game is held (as in the four-player game) */
    private fun buildHoldBar() {
        if (::holdBar.isInitialized) { try { ov.removeView(holdBar) } catch (e: Exception) { } }
        holdBar = LinearLayout(act); holdBar.orientation = LinearLayout.VERTICAL; holdBar.gravity = Gravity.CENTER_HORIZONTAL
        holdBar.setBackgroundColor(0xFF222222.toInt())
        holdBar.setPadding(Px.dp(10), Px.dp(12), Px.dp(10), Px.dp(12))
        holdBar.layoutDirection = View.LAYOUT_DIRECTION_RTL
        holdTv = tv("", 15f, Color.WHITE); holdTv.gravity = Gravity.CENTER
        holdTv.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_ASSERTIVE
        holdBar.addView(holdTv)
        holdBtn = app.dlg.btn("ادامه بازی", false) { resumeHold() }
        holdBar.addView(holdBtn)
        holdBar.visibility = View.GONE
        ov.addView(holdBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
    }

    private fun holdUi() {
        if (!::holdBar.isInitialized) return
        if (!held || holdTxt.isEmpty()) { holdBar.visibility = View.GONE; return }
        holdTv.text = holdTxt
        holdBtn.visibility = if (role == "host") View.VISIBLE else View.GONE
        holdBar.visibility = if (screen == "game") View.VISIBLE else View.GONE
    }

    /** with announcements off the message box is hidden (as in the four-player game) */
    private fun applyA11y() {
        if (!::msgBox.isInitialized) return
        msgBox.visibility = if (Prefs.a11y || keepNg) View.VISIBLE else View.GONE
        if (::logScroll.isInitialized) logScroll.visibility = if (Prefs.a11y) View.VISIBLE else View.GONE
    }

    /** the game is over: the message and the button "بازی جدید" (the guest has none) */
    private fun showNewGameButton(text: String) {
        keepNg = true
        msgBox.removeAllViews()
        if (text.isNotEmpty()) { msgTv.text = text; msgBox.addView(msgTv) }
        val b = app.dlg.btn("بازی جدید", false) { newGame() }
        b.tag = "newgame"
        msgBox.addView(b)
        applyA11y()
    }

    /** where the card of the player at relative position [rel] (0 = me) lies in the middle of the table */
    private fun midGravity(rel: Int): Int {
        if (rel == 0) return Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        val others = n - 1
        // the others from my left to my right: the first on the left edge, the last on the right edge, the rest on top
        return when {
            others == 1 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            rel == 1 -> Gravity.LEFT or Gravity.CENTER_VERTICAL
            rel == others -> Gravity.RIGHT or Gravity.CENTER_VERTICAL
            else -> Gravity.TOP or (if (others == 3 || rel == (others + 1) / 2) Gravity.CENTER_HORIZONTAL else if (rel < (others + 1) / 2) Gravity.LEFT else Gravity.RIGHT)
        }
    }

    /** the name of a side in the line of the points: "شما+یار | حریف" in the six-player game of two teams, every name otherwise */
    private fun sideName(t: Int): String {
        val mine = t == teamOf(me)
        if (teams == n) return if (mine) "شما" else names[t]
        if (teams == 2) return if (mine) (if (n / teams == 2) "شما+یار" else "شما+یاران") else "حریف"
        return if (mine) "شما+یار" else teamName(t)
    }

    /** the card of an ace to choose the trump by (as in the four-player game) */
    private fun trumpCardView(i: Int, fn: () -> Unit): View {
        val b = FrameLayout(act)
        b.addView(app.cardImage(Card(i, 14), Px.dp(64)))
        b.contentDescription = "انتخاب حکم " + Cards.SN[i]
        b.isClickable = true; b.isFocusable = true
        b.setOnClickListener { fn() }
        b.tag = "pick"
        return b
    }

    private fun render() {
        if (screen != "game" || !::topTr.isInitialized) return
        val red = trump == 1 || trump == 2
        topTr.text = kv("حکم: ", if (trump < 0) "—" else Cards.SU[trump] + " " + Cards.SN[trump], if (red) 0xFFEE3344.toInt() else null)
        topHk.text = kv("حاکم: ", if (hakem in 0 until n) names[hakem] else "—")
        topSc.text = android.text.SpannableStringBuilder("دست: ").also { sb ->
            for (t in 0 until teams) { if (t > 0) sb.append(" | "); sb.append(sideName(t) + " "); sb.append(kv("", Cards.fa(pts[t]))) }
        }
        topTk.text = android.text.SpannableStringBuilder("این دست: ").also { sb ->
            for (t in 0 until teams) { if (t > 0) sb.append(" - "); sb.append(kv("", Cards.fa(tricksWon[t]))) }
        }
        if (!keepNg) msgTv.text = msg
        applyA11y()
        val rug = Prefs.bg > 0
        val dt = ArrayList(if (trick.isNotEmpty()) trick else shown)
        // the players sit around the round table: I am at the bottom, the others follow clockwise (my left first)
        seatLayer.removeAllViews()
        val sw = IntArray(n); val sh = IntArray(n)
        for (rel in 0 until n) {
            val i = (me + rel) % n
            val p = pBox[i]!!
            p.removeAllViews()
            val act_ = turn == i
            val pc = dt.firstOrNull { it.seat == i }
            val nt = TextView(act)
            val mate = if (teams < n && i != me && teamOf(i) == teamOf(me)) " (یار)" else ""
            nt.text = (if (i == me) "شما" else names[i] + mate) + (if (i == hakem) " 👑" else "")
            nt.textSize = 11f
            nt.setTextColor(if (act_) 0xFFFFE36B.toInt() else Color.WHITE)
            if (act_) nt.setTypeface(nt.typeface, Typeface.BOLD)
            nt.setPadding(Px.dp(6), Px.dp(2), Px.dp(6), Px.dp(2))
            nt.background = Px.rounded(if (rug) 0x99000000.toInt() else 0x33000000, 8)
            if (Prefs.a11y && pc != null) nt.contentDescription = nt.text.toString() + ": " + Cards.cname(pc.c)
            p.addView(Av.view(act, if (i == me) Av.me() else names[i], if (n > 4) 34 else 44, act_ || (choosingTrump && hakem == i), act_))
            p.addView(nt)
            if (i != me) p.addView(app.fanView(hands[i].size, true))
            (p.parent as? ViewGroup)?.removeView(p)
            p.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            sw[i] = p.measuredWidth; sh[i] = p.measuredHeight
            val th = Math.PI / 2 + 2 * Math.PI * rel / n          // 0 = bottom, then clockwise (left, top, right)
            val rx = roundW / 2.0 - p.measuredWidth / 2.0 - Px.dp(2)
            val ry = roundH / 2.0 - p.measuredHeight / 2.0 - Px.dp(2)
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.LEFT)
            lp.leftMargin = Math.max(0, (roundW / 2.0 + rx * Math.cos(th) - p.measuredWidth / 2.0).toInt())
            lp.topMargin = Math.max(0, (roundH / 2.0 + ry * Math.sin(th) - p.measuredHeight / 2.0).toInt())
            seatLayer.addView(p, lp)
        }
        // the cards played in this trick lie towards the player who played them
        mid.removeAllViews()
        for (t in dt) {
            val slot = FrameLayout(act)
            if (winSeat >= 0 && winSeat == t.seat && dt.size == n) slot.background = Px.rounded(Color.TRANSPARENT, 6, 3, Px.GOLD)
            val rel = (t.seat - me + n) % n
            val cw = Px.dp(if (n > 4) 42 else 50)
            slot.addView(app.cardImage(t.c, cw))
            if (Prefs.a11y) { slot.contentDescription = (if (t.seat == me) "شما" else names[t.seat]) + ": " + Cards.cname(t.c); slot.isFocusable = true }
            val th = Math.PI / 2 + 2 * Math.PI * rel / n
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.LEFT)
            val pw = Math.max(1, sw[t.seat]).toDouble(); val ph = Math.max(1, sh[t.seat]).toDouble()
            val sRx = roundW / 2.0 - pw / 2.0 - Px.dp(2); val sRy = roundH / 2.0 - ph / 2.0 - Px.dp(2)
            val sx = roundW / 2.0 + sRx * Math.cos(th); val sy = roundH / 2.0 + sRy * Math.sin(th)      // centre of the seat
            val vx = -sRx * Math.cos(th); val vy = -sRy * Math.sin(th)                                  // from the seat towards the table centre
            val dist = Math.hypot(vx, vy)
            val nx = if (dist > 0) vx / dist else 0.0; val ny = if (dist > 0) vy / dist else -1.0
            val chh = cw * 1.4
            fun ext(w: Double, h: Double) = Math.min((w / 2) / Math.max(Math.abs(nx), 1e-6), (h / 2) / Math.max(Math.abs(ny), 1e-6))
            val tt = Math.min(ext(pw, ph) + ext(cw.toDouble(), chh) + Px.dp(2), dist)
            lp.leftMargin = Math.max(0, (sx + nx * tt - cw / 2.0).toInt())
            lp.topMargin = Math.max(0, (sy + ny * tt - chh / 2.0).toInt())
            mid.addView(slot, lp)
        }
        if (asideN > 0) mid.addView(app.pileView(asideN), FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.LEFT or Gravity.TOP).also { it.setMargins(Px.dp(8), Px.dp(8), 0, 0) })
        // my hand
        handBox.removeAllViews()
        handViews.clear()
        val myHand = Cards.sorted2(hands[me])
        val playable = HokmRules.legal(hands[me], trick)
        val w = FlowLayout(act, Px.dp(4), Px.dp(4))
        for (c in myHand) {
            val legal = myTurn && playable.contains(c)
            val b = FrameLayout(act)
            b.addView(app.cardImage(c, Px.dp(if (hands[me].size > 10) 42 else 50)))
            b.contentDescription = Cards.cname(c) + (if (c.s == trump) "، حکم" else "") + (if (legal) "" else "، قابل بازی نیست")
            b.isFocusable = true
            if (legal) { b.isClickable = true; b.background = Px.rounded(Color.TRANSPARENT, 7, 2, Px.GOLD); b.setOnClickListener { playCard(c) } }
            else { b.alpha = 0.45f; b.isEnabled = false }
            w.addView(b); handViews.add(b)
        }
        if (hidesHand()) { handBox.removeAllViews(); handViews.clear(); handBox.addView(app.fanView(hands[me].size, true)) }
        else handBox.addView(w)
        // the pause bar (host: with the button), then the trump choice
        ctl.removeAllViews()
        holdUi()
        if (choosingTrump) {
            ctl.addView(tv("حکم را انتخاب کنید:", 15f).also { it.gravity = Gravity.CENTER })
            val row = FlowLayout(act, Px.dp(12), Px.dp(8))
            for (sd in 0 until 4) row.addView(trumpCardView(sd) { if (choosingTrump) { if (role == "client") { choosingTrump = false; net?.toHost(JSONObject().put("t", "ans").put("m", "t" + sd)) } else moveQ.offer("t" + sd) } })
            ctl.addView(row)
        }
        postFx()
    }

    private fun playCard(c: Card) {
        if (!myTurn) return
        if (held && role == "host") { ann("بازی متوقف است؛ ابتدا «ادامه بازی» را بزنید."); return }
        val i = hands[me].indexOf(c)
        if (i < 0) return
        myTurn = false
        if (role == "client") net?.toHost(JSONObject().put("t", "ans").put("m", "c" + i)) else moveQ.offer("c" + i)
        render()
    }

    // ------------------------------------------------------------------ menu inside the game

    private fun gameMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (role != "client") items.add("بازی جدید" to { app.dlg.confirm("بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.", { newGame() }) })
        items.add("تغییر نام" to { renameAsk() })
        if (role == "host") {
            if ((1 until n).any { !remote[it] }) items.add("افزودن بازیکن" to { addAsk() })
            if ((1 until n).any { remote[it] }) {
                items.add("حذف بازیکن" to { kickAsk() })
                items.add("انتقال میزبانی" to { xferAsk() })
            }
        }
        if (role != "client") items.add("ذخیره" to { manualSave() })
        if (started && !keepNg && stake > 0L) items.add("تغییر ژتون" to { chipAsk() })
        items.add(("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) to { app.a11yToggle(); applyA11y() })
        items.add("سرعت انیمیشن" to { app.animSpeedAsk() })
        items.add("تنظیمات صدا" to { app.dlg.sound() })
        items.add("تنظیمات تصویر زمینه" to { app.dlg.cards("bg") { applyBg() } })
        items.add("تنظیمات پشت کارت" to { app.dlg.cards("back") { render() } })
        items.add("خروج" to { if (role == "host") exitHostAsk() else app.quitAskPublic() })
        app.dlg.list("گزینه‌های بیشتر", items)
    }

    /** "بازی جدید": against the robots the page of the new game opens (game type and settings), as in the four-player game; the host goes back to the room where the phones stay connected */
    private fun newGame() {
        stopGame()
        keepNg = false
        try { SavesHn.del("auto") } catch (e: Exception) { }
        if (role == "host") { app.hostPageAfterGame("hn"); return }
        close()
        app.newGamePage()
    }

    private fun renameAsk() {
        app.dlg.nameAsk(true) { v ->
            val nm = v.trim()
            if (nm.isNotEmpty()) { Prefs.name = nm; val l = names.toMutableList(); l[me] = nm; names = l; draw() }
        }
    }

    // ------------------------------------------------------------------ the game (worker thread)

    private fun outSuits(): List<Int> = when (n) { 3 -> listOf(2); 5 -> listOf(2, 3); else -> listOf(0, 1, 2, 3) }

    /** the 2s taken out of the pack appear in the middle of the table, are shown one after the other and put aside (as in the two-player Hokm) */
    private fun flyAside(out: List<Card>): Long {
        if (!::mid.isInitialized || mid.width == 0) { Sound.cardSnd(); return Anim.ad(600L) }
        val o = loc(ov); val m = loc(mid)
        val w = Px.dp(52); val h = Px.dp(76)
        val cx = m[0] - o[0] + mid.width / 2f; val cy = m[1] - o[1] + mid.height / 2f
        val px = m[0] - o[0] + Px.dp(30).toFloat(); val py = m[1] - o[1] + Px.dp(40).toFloat()
        val gap = Px.dp(58)
        val ap = Anim.ad(260L); val ho = Anim.ad(550L); val fl = Anim.ad(650L)
        var tot = 0L
        out.forEachIndexed { i, cd ->
            val bmp = Assets.bitmap(act, Assets.cardPath(cd)) ?: return@forEachIndexed
            val d = Anim.ad(420L) * i
            tot = Math.max(tot, d + ap + ho + fl + Anim.ad(160L))
            val iv = ImageView(act)
            iv.setImageBitmap(bmp)
            iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
            ov.addView(iv, lp)
            iv.x = cx + (i - (out.size - 1) / 2f) * gap - w / 2f; iv.y = cy - h / 2f
            iv.alpha = 0f; iv.scaleX = 0.5f; iv.scaleY = 0.5f
            val rot = (if (i % 2 == 1) 1f else -1f) * 12f
            Sched.later(Math.max(0L, d + ap + ho + fl - Sound.CSO)) { Sound.cardSnd() }
            iv.animate().setStartDelay(d).alpha(1f).scaleX(1.1f).scaleY(1.1f).setDuration(ap).withEndAction {
                iv.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(Anim.ad(120L)).withEndAction {
                    iv.animate().setStartDelay(ho).x(px - w / 2f).y(py - h / 2f).scaleX(0.4f).scaleY(0.4f).rotation(rot)
                        .setInterpolator(android.view.animation.PathInterpolator(0.42f, 0f, 0.58f, 1f)).setDuration(fl).withEndAction {
                            iv.animate().setStartDelay(0).alpha(0f).setDuration(Anim.ad(160L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
                        }.start()
                }.start()
            }.start()
        }
        return tot
    }

    private fun asideStart() {
        val out = outSuits().map { Card(it, 2) }
        val ids = JSONArray(); out.forEach { ids.put(Cards.idc(it)) }
        val nm = out.size
        val at = (if (nm == 1) "یک کارت دو" else Cards.fa(nm) + " کارت دو") + " کنار گذاشته شد."
        setMsg(at); draw()
        say(at)
        if (role == "host") sendAll(JSONObject().put("t", "aside").put("c", ids))
        var tot = 0L
        uiWait { tot = flyAside(out) }
        pace(tot + Anim.ad(60L))
        asideN = nm; draw()
        pace(Anim.ad(540L))
    }

    private fun loop() {
        if (hakem >= 0) asideN = outSuits().size
        if (hakem < 0) {
            asideN = 0
            hakemDraw(); if (!alive) return
            if ((0 until 6).all { pts[it] == 0 }) { asideStart(); if (!alive) return }
        }
        while (alive) {
            playRound()
            if (!alive) return
            val best = (0 until teams).maxByOrNull { pts[it] } ?: 0
            if (pts[best] >= TARGET) { finish(best); return }
            saveAuto()
        }
    }

    /** the deck of this game: the 2s that are not played are taken out (diamonds first, then clubs, hearts, spades) */
    private fun deckCards(): MutableList<Card> {
        val out = when (n) { 3 -> listOf(2); 5 -> listOf(2, 3); else -> listOf(0, 1, 2, 3) }
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 2..14) if (!(r == 2 && out.contains(s))) d.add(Card(s, r))
        return d
    }
    private fun buildDeck(): MutableList<Card> = Cards.shuf(deckCards())

    /** the trump and the first turn wait until the dealing (its recorded sound) is over, as in the four-player game */
    private fun waitDeal() { var w = Deal.wait(); while (w > 0 && alive) { Thread.sleep(Math.min(w, 300L)); w = Deal.wait() } }

    private fun firstSize(): Int = if (n == 6) 4 else 5

    private fun waitFor(l: CountDownLatch, sec: Long) { try { l.await(sec, java.util.concurrent.TimeUnit.SECONDS) } catch (e: InterruptedException) { throw e } }

    // ---- the draw for the hakem: cards are dealt face up until the first ace (the same scene as in the four-player game)

    private fun sendDraw(D: Draw.D) {
        if (role != "host") return
        for (sd in 0 until n) if (remote[sd]) {
            val rl = { p: Int -> (p - sd + n) % n }
            val o = JSONObject().put("t", "drw").put("n", n)
            o.put("seq", JSONArray().also { a -> D.seq.forEach { a.put(JSONObject().put("p", rl(it.p)).put("c", Cards.idc(it.c))) } })
            o.put("h", rl(D.h)).put("i1", D.i1).put("i2", D.i2)
            o.put("pl", JSONArray().also { a -> D.pl.forEach { a.put(rl(it)) } })
            o.put("il", JSONArray().also { a -> D.il.forEach { a.put(it) } })
            o.put("mv", JSONArray().also { a -> for (r in 0 until n) a.put(if (D.mv.size > (sd + r) % n) rl(D.mv[(sd + r) % n]) else r) })
            o.put("nm", JSONArray().also { a -> for (r in 0 until n) a.put(if ((sd + r) % n == sd) "شما" else names[(sd + r) % n]) })
            net?.send(cidOf[sd], o)
        }
    }

    private fun drawSay(t: String, q: Boolean) { ui { msg = t; if (!q) logNow(t); render() } }

    private fun hakemDraw() {
        val D = if ((kind == 62 || kind == 63) && pdraw) Draw.genDraw6(kind) else Draw.genDraw(n, false)
        hakem = D.h
        sendDraw(D)
        val labs = List(n) { if (it == me) "شما" else names[it] }
        val l = CountDownLatch(1)
        ui { try { Fx.drawScene(D, labs, { l.countDown() }, null) { t, q -> drawSay(t, q) } } catch (e: Exception) { l.countDown() } }
        waitFor(l, 90)
        if (D.pl.isNotEmpty()) applyReseat(D.mv)
        setMsg(""); draw()
    }

    /** the seats move so that the partners of the hakem sit where the teams are (me stays at seat 0); [to][r] = the new seat of the player at r */
    private fun applyReseat(to: IntArray) {
        if ((0 until n).all { to[it] == it }) return
        val nm = names.toMutableList(); val rm = remote.copyOf(); val cd = cidOf.copyOf(); val id = idOf.copyOf()
        for (o in 0 until n) { nm[to[o]] = names[o]; remote[to[o]] = rm[o]; cidOf[to[o]] = cd[o]; idOf[to[o]] = id[o] }
        names = nm
        hakem = to[hakem]
    }

    // ---- shuffling (as newHand of the four-player game)

    private fun shuffleScene() {
        val again = pts.any { it != 0 }
        val l = CountDownLatch(1)
        ui {
            try {
                Fx.shufThen({ Sound.psnd("shuffle", true) { if (again) pub({ p -> "دور جدید. حاکم: " + who(hakem, p) + "." }, -1, true) } }) { l.countDown() }
            } catch (e: Exception) { l.countDown() }
        }
        if (role == "host") sendAll(JSONObject().put("t", "shf"))
        waitFor(l, 25)
    }

    private fun playRound() {
        setMsg(""); trump = -1; trick = ArrayList(); shown = ArrayList(); winSeat = -1; seen = HashSet(); plays.clear()
        for (v in void) java.util.Arrays.fill(v, false)
        java.util.Arrays.fill(tricksWon, 0)
        for (i in 0 until 6) hands[i] = ArrayList()
        turn = -1
        val deck = buildDeck()
        Deal.reset()
        draw()
        shuffleScene()
        if (!alive) return
        // the first series, then the hakem chooses the trump
        val first = firstSize()
        val size = handSize()
        val series = if (n == 5) 5 else 4
        var di = 0
        for (k in 0 until n) { val s = (hakem + k) % n; for (x in 0 until first) hands[s].add(deck[di++]) }
        clearLog()
        setMsg(if (hakem == me) "" else names[hakem] + " حاکم است و حکم را انتخاب می‌کند...")
        draw(); pace(900)
        chooseTrump()
        if (!alive) return
        while (hands[hakem].size < size) {
            for (k in 0 until n) { val s = (hakem + k) % n; val give = Math.min(series, size - hands[s].size); for (x in 0 until give) hands[s].add(deck[di++]) }
        }
        pub({ p -> "کارت‌های شما: " + Cards.handText(hands[p]) + "." })
        draw(); pace(900)
        waitDeal()
        // the tricks: exactly as in the four-player Hokm. The first side to reach 7 tricks wins the round; if the others have
        // no trick at that moment it is a kot (the round goes on: it ends when another side takes a trick, or as a bam when
        // the side takes all the tricks).
        var leader = hakem
        var kt = -1
        var winSide = -1
        val reachedAt = IntArray(6)          // the trick at which a side got its present number of tricks
        for (t in 0 until size) {
            if (!alive) return
            val w = playTrick(leader)
            if (!alive) return
            reachedAt[lastWinnerTeam] = t
            leader = w
            val hs = (0 until teams).firstOrNull { tricksWon[it] >= 7 } ?: -1
            if (hs >= 0) {
                val othersZero = (0 until teams).all { it == hs || tricksWon[it] == 0 }
                if (othersZero && kt < 0) kt = hs
                if (!othersZero || tricksWon[hs] == size) { winSide = hs; break }
            }
            if (t < size - 1) trickReport(w)
        }
        if (winSide < 0) {      // nobody reached 7 (possible with 3, 5 and 6 players): the side with most tricks; in a tie the one who reached that number first
            val mx = tricksWon.take(teams).maxOrNull() ?: 0
            val tied = (0 until teams).filter { tricksWon[it] == mx }
            winSide = tied.minByOrNull { reachedAt[it] } ?: tied[0]
        }
        val t = winSide
        val hk = teamOf(hakem)
        val bam = tricksWon[t] == size
        val kot = bam || kt == t
        val gain = HokmRules.gain(kot, t == hk)
        pts[t] += gain
        if (bam) pts[t] = Math.max(pts[t], TARGET)
        val gm = pts[t] >= TARGET
        val bn = HokmRules.bamName(t == hk)
        val mf = { p: Int -> roundText(t, p, bam, bn, gm, kot, hk) }
        lastMf = mf
        if (t != hk) hakem = (hakem + 1) % n
        turn = -1; draw()
        // every guest hears the end of the hand in his own words
        for (sd in 0 until n) if (isRemote(sd)) net?.send(cidOf[sd], JSONObject().put("t", "es").put("w", teamOf(sd) == t).put("kot", kot).put("gm", gm).put("x", mf(sd)))
        val won = t == teamOf(me)
        if (gm) {
            Sound.endSnd(if (won) 0 else 1, kot, gm) { ui { log(mf(me)) } }
            val l = CountDownLatch(1)
            Sound.afterSnd { l.countDown() }
            waitFor(l, 25)
        } else {
            Sound.endSnd(if (won) 0 else 1, kot, gm) { ui { setMsgF(mf); render(); log(mf(me)) } }
            Thread.sleep(if (Sound.on) 4600L else 3300L)
        }
    }

    /** the words about the end of a hand, from the view of seat [p] */
    private fun roundText(t: Int, p: Int, bam: Boolean, bn: String, gm: Boolean, kot: Boolean, hk: Int): String {
        return HokmRules.roundText(t == teamOf(p), teams, n, teamName(t), bam, bn, gm, kot, t == hk)
    }

    private fun robotTrump(h: List<Card>): Int {
        var best = 0; var bs = -1.0
        for (sd in 0 until 4) {
            val cs = h.filter { it.s == sd }
            val sc = cs.sumOf { when (it.r) { 14 -> 5.0; 13 -> 4.0; 12 -> 3.0; 11 -> 2.0; 10 -> 1.5; else -> 0.5 } } + 2.5 * cs.size + (if (cs.size >= 4) 2.0 else 0.0)
            if (sc > bs) { bs = sc; best = sd }
        }
        return best
    }

    private fun chooseTrump() {
        var picked = -1
        val fw = if (firstSize() == 5) "پنج" else "چهار"
        val intro = "شما حاکم هستید. " + fw + " کارت اول شما: " + Cards.handText(hands[hakem]) + ". حکم را انتخاب کنید."
        if (hakem == me) {
            choosingTrump = true; setMsg(""); draw()
            log(intro)
            while (picked < 0 && alive) { val a = moveQ.take(); while (held && alive) Thread.sleep(300); if (a.startsWith("t")) picked = a.substring(1).toIntOrNull() ?: -1 }
            choosingTrump = false
        } else if (isRemote(hakem)) {      // the hakem is a person on another phone
            setMsg(names[hakem] + " حاکم است و حکم را انتخاب می‌کند...")
            pubTo(hakem, intro)
            ansQ[hakem].clear(); waitSeat = hakem; waitTrump = true; draw()
            while (picked < 0 && alive) {
                val a = ansQ[hakem].take()
                if (a != "drop") while (held && alive) Thread.sleep(300)
                if (a == "drop") break
                if (a.startsWith("t")) { val v = a.substring(1).toIntOrNull() ?: -1; if (v in 0..3) picked = v }
            }
            waitSeat = -1; waitTrump = false
        } else {
            pace(1200)
        }
        if (picked !in 0..3) {
            // the trump is chosen by playing whole rounds out with every suit as the trump
            picked = try { HokmAI(n, kind, 0, hakem).chooseTrump(hakem, ArrayList(hands[hakem]), deckCards(), handSize()) }
                catch (e: Exception) { try { HokmSim(n, kind, 0, hakem).chooseTrump(hakem, ArrayList(hands[hakem]), deckCards(), handSize()) } catch (e2: Exception) { robotTrump(hands[hakem]) } }
        }
        if (!alive) return
        waitDeal()
        if (!alive) return
        trump = picked
        ui { Fx.trumpFlash(picked) }
        if (role == "host") sendAll(JSONObject().put("t", "tfl").put("s", picked))
        pub({ p -> "حکم: " + Cards.SN[picked] + (if (hakem == p) "." else " (انتخاب " + who(hakem, p) + ").") })
        draw()
    }

    private fun beats(a: Card, b: Card): Boolean = HokmRules.beats(a, b, trump)

    private fun winnerOf(t: List<TC>): TC = HokmRules.winnerOf(t, trump)

    /** the sound of a finished trick (the next turn waits for it) */
    private fun trickSound(mine: Boolean) {
        Sound.TBU = Sched.now() + Anim.ad(1000L) + (if (Sound.on) (if (mine) Sound.EST["trick"]!! else Sound.EST["tlose"]!!).toLong() else Anim.ad(400L))
        Sched.later(Anim.ad(1000L)) { Sound.psnd(if (mine) "trick" else "tlose", true) }
    }

    private fun tally(p: Int): String {
        val tp = teamOf(p)
        if (teams == 2) return HokmRules.tallyTeams(tricksWon[tp], tricksWon[1 - tp])
        return "دست‌ها: " + (0 until teams).joinToString("، ") { (if (it == tp) "شما" else teamName(it)) + " " + tricksWon[it] } + "."
    }

    /** the words and the sound after a trick that did not end the hand */
    private fun trickReport(w: Int) {
        val wt = teamOf(w)
        for (sd in 0 until n) if (isRemote(sd)) net?.send(cidOf[sd], JSONObject().put("t", "tsn").put("w", teamOf(sd) == wt))
        trickSound(teamOf(me) == wt)
        val wf = { p: Int -> HokmRules.trickText(who(w, p), w == p, tally(p)) }
        val wmin = Anim.ad(1000L)
        pub(wf, -1, false, wmin)
        Thread.sleep(wmin)
        setMsgF(wf); draw()
    }

    private fun playTrick(leader: Int): Int {
        trick = ArrayList()
        for (k in 0 until n) {
            if (!alive) return leader
            val seat = (leader + k) % n
            turn = seat
            var c: Card? = null
            val wd = Math.max(Sound.TBU, Spk.end) - Sched.now()
            val lead = if (trick.isEmpty()) "شما شروع می‌کنید." else "خال زمین: " + Cards.SN[trick[0].c.s] + "."
            if (isRemote(seat)) {
                setMsg("")
                pubTo(seat, "نوبت شماست. " + lead)
                if (wd > 0) Thread.sleep(wd + Anim.ad(150L))
                while (c == null && alive) {
                    ansQ[seat].clear(); waitSeat = seat; draw()
                    val a = ansQ[seat].take()
                    if (a != "drop") while (held && alive) Thread.sleep(300)
                    if (a == "drop") break
                    if (a.startsWith("c")) {
                        val i = a.substring(1).toIntOrNull() ?: -1
                        if (i in hands[seat].indices) {
                            val pk = hands[seat][i]
                            if (HokmRules.legal(hands[seat], trick).contains(pk)) c = pk
                        }
                    }
                }
                waitSeat = -1
                if (c == null) { draw(); pace(600); c = botCard(seat) }      // he left: a robot plays his card
            } else if (seat == me) {
                setMsg("نوبت شماست."); draw()
                log("نوبت شماست. " + lead)
                if (wd > 0) Thread.sleep(wd + Anim.ad(150L))
                myTurn = true; draw()
                var pick: Card? = null
                while (pick == null && alive) {
                    val a = moveQ.take()
                    while (held && alive) Thread.sleep(300)
                    if (a.startsWith("c")) { val i = a.substring(1).toInt(); if (i in hands[me].indices) pick = hands[me][i] }
                    if (pick != null && !HokmRules.legal(hands[me], trick).contains(pick)) { pick = null; myTurn = true; draw() }
                }
                myTurn = false
                c = pick ?: return leader
            } else {
                setMsg(""); draw()
                val d = Math.max(if (shown.isNotEmpty()) 1000L else 600L, Math.max(Sound.TBU - Sched.now() + Anim.ad(250L), Spk.end - Sched.now() + Anim.ad(100L)))
                Thread.sleep(d)
                while (held && alive) Thread.sleep(300)
                c = botCard(seat)
            }
            val card = c ?: return leader
            if (shown.isNotEmpty()) { shown = ArrayList(); winSeat = -1 }      // the cards of the last trick were taken by their winner a second after it ended (postTable)
            if (trick.isNotEmpty() && card.s != trick[0].c.s) void[seat][trick[0].c.s] = true
            run { val bw = if (trick.isEmpty()) null else winnerOf(trick); plays.add(AiPlay(seat, card, if (trick.isEmpty()) -1 else trick[0].c.s, trick.size, bw?.seat ?: -1, bw?.c)) }
            pub({ p -> who(seat, p) + " " + Cards.cname(card) + (if (seat == p) " بازی کردید" else " بازی کرد") + (if (card.s == trump) " (حکم)." else ".") },
                seat, trick.isEmpty(), Math.max(0L, Anim.ad(360L) - Sound.CSO))
            hands[seat].remove(card)
            val nt = ArrayList(trick); nt.add(TC(seat, card)); trick = nt
            seen.add(Cards.idc(card))
            draw()
            Thread.sleep(Anim.ad(360L))
        }
        val w = winnerOf(trick)
        lastWinnerTeam = teamOf(w.seat)
        tricksWon[lastWinnerTeam]++
        winSeat = w.seat
        shown = ArrayList(trick); trick = ArrayList(); turn = w.seat
        draw()
        return w.seat
    }

    // ---- the robots
    // A robot tries each card it may play on many random deals of the cards nobody has shown (every opponent keeps
    // the number of cards he has and none in a suit he did not follow); every player of the simulation plays by the
    // rule policy below, and the card that wins the round most often is chosen.

    private fun isTop(h: List<Card>, c: Card, sn: Set<Int>): Boolean =
        (c.r + 1..14).all { r -> sn.contains(c.s * 20 + r) || h.any { it.s == c.s && it.r == r } }

    /** the rule policy: the card [seat] plays holding [h] when [tr] is already on the table */
    private fun policy(seat: Int, h: List<Card>, tr: List<TC>, sn: Set<Int>): Card {
        if (tr.isEmpty()) return leadPolicy(seat, h, sn)
        val led = tr[0].c.s
        val following = h.any { it.s == led }
        val legal = HokmRules.legal(h, tr).toList()
        val my = teamOf(seat)
        val w = winnerOf(tr)
        val partnerWins = teamOf(w.seat) == my
        if (following) {
            if (partnerWins) return legal.minByOrNull { it.r }!!
            val beat = legal.filter { beats(it, w.c) }.sortedBy { it.r }
            return if (beat.isNotEmpty()) beat[0] else legal.minByOrNull { it.r }!!
        }
        val trumps = h.filter { it.s == trump }
        val others = h.filter { it.s != trump }
        if (partnerWins) return (if (others.isNotEmpty()) others else h).minByOrNull { it.r }!!
        if (trumps.isNotEmpty()) {
            val bt = trumps.filter { beats(it, w.c) }.sortedBy { it.r }
            if (bt.isNotEmpty()) return bt[0]
        }
        return (if (others.isNotEmpty()) others else h).minByOrNull { it.r }!!
    }

    private fun leadPolicy(seat: Int, h: List<Card>, sn: Set<Int>): Card {
        val nonTrump = h.filter { it.s != trump }
        val tops = nonTrump.filter { isTop(h, it, sn) }.sortedByDescending { it.r }
        if (tops.isNotEmpty()) return tops[0]
        val tr = h.filter { it.s == trump }
        if (tr.isNotEmpty() && teamOf(seat) == teamOf(hakem)) {
            val topTr = tr.filter { isTop(h, it, sn) }
            if (topTr.isNotEmpty()) return topTr.maxByOrNull { it.r }!!
        }
        if (nonTrump.isNotEmpty()) {
            val longest = nonTrump.groupBy { it.s }.maxByOrNull { it.value.size }!!.value
            return longest.minByOrNull { it.r }!!
        }
        return tr.minByOrNull { it.r }!!
    }

    /** a random deal of the unseen cards to the other players, with the known numbers of cards and voids */
    private fun sampleHands(seat: Int, unseen: List<Card>): Array<MutableList<Card>> {
        val need = IntArray(n) { if (it == seat) 0 else hands[it].size }
        for (attempt in 0 until 12) {
            val pool = unseen.shuffled()
            val out = Array(n) { ArrayList<Card>() as MutableList<Card> }
            var ok = true
            for (c in pool) {
                val cand = (0 until n).filter { it != seat && out[it].size < need[it] && !void[it][c.s] }
                if (cand.isEmpty()) { ok = false; break }
                out[cand[(Math.random() * cand.size).toInt()]].add(c)
            }
            if (ok) return out
        }
        val pool = unseen.shuffled()
        val out = Array(n) { ArrayList<Card>() as MutableList<Card> }
        var k = 0
        for (sd in 0 until n) if (sd != seat) for (x in 0 until need[sd]) if (k < pool.size) out[sd].add(pool[k++])
        return out
    }

    /** play [first] now and then the rest of the round by the policy: 1 plus a little when [seat]'s side wins the round */
    private fun rollout(seat: Int, first: Card, dealt: Array<MutableList<Card>>): Double {
        val hs = Array(n) { ArrayList<Card>(dealt[it]) }
        hs[seat] = ArrayList(hands[seat]); hs[seat].remove(first)
        var tr = ArrayList(trick)
        val sn = HashSet(seen)
        val tw = tricksWon.copyOf()
        val reached = IntArray(6)
        var cnt = 0
        tr.add(TC(seat, first)); sn.add(Cards.idc(first))
        var winSide = -1
        while (true) {
            while (tr.size < n) {
                val s2 = (tr[0].seat + tr.size) % n
                val c2 = policy(s2, hs[s2], tr, sn)
                hs[s2].remove(c2); tr.add(TC(s2, c2)); sn.add(Cards.idc(c2))
            }
            val w = winnerOf(tr)
            val ws = teamOf(w.seat)
            tw[ws]++; reached[ws] = ++cnt
            val h7 = (0 until teams).firstOrNull { tw[it] >= 7 } ?: -1
            if (h7 >= 0) {
                val oz = (0 until teams).all { it == h7 || tw[it] == 0 }
                if (!oz || tw[h7] == handSize()) { winSide = h7; break }
            }
            if (hs[w.seat].isEmpty()) break
            tr = ArrayList()
            val c0 = policy(w.seat, hs[w.seat], tr, sn)
            hs[w.seat].remove(c0); tr.add(TC(w.seat, c0)); sn.add(Cards.idc(c0))
        }
        if (winSide < 0) {
            val mx = tw.take(teams).maxOrNull() ?: 0
            val tied = (0 until teams).filter { tw[it] == mx }
            winSide = tied.minByOrNull { reached[it] } ?: tied[0]
        }
        val mt = teamOf(seat)
        return (if (winSide == mt) 1.0 else 0.0) + 0.02 * tw[mt]
    }

    private fun botCard(seat: Int): Card {
        val h = hands[seat]
        val legal = HokmRules.legal(h, trick).toList()
        if (legal.size <= 1) return legal[0]
        val arr = BooleanArray(80); for (cid in seen) if (cid in 0 until 80) arr[cid] = true
        val cnt = IntArray(6) { hands[it].size }
        try {      // the strong robot (HokmAI): card counting, inference from the plays, exact search at the end, no randomness
            val kt = (0 until teams).firstOrNull { t -> tricksWon[t] >= 7 && (0 until teams).all { o -> o == t || tricksWon[o] == 0 } } ?: -1
            val pick = HokmAI(n, kind, trump, hakem).choose(seat, ArrayList(h), ArrayList(trick), arr, deckCards(), cnt, void, tricksWon, kt, handSize(), ArrayList(plays))
            if (legal.contains(pick)) return pick
        } catch (e: Exception) { }
        try {      // the older robot (HokmSim)
            return HokmSim(n, kind, trump, hakem).choose(seat, ArrayList(h), ArrayList(trick), arr, deckCards(), cnt, void, tricksWon)
        } catch (e: Exception) { }
        try {
            val unseen = deckCards().filter { c -> !seen.contains(Cards.idc(c)) && h.none { x -> x.s == c.s && x.r == c.r } }
            val iters = Math.max(30, Math.min(120, 1500 / legal.size))
            val sums = DoubleArray(legal.size)
            for (k in 0 until iters) {
                val d = sampleHands(seat, unseen)
                for ((i, c) in legal.withIndex()) sums[i] += rollout(seat, c, d)
            }
            val bi = sums.indices.maxByOrNull { sums[it] } ?: 0
            return legal[bi]
        } catch (e: Exception) {
            return policy(seat, h, trick, seen)
        }
    }

    /** the chips of the game are paid (as applyChips of the four-player game) */
    private fun chips(d: Long) {
        if (d == 0L) return
        Prefs.wallet = Prefs.wallet + d
        log((if (d > 0) "شما " + Cards.fa(d) + " ژتون بردید." else "شما " + Cards.fa(-d) + " ژتون باختید.") + " ژتون شما: " + Cards.fa(Prefs.wallet))
        ui { app.syncBg() }
    }

    // ------------------------------------------------------------------ تغییر ژتون (a vote while the game is played; as in the Hokm of two and four players)

    /** an extra bet: the requester (with the partners who share it) against every opponent who agreed: [e] each */
    private class HxExtra(val req: Int, val opps: List<Int>, val partners: List<Int>, val e: Long) {
        fun settle(winners: Set<Int>, d: LongArray) {
            val side = 1 + partners.size
            val per = e / side
            for (o in opps) {
                val reqWon = req in winners; val oWon = o in winners
                if (reqWon == oWon) continue
                val sign = if (reqWon) 1L else -1L
                if (o < d.size) d[o] -= sign * e
                for (p in partners) if (p < d.size) d[p] += sign * per
                if (req < d.size) d[req] += sign * (e - per * partners.size)
            }
        }
    }
    private val extras = ArrayList<HxExtra>()
    private var voteRound: ChipVote.Round? = null
    private var voteId = 0
    private val cooldownAt = HashMap<Int, Long>()
    private val walletOf = LongArray(6) { -1L }
    private var coolMe = 0L

    private fun resetChipVote() {
        extras.clear(); cooldownAt.clear(); voteRound?.cancel(); voteRound = null; coolMe = 0L
        for (i in 0 until 6) walletOf[i] = -1L
    }

    private fun chipTell(seat: Int, t: String) {
        if (seat == me) ui { log(t) } else if (isRemote(seat)) net?.send(cidOf[seat], JSONObject().put("t", "cv").put("op", "say").put("m", t))
    }

    private fun chipAsk() {
        val wait = coolMe - System.currentTimeMillis()
        if (wait > 0) { app.dlg.message("بعد از رد شدن باید " + Cards.fa((wait / 1000 + 1).toInt()) + " ثانیه صبر کنید."); return }
        if (role == "client") { net?.toHost(JSONObject().put("t", "cv").put("op", "q")); return }      // the guest does not know the stake: the host tells it
        chipDialog(stake)
    }

    private fun chipDialog(cur: Long) {
        ChipVote.requestDialog(act, app, "تغییر ژتون", cur, Prefs.wallet) { amt ->
            if (role == "client") { net?.toHost(JSONObject().put("t", "cv").put("op", "req").put("amt", amt).put("w", Prefs.wallet)); log("درخواست شما برای بقیه فرستاده شد.") }
            else chipStart(me, amt)
        }
    }

    /** a message of the host about the chips, on a guest phone */
    private fun chipClientMsg(m: JSONObject) {
        when (m.optString("op")) {
            "stk" -> ui { chipDialog(m.optLong("v", stake)) }
            "say" -> ui { log(m.optString("m")) }
            "cool" -> coolMe = System.currentTimeMillis() + ChipVote.COOLDOWN_MS
            "ask" -> {
                val id = m.optInt("id")
                ui { ChipVote.voteDialog(act, app, m.optString("q")) { ok -> net?.toHost(JSONObject().put("t", "cv").put("op", "ans").put("id", id).put("ok", ok).put("w", Prefs.wallet)) } }
            }
        }
    }

    /** a guest's message about the chips, on the host */
    private fun chipHostMsg(seat: Int, m: JSONObject) {
        ui {
            if (m.has("w")) walletOf[seat] = m.optLong("w", -1L)
            when (m.optString("op")) {
                "q" -> net?.send(cidOf[seat], JSONObject().put("t", "cv").put("op", "stk").put("v", stake))
                "req" -> chipStart(seat, m.optLong("amt"))
                "ans" -> if (m.optInt("id") == voteId) voteRound?.answer(seat, m.optBoolean("ok"))
            }
        }
    }

    private fun chipStart(req: Int, amt: Long) {
        if (role == "client" || keepNg) return
        if (req == me) walletOf[me] = Prefs.wallet
        else if (walletOf[req] < 0L) net?.peerInfo(cidOf[req])?.let { walletOf[req] = it.wallet }
        val e = amt - stake
        if (e <= 0L) { chipTell(req, "مبلغ باید از ژتون فعلی بیشتر باشد."); return }
        if (voteRound != null) { chipTell(req, "رأی‌گیری دیگری باز است. کمی بعد دوباره امتحان کنید."); return }
        if (System.currentTimeMillis() < (cooldownAt[req] ?: 0L)) { chipTell(req, "بعد از رد شدن باید کمی صبر کنید."); return }
        val humans = (0 until n).filter { it == me || isRemote(it) }
        val team = teams < n
        val opps = humans.filter { it != req && teamOf(it) != teamOf(req) }
        val partners = if (team) humans.filter { it != req && teamOf(it) == teamOf(req) } else emptyList()
        if (opps.isEmpty()) {          // nobody to ask (only robots against him): the stake changes at once
            stake = amt; app.hokmStake = amt
            for (h in humans) chipTell(h, if (h == req) "ژتون بازی " + Cards.fa(amt) + " شد." else names[req] + " ژتون بازی را " + Cards.fa(amt) + " کرد.")
            return
        }
        val voters = opps + partners
        val id = ++voteId
        val qOpp = names[req] + " می‌خواهد ژتون بازی را از " + Cards.fa(stake) + " به " + Cards.fa(amt) + " ببرد؛ یعنی اضافی " + Cards.fa(e) + " بین شما. قبول دارید؟"
        val qPar = names[req] + " می‌خواهد ژتون بازی را از " + Cards.fa(stake) + " به " + Cards.fa(amt) + " ببرد؛ یعنی اضافی " + Cards.fa(e) + " با حریف‌ها. در اضافی شریک می‌شوید؟"
        chipTell(req, "رأی‌گیری شروع شد.")
        voteRound = ChipVote.Round(voters, ChipVote.VOTE_MS + 1500L + qOpp.length * 50L + 2500L) { map -> ui { chipDone(req, amt, e, opps, partners, map) } }
        for (v in voters) {
            val q = if (v in partners) qPar else qOpp
            if (v == me) ui { ChipVote.voteDialog(act, app, q) { ok -> walletOf[me] = Prefs.wallet; voteRound?.answer(me, ok) } }
            else net?.send(cidOf[v], JSONObject().put("t", "cv").put("op", "ask").put("id", id).put("q", q))
        }
        voteRound?.start()
    }

    private fun chipDone(req: Int, amt: Long, e: Long, opps: List<Int>, partners: List<Int>, map: Map<Int, Boolean>) {
        voteRound = null
        val acc = opps.filter { map[it] == true }
        val pIn = partners.filter { map[it] == true }
        if (acc.isEmpty()) {
            cooldownAt[req] = System.currentTimeMillis() + ChipVote.COOLDOWN_MS
            if (req != me) net?.send(cidOf[req], JSONObject().put("t", "cv").put("op", "cool"))
            else coolMe = System.currentTimeMillis() + ChipVote.COOLDOWN_MS
            chipTell(req, "درخواست ژتون رد شد.")
            return
        }
        // nobody of the requesting side may be asked for more chips than he has
        var ee = e
        val share = pIn.size + 1
        for (x in listOf(req) + pIn) if (walletOf[x] >= 0L) ee = Math.min(ee, walletOf[x] * share / acc.size)
        if (ee <= 0L) { chipTell(req, "ژتون شما برای این اضافی کافی نیست."); return }
        extras.add(HxExtra(req, acc, pIn, ee))
        val nms = acc.joinToString("، ") { names[it] }
        val cut = if (ee < e) " (چون ژتون کافی نبود از " + Cards.fa(e) + " کم شد)" else ""
        val refused = opps.filter { it !in acc }.joinToString("، ") { names[it] }
        chipTell(req, "اضافی " + Cards.fa(ee) + " با " + nms + " بسته شد" + cut + "." + (if (refused.isNotEmpty()) " " + refused + " رد کرد." else "") +
            (if (partners.isNotEmpty()) (if (pIn.size == partners.size) " یاران شما شریک شدند." else if (pIn.isEmpty()) " یاران شما قبول نکردند؛ همهٔ اضافی با شماست." else " بعضی از یاران شما شریک شدند.") else ""))
        for (o in acc) chipTell(o, names[req] + " با شما اضافی " + Cards.fa(ee) + " بست.")
        for (p in pIn) chipTell(p, "در اضافی " + Cards.fa(ee) + " شریک شدید.")
    }

    private fun finish(best: Int) {
        // everybody put the stake in: each player of a losing team loses it, and the winners share what the losers lost
        val winners = (0 until n).count { teamOf(it) == best }
        val losers = n - winners
        val gainWin = if (winners > 0) stake * losers / winners else 0L
        val dx = LongArray(6)
        val ws = (0 until n).filter { teamOf(it) == best }.toSet()
        for (x in extras) x.settle(ws, dx)
        extras.clear()
        for (seat in 0 until n) {
            if (seat != me && !isRemote(seat)) continue
            val won = teamOf(seat) == best
            val d = (if (won) gainWin else -stake) + dx[seat]
            if (seat == me) chips(d)
            else net?.send(cidOf[seat], JSONObject().put("t", "fin").put("w", won).put("d", d))
        }
        try { SavesHn.del("auto"); SavesHn.del("autoM") } catch (e: Exception) { }
        val mf = lastMf
        if (role != "client") ui { showNewGameButton(if (Prefs.a11y && mf != null) mf(me) else "") }
    }

    // ------------------------------------------------------------------ several phones

    private fun cardOf(id: Int) = Card(id / 20, id % 20)

    private fun sendAll(j: JSONObject) { for (sd in 0 until n) if (remote[sd]) net?.send(cidOf[sd], j) }

    fun hasSeat(cid: Int): Boolean = cidOf.indexOf(cid) >= 0

    /** what seat [seat] sees: its own hand, the table, the counts of the others */
    private fun snapFor(seat: Int, mt: Boolean, ct: Boolean): JSONObject {
        val nm = JSONArray(); for (x in names) nm.put(x)
        val pj = JSONArray(); for (t in 0 until teams) pj.put(pts[t])
        val tw = JSONArray(); for (t in 0 until teams) tw.put(tricksWon[t])
        val hd = JSONArray(); for (c in ArrayList(hands[seat])) hd.put(Cards.idc(c))
        val cn = JSONArray(); for (i in 0 until n) cn.put(hands[i].size)
        val tk = JSONArray(); for (p in ArrayList(if (trick.isNotEmpty()) trick else shown)) tk.put(JSONArray().put(p.seat).put(Cards.idc(p.c)))
        val m = if (mt) "نوبت شماست." else if (ct) ""
            else msgFor(seat)
        return JSONObject().put("t", "st").put("me", seat).put("kind", kind).put("stake", stake).put("hakem", hakem).put("trump", trump).put("ap", asideN)
            .put("turn", turn).put("names", nm).put("pts", pj).put("tw", tw).put("hand", hd).put("cnt", cn).put("trick", tk)
            .put("mt", mt).put("ct", ct).put("msg", m).put("win", winSeat)
    }

    private fun sendStates() {
        for (sd in 0 until n) if (remote[sd]) net?.send(cidOf[sd], snapFor(sd, waitSeat == sd && !waitTrump, waitSeat == sd && waitTrump))
    }

    private fun startMsg(seat: Int): JSONObject = JSONObject().put("t", "start").put("me", seat)

    /** the host starts a game: seats 1.. are the phones that joined, the other seats are robots */
    fun startHostGame(ps: List<NetHn.Peer?>, k: Int, st: Long, byDraw: Boolean = true) {
        pdraw = byDraw
        role = "host"; me = 0; kind = k; n = players(k); teams = teamsOf(k); stake = st
        for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
        val nm = ArrayList<String>()
        nm.add(if (Prefs.name.isEmpty()) "شما" else Prefs.name)
        val robots = NM.shuffled().filter { x -> ps.none { it?.name == x } && x != nm[0] }.iterator()
        for (i in 0 until n - 1) {
            val p = ps.getOrNull(i)
            if (p != null) { nm.add(p.name); remote[i + 1] = true; cidOf[i + 1] = p.cid; idOf[i + 1] = p.id }
            else nm.add(if (robots.hasNext()) robots.next() else "ربات " + (i + 1))
        }
        names = nm
        pts = IntArray(6); hakem = -1
        for (sd in 1 until n) if (remote[sd]) net?.send(cidOf[sd], startMsg(sd))
        lastSave = saveJson().toString()
        startGame()
        sendSync()
    }

    /** the last save goes to every guest: if the host drops out, the first guest takes over from it */
    private fun sendSync() {
        if (role != "host" || lastSave.isEmpty()) return
        val succ = (1 until n).firstOrNull { remote[it] } ?: return
        sendAll(JSONObject().put("t", "sync").put("sv", lastSave).put("succ", succ))
    }

    fun adoptFromSync() {
        val nt = net
        if (nt == null || syncSv.isEmpty()) { showReconnect(); return }
        try {
            nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
            stopGame(); started = false
            resumeHostGame(JSONObject(syncSv), true)
        } catch (e: Exception) { showReconnect() }
    }

    // ---- a saved multi-phone game, or a game handed over by the old host

    /** load a save: the host waits until the players are back (they are known by their device ids) */
    fun resumeHostGame(j: JSONObject, handedOver: Boolean) {
        try {
            kind = j.getInt("kind"); n = players(kind); teams = teamsOf(kind); stake = j.optLong("stake", 100000L)
            val nm = j.getJSONArray("names"); val sc = j.getJSONArray("pts"); val ids = j.optJSONArray("ids")
            var k = 0
            if (handedOver && ids != null) for (i in 0 until n) if (ids.optString(i) == Prefs.devId()) k = i
            names = List(n) { nm.getString((it + k) % n) }
            val old = IntArray(6) { if (it < sc.length()) sc.getInt(it) else 0 }
            val np = IntArray(6)
            for (sd in 0 until n) np[teamOf(sd)] = old[teamOf((sd + k) % n)]       // the teams keep their points when the seats turn around
            pts = np
            val oh = j.optInt("hakem", -1)
            hakem = if (oh < 0) -1 else ((oh - k) % n + n) % n
            for (i in 0 until 6) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
            if (ids != null) for (i in 0 until n) idOf[i] = ids.optString((i + k) % n)
            idOf[0] = ""                                  // this phone is the host
            if (Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            role = "host"; me = 0; resuming = true; started = false
            showResumeLobby()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده خراب است."); net?.leave(); close() }
    }

    private fun showResumeLobby() {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("ادامهٔ بازی ذخیره‌شده"))
        v.addView(tv("بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند و بازی «" + (if (Prefs.name.isEmpty()) "میزبان" else Prefs.name) + "» را انتخاب کنند. وقتی آماده بودید «ادامه بازی» را بزنید؛ جای کسانی که نیامده‌اند ربات بازی می‌کند.", 15f))
        for (i in 1 until n) {
            val st = if (remote[i]) "وصل شد" else if (idOf[i].isNotEmpty()) "منتظر است" else "ربات"
            v.addView(tv(names[i] + " — " + st, 15f))
        }
        v.addView(mbtn("ادامه بازی") {
            resuming = false
            for (sd in 1 until n) if (remote[sd]) net?.send(cidOf[sd], startMsg(sd))
            lastSave = saveJson().toString()
            startGame()
            sendSync()
        })
        v.addView(mbtn("بستن") { net?.leave(); close() })
        setScreen("net", v)
    }

    /** the saved multi-phone games (from the lobby): the one who taps becomes the host */
    fun showMultiSaves() { net?.showSaved() }

    private fun xferTo(seat: Int, exitApp: Boolean = false) {
        val cid = cidOf[seat]
        if (cid < 0 || lastSave.isEmpty()) return
        net?.send(cid, JSONObject().put("t", "xfer").put("sv", lastSave))
        val rm = net?.curRoom() ?: ""
        Sched.laterRaw(1500) {
            act.runOnUiThread {
                if (exitApp || rm.isEmpty()) { net?.leave(); close(false); if (exitApp) act.bridge.exitApp() }
                else {      // as in the four-player game: this phone becomes a normal player of the new host
                    stopGame(); held = false; holdTxt = ""; syncSv = ""; succSeat = -1
                    role = "client"; started = true
                    net?.becomeClient(rm, if (Prefs.name.isEmpty()) "بازیکن" else Prefs.name)
                    showReconnect()
                }
            }
        }
    }

    private fun exitHostAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.quitAskPublic(); return }
        val sd = seats[0]
        app.dlg.confirm("مطمئنید؟ برنامه کاملاً بسته می‌شود. میزبانی به " + names[sd] + " منتقل می‌شود و ربات جای شما بازی می‌کند.", { xferTo(sd, true) })
    }

    fun onGuestDrop(cid: Int) {
        val sd = cidOf.indexOf(cid)
        if (sd < 1) return
        remote[sd] = false; cidOf[sd] = -1
        ansQ[sd].offer("drop")
        if (resuming) { ui { showResumeLobby() }; return }
        if (started) { say(names[sd] + " قطع شد و ربات تا اتصال دوباره جای او بازی می‌کند."); startHold(names[sd] + " قطع شد و ربات جای او آمد.") }
    }

    /** a phone that sat here before says hello again: it takes its seat back. true when it was one of ours */
    fun onGuestHello(cid: Int, id: String): Boolean {
        if ((!started && !resuming) || role != "host" || id.isEmpty()) return false
        for (sd in 1 until n) if (idOf[sd] == id) {
            remote[sd] = true; cidOf[sd] = cid
            if (resuming) { ui { showResumeLobby() }; return true }
            net?.send(cid, startMsg(sd))
            if (held) net?.send(cid, JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
            say(names[sd] + " دوباره وصل شد و بازی را ادامه می‌دهد.")
            sendStates()
            sendSync()
            return true
        }
        return false
    }

    fun onGuestMsg(cid: Int, m: JSONObject) {
        val sd = cidOf.indexOf(cid)
        if (sd >= 1 && m.optString("t") == "ans") ansQ[sd].offer(m.optString("m"))
        if (sd >= 1 && m.optString("t") == "cv") chipHostMsg(sd, m)
    }

    fun netNote(t: String) { localSay(t) }

    /** the connection to the host dropped during a game */
    fun showReconnect() {
        if (screen != "game" || role != "client") return
        val t = "اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید ربات جای شما بازی می‌کند. در حال اتصال دوباره..."
        ui {
            ctl.removeAllViews()
            ctl.addView(tv(t, 14f, Color.WHITE))
            ctl.addView(app.dlg.btn("اتصال دوباره", false) { net?.reconnect() })
            ctl.addView(app.dlg.btn("خروج به منو", false) { net?.leave(); close() })
            ann(t)
        }
        myTurn = false
    }

    /** the host's messages, on the guest phone */
    fun onHostMsg(m: JSONObject) {
        when (m.optString("t")) {
            "start" -> {
                role = "client"; me = m.optInt("me", 1)
                if (screen != "game") { ui { stopGame(); clearLog(); Spk.reset(); Sound.resetQueue(); started = true } }
            }
            "st" -> {
                role = "client"
                if (screen != "game" || !started) {
                    stopGame(); Spk.reset(); Sound.resetQueue()
                    me = m.optInt("me", me); kind = m.getInt("kind"); n = players(kind); teams = teamsOf(kind)
                    val nm = m.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
                    buildGameView(); started = true
                }
                applySnap(m)
            }
            "say" -> localSay(m.optString("m"))
            "log" -> { if (m.optBoolean("clr")) clearLog(); log(m.optString("x")) }
            "shf" -> ui { try { Fx.shufThen({ Sound.psnd("shuffle", true) }) { } } catch (e: Exception) { } }
            "tfl" -> ui { try { Fx.trumpFlash(m.optInt("s")) } catch (e: Exception) { } }
            "tsn" -> trickSound(m.optBoolean("w"))
            "es" -> {
                val x = m.optString("x"); val gm = m.optBoolean("gm")
                Sound.endSnd(if (m.optBoolean("w")) 0 else 1, m.optBoolean("kot"), gm) { ui { if (!gm) { msg = x; render() }; log(x) } }
            }
            "drw" -> {
                try {
                    val dn = m.getInt("n"); val sq = m.getJSONArray("seq"); val nmA = m.getJSONArray("nm")
                    val seq = List(sq.length()) { val e = sq.getJSONObject(it); TP(e.getInt("p"), cardOf(e.getInt("c"))) }
                    val plA = m.optJSONArray("pl"); val ilA = m.optJSONArray("il"); val mvA = m.optJSONArray("mv")
                    val pl = if (plA == null) emptyList() else List(plA.length()) { plA.getInt(it) }
                    val il = if (ilA == null) emptyList() else List(ilA.length()) { ilA.getInt(it) }
                    val mv = if (mvA == null || pl.isEmpty()) intArrayOf(0, 1) else IntArray(mvA.length()) { mvA.getInt(it) }
                    val D = Draw.D(dn, seq, m.getInt("h"), if (pl.isEmpty()) null else pl[0], m.getInt("i1"), if (pl.isEmpty()) -1 else m.optInt("i2", -1), mv, pl, il)
                    val labs = List(nmA.length()) { nmA.getString(it) }
                    ui { try { Fx.drawScene(D, labs, null, null) { t, q -> drawSay(t, q) } } catch (e: Exception) { } }
                } catch (e: Exception) { }
            }
            "hold" -> { held = m.optBoolean("on"); holdTxt = if (held) m.optString("x") else ""; ui { if (held) ann(holdTxt); render() } }
            "mv", "col" -> { }      // the state itself brings the card (postTable)
            "aside" -> { val a = m.optJSONArray("c"); if (a != null) { val l = List(a.length()) { cardOf(a.getInt(it)) }; ui { flyAside(l) } } }
            "sync" -> { syncSv = m.optString("sv"); succSeat = m.optInt("succ", -1) }
            "snd" -> Sched.post { Sound.game(m.optString("n")) }
            "ban" -> ui { banner(m.optString("m")) }
            "cv" -> chipClientMsg(m)
            "fin" -> {
                chips(m.optLong("d"))
                myTurn = false; choosingTrump = false
            }
            "xfer" -> {
                val nt = net ?: return
                nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
                stopGame(); started = false
                resumeHostGame(JSONObject(m.getString("sv")), true)
            }
            "end" -> { app.dlg.message(m.optString("m", "بازی تمام شد.")); net?.leave(); close() }
        }
    }

    private fun applySnap(m: JSONObject) {
        ui {
            me = m.optInt("me", me); kind = m.optInt("kind", kind); n = players(kind); teams = teamsOf(kind); stake = m.optLong("stake", stake)
            val nm = m.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
            val pj = m.getJSONArray("pts"); pts = IntArray(6) { if (it < pj.length()) pj.getInt(it) else 0 }
            val tw = m.getJSONArray("tw"); tricksWon = IntArray(6) { if (it < tw.length()) tw.getInt(it) else 0 }
            hakem = m.optInt("hakem", -1); trump = m.optInt("trump", -1); turn = m.optInt("turn", -1)
            val cn = m.getJSONArray("cnt"); val hd = m.getJSONArray("hand")
            for (i in 0 until 6) hands[i] = if (i == me) ArrayList<Card>().also { l -> for (k in 0 until hd.length()) l.add(cardOf(hd.getInt(k))) }
                else ArrayList<Card>().also { l -> for (k in 0 until (if (i < cn.length()) cn.getInt(i) else 0)) l.add(Card(0, 2)) }
            val tk = m.getJSONArray("trick")
            trick = ArrayList<TC>().also { l -> for (k in 0 until tk.length()) { val e = tk.getJSONArray(k); l.add(TC(e.getInt(0), cardOf(e.getInt(1)))) } }
            msg = m.optString("msg"); asideN = m.optInt("ap", 0)
            myTurn = m.optBoolean("mt"); choosingTrump = m.optBoolean("ct"); winSeat = m.optInt("win", -1)
            render()
        }
    }

    // ---- the host's menu: add, remove and hand over

    private fun addAsk() {
        val nt = net ?: return
        val seats = (1 until n).filter { !remote[it] }
        if (seats.isEmpty()) { app.dlg.message("جای خالی نیست."); return }
        val w = nt.waiting()
        if (w.isEmpty()) { app.dlg.list("بازیکن جدیدی وصل نیست. از او بخواهید «به بازی دیگری می‌پیوندم» را بزند و گوشی میزبان را انتخاب کند؛ بعد «بررسی دوباره» را بزنید.", listOf("بررسی دوباره" to { addAsk() }), "بستن"); return }
        fun pickSeat(cid: Int, nm: String) {
            if (seats.size == 1) { addPlayer(cid, seats[0]); return }
            app.dlg.list("«" + nm + "» جای کدام ربات بنشیند؟", seats.map { x -> names[x] to { addPlayer(cid, x) } }, "بستن")
        }
        if (w.size == 1) pickSeat(w[0].first, w[0].second)
        else app.dlg.list("کدام بازیکن به بازی اضافه شود؟", w.map { (cid, nm) -> nm to { pickSeat(cid, nm) } }, "بستن")
    }

    private fun addPlayer(cid: Int, seat: Int) {
        val info = net?.peerInfo(cid) ?: return
        if (remote[seat]) return
        val nd = need(kind, stake)
        if (info.wallet < nd) { app.dlg.message("«" + info.name + "» ژتون کافی ندارد (دست‌کم " + Cards.fa(nd) + " لازم است) و نمی‌تواند وارد بازی شود."); return }
        remote[seat] = true; cidOf[seat] = cid; idOf[seat] = info.id
        val l = names.toMutableList(); l[seat] = info.name; names = l
        net?.send(cid, startMsg(seat))
        say(info.name + " به بازی اضافه شد و بازی را ادامه می‌دهد.")
        sendStates(); sendSync()
    }

    private fun kickAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { sd: Int -> app.dlg.confirm("«" + names[sd] + "» از بازی حذف شود؟ ربات جای او بازی می‌کند. او می‌تواند دوباره وارد بازی شود.", { kickPlayer(sd) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("کدام بازیکن از بازی حذف شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }

    private fun kickPlayer(sd: Int) {
        if (!remote[sd]) return
        net?.send(cidOf[sd], JSONObject().put("t", "end").put("m", "میزبان شما را از بازی حذف کرد."))
        remote[sd] = false; cidOf[sd] = -1; idOf[sd] = ""
        ansQ[sd].offer("drop")
        say(names[sd] + " از بازی حذف شد و ربات جای او بازی می‌کند.")
        sendSync()
    }

    private fun xferAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { sd: Int -> app.dlg.confirm("میزبانی همین الان به «" + names[sd] + "» منتقل شود؟ بعد از آن شما بازیکن عادی هستید و تا وصل شدن دوباره‌ی بازیکن‌ها، ربات جایشان بازی می‌کند.", { xferTo(sd) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("میزبانی به کدام بازیکن منتقل شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }
}
