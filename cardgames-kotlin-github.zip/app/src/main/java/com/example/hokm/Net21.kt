package com.example.hokm

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject

/**
 * The multi-phone side of the 21 game: lobby screens (host / join), the transport events of the
 * bridge (Bluetooth, Wi-Fi, Wi-Fi Direct) and the messages.
 * The host phone runs the game; guests only show the table and answer the questions they are asked.
 */
class Net21(private val act: MainActivity, private val app: App, private val g: Bist21) {
    class Peer(@JvmField val cid: Int, @JvmField var name: String, @JvmField var addr: String) {
        @JvmField var id = ""
        @JvmField var joined = false
        @JvmField var wallet = 10000
    }

    private val NETN = mapOf("bt" to "بلوتوث", "lan" to "وای‌فای (یک شبکهٔ مشترک)", "direct" to "وای‌فای مستقیم")
    private val NETH = mapOf(
        "bt" to "گوشی‌ها باید نزدیک هم باشند و بلوتوث (و در بعضی گوشی‌ها موقعیت‌مکانی) روشن باشد. نیازی به جفت‌کردن در تنظیمات بلوتوث نیست.",
        "lan" to "همه‌ی گوشی‌ها باید به یک شبکه‌ی وای‌فای وصل باشند، مثلاً یک مودم یا هات‌اسپات یکی از گوشی‌ها. بعد میزبان بازی را باز می‌کند و بقیه نامش را در فهرست می‌بینند.",
        "direct" to "وای‌فای همه‌ی گوشی‌ها باید روشن و گوشی‌ها نزدیک هم باشند. لازم نیست به مودم یا شبکه‌ای وصل شوید؛ بقیه مستقیم به گوشی میزبان وصل می‌شوند."
    )
    private val bases = listOf(500, 1000, 2000, 5000)
    private val mins = listOf(25, 50, 100)

    private val peers = LinkedHashMap<Int, Peer>()
    private val found = LinkedHashMap<String, Array<String>>()   // endpoint -> [room, name]
    private var role = "off"                                      // "host" | "client" | "off"
    private var conn = false
    private var leaving = false
    private var room = ""
    private var lastAddr = ""
    private var myName = ""
    private var netMode = Prefs.net
    private var retry: ((Boolean) -> Unit)? = null
    private var tries = 0
    private var rcN = 0
    private var screen = ""

    private var info: TextView? = null
    private var listBox: LinearLayout? = null
    private var spTotal: Spinner? = null
    private var spKhabre: Spinner? = null
    private val khabreMuls = listOf(2, 3, 4, 5, 10)
    private var spDeal: Spinner? = null
    private var botLab: TextView? = null
    private var spBase: android.widget.EditText? = null
    private var spMin: android.widget.EditText? = null
    private var cbSide: CheckBox? = null
    private var botsWanted = 3

    private val br get() = act.bridge

    // ------------------------------------------------------------------ plumbing

    fun show() {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        showRoles()
    }

    /** send a message to the phone with connection id cid (0 = the host, from a guest) */
    fun send(cid: Int, j: JSONObject) {
        act.runOnUiThread { try { br.send(cid, j.toString()) } catch (e: Exception) { } }
    }

    fun toHost(j: JSONObject) { send(0, j) }

    fun close() {
        try { br.stopHost() } catch (e: Exception) { }
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        role = "off"; conn = false; peers.clear(); found.clear()
    }

    fun leave() {
        leaving = true
        if (role == "client" && conn) { try { send(0, JSONObject().put("t", "bye")) } catch (e: Exception) { } }
    }

    /** the phone's back button inside the lobby; true = handled here */
    fun back(): Boolean {
        if (role == "off") return false
        leaving = true
        close()
        showRoles()
        return true
    }

    private fun setInfo(t: String) {
        info?.text = t
        try { if (Prefs.a11y) info?.announceForAccessibility(t) } catch (e: Exception) { }
    }

    /** a lobby screen: the ⋮ button and the title, as in the Hokm lobby */
    private fun lobbyBase(): LinearLayout {
        val v = column()
        v.addView(app.moreButtonView())
        v.addView(g.heading("بازی با چند گوشی"))
        return v
    }

    /** the status line under the content (a polite live region, like the lobby message of the Hokm game) */
    private fun statusTv(): TextView {
        val t = g.tv("", 15f)
        t.gravity = Gravity.CENTER
        t.setPadding(Px.dp(8), Px.dp(10), Px.dp(8), Px.dp(10))
        t.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        info = t
        return t
    }

    private fun column(): LinearLayout {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        return v
    }

    // ------------------------------------------------------------------ lobby screens

    private fun showRoles() {
        screen = "roles"; role = "off"; leaving = false
        val v = lobbyBase()
        // name and gender, as in the Hokm lobby (hidden once both are saved)
        val nmrow = column()
        nmrow.addView(g.tv("نام شما در بازی (بقیه‌ی بازیکنان همین نام را می‌بینند):", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val et = android.widget.EditText(act)
        et.filters = arrayOf(android.text.InputFilter.LengthFilter(20)); et.textSize = 16f
        et.setTextColor(Px.tx); et.isSingleLine = true; et.contentDescription = "نام شما در بازی"
        et.setText(Prefs.name)
        et.onDone(null)
        nmrow.addView(et, fieldLp())
        nmrow.addView(g.tv("جنسیت شما:", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val gs = Spinner(act)
        gs.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf("زن", "مرد"))
        gs.speakLabel("جنسیت شما")
        gs.setSelection(if (Prefs.gender == "m") 1 else 0)
        nmrow.addView(gs, fieldLp())
        nmrow.visibility = if (Prefs.name.isNotEmpty() && Prefs.gender.isNotEmpty()) View.GONE else View.VISIBLE
        nameEt = et; genderSp = gs
        v.addView(nmrow)
        v.addView(g.tv("برای بازی با چند گوشی، همه‌ی گوشی‌ها باید این برنامه را داشته باشند و همه یک «روش اتصال» را انتخاب کنند. توضیح روش انتخاب‌شده را زیر دکمهٔ «روش اتصال» می‌بینید.", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        v.addView(g.mbtn("روش اتصال: " + (NETN[netMode] ?: "")) { netChoose() })
        val t = statusTv()
        t.text = NETH[netMode] ?: ""
        v.addView(t)
        v.addView(g.mbtn("میزبان بازی می‌شوم") { startHost(false) })
        v.addView(g.mbtn("به بازی دیگری می‌پیوندم") { startJoin(false) })
        v.addView(g.mbtn("بازی‌های قبلی") { if (Saves.all(true).isEmpty()) app.dlg.list("بازی ذخیره‌شده‌ای نیست. میزبان باید در بازی از «گزینه‌های بیشتر» دکمهٔ «ذخیره» را بزند.", listOf(), "باشه") else showSavedMulti() })
        g.setScreen("net", v)
    }

    private var hostNm = "میزبان"
    private var nameEt: android.widget.EditText? = null
    private var genderSp: Spinner? = null

    private fun fieldLp() = LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), Px.dp(48)).also {
        it.gravity = Gravity.CENTER_HORIZONTAL; it.setMargins(0, Px.dp(6), 0, Px.dp(6))
    }

    /** the name (and gender) typed on the lobby screen are saved and used in the game */
    private fun myNm(): String {
        val et = nameEt; val gs = genderSp
        if (et != null && gs != null) {
            var v = et.text.toString().trim().take(20)
            if (v.isEmpty()) v = Prefs.name.ifEmpty { "بازیکن" }
            Prefs.name = v
            Prefs.gender = if (gs.selectedItemPosition == 1) "m" else "f"
            Av.GN[v] = Prefs.gender
            return v
        }
        return Prefs.name.ifEmpty { "بازیکن" }
    }

    private fun netChoose() {
        app.dlg.list("روش اتصال", listOf(
            "بلوتوث" to { setNet("bt") },
            "وای‌فای: همهٔ گوشی‌ها به یک مودم یا هات‌اسپات وصل باشند" to { setNet("lan") },
            "وای‌فای مستقیم: بدون مودم، گوشی‌ها مستقیم به میزبان وصل می‌شوند" to { setNet("direct") }
        ))
    }

    private fun setNet(v: String) {
        netMode = v; Prefs.net = v
        try { br.setNet(v) } catch (e: Exception) { }
        showRoles()
    }

    /** permissions / Bluetooth / Wi-Fi checks; false = something is still needed (the user was told) */
    private fun ready(r: ((Boolean) -> Unit)?): Boolean {
        retry = r
        br.setNet(netMode)
        val st = br.state()
        if (st == "nogms") { setInfo("این گوشی خدمات گوگل پلی (Google Play Services) ندارد یا به‌روز نیست و اتصال نزدیک کار نمی‌کند."); return false }
        if (st == "noperm") {
            br.ensure()
            setInfo(if (netMode == "bt") "اجازه‌های درخواست‌شده (بلوتوث و دستگاه‌های نزدیک) را بدهید." else "اجازه‌های درخواست‌شده (دستگاه‌های نزدیک و موقعیت مکانی) را بدهید.")
            return false
        }
        if (st == "off") { br.enableBt(); setInfo("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن بلوتوث را بدهید."); return false }
        if (st == "locoff") { br.enableLoc(); setInfo("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن موقعیت مکانی را بدهید."); return false }
        if (st == "wifioff") {
            br.enableWifi()
            setInfo(if (netMode == "lan") "در پنجره‌ی باز‌شده وای‌فای را روشن کنید و به همان شبکه‌ای وصل شوید که بقیه‌ی بازیکن‌ها هستند (مودم یا هات‌اسپات). با بستن پنجره، برنامه خودش ادامه می‌دهد."
            else "در پنجره‌ی باز‌شده وای‌فای را روشن کنید (لازم نیست به شبکه‌ای وصل شوید). با بستن پنجره، برنامه خودش ادامه می‌دهد.")
            return false
        }
        if (st == "nobt") { setInfo("این گوشی بلوتوث ندارد."); return false }
        retry = null; tries = 0
        return true
    }

    private fun startHost(auto: Boolean) {
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> startHost(a) }) return
        role = "host"; peers.clear(); conn = false
        myName = myNm()
        room = java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, myName)
        showHostLobby()
    }

    private fun showSavedMulti() {
        val l = Saves.all(true)
        screen = "saved"
        val v = column()
        v.addView(g.heading("بازی‌های قبلی"))
        for (e in l) v.addView(g.mbtn(Saves.describe(e)) {
            app.dlg.list(Saves.describe(e), listOf(
                "ادامه بازی (میزبان می‌شوم)" to { resumeHost(false, e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { Saves.del(e.id); showRoles() }) }
            ), "بستن")
        })
        g.setScreen("net", v)
    }

    private var resumeE: Saves.E? = null

    /** the host chose this saved game in the common list of saved games */
    fun resumeSaved(e: Saves.E) { resumeHost(false, e) }

    private fun resumeHost(auto: Boolean, e: Saves.E? = null) {
        if (e != null) resumeE = e
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> resumeHost(a) }) return
        val en = resumeE ?: return
        val sv = try { JSONObject(en.data) } catch (x: Exception) { setInfo("بازی ذخیره‌شده خراب است."); return }
        role = "host"; peers.clear(); conn = false
        myName = myNm()
        g.adoptHost(sv, 0, "بازی قبلی بارگذاری شد. بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند؛ وقتی وصل شدند و آماده بودید «ادامه بازی» را بزنید.")
    }

    /** this phone is the host now (the old host left): advertise the same room so the others find us again */
    fun becomeHost(rm: String, name: String) {
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        role = "host"; conn = false; leaving = false; peers.clear()
        myName = name; room = if (rm.isNotEmpty()) rm else java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, name)
    }

    /** the settings of the waiting room of this game (the same in the lobby of this game and in the host page of the main menu) */
    private fun buildHostSettings(v: LinearLayout) {
        v.addView(g.tv("تعداد کل بازیکن‌ها (با خودتان، بازیکن‌های وارد شده و ربات‌ها)", 16f))
        val spT = Spinner(act)
        spT.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, (2..10).map { Cards.fa(it) + " نفره" })
        spT.setSelection(0)
        spT.speakLabel("تعداد کل بازیکن‌ها")
        v.addView(spT, fieldLp()); spTotal = spT
        v.addView(g.tv("بانک اولیه (ژتون بانکدار؛ عدد را تایپ کنید)", 16f))
        val s1 = numField(act, "بانک اولیه", 1000); spBase = s1
        v.addView(s1, fieldLp())
        v.addView(g.tv("کمترین شرط (عدد را تایپ کنید)", 16f))
        val s2 = numField(act, "کمترین شرط", 50); spMin = s2
        v.addView(s2, fieldLp())
        v.addView(g.tv("بانک خبره: وقتی بانک به این چند برابر بانک اولیه برسد، بانکدار می‌تواند «بانک خبره» بگوید و بانک را بردارد", 16f))
        val s3 = Spinner(act)
        s3.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, khabreMuls.map { Cards.fa(it) + " برابر بانک اولیه" })
        s3.setSelection(1)
        s3.speakLabel("مقدار بانک خبره")
        v.addView(s3, fieldLp()); spKhabre = s3
        v.addView(g.tv("نحوهٔ پخش کارت", 16f))
        val sd = Spinner(act)
        sd.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf("به نوبت: بانکدار به نفر دست راستش کارت می‌دهد و با او بازی می‌کند، بعد نفر بعدی", "اول به همه: بانکدار ابتدا به همهٔ بازیکن‌ها یک کارت می‌دهد، بعد با هر نفر به نوبت بازی می‌کند"))
        sd.setSelection(0)
        sd.speakLabel("نحوهٔ پخش کارت")
        v.addView(sd, fieldLp()); spDeal = sd
        val cb = CheckBox(act); cb.text = "شرط روی دست دیگران (خواندن)"; cb.setTextColor(Px.tx); cbSide = cb
        v.addView(cb)
        Mem.spinner("n21.n", spT); Mem.field("n21.base", s1); Mem.field("n21.min", s2)      // the choices stay when the page is opened again
        Mem.spinner("n21.k", s3); Mem.spinner("n21.d", sd); Mem.check("n21.side", cb)
    }

    /** the host page of the main menu shows this game's settings and players (no screen of this game until the game starts) */
    private var inPage = false

    fun adoptHostInPage(rm: String, name: String, list: List<HandPeer>, box: LinearLayout, plist: LinearLayout, infoTv: TextView) {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        role = "host"; conn = false; leaving = false
        peers.clear()
        for (p in list) peers[p.cid] = Peer(p.cid, p.name, p.addr)
        myName = name; room = rm
        g.roomCode = room
        screen = "host"; inPage = true
        listBox = plist; info = infoTv
        box.removeAllViews()
        buildHostSettings(box)
        refreshHost()
    }

    fun startFromPage() { hostGo() }

    /** room, host name and the connected phones (to hand them over to another game) */
    fun handoff(): Triple<String, String, List<HandPeer>> = Triple(room, myName, handPeers())

    private fun showHostLobby() {
        screen = "host"
        val v = lobbyBase()
        v.addView(g.tv("سکه‌های شما: " + Cards.fa(Prefs.wallet), 15f, Px.GOLD, true).also { it.gravity = Gravity.CENTER })
        v.addView(g.tv("نام شما در بازی: " + myName + ". منتظر ورود بازیکنان هستید. بازیکنان باید از بخش «به بازی دیگری می‌پیوندم» بازی «" + myName + "» را از فهرست بازی‌های نزدیک انتخاب کنند (گوشی‌ها باید نزدیک هم باشند). بازی تا وقتی دست‌کم یک بازیکن انسانی نپیوندد شروع نمی‌شود. هر وقت آماده بودید، «شروع بازی» را بزنید؛ جاهای خالی را ربات پر می‌کند.", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val lb = column(); listBox = lb
        v.addView(lb)
        v.addView(g.tv("نوع بازی (می‌توانید هر وقت خواستید عوض کنید؛ اتصال بازیکنان قطع نمی‌شود)", 16f))
        v.addView(app.kindSpinner("21") { k -> app.switchLobbyHost("21", k, room, myName, handPeers()) }, fieldLp())
        buildHostSettings(v)
        val goB = g.mbtn("شروع بازی") { app.hideKeyboard(); hostGo() }
        v.addView(goB)
        spBase?.let { b -> spMin?.let { m -> b.onNext(m) } }
        spMin?.onDone { goB.performClick() }
        v.addView(g.mbtn("بستن") { back() })
        v.addView(statusTv())
        g.setScreen("net", v)
        refreshHost()
    }

    private fun joined(): List<Peer> = peers.values.filter { it.joined }

    /** phones that are connected to a running game but have no seat yet: (connection id, name) */
    fun waiting(): List<Pair<Int, String>> = peers.values.filter { it.joined && !g.hasSeat(it.cid) }.map { it.cid to it.name }

    class PeerInfo(@JvmField val id: String, @JvmField val name: String, @JvmField val wallet: Int)

    fun peerInfo(cid: Int): PeerInfo? = peers[cid]?.let { PeerInfo(it.id, it.name, it.wallet) }
    private fun refreshHost() {
        if (screen != "host") return
        val ps = joined()
        val lb = listBox ?: return
        lb.removeAllViews()
        for (p in ps) lb.addView(g.tv(p.name, 15f).also { it.gravity = Gravity.CENTER })
        setInfo(if (ps.isNotEmpty()) "${ps.size} بازیکن وارد شده است." else "هنوز کسی وارد نشده است.")
    }

    private fun hostGo() {
        val ps = joined()
        val total = (spTotal?.selectedItemPosition ?: 0) + 2           // the host + the phones + the robots
        if (ps.isEmpty()) { setInfo("برای شروع بازی باید دست‌کم یک بازیکن انسانی بپیوندد."); return }   // like Hokm: no game with bots only
        val nb = Cards.num(spBase?.text?.toString() ?: "1000"); val nm = Cards.num(spMin?.text?.toString() ?: "50")
        if (nb < 1) { setInfo("بانک اولیه را به‌صورت عدد (دست‌کم ۱) تایپ کنید."); return }
        if (nm < 1) { setInfo("کمترین شرط را به‌صورت عدد (دست‌کم ۱) تایپ کنید."); return }
        if (nm > nb) { setInfo("کمترین شرط نباید از بانک اولیه بیشتر باشد."); return }
        if (Prefs.wallet < nm) { setInfo("سکه‌های شما از کمترین شرط کمتر است. کمترین شرط را کمتر کنید."); return }
        val able = ps.filter { it.wallet >= nm }      // people must have the chips for the smallest bet (robots have no limit)
        if (able.isEmpty()) {
            for (p in ps) send(p.cid, JSONObject().put("t", "welcome").put("name", p.name).put("x", "سکه‌های شما از کمترین شرط کمتر است. میزبان باید کمترین شرط را کمتر کند."))
            setInfo(ps.joinToString("، ") { it.name } + " سکهٔ کافی برای کمترین شرط ندارد. کمترین شرط را کمتر کنید.")
            return
        }
        val play = able.take(total - 1)      // the others stay connected and the host can add them later
        for (p in ps) if (p !in play) send(p.cid, JSONObject().put("t", "welcome").put("name", p.name).put("x",
            if (p.wallet < nm) "سکه‌های شما از کمترین شرط کمتر است. بازی بدون شما شروع شد و وصل می‌مانید."
            else "جای خالی میز پر بود. بازی بدون شما شروع شد و وصل می‌مانید تا میزبان شما را اضافه کند."))
        val bots = total - 1 - play.size
        val kh = khabreMuls[spKhabre?.selectedItemPosition ?: 1]
        if (inPage) { inPage = false; g.ensureHostShown() }
        g.startHostGame(play, bots, nb, nm, cbSide?.isChecked ?: false, kh, (spDeal?.selectedItemPosition ?: 0) == 1)
    }

    private fun startJoin(auto: Boolean) {
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> startJoin(a) }) return
        role = "client"; leaving = false; conn = false
        myName = myNm()
        found.clear()
        showJoin()
        br.scan()
    }

    private fun showJoin() {
        screen = "join"
        val v = lobbyBase()
        v.addView(g.tv("بازی نزدیک را از فهرست انتخاب کنید (جست‌وجو ادامه دارد):", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val lb = column(); listBox = lb
        v.addView(lb)
        v.addView(g.mbtn("بستن") { back() })
        v.addView(statusTv())
        g.setScreen("net", v)
        refreshJoin()
    }

    private fun refreshJoin() {
        if (screen != "join") return
        val lb = listBox ?: return
        lb.removeAllViews()
        for ((ep, f) in found) lb.addView(g.mbtn(if (f[1].isEmpty()) "بازی بدون نام" else f[1]) { joinDev(ep, f[0], f[1]) })
        val n = found.size
        setInfo(if (n > 0) "$n بازی نزدیک پیدا شد." else "در حال جست‌وجو. میزبان باید «میزبان بازی می‌شوم» را باز کرده باشد.")
    }

    private fun joinDev(ep: String, rm: String, name: String) {
        room = rm
        lastAddr = if (rm.isNotEmpty()) "room:$rm" else ep
        rcN = 0
        hostNm = name.ifEmpty { "میزبان" }
        setInfo("در حال اتصال به " + name.ifEmpty { "بازی" } + " ...")
        br.connect(ep)
    }

    // ------------------------------------------------------------------ transport events

    fun onEvt(type: String, cid: Int, data: String) {
        when (type) {
            "conn" -> if (role == "host") {
                val pr = data.split("\u0001")
                peers[cid] = Peer(cid, pr.getOrNull(0).orEmpty().ifEmpty { "بازیکن" }, pr.getOrNull(1).orEmpty())
            }
            "found" -> if (role == "client" && !conn) {
                val pr = data.split("\u0001")
                found[pr[0]] = arrayOf(pr.getOrNull(1).orEmpty(), pr.getOrNull(2).orEmpty())
                refreshJoin()
            }
            "lost" -> if (found.remove(data) != null) refreshJoin()
            "open" -> if (role == "client") {
                br.stopScan(); conn = true; rcN = 0
                toHost(JSONObject().put("t", "hello").put("k", "21").put("name", myName).put("id", Prefs.devId()).put("g", Prefs.gender).put("w", Prefs.wallet))
            }
            "msg" -> {
                val m = try { JSONObject(data) } catch (e: Exception) { return }
                if (role == "host") onHostSide(cid, m) else if (role == "client") onClientSide(m)
            }
            "drop" -> {
                if (role == "host") hostDrop(cid)
                else if (role == "client" && !leaving) {
                    conn = false
                    if (g.started) { if (g.isSucc) g.adoptFromSync() else { g.showReconnect(); autoReconnect() } }
                    else setInfo("اتصال برقرار نشد یا قطع شد. دوباره امتحان کنید.")
                }
            }
            "err" -> setInfo("خطا: $data")
            "perm" -> {
                val r = retry
                if (data == "1" && r != null && tries < 5) { retry = null; tries++; Sched.laterRaw(700) { r(true) } }
                else if (data == "s0") setInfo("برای ادامه باید مجوزها را در تنظیمات برنامه روشن کنید. صفحهٔ تنظیمات باز شد؛ مجوزها را بدهید و برگردید تا برنامه خودش ادامه دهد.")
                else {
                    retry = null
                    setInfo(if (data == "1") "اجازه داده شد. دوباره دکمه را بزنید."
                    else if (data == "w0") "وای‌فای هنوز خاموش است. برای وای‌فای مستقیم باید روشن باشد. دوباره دکمه را بزنید و آن را روشن کنید."
                    else if (data == "l0") "موقعیت مکانی روشن نشد. برای وای‌فای مستقیم باید روشن باشد. دوباره دکمه را بزنید."
                    else "اجازه‌ها داده نشد. بدون آن‌ها اتصال نزدیک کار نمی‌کند.")
                }
            }
        }
    }

    private fun unique(base: String, me: Peer): String {
        var nm = base; var i = 2
        while (nm == myName || peers.values.any { it !== me && it.joined && it.name == nm }) { nm = base + " " + Cards.fa(i); i++ }
        return nm
    }

    private fun hostDrop(cid: Int) {
        peers.remove(cid)
        g.onGuestDrop(cid)
        if (!g.started) refreshHost()
    }

    private fun onHostSide(cid: Int, m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> {
                val p = peers[cid] ?: return
                val gk = m.optString("k")
                if (gk.isNotEmpty() && gk != "21") { send(cid, JSONObject().put("t", "kind").put("k", "21").put("host", myName)); return }      // the guest chose another game: it opens this game's lobby and says hello again
                p.id = m.optString("id")
                p.wallet = m.optInt("w", 0)
                p.name = unique(m.optString("name").ifEmpty { "بازیکن" }, p)
                if (g.onGuestHello(cid, p.id)) { p.joined = true; return }          // a player who dropped out came back
                if (g.started) {   // the game is running: wait until the host adds this phone ("افزودن بازیکن")
                    p.joined = true
                    send(cid, JSONObject().put("t", "welcome").put("name", p.name).put("x", "بازی در جریان است. وصل می‌مانید تا میزبان شما را به بازی اضافه کند."))
                    return
                }
                if (joined().size >= 9) { send(cid, JSONObject().put("t", "busy")); return }
                p.joined = true
                send(cid, JSONObject().put("t", "welcome").put("name", p.name))
                refreshHost()
            }
            "ans" -> g.onGuestMsg(cid, m)
            "bye" -> hostDrop(cid)
        }
    }

    private fun onClientSide(m: JSONObject) {
        when (m.optString("t")) {
            "welcome" -> waitScreen(m.optString("name"), m.optString("x"))
            "busy" -> setInfo("این بازی پر است یا جای شما در آن دیگر خالی نیست.")
            "kind" -> if (!g.started) app.switchLobbyGuest("21", m.optString("k"), myName, room, lastAddr, m.optString("host"))
            else -> g.onHostMsg(m)
        }
    }

    private fun waitScreen(nm: String, x: String = "") {
        screen = "wait"
        val v = lobbyBase()
        v.addView(g.mbtn("بستن") { back() })
        v.addView(statusTv())
        g.setScreen("net", v)
        setInfo(if (x.isNotEmpty()) x else "به بازی پیوستید. منتظر شروع بازی توسط " + hostNm + " باشید...")
    }

    // ------------------------------------------------------------------ the waiting room changes to another game (the links stay open)

    /** the phones that are connected now, for the lobby of another game */
    private fun handPeers(): List<HandPeer> = peers.values.map { HandPeer(it.cid, it.name, it.addr) }

    /** another game's lobby has handed its phones over: this is the host lobby of this game with the same room; each phone says hello again */
    fun adoptHost(rm: String, name: String, list: List<HandPeer>) {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        role = "host"; conn = false; leaving = false
        peers.clear()
        for (p in list) peers[p.cid] = Peer(p.cid, p.name, p.addr)
        myName = name; room = rm
        g.roomCode = room
        showHostLobby()
    }

    /** the host changed the game of the waiting room: this phone is a guest of this game now and says hello to the host again */
    fun adoptClient(name: String, rm: String, addr: String, hostName: String) {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        role = "client"; leaving = false; conn = true; rcN = 0
        myName = name; room = rm; lastAddr = addr
        hostNm = hostName.ifEmpty { "میزبان" }
        waitScreen(hostNm, "نوع بازی عوض شد. در حال پیوستن به بازی «" + hostNm + "» ...")
        toHost(JSONObject().put("t", "hello").put("k", "21").put("name", myName).put("id", Prefs.devId()).put("g", Prefs.gender).put("w", Prefs.wallet))
    }

    // ------------------------------------------------------------------ reconnecting a guest

    fun reconnect() {
        if (role != "client") return
        rcN++
        try { br.connect(if (lastAddr.isNotEmpty()) lastAddr else null) } catch (e: Exception) { }
    }

    private fun autoReconnect() {
        Sched.laterRaw(4000) {
            if (!conn && !leaving && g.started && role == "client" && rcN < 15) { reconnect(); autoReconnect() }
            else if (!conn && !leaving && g.started && role == "client" && rcN == 15) {
                rcN++
                g.netNote("اتصال دوباره ممکن نشد. می‌توانید دکمه‌ی «اتصال دوباره» را بزنید.")
            }
        }
    }
}
