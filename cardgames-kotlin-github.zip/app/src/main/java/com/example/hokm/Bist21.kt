package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.CheckBox
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Rules of Iranian "بیست‌ویک" (36 cards: 6..10, J, Q, K, A). Pure logic, no UI. */
object Bist {
    /** card values: A 11, K 4, Q 3, J 2, others their number */
    fun value(r: Int): Int = when (r) { 14 -> 11; 13 -> 4; 12 -> 3; 11 -> 2; else -> r }

    class Total(@JvmField val t: Int, @JvmField val pair: Boolean)

    /** two aces (and only two cards) count 21 */
    fun total(h: List<Card>): Total {
        val pair = h.size == 2 && h[0].r == 14 && h[1].r == 14
        var sum = 0
        for (c in h) sum += value(c.r)
        return Total(if (pair) 21 else sum, pair)
    }

    /** a tie goes to the banker; a player who burned (over 21) has already lost */
    fun playerWins(p: Int, b: Int): Boolean = p <= 21 && (b > 21 || p > b)

    fun newDeck(): MutableList<Card> {
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 6..14) d.add(Card(s, r))
        Cards.shuf(d)
        return d
    }
}

/**
 * The 21 game screen. It is drawn over the main menu (a full-screen overlay) and uses the app
 * settings: name, sounds, card back, table, animation speed, screen-reader mode.
 * The game itself runs on a worker thread that waits for the player's taps (like the page's async code).
 */
class Bist21(private val act: MainActivity, private val app: App) {
    private val NM21 = listOf("علی", "ندا", "رضا", "سارا", "امیر", "مینا", "کیان", "نرگس", "پویا", "هانیه")

    // ---- game options and state ----
    private var bots = 3
    private var base = 1000
    private var minBet = 50
    private var side = false

    private var n = 0
    private var chips = IntArray(0)
    private var names: List<String> = emptyList()
    private var bank = 0
    private var bk = -1
    private var cur = -1
    @Volatile private var mine: MutableList<Card> = ArrayList()
    @Volatile private var bh: MutableList<Card> = ArrayList()
    private val seen = ArrayList<Card>()
    private var reveal = false
    private var msg = ""
    private val logLines = ArrayList<String>()

    // ---- multi-phone: role "solo" (robots only) | "host" (runs the game) | "guest" (only shows it) ----
    @JvmField var role = "solo"
    @JvmField var mySeat = 0
    @Volatile var started = false
    private val freeAt = LongArray(10)
    @JvmField var isSucc = false
    private var syncSnap: JSONObject? = null
    @JvmField var roomCode = ""
    private val remote = BooleanArray(10)
    private val cidOf = IntArray(10) { -1 }
    private val idOf = Array(10) { "" }
    private val ansQ = Array(10) { LinkedBlockingQueue<String>() }
    @Volatile private var askSeq = 0
    @Volatile private var curHand: MutableList<Card> = ArrayList()
    private var net: Net21? = null
    private var lastGo: JSONObject? = null

    @Volatile private var alive = false
    private var worker: Thread? = null
    private val answers = LinkedBlockingQueue<String>()

    // ---- views ----
    private val ov = FrameLayout(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)
    private lateinit var gameV: LinearLayout
    private lateinit var bankTv: TextView
    private lateinit var msgTv: TextView
    private lateinit var playersV: FrameLayout
    private lateinit var bankerLab: TextView
    private lateinit var bankerV: com.example.hokm.FlowLayout
    private lateinit var mineLab: TextView
    private lateinit var mineV: com.example.hokm.FlowLayout
    private lateinit var ctl: LinearLayout
    private lateinit var logTv: TextView
    private var screen = "menu"
    private var lastMsg = ""
    private var lastMine = ""
    private var lastBank = ""
    private var lastMineN = 0
    private var lastReveal = false
    private var lastBhN = 0
    private var lastMineKey = ""
    private var lastBankKey = ""
    private lateinit var deckV: ImageView
    @Volatile private var held = false
    private lateinit var holdBar: LinearLayout
    private lateinit var holdTv: TextView

    // ------------------------------------------------------------------ shell

    // ---- small UI helpers (also used by Net21) ----

    /** run on the UI thread (the game itself runs on a worker thread) */
    fun ui(f: () -> Unit) {
        act.runOnUiThread { try { f() } catch (e: Exception) { } }
    }

    fun tv(t: String, size: Float = 15f, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    /** a screen title; TalkBack treats it as a heading */
    fun heading(t: String): TextView {
        val v = tv(t, 22f, Px.tx, true)
        v.gravity = Gravity.CENTER
        v.setPadding(0, Px.dp(8), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) v.isAccessibilityHeading = true
        return v
    }

    /** the green rounded menu button */
    fun mbtn(t: String, f: () -> Unit): android.widget.Button {
        val b = app.dlg.btn(t, true, f)
        val l = LinearLayout.LayoutParams(
            Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)),
            ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    /** show one screen (menu, setup, saves, net, game) in the overlay */
    fun setScreen(name: String, v: View) {
        screen = name
        content.removeAllViews()
        content.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }


    fun show(start: String) {
        ov.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ov.setBackgroundColor(Px.bg)
        ov.isClickable = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        val sc = ScrollView(act)
        sc.isFillViewport = true
        sc.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.addView(sc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        app.menuShown(false)
        act.onBack = { back() }
        if (start == "resume") { showSaves() }
        else if (start == "net") { val nt = Net21(act, app, this); net = nt; nt.show() }
        else showSetup()
    }

    /** leave the 21 game and return to the main menu */
    fun close() {
        stopGame()
        net?.close(); net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        app.menuShown(true)
        app.syncBg()
        act.onBack = { app.back() }
        act.btEvt = null
    }

    /** does the phone with connection id [cid] have a seat in the running game */
    fun hasSeat(cid: Int): Boolean = cidOf.indexOf(cid) >= 1

    private fun back(): Boolean {
        if (screen == "net" && net?.back() == true) return true
        if (screen == "game") { backAsk(); return true }   // one step back (asks first)
        net?.leave(); close()
        return true
    }

    private fun showSaves() {
        val l = Saves.all(false)
        if (l.isEmpty()) { app.dlg.message("بازی ذخیره‌شده‌ای وجود ندارد."); close(); return }
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("بازی‌های قبلی"))
        for (e in l) v.addView(mbtn(Saves.describe(e)) { saveActions(e) })
        setScreen("saves", v)
    }

    private fun saveActions(e: Saves.E) {
        app.dlg.list(Saves.describe(e), listOf(
            "ادامه بازی" to { resumeFrom(e) },
            "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { Saves.del(e.id); showSaves() }) }
        ), "بستن")
    }

    private fun showSetup() {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL
        v.addView(heading("بازی جدید"))
        v.addView(tv("سکه‌های شما: " + Cards.fa(Prefs.wallet), 16f, Px.GOLD, true))
        val botLab = tv("تعداد ربات‌ها: " + Cards.fa(bots), 16f)
        v.addView(botLab)
        val sb = SeekBar(act); sb.max = 8; sb.progress = bots - 1
        sb.contentDescription = "تعداد ربات‌ها"
        var botsSel = bots
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { botsSel = p + 1; botLab.text = "تعداد ربات‌ها: " + Cards.fa(botsSel) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        v.addView(sb)
        v.addView(tv("بانک اولیه (ژتون بانکدار؛ عدد را تایپ کنید)", 16f))
        val e1 = numField(act, "بانک اولیه", base)
        v.addView(e1, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        v.addView(tv("کمترین شرط (عدد را تایپ کنید)", 16f))
        val e2 = numField(act, "کمترین شرط", minBet)
        v.addView(e2, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        val cb = CheckBox(act); cb.text = "شرط روی دست دیگران (خواندن)"; cb.isChecked = side
        cb.setTextColor(Px.tx)
        v.addView(cb)
        v.addView(mbtn("شروع بازی") {
            val nb = Cards.num(e1.text.toString()); val nm = Cards.num(e2.text.toString())
            if (nb < 1) { app.dlg.message("بانک اولیه را به‌صورت عدد (دست‌کم ۱) تایپ کنید."); return@mbtn }
            if (nm < 1) { app.dlg.message("کمترین شرط را به‌صورت عدد (دست‌کم ۱) تایپ کنید."); return@mbtn }
            if (nm > nb) { app.dlg.message("کمترین شرط نباید از بانک اولیه بیشتر باشد."); return@mbtn }
            bots = botsSel; base = nb; minBet = nm; side = cb.isChecked
            if (Prefs.wallet < minBet) { app.dlg.message("سکه‌های شما از کمترین شرط کمتر است. کمترین شرط را کمتر کنید."); return@mbtn }
            startNew()
        })
        setScreen("setup", v)
    }

    // ------------------------------------------------------------------ game start / resume / save

    private fun startNew() {
        role = "solo"; mySeat = 0; remote.fill(false); held = false
        n = bots + 1
        chips = IntArray(n) { if (it == 0) Prefs.wallet else START }
        names = listOf(if (Prefs.name.isEmpty()) "شما" else Prefs.name) + NM21.subList(0, bots)
        bk = -1
        startGame()
    }

    private fun resumeFrom(e: Saves.E) {
        try {
            val j = JSONObject(e.data)
            role = "solo"; mySeat = 0; remote.fill(false); held = false
            bots = j.getInt("bots"); base = j.getInt("base"); minBet = j.getInt("min"); side = j.getBoolean("side")
            val c = j.getJSONArray("chips"); val nm = j.getJSONArray("names")
            n = c.length()
            chips = IntArray(n) { c.getInt(it) }
            chips[0] = Prefs.wallet
            names = List(n) { nm.getString(it) }
            bk = j.getInt("bk")
            startGame()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده پیدا نشد."); close() }
    }

    /** the state at the end of the last hand (a game can only be saved or handed over there) */
    private var bChips = IntArray(0)
    private var bBk = -1

    private fun soloJson(): String {
        val j = JSONObject()
        j.put("bots", bots); j.put("base", base); j.put("min", minBet); j.put("side", side)
        j.put("chips", JSONArray(bChips.toList())); j.put("names", JSONArray(names)); j.put("bk", bBk)
        return j.toString()
    }

    private fun saveGame() {
        if (role != "solo") return
        try { Saves.put("auto", false, soloJson()) } catch (e: Exception) { }
    }

    /** "ذخیره" in the game menu */
    private fun manualSave() {
        try {
            val where: String
            if (role == "solo") { Saves.put("s" + System.currentTimeMillis(), false, soloJson()); where = "بازی با ربات" }
            else if (role == "host") { Saves.put("s" + System.currentTimeMillis(), true, snapshot().toString()); where = "بازی با چند گوشی" }
            else { app.dlg.list("فقط میزبان می‌تواند بازی را ذخیره کند.", listOf(), "باشه"); return }
            app.dlg.list("بازی ذخیره شد. هر وقت خواستید از «بازی‌های قبلی» در بخش «" + where + "» ادامه‌اش دهید.", listOf(), "باشه")
        } catch (e: Exception) { app.dlg.list("ذخیرهٔ بازی ممکن نشد.", listOf(), "باشه") }
    }

    private fun startGame() {
        stopGame()
        bank = 0; cur = -1; mine = ArrayList(); bh = ArrayList(); seen.clear(); reveal = false; msg = ""
        bChips = chips.copyOf(); bBk = bk
        logLines.clear(); lastMsg = ""; lastMine = ""; lastBank = ""
        Spk.reset()
        buildGameView()
        alive = true
        started = true
        bChips = chips.copyOf(); bBk = bk
        if (role == "host") { lastGo = null; for (q in 1 until n) if (remote[q]) sendSeat(q, goMsg(q)); syncSucc() }
        val t = Thread {
            try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { }
        }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun stopGame() {
        alive = false
        worker?.interrupt()
        worker = null
    }

    // ------------------------------------------------------------------ game view

    private fun buildGameView() {
        gameV = LinearLayout(act); gameV.orientation = LinearLayout.VERTICAL
        gameV.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val bmp = if (Prefs.bg > 0) Assets.bitmap(act, Assets.bgPath(Prefs.bg)) else null
        gameV.background = if (bmp != null) CoverDrawable(bmp, 0x1F000000) else Px.rounded(Px.FELT, 16)

        val more = LinearLayout(act); more.orientation = LinearLayout.HORIZONTAL
        more.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val mb = TextView(act)
        mb.text = "⋮"; mb.textSize = 26f; mb.setTextColor(Color.WHITE); mb.gravity = Gravity.CENTER
        mb.background = Px.rounded(0x59000000, 20)
        mb.contentDescription = "گزینه‌های بیشتر"
        mb.isClickable = true; mb.isFocusable = true
        mb.setOnClickListener { gameMenu() }
        more.addView(mb, LinearLayout.LayoutParams(Px.dp(40), Px.dp(40)))
        gameV.addView(more)
        val top = LinearLayout(act); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        bankTv = tv("", 20f, Px.GOLD, true)
        top.addView(bankTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
        gameV.addView(top)
        msgTv = tv("", 15f, Color.WHITE)
        msgTv.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_NONE
        gameV.addView(msgTv)
        val ringBox = FrameLayout(act)
        playersV = FrameLayout(act)
        playersV.layoutDirection = View.LAYOUT_DIRECTION_LTR
        ringBox.addView(playersV, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        deckV = ImageView(act)
        val backBmp = Assets.bitmap(act, Assets.backPath(Prefs.back))
        if (backBmp != null) deckV.setImageBitmap(backBmp)
        deckV.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        ringBox.addView(deckV, FrameLayout.LayoutParams(Px.dp(46), Px.dp(64), Gravity.CENTER))
        gameV.addView(ringBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(if (n > 6) 290 else 230)).also { it.topMargin = Px.dp(8) })
        bankerLab = tv("بانکدار", 14f, 0xFFD8CDB4.toInt())
        gameV.addView(bankerLab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        bankerV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(bankerV)
        mineLab = tv("برگ‌های شما", 14f, 0xFFD8CDB4.toInt())
        gameV.addView(mineLab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        mineV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(mineV)
        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL
        gameV.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        logTv = tv("", 13f, 0xFFE8DCC4.toInt())
        gameV.addView(logTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        holdBar = LinearLayout(act); holdBar.orientation = LinearLayout.VERTICAL; holdBar.visibility = View.GONE
        holdTv = tv("", 14f, 0xFFFFE36B.toInt(), true)
        holdBar.addView(holdTv)
        holdBar.addView(app.dlg.btn("ادامه بازی", true) { resumeHold() })
        gameV.addView(holdBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        lastMineN = 0; lastBhN = 0; lastMineKey = ""; lastBankKey = ""; lastReveal = false
        setScreen("game", gameV)
    }

    private fun cardView(c: Card, hidden: Boolean): View {
        val iv = ImageView(act)
        val bmp = Assets.bitmap(act, if (hidden) Assets.backPath(Prefs.back) else Assets.cardPath(c))
        if (bmp != null) iv.setImageBitmap(bmp)
        iv.tag = bmp
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.contentDescription = if (hidden) "برگ رونشده" else Cards.cname(c)
        iv.layoutParams = ViewGroup.LayoutParams(Px.dp(46), Px.dp(64))
        return iv
    }

    /** puts the players on an oval: our seat at the bottom, the others round the table */
    private fun placeRing() {
        val w = playersV.width; val h = playersV.height
        val cnt = playersV.childCount
        if (w <= 0 || h <= 0 || cnt == 0) return
        for (k in 0 until cnt) {
            val c = playersV.getChildAt(k)
            c.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            val cw = c.measuredWidth.toFloat(); val ch = c.measuredHeight.toFloat()
            val ang = Math.PI / 2 + 2 * Math.PI * k / cnt
            c.translationX = (w / 2f + (w / 2f - cw / 2f) * Math.cos(ang) - cw / 2f).toFloat()
            c.translationY = (h / 2f + (h / 2f - ch / 2f) * Math.sin(ang) - ch / 2f).toFloat()
        }
        // the deck lies beside the banker (between his seat and the middle of the table)
        if (::deckV.isInitialized) {
            var dx = 0f; var dy = 0f
            if (bk >= 0 && n > 0) {
                val kb = ((bk - mySeat) % n + n) % n
                if (kb < cnt) {
                    val bc = playersV.getChildAt(kb)
                    val bx = bc.translationX + bc.measuredWidth / 2f; val by = bc.translationY + bc.measuredHeight / 2f
                    val cx = w / 2f; val cy = h / 2f
                    val len = Math.hypot((cx - bx).toDouble(), (cy - by).toDouble()).toFloat()
                    if (len > 1f) {
                        val off = bc.measuredHeight / 2f + Px.dp(64) / 2f + Px.dp(4)
                        dx = bx + (cx - bx) / len * off - cx; dy = by + (cy - by) / len * off - cy
                    }
                }
            }
            deckV.animate().translationX(dx).translationY(dy).setDuration(Anim.ad(300L)).start()
        }
    }

    /** cards that were just dealt slide in from above */
    private fun loc(v: View): IntArray { val a = IntArray(2); v.getLocationInWindow(a); return a }

    /** new cards fly from the deck to their place and turn over there */
    private fun animNew(row: ViewGroup, prev: Int) {
        val back = Assets.bitmap(act, Assets.backPath(Prefs.back))
        for (i in prev until row.childCount) {
            val v = row.getChildAt(i)
            val iv = v as? ImageView
            val face = v.tag as? android.graphics.Bitmap
            val flip = iv != null && face != null && back != null && face !== back
            if (flip) iv!!.setImageBitmap(back)
            v.alpha = 0f
            val order = i - prev
            v.post {
                try {
                    if (!v.isAttachedToWindow || !::deckV.isInitialized) { v.alpha = 1f; if (flip) iv!!.setImageBitmap(face); return@post }
                    val sv: View = deckV
                    val a = loc(sv); val b = loc(v)
                    v.translationX = a[0] + (sv.width - v.width) / 2f - b[0]; v.translationY = a[1] + (sv.height - v.height) / 2f - b[1]
                    dealGesture(v)
                    v.scaleX = 0.7f; v.scaleY = 0.7f; v.rotation = -25f; v.alpha = 1f
                    v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).rotation(0f)
                        .setDuration(Anim.ad(380L)).setStartDelay(Anim.ad(80L * order))
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .withEndAction {
                            if (flip) iv!!.animate().scaleX(0f).setDuration(Anim.ad(90L)).withEndAction {
                                iv.setImageBitmap(face); iv.animate().scaleX(1f).setDuration(Anim.ad(90L)).start()
                            }.start()
                        }.start()
                } catch (e: Exception) { v.alpha = 1f; if (flip) iv!!.setImageBitmap(face) }
            }
        }
    }

    /** a card flies from the deck to another player's seat (their cards are not shown, so only the movement is) */
    /** the table seat (the round cell with the face) of a player */
    private fun cellOf(seat: Int): View? {
        if (seat < 0 || n <= 0 || !::playersV.isInitialized) return null
        val k = ((seat - mySeat) % n + n) % n
        return if (k < playersV.childCount) playersV.getChildAt(k) else null
    }

    /** where dealt cards start: the banker's seat (the deck for the banker's own card) */
    private fun dealerView(forSeat: Int): View = deckV

    /** the banker's cell leans towards the player he deals to, and back */
    private fun dealGesture(to: View?) {
        val c = (if (bk >= 0) cellOf(bk) else null) ?: return
        if (to == null || to === c) return
        val a = loc(c); val b = loc(to)
        val dx = (b[0] - a[0]) * 0.12f; val dy = (b[1] - a[1]) * 0.12f
        val x0 = c.translationX; val y0 = c.translationY
        c.animate().translationX(x0 + dx).translationY(y0 + dy).setDuration(Anim.ad(110L))
            .withEndAction { c.animate().translationX(x0).translationY(y0).setDuration(Anim.ad(140L)).start() }.start()
    }

    private fun flyTo(seat: Int) {
        if (screen != "game" || seat == mySeat || !::deckV.isInitialized || n <= 0) return
        val k = (seat - mySeat + n) % n
        if (k >= playersV.childCount) return
        val target = playersV.getChildAt(k)
        val srcV: View = dealerView(seat)
        val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back)) ?: return
        val w = Px.dp(34); val h = Px.dp(48)
        val iv = ImageView(act); iv.setImageBitmap(bmp)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val o = loc(ov); val a = loc(srcV); val t = loc(target)
        val lp0 = FrameLayout.LayoutParams(w, h); lp0.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp0)
        iv.x = a[0] - o[0] + (srcV.width - w) / 2f
        iv.y = a[1] - o[1] + (srcV.height - h) / 2f
        dealGesture(target)
        iv.animate().x(t[0] - o[0] + (target.width - w) / 2f).y(t[1] - o[1] + (target.height - h) / 2f).rotation(20f)
            .setDuration(Anim.ad(320L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** a gold chip with the amount flies between a player's seat and the bank (from / to = -1 is the bank) */
    private fun flyChip(from: Int, to: Int, amount: Int) {
        if (screen != "game" || n <= 0) return
        val a: View = (if (from < 0) bankTv else cellOf(from)) ?: return
        val b: View = (if (to < 0) bankTv else cellOf(to)) ?: return
        val o = loc(ov); val pa = loc(a); val pb = loc(b)
        val sz = Px.dp(38)
        val chip = TextView(act)
        chip.text = Cards.fa(amount); chip.textSize = 11f; chip.setTextColor(0xFF222222.toInt())
        chip.setTypeface(chip.typeface, Typeface.BOLD)
        chip.gravity = Gravity.CENTER
        chip.background = Px.rounded(Px.GOLD, 19, 2, 0xFFB8860B.toInt())
        chip.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val lp = FrameLayout.LayoutParams(sz, sz); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(chip, lp)
        chip.x = pa[0] - o[0] + (a.width - sz) / 2f; chip.y = pa[1] - o[1] + (a.height - sz) / 2f
        chip.animate().x(pb[0] - o[0] + (b.width - sz) / 2f).y(pb[1] - o[1] + (b.height - sz) / 2f).scaleX(0.75f).scaleY(0.75f)
            .setDuration(Anim.ad(480L)).setInterpolator(android.view.animation.AccelerateDecelerateInterpolator())
            .withEndAction { try { ov.removeView(chip) } catch (e: Exception) { } }.start()
    }

    private fun chipFx(from: Int, to: Int, amount: Int) {
        ui { flyChip(from, to, amount) }
        if (role == "host") sendAll(JSONObject().put("t", "chip").put("a", from).put("b", to).put("m", amount))
    }

    /** a player who burned shakes his head */
    private fun shake(seat: Int) {
        val c = cellOf(seat) ?: return
        val x0 = c.translationX; val d = Px.dp(7).toFloat()
        c.animate().translationX(x0 + d).setDuration(Anim.ad(60L)).withEndAction {
            c.animate().translationX(x0 - d).setDuration(Anim.ad(90L)).withEndAction {
                c.animate().translationX(x0 + d / 2).setDuration(Anim.ad(70L)).withEndAction {
                    c.animate().translationX(x0).setDuration(Anim.ad(60L)).start()
                }.start()
            }.start()
        }.start()
    }

    /** gold coins fly between the bank (top of the screen) and a player: toPlayer = the bank pays him, else he pays the bank */
    private fun flyCoins(seat: Int, toPlayer: Boolean, amount: Int) {
        try {
            // the more money, the more coins (1 to 10)
            val unit = Math.max(minBet, base / 5)
            val cnt = Math.max(1, Math.min(10, (amount + unit - 1) / unit))
            val cell = cellOf(seat) ?: return
            val o = loc(ov); val a = loc(bankTv); val c = loc(cell)
            val bx = a[0] - o[0] + bankTv.width / 2f; val by = a[1] - o[1] + bankTv.height / 2f
            val px = c[0] - o[0] + cell.width / 2f; val py = c[1] - o[1] + cell.height / 2f
            val sx = if (toPlayer) bx else px; val sy = if (toPlayer) by else py
            val ex = if (toPlayer) px else bx; val ey = if (toPlayer) py else by
            val sz = Px.dp(18)
            for (i in 0 until cnt) {
                val coin = View(act)
                coin.background = Px.rounded(Px.GOLD, 9, 2, 0xFF8A6A00.toInt())
                coin.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                val lp = FrameLayout.LayoutParams(sz, sz); lp.gravity = Gravity.TOP or Gravity.LEFT
                ov.addView(coin, lp)
                coin.x = sx - sz / 2f; coin.y = sy - sz / 2f; coin.alpha = 0f
                coin.animate().alpha(1f).x(ex - sz / 2f + (i - (cnt - 1) / 2f) * Px.dp(4)).y(ey - sz / 2f)
                    .setStartDelay(Anim.ad(60L * i)).setDuration(Anim.ad(420L))
                    .withEndAction {
                        coin.animate().alpha(0f).setStartDelay(0L).setDuration(Anim.ad(150L))
                            .withEndAction { try { ov.removeView(coin) } catch (e: Exception) { } }.start()
                    }.start()
            }
        } catch (e: Exception) { }
    }

    private fun coinFx(seat: Int, toPlayer: Boolean, amount: Int) {
        ui { flyCoins(seat, toPlayer, amount) }
        if (role == "host") sendAll(JSONObject().put("t", "coin").put("s", seat).put("w", toPlayer).put("a", amount))
    }

    private fun shakeFx(seat: Int) {
        ui { shake(seat) }
        if (role == "host") sendAll(JSONObject().put("t", "fx").put("s", seat))
    }

    /** at the end of a hand the cards on the table go back to the deck */
    private fun flyCollect(winner: Int) {
        if (screen != "game" || n <= 0) return
        if (!::deckV.isInitialized) return
        val target: View = deckV
        val o = loc(ov); val t = loc(target)
        var i = 0
        for (row in listOf<ViewGroup>(bankerV, mineV)) {
            for (j in 0 until row.childCount) {
                val c = row.getChildAt(j) as? ImageView ?: continue
                val d = c.drawable ?: continue
                val a = loc(c)
                val w = c.width; val h = c.height
                val iv = ImageView(act)
                iv.setImageDrawable(d.constantState?.newDrawable() ?: d)
                iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
                ov.addView(iv, lp)
                iv.x = (a[0] - o[0]).toFloat(); iv.y = (a[1] - o[1]).toFloat()
                c.visibility = View.INVISIBLE
                iv.animate().x(t[0] - o[0] + (target.width - w) / 2f).y(t[1] - o[1] + (target.height - h) / 2f)
                    .scaleX(0.6f).scaleY(0.6f).alpha(0f)
                    .setStartDelay(Anim.ad(70L * i)).setDuration(Anim.ad(420L))
                    .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
                i++
            }
        }
    }

    private fun collectFx(winner: Int) {
        ui { flyCollect(winner) }
        if (role == "host") sendAll(JSONObject().put("t", "col").put("s", winner))
    }

    private fun dealTo(seat: Int) {
        ui { flyTo(seat) }
        if (role == "host") sendAll(JSONObject().put("t", "fly").put("s", seat))
    }

    /** a big gold message in the middle of the screen  */
    private fun banner(text: String) {
        val e = TextView(act)
        e.text = text; e.textSize = 26f; e.setTextColor(0xFFFFE36B.toInt()); e.setTypeface(e.typeface, Typeface.BOLD)
        e.gravity = Gravity.CENTER
        e.setPadding(Px.dp(22), Px.dp(14), Px.dp(22), Px.dp(14))
        e.background = Px.rounded(0xCC000000.toInt(), 16, 2, Px.GOLD)
        e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        e.alpha = 0f; e.scaleX = 0.5f; e.scaleY = 0.5f
        ov.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        e.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(Anim.ad(250L)).withEndAction {
            e.animate().alpha(0f).setStartDelay(Anim.ad(1300L)).setDuration(Anim.ad(350L)).withEndAction { try { ov.removeView(e) } catch (x: Exception) { } }.start()
        }.start()
    }

    private fun bannerSeat(seat: Int, text: String) {
        if (seat == 0 || role != "host") { if (seat == 0) ui { banner(text) }; return }
        if (remote[seat]) sendSeat(seat, JSONObject().put("t", "ban").put("m", text))
    }

    private fun totalText(h: List<Card>): String {
        if (h.isEmpty()) return ""
        val t = Bist.total(h)
        return " = " + Cards.fa(t.t) + (if (t.pair) " (جفت تک)" else "")
    }

    private fun handSpeech(h: List<Card>): String =
        h.joinToString("، ") { Cards.cname(it) } + ". مجموع " + Cards.fa(Bist.total(h).t)

    private fun draw() { ui { render() }; if (role == "host") pushAll() }

    private fun render() {
        if (screen != "game" || !::playersV.isInitialized) return
        bankTv.text = "بانک: " + Cards.fa(bank)
        msgTv.text = msg
        if (msg.isNotEmpty() && msg != lastMsg) { lastMsg = msg; ann(msg) }
        playersV.removeAllViews()
        for (k in 0 until n) {
            val i = (mySeat + k) % n          // our own seat first, then the others in order round the table
            val isB = i == bk
            val cell = LinearLayout(act)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(Px.dp(8), Px.dp(4), Px.dp(8), Px.dp(4))
            cell.background = Px.rounded(if (isB) Px.GOLD else 0x8C000000.toInt(), 10, if (i == cur) 2 else 0, Px.GOLD)
            cell.contentDescription = names[i] + (if (isB) "، بانکدار" else "") + "، ژتون " + Cards.fa(chips[i])
            cell.isFocusable = true
            try { cell.addView(Av.view(act, names[i], 36, i == cur, i == cur)) } catch (e: Exception) { }
            val t = tv(names[i] + (if (isB) " 👑" else "") + "\n" + Cards.fa(chips[i]), 12f, if (isB) 0xFF222222.toInt() else Color.WHITE)
            t.gravity = Gravity.CENTER
            t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            cell.addView(t)
            playersV.addView(cell, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        playersV.post { placeRing() }
        val meBank = bk == mySeat
        val bl = ArrayList(bh)
        bankerLab.text = "بانکدار" + (if (meBank) totalText(bl) else "")
        val kb2 = bl.joinToString(",") { Cards.idc(it).toString() } + "|" + meBank + "|" + reveal + "|" + Prefs.back
        if (kb2 != lastBankKey) {
            lastBankKey = kb2
            bankerV.removeAllViews()
            bl.forEachIndexed { i, c -> bankerV.addView(cardView(c, i == 0 && !meBank && !reveal)) }
            animNew(bankerV, lastBhN)
            lastBhN = bl.size
            if (reveal && !lastReveal && !meBank && bankerV.childCount > 0) {
                val f0 = bankerV.getChildAt(0)
                f0.scaleX = 0f
                f0.animate().scaleX(1f).setDuration(Anim.ad(260L)).start()
            }
            lastReveal = reveal
        }
        val ml = ArrayList(mine)
        mineLab.text = "برگ‌های شما" + totalText(ml)
        val km2 = ml.joinToString(",") { Cards.idc(it).toString() } + "|" + Prefs.back
        if (km2 != lastMineKey) {
            lastMineKey = km2
            mineV.removeAllViews()
            for (c in ml) mineV.addView(cardView(c, false))
            animNew(mineV, lastMineN)
            lastMineN = ml.size
        }
        // what the screen reader says about our hands
        val km = ml.joinToString(" ") { Cards.idc(it).toString() }
        if (km.isNotEmpty() && km != lastMine) { lastMine = km; ann("برگ‌های شما: " + handSpeech(ml)) } else if (km.isEmpty()) lastMine = ""
        val kb = if (meBank) bl.joinToString(" ") { Cards.idc(it).toString() } else ""
        if (kb.isNotEmpty() && kb != lastBank) { lastBank = kb; ann("برگ‌های شما به عنوان بانکدار: " + handSpeech(bl)) } else if (kb.isEmpty()) lastBank = ""
        // only the newest message stays on the screen; older ones are dropped
        while (logLines.size > 1) logLines.removeAt(0)
        logTv.text = logLines.lastOrNull() ?: ""
    }

    // ------------------------------------------------------------------ speech 

    private fun ann(t: String) {
        val d = Spk.slot(t, 0L)
        Sched.laterRaw(d) { speak(t) }
        // a guest tells the host when it will have finished speaking, so the host waits a little for it
        if (role == "guest") net?.toHost(JSONObject().put("t", "free").put("ms", Math.max(0L, Spk.end - Sched.now())))
    }

    private fun speak(t: String) {
        if (!Prefs.a11y) return
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logTv.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    private fun idle(): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now())

    private fun focusSoon(v: View?) {
        if (v == null || !Prefs.a11y) return
        Sched.laterRaw(idle() + 50L) {
            try { v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null) } catch (e: Exception) { }
        }
    }

    // ------------------------------------------------------------------ worker helpers (run on the game thread)

    private fun sleep(ms: Long) { Thread.sleep(Anim.ad(ms)) }
    private fun gate() {
        if (role != "host") return
        val t0 = Sched.now(); var wm = 0L
        while (alive) {
            val now = Sched.now(); var w = 0L
            for (q in 1 until n) if (remote[q] && freeAt[q] > now) w = Math.max(w, freeAt[q] - now)
            wm = Math.max(wm, w)
            val used = now - t0
            val cap = Math.min(6000.0, Math.max(700.0, wm * 0.3)).toLong()
            if (w > 0 && used < cap) Thread.sleep(Math.min(w, cap - used) + 30) else break
        }
    }

    private fun pace(ms: Long) {
        Thread.sleep(Math.max(Anim.ad(ms), idle()))
        gate()
        while (held && alive) Thread.sleep(300)      // paused: waiting for the host to press "ادامه بازی"
    }

    private fun startHold(t: String) {
        held = true
        val txt = t + " بازی متوقف است. برای ادامه، دکمه‌ی «ادامه بازی» را بزنید."
        ui { holdTv.text = txt; holdBar.visibility = View.VISIBLE; ann(txt) }
        sendAll(JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
    }

    private fun resumeHold() {
        if (!held) return
        held = false
        holdBar.visibility = View.GONE
        sendAll(JSONObject().put("t", "hold").put("on", false))
        say("بازی ادامه پیدا کرد.")
    }

    /** a seat played by a person: the host himself (seat 0) or a connected guest */
    private fun isH(p: Int): Boolean = p == 0 || (role == "host" && remote[p])

    private fun say(m: String) {
        ui { logLines.add(m); ann(m); render() }
        if (role == "host") sendAll(JSONObject().put("t", "say").put("m", m))
    }

    /** a line only one player hears (for example his own chips) */
    private fun sayTo(seat: Int, m: String) {
        if (seat == 0) { ui { logLines.add(m); ann(m); render() }; return }
        if (role == "host" && remote[seat]) sendSeat(seat, JSONObject().put("t", "say").put("m", m))
    }

    /** three card backs shuffle in the middle of the screen */
    private fun shuffleAnim() {
        val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back)) ?: return
        val box = FrameLayout(act)
        box.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        for (i in 0 until 3) {
            val iv = ImageView(act); iv.setImageBitmap(bmp)
            box.addView(iv, FrameLayout.LayoutParams(Px.dp(60), Px.dp(84), Gravity.CENTER))
            iv.animate().translationX(((if (i % 2 == 0) 1 else -1) * Px.dp(28)).toFloat()).rotation(((i - 1) * 14).toFloat())
                .setDuration(Anim.ad(180L)).setStartDelay(Anim.ad(60L * i))
                .withEndAction { iv.animate().translationX(0f).rotation(0f).setDuration(Anim.ad(180L)).start() }.start()
        }
        if (::deckV.isInitialized && deckV.width > 0) {
            val bw = Px.dp(130); val bh = Px.dp(100)
            val lpb = FrameLayout.LayoutParams(bw, bh); lpb.gravity = Gravity.TOP or Gravity.LEFT
            ov.addView(box, lpb)
            val d = loc(deckV); val o = loc(ov)
            box.x = d[0] - o[0] + deckV.width / 2f - bw / 2f; box.y = d[1] - o[1] + deckV.height / 2f - bh / 2f
        } else {
            ov.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
        box.postDelayed({ try { ov.removeView(box) } catch (e: Exception) { } }, Anim.ad(700L))
    }

    private fun snd(name: String) {
        Sched.post { Sound.plain(name) }
        if (name == "shuffle") ui { shuffleAnim() }
        if (role == "host") sendAll(JSONObject().put("t", "snd").put("n", name))
    }

    private fun sndSeat(seat: Int, name: String) {
        if (seat == 0) { Sched.post { Sound.plain(name) }; return }
        if (role == "host" && remote[seat]) sendSeat(seat, JSONObject().put("t", "snd").put("n", name))
    }

    // ---- the buttons shown to whoever has to decide (this phone's player, or a guest) ----

    /** shows buttons; onPick gets the key of the tapped one. Runs on the UI thread. */
    private fun buildButtons(opts: List<Pair<String, String>>, extra: String?, onPick: (String) -> Unit) {
        ctl.removeAllViews()
        if (extra != null && extra.isNotEmpty()) ctl.addView(tv(extra, 14f, Color.WHITE))
        var first: View? = null
        for ((k, t) in opts) {
            val b = app.dlg.btn(t, true) { ctl.removeAllViews(); onPick(k) }
            ctl.addView(b)
            if (first == null) first = b
        }
        focusSoon(first)
    }

    /** shows the bet slider; onPick gets "b<amount>" */
    private fun buildBet(mn: Int, mx: Int, bnk: Int, canAll: Boolean, onPick: (String) -> Unit) {
        ctl.removeAllViews()
        var amount = mn
        val lab = tv("شرط: " + Cards.fa(mn), 16f, Color.WHITE)
        ctl.addView(lab)
        val steps = Math.max(1, mx / mn)
        val sb = SeekBar(act); sb.max = steps - 1; sb.progress = 0
        sb.contentDescription = "مقدار شرط"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { amount = (p + 1) * mn; lab.text = "شرط: " + Cards.fa(amount) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        ctl.addView(sb)
        ctl.addView(app.dlg.btn("شرط می‌بندم", true) { ctl.removeAllViews(); onPick("b" + amount) })
        if (canAll) ctl.addView(app.dlg.btn("کل بانک (" + Cards.fa(bnk) + ")", true) { ctl.removeAllViews(); onPick("b" + bnk) })
        focusSoon(sb)
    }

    /** this phone's player decides; blocks the game thread until he taps */
    private fun ask(opts: List<Pair<String, String>>, extra: String? = null): String {
        answers.clear()
        ui { buildButtons(opts, extra) { k -> answers.offer(k) } }
        return answers.take()
    }

    private fun askBet(mx: Int): Int {
        answers.clear()
        val all = chips[0] >= bank && bank >= minBet
        ui { buildBet(minBet, mx, bank, all) { v -> answers.offer(v) } }
        return answers.take().substring(1).toInt()
    }

    /** waits for the answer of a guest (with the number of the question); def only when he drops out */
    private fun waitAns(seat: Int, id: Int, def: String): String {
        while (alive) {
            val a = ansQ[seat].take()
            if (a == "drop") return def
            val i = a.indexOf('|')
            if (i > 0 && a.substring(0, i) == id.toString()) return a.substring(i + 1)
        }
        return def
    }

    /** the player at [seat] decides (def = what a robot does when nobody answers) */
    private fun askSeat(seat: Int, opts: List<Pair<String, String>>, extra: String?, def: String): String {
        if (seat == 0 || role != "host") return ask(opts, extra)
        if (!remote[seat]) return def
        val id = ++askSeq
        ansQ[seat].clear()
        val o = JSONArray()
        for (x in opts) o.put(JSONArray().put(x.first).put(x.second))
        sendSeat(seat, JSONObject().put("t", "ask").put("id", id).put("k", "btn").put("x", extra ?: "").put("o", o))
        return waitAns(seat, id, def)
    }

    private fun askBetSeat(seat: Int, mx: Int): Int {
        if (seat == 0 || role != "host") return askBet(mx)
        if (!remote[seat]) return minBet
        val id = ++askSeq
        ansQ[seat].clear()
        sendSeat(seat, JSONObject().put("t", "ask").put("id", id).put("k", "bet").put("mn", minBet).put("mx", mx).put("bank", bank)
            .put("all", chips[seat] >= bank && bank >= minBet))
        val v = waitAns(seat, id, "b" + minBet)
        val amt = try { v.substring(1).toInt() } catch (e: Exception) { minBet }
        return Math.max(minBet, Math.min(mx, amt))
    }

    private fun draw1(deck: MutableList<Card>): Card {
        if (deck.isEmpty()) {
            val f: MutableList<Card> = if (seen.isNotEmpty()) ArrayList(seen) else Bist.newDeck()
            seen.clear()
            Cards.shuf(f)
            deck.addAll(f)
            snd("shuffle")
            say("دسته دوباره بُر خورد.")
            pace(900)
        }
        return deck.removeAt(deck.size - 1)
    }

    /** chance that the next card burns this hand, given the cards already seen (the bots count cards) */
    private fun bust(h: List<Card>): Double {
        val known = HashSet<Int>()
        for (c in seen) known.add(Cards.idc(c))
        for (c in h) known.add(Cards.idc(c))
        val t = Bist.total(h).t
        var tot = 0; var bad = 0
        for (c in Bist.newDeck()) {
            if (known.contains(Cards.idc(c))) continue
            tot++
            if (t + Bist.value(c.r) > 21) bad++
        }
        return if (tot == 0) 1.0 else bad.toDouble() / tot
    }

    // ------------------------------------------------------------------ the game (runs on the host / solo thread)

    private fun loop() {
        while (alive) {
            if (chips[0] < minBet) {
                say(if (chips[0] < MIN_PLAY) "سکه‌های شما تمام شد. برای ادامه باید برنامه را حذف و دوباره نصب کنید." else "ژتون میزبان تمام شد؛ بازی تمام شد.")
                if (role == "solo") Saves.del("auto") else if (role == "host") Saves.del("autoM")
                if (role == "host") sendAll(JSONObject().put("t", "end"))
                return
            }
            var b = ((if (bk < 0) n - 1 else bk) + 1) % n
            var tries = 0
            while (chips[b] < base && tries++ < n) b = (b + 1) % n
            if (chips[b] < base) { say("هیچ‌کس برای بانکداری ژتون ندارد."); return }
            bk = b; cur = b; draw()
            if (isH(b)) {
                msg = "نوبت بانکداری " + names[b]; draw()
                if (askSeat(b, listOf("y" to "بانکدار می‌شوم", "n" to "نمی‌خواهم"), null, "y") == "n") { say(names[b] + " بانکداری را رد کرد."); continue }
            }
            chips[b] -= base; bank = base
            chipFx(b, -1, base)
            say(names[b] + " بانکدار شد؛ بانک " + Cards.fa(base))
            round(b)
            if (!alive) return
            chipFx(-1, b, bank)
            if (bank > 0) coinFx(b, true, bank)
            chips[b] += bank
            say(names[b] + " بانک را برداشت: " + Cards.fa(bank))
            bank = 0
            bChips = chips.copyOf(); bBk = bk
            Prefs.wallet = chips[0]                      // what he has now is what he keeps
            if (role == "host") for (q in 1 until n) if (remote[q]) sendSeat(q, JSONObject().put("t", "wal").put("v", chips[q]))
            saveGame()
            if (role == "host") { syncSucc(); try { Saves.put("autoM", true, snapshot().toString()) } catch (e: Exception) { } }
            draw(); pace(900)
        }
    }

    private fun round(b: Int) {
        val deck = Bist.newDeck()
        snd("shuffle"); pace(900); seen.clear(); mine = ArrayList(); bh = ArrayList(); curHand = ArrayList()
        for (k in 1..n) {
            val p = (b + k) % n
            if (p == b) break
            if (!alive) return
            if (chips[p] < minBet) continue
            if (bank < minBet) break
            cur = p; reveal = false
            val ph: MutableList<Card> = ArrayList()
            ph.add(draw1(deck))
            curHand = ph
            var bhand: MutableList<Card> = ArrayList()
            bhand.add(draw1(deck))
            if (isH(b)) {
                bh = bhand; msg = "برگ بانکدار"; snd("card"); draw()
                if (askSeat(b, listOf("k" to "نگه می‌دارم", "w" to "عوض می‌کنم"), null, "k") == "w") { bhand = ArrayList(); bhand.add(draw1(deck)) }
            } else if (Bist.value(bhand[0].r) <= 3) {
                bhand = ArrayList(); bhand.add(draw1(deck))
            }
            bh = bhand
            mine = if (p == 0) ph else ArrayList()
            msg = names[b] + " به " + names[p] + " کارت می‌دهد"; snd("card"); dealTo(p); dealTo(b); draw(); pace(500)
            msg = "نوبت " + names[p]; draw()

            // the bet
            val mx = Math.min(bank, chips[p])
            var bet: Int
            if (isH(p)) bet = askBetSeat(p, mx)
            else {
                val hi = if (Bist.value(ph[0].r) >= 10) 1.6 else 1.0
                val raw = minBet * (1 + Math.random() * (bank.toDouble() / minBet / 4) * hi)
                bet = Math.max(minBet, Math.min(mx, (Math.round(raw / minBet) * minBet).toInt()))
                if (chips[p] >= bank && ph[0].r == 14 && Math.random() < 0.4) { bet = bank; say(names[p] + ": کل بانک!") }
            }
            say(names[p] + " شرط بست: " + Cards.fa(bet))

            // bets on this player's hand (optional rule)
            val sideQ = ArrayList<Int>(); val sideA = ArrayList<Int>()
            if (side) {
                val c0 = ph[0]
                say(names[p] + ": برگ اول " + Cards.cname(c0))
                for (q in 0 until n) {
                    if (q == p || q == b || chips[q] < minBet) continue
                    var used = 0
                    for (a in sideA) used += a
                    val rem = bank - bet - used
                    val mxr = (Math.min(bet, Math.min(chips[q], rem)) / minBet) * minBet
                    if (mxr < minBet) continue
                    val half = Math.max(minBet, (mxr / 2 / minBet) * minBet)
                    var a = 0
                    if (isH(q)) {
                        val f = askSeat(q, listOf("0" to "نمی‌خوانم", "h" to ("می‌خوانم " + Cards.fa(half)), "f" to ("می‌خوانم " + Cards.fa(mxr))), "روی دست " + names[p] + " بخوانید؟", "0")
                        a = if (f == "f") mxr else if (f == "h") half else 0
                    } else if (Bist.value(c0.r) >= 10 && Math.random() < 0.5) a = half
                    if (a > 0) { sideQ.add(q); sideA.add(a); say(names[q] + " روی " + names[p] + " " + Cards.fa(a) + " خواند") }
                }
            }

            // the player plays, then the banker
            val pt = play(p, ph, deck, false)
            val out: Boolean
            if (pt > 21) { out = false; say(names[p] + " سوخت (" + Cards.fa(pt) + ")."); shakeFx(p) }
            else {
                val bt = play(b, bh, deck, true)
                reveal = true; snd("card"); draw(); pace(500)
                if (bt > 21) shakeFx(b)
                out = Bist.playerWins(pt, bt)
                say(names[p] + " " + Cards.fa(pt) + " — بانکدار " + (if (bt > 21) "سوخت" else Cards.fa(bt)) + " ← " + (if (out) "برد " else "باخت ") + Cards.fa(bet))
            }
            // faces and banners
            val wn = if (out) names[p] else names[b]; val ls = if (out) names[b] else names[p]
            Sched.post { try { Av.set(wn, "joy", 3000L); Av.set(ls, if (pt > 21) "surprised" else "sad", 3000L) } catch (e: Exception) { } }
            // win / lose sound for every person involved
            for (s in 0 until n) {
                if (!isH(s)) continue
                val w: Boolean? = if (s == p) out else if (s == b) !out else if (sideQ.contains(s)) out else null
                if (w != null) { sndSeat(s, if (w) "win" else "lose"); bannerSeat(s, if (w) "بردید!" else if (s == p && pt > 21) "سوختید!" else "باختید!") }
            }
            seen.addAll(ph); if (pt <= 21) seen.addAll(bh)
            chipFx(if (out) -1 else p, if (out) p else -1, bet)
            for (i in sideQ.indices) chipFx(if (out) -1 else sideQ[i], if (out) sideQ[i] else -1, sideA[i])
            if (out) { chips[p] += bet; bank -= bet } else { chips[p] -= bet; bank += bet }
            for (i in sideQ.indices) {
                if (out) { chips[sideQ[i]] += sideA[i]; bank -= sideA[i] } else { chips[sideQ[i]] -= sideA[i]; bank += sideA[i] }
            }
            draw()
            coinFx(p, out, bet)
            collectFx(if (out) p else b)
            sayTo(p, "ژتون شما: " + Cards.fa(chips[p]))
            if (b != p) sayTo(b, "ژتون شما: " + Cards.fa(chips[b]))
            for (q in sideQ) sayTo(q, "ژتون شما: " + Cards.fa(chips[q]))
            pace(900)
            if (bank <= 0) { say("بانک خالی شد؛ نوبت بانکدار بعدی."); break }
            if (bank >= base * 3 && k < n - 1) {
                var call = true
                if (isH(b)) { msg = "بانک خبره؟"; draw(); call = askSeat(b, listOf("y" to "بانک خبره", "n" to "ادامه"), null, "y") == "y" }
                if (call) { say("بانک خبره!"); for (s in 0 until n) if (isH(s)) bannerSeat(s, "بانک خبره!"); break }
            }
        }
    }

    /** one player (or the banker) draws until they stop or burn; returns the total */
    private fun play(p: Int, hand: MutableList<Card>, deck: MutableList<Card>, isBank: Boolean): Int {
        while (alive) {
            val t = Bist.total(hand).t
            if (t > 21) return t
            val bots = bust(hand) < (if (isBank) 0.5 else 0.42)
            val hit: Boolean
            if (isH(p)) {
                cur = p; msg = if (isBank) "بانکدار: " + names[p] else "نوبت " + names[p]; draw()
                hit = askSeat(p, listOf("h" to "کارت بده", "s" to "بس است"), null, if (bots) "h" else "s") == "h"
            } else hit = bots
            if (!hit) return t
            var nr = false
            if (!isBank && hand.size >= 3) {
                // three-card rule: to get another card you must show one of yours, or the banker shows the new one
                if (isH(p)) {
                    val opts = ArrayList<Pair<String, String>>()
                    hand.forEachIndexed { i, c -> opts.add(i.toString() to Cards.cname(c)) }
                    opts.add("n" to "رو نمی‌کنم")
                    val k = askSeat(p, opts, "برای برگ بعدی یکی را رو کن:", "0")
                    if (k == "n") nr = true else say(names[p] + " " + Cards.cname(hand[Math.min(hand.size - 1, k.toIntOrNull() ?: 0)]) + " را رو کرد.")
                } else {
                    val c = hand[(Math.random() * hand.size).toInt()]
                    say(names[p] + " " + Cards.cname(c) + " را رو کرد.")
                }
            }
            hand.add(draw1(deck)); snd("card"); dealTo(p)
            if (nr) say("بانکدار برگ جدید " + names[p] + " را رو کرد: " + Cards.cname(hand[hand.size - 1]))
            draw(); pace(500)
        }
        return Bist.total(hand).t
    }

    // ------------------------------------------------------------------ multi-phone: the host side

    private fun sendSeat(seat: Int, j: JSONObject) {
        val cid = cidOf[seat]
        if (cid >= 0) net?.send(cid, j)
    }

    private fun sendAll(j: JSONObject) { for (s in 1 until n) if (remote[s]) sendSeat(s, j) }

    private fun goMsg(seat: Int): JSONObject {
        val nm = JSONArray(); for (x in names) nm.put(x)
        return JSONObject().put("t", "go").put("seat", seat).put("n", n).put("names", nm).put("base", base).put("min", minBet).put("side", side)
    }

    /** the picture of the table that guest [s] may see (his own hand, the banker's first card hidden) */
    private fun snapFor(s: Int): JSONObject {
        val j = JSONObject().put("t", "st").put("bank", bank).put("bk", bk).put("cur", cur).put("msg", msg).put("rev", reveal)
        val c = JSONArray(); for (i in 0 until n) c.put(chips[i])
        j.put("chips", c)
        val m = JSONArray()
        if (cur == s && bk != s) for (x in ArrayList(curHand)) m.put(Cards.idc(x))
        j.put("mine", m)
        val b = JSONArray()
        var i = 0
        for (x in ArrayList(bh)) { b.put(if (i == 0 && bk != s && !reveal) -1 else Cards.idc(x)); i++ }
        j.put("bh", b)
        return j
    }

    private fun pushAll() { for (s in 1 until n) if (remote[s]) sendSeat(s, snapFor(s)) }

    /** the host starts a game with the connected phones (seats 1..) and robots for the rest */
    fun startHostGame(ps: List<Net21.Peer>, botCount: Int, b: Int, m: Int, sd: Boolean) {
        role = "host"; mySeat = 0; held = false
        base = b; minBet = m; side = sd
        n = 1 + ps.size + botCount
        val nm = ArrayList<String>()
        nm.add(if (Prefs.name.isEmpty()) "بازیکن" else Prefs.name)
        remote.fill(false)
        for (i in ps.indices) { nm.add(ps[i].name); remote[i + 1] = true; cidOf[i + 1] = ps[i].cid; idOf[i + 1] = ps[i].id }
        var k = 0
        while (nm.size < n) {
            val c = if (k < NM21.size) NM21[k] else "ربات " + Cards.fa(k + 1)
            k++
            if (!nm.contains(c)) nm.add(c)
        }
        names = nm
        chips = IntArray(n) { i -> if (i == 0) Prefs.wallet else if (i <= ps.size) ps[i - 1].wallet else START }
        bk = -1
        startGame()
    }

    private fun succSeat(): Int { for (q in 1 until n) if (remote[q]) return q; return -1 }

    /** everything needed to continue the game on another phone (at a round boundary) */
    private fun snapshot(): JSONObject {
        val j = JSONObject().put("n", n).put("bk", bBk).put("base", base).put("min", minBet).put("side", side).put("room", roomCode)
        val nm = JSONArray(); val ch = JSONArray(); val ids = JSONArray()
        for (i in 0 until n) { nm.put(names[i]); ch.put(if (i < bChips.size) bChips[i] else chips[i]); ids.put(if (i == 0) Prefs.devId() else idOf[i]) }
        j.put("names", nm).put("chips", ch).put("ids", ids)
        return j
    }

    /** the first connected guest is the successor: it gets the latest snapshot */
    private fun syncSucc() {
        val q = succSeat()
        if (q > 0) sendSeat(q, JSONObject().put("t", "sync").put("snap", snapshot()))
    }

    /**
     * This phone becomes the host (the old host left, or a saved multi-phone game is loaded). [old] = the seat this phone had;
     * the seats are turned so that it becomes seat 0. The other players come back by their device id; until the host
     * presses "ادامه بازی" the game waits for them.
     */
    fun adoptHost(snap: JSONObject, old: Int, hello: String) {
        stopGame()
        val nn = snap.getInt("n")
        val on = snap.getJSONArray("names"); val oc = snap.getJSONArray("chips"); val oi = snap.getJSONArray("ids")
        val nm = Array(nn) { "" }; val ch = IntArray(nn)
        for (i in 0 until 10) { idOf[i] = ""; cidOf[i] = -1; remote[i] = false }
        for (i in 0 until nn) {
            val k = (i - old + nn) % nn
            nm[k] = on.getString(i); ch[k] = oc.getInt(i); idOf[k] = oi.getString(i)
        }
        role = "host"; mySeat = 0; n = nn
        names = nm.toList(); chips = ch
        chips[0] = Prefs.wallet
        base = snap.getInt("base"); minBet = snap.getInt("min"); side = snap.getBoolean("side")
        bk = (snap.getInt("bk") - old + nn) % nn
        roomCode = snap.optString("room")
        isSucc = false; syncSnap = null
        net?.becomeHost(roomCode, names[0])
        held = true
        startGame()
        startHold(hello)
    }

    /** the connection to the host is gone and this phone is the successor */
    fun adoptFromSync() {
        val sn = syncSnap
        if (sn == null) { showReconnect(); return }
        Sched.laterRaw(1500L) {
            try { adoptHost(sn, mySeat, "میزبان قبلی قطع شد و میزبانی به شما رسید. بازیکنان به‌زودی دوباره وصل می‌شوند و تا آن موقع ربات جایشان بازی می‌کند.") } catch (e: Exception) { showReconnect() }
        }
    }

    /** a guest answered a question */
    fun onGuestMsg(cid: Int, m: JSONObject) {
        val s = cidOf.indexOf(cid)
        if (s < 1) return
        when (m.optString("t")) {
            "ans" -> ansQ[s].offer(m.optInt("id").toString() + "|" + m.optString("v"))
            "free" -> freeAt[s] = Sched.now() + m.optLong("ms")
            "name" -> { val v = m.optString("v").trim(); if (v.isNotEmpty()) ui { setName(s, v) } }
        }
    }

    /** a guest left the game: a robot plays his seat until he comes back */
    fun onGuestDrop(cid: Int) {
        val s = cidOf.indexOf(cid)
        if (s < 1) return
        remote[s] = false; cidOf[s] = -1
        ansQ[s].offer("drop")
        if (started) { say(names[s] + " قطع شد و ربات جای او آمد."); startHold(names[s] + " قطع شد و ربات جای او آمد.") }
    }

    /** a phone that sat here before says hello again: give his seat back. true when it was one of ours */
    fun onGuestHello(cid: Int, id: String): Boolean {
        if (!started || role != "host" || id.isEmpty()) return false
        for (s in 1 until n) {
            if (idOf[s] == id && !remote[s]) {
                remote[s] = true; cidOf[s] = cid
                sendSeat(s, goMsg(s)); sendSeat(s, snapFor(s)); syncSucc()
                say(names[s] + " دوباره وصل شد و بازی را ادامه می‌دهد.")
                return true
            }
        }
        return false
    }

    // ------------------------------------------------------------------ multi-phone: the guest side

    /** the host started (or we came back to) a game: show the table, no game thread here */
    private fun startGuest(m: JSONObject) {
        stopGame()
        role = "guest"; mySeat = m.getInt("seat"); n = m.getInt("n"); held = false
        val nm = m.getJSONArray("names")
        names = List(n) { nm.getString(it) }
        base = m.getInt("base"); minBet = m.getInt("min"); side = m.getBoolean("side")
        chips = IntArray(n) { base * 10 }
        bank = 0; bk = -1; cur = -1; mine = ArrayList(); bh = ArrayList(); reveal = false; msg = ""
        logLines.clear(); lastMsg = ""; lastMine = ""; lastBank = ""
        Spk.reset()
        buildGameView()
        started = true
    }

    private fun cardsOf(a: JSONArray): MutableList<Card> {
        val r = ArrayList<Card>()
        for (i in 0 until a.length()) { val id = a.getInt(i); r.add(if (id < 0) Card(0, 6) else Card(id / 20, id % 20)) }
        return r
    }

    /** a message from the host (runs on the UI thread) */
    fun onHostMsg(m: JSONObject) {
        try {
            when (m.optString("t")) {
                "go" -> { startGuest(m); isSucc = false; syncSnap = null }
                "sync" -> { syncSnap = m.getJSONObject("snap"); isSucc = true }
                "st" -> {
                    if (screen != "game") return
                    bank = m.getInt("bank"); bk = m.getInt("bk"); cur = m.getInt("cur"); msg = m.getString("msg"); reveal = m.getBoolean("rev")
                    val c = m.getJSONArray("chips")
                    for (i in 0 until Math.min(n, c.length())) chips[i] = c.getInt(i)
                    mine = cardsOf(m.getJSONArray("mine")); bh = cardsOf(m.getJSONArray("bh"))
                    render()
                }
                "say" -> { val t = m.getString("m"); logLines.add(t); ann(t); render() }
                "ban" -> banner(m.getString("m"))
                "fly" -> flyTo(m.getInt("s"))
                "coin" -> flyCoins(m.getInt("s"), m.getBoolean("w"), m.optInt("a", 0))
                "col" -> flyCollect(m.getInt("s"))
                "chip" -> flyChip(m.getInt("a"), m.getInt("b"), m.getInt("m"))
                "fx" -> shake(m.getInt("s"))
                "wal" -> Prefs.wallet = m.optInt("v", Prefs.wallet)
                "names" -> { val a = m.getJSONArray("a"); if (a.length() == n) { names = List(n) { a.getString(it) }; render() } }
                "kick" -> { app.dlg.message("میزبان شما را از بازی حذف کرد. اگر خواستید می‌توانید دوباره وارد شوید."); net?.leave(); close() }
                "unsucc" -> { isSucc = false; syncSnap = null }
                "xfer" -> ann("میزبانی به شما منتقل شد. بازیکنان به‌زودی دوباره وصل می‌شوند و تا آن موقع ربات جایشان بازی می‌کند.")
                "hold" -> { val t = m.optString("x"); if (m.optBoolean("on") && t.isNotEmpty()) { logLines.add(t); ann(t); render() } }
                "snd" -> { val sn = m.getString("n"); Sched.post { Sound.plain(sn) }; if (sn == "shuffle") shuffleAnim() }
                "ask" -> onAsk(m)
                "end" -> app.dlg.message("بازی تمام شد.")
            }
        } catch (e: Exception) { }
    }

    private fun onAsk(m: JSONObject) {
        if (screen != "game") return
        val id = m.getInt("id")
        if (m.getString("k") == "bet") {
            buildBet(m.getInt("mn"), m.getInt("mx"), m.getInt("bank"), m.getBoolean("all")) { v -> net?.toHost(JSONObject().put("t", "ans").put("id", id).put("v", v)) }
        } else {
            val o = m.getJSONArray("o")
            val opts = ArrayList<Pair<String, String>>()
            for (i in 0 until o.length()) { val x = o.getJSONArray(i); opts.add(x.getString(0) to x.getString(1)) }
            buildButtons(opts, m.optString("x")) { k -> net?.toHost(JSONObject().put("t", "ans").put("id", id).put("v", k)) }
        }
    }

    /** a message from the network layer, shown and read like the Hokm game's c5log + say */
    fun netNote(t: String) { ui { logLines.add(t); ann(t); render() } }

    /** the connection to the host dropped during a game: offer to connect again */
    fun showReconnect() {
        if (screen != "game" || role != "guest") return
        ctl.removeAllViews()
        ctl.addView(tv("اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید ربات جای شما بازی می‌کند. در حال اتصال دوباره...", 14f, Color.WHITE))
        ctl.addView(app.dlg.btn("اتصال دوباره", false) { net?.reconnect() })
        ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
        ann("اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید ربات جای شما بازی می‌کند. در حال اتصال دوباره...")
    }

    // ------------------------------------------------------------------ the menu inside the game

    private fun gameMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (role == "solo") items.add("بازی جدید" to { askNewGame() })
        items.add("تغییر نام" to { renameAsk() })
        if (role == "host") {
            items.add("افزودن بازیکن" to { addAsk() })
            items.add("حذف بازیکن" to { removeAsk() })
            if (succSeat() > 0) items.add("انتقال میزبانی" to { xferAsk() })
        }
        if (role != "guest") items.add("ذخیره" to { manualSave() })
        items.add(("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) to { app.a11yToggle() })
        items.add("سرعت انیمیشن" to { app.animSpeedAsk() })
        items.add("تنظیمات صدا" to { app.dlg.sound() })
        items.add("تنظیمات تصویر زمینه" to { app.dlg.cards("bg") { } })
        items.add("تنظیمات پشت کارت" to { app.dlg.cards("back") { } })
        items.add("خروج" to { quitAsk() })
        app.dlg.list("گزینه‌های بیشتر", items)
    }

    private fun askNewGame() {
        app.dlg.confirm("بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.", { stepBack() })
    }

    /** one step back for a game against the bots: the setup screen */
    private fun stepBack() {
        stopGame(); started = false
        showSetup()
    }

    /** the phone's back button during a game */
    private fun backAsk() {
        if (role == "solo") { app.dlg.confirm("بازی فعلی از بین می‌رود. به مرحله‌ی قبل برگردیم؟", { stepBack() }); return }
        val txt = if (role == "host" && succSeat() > 0) "از بازی خارج می‌شوید؟ میزبانی به بازیکن بعدی داده می‌شود."
        else if (role == "guest") "از بازی چندگوشی خارج می‌شوید؟ ربات جای شما بازی می‌کند."
        else "از بازی خارج می‌شوید؟"
        app.dlg.confirm(txt, { net?.leave(); close() })
    }

    private fun quitAsk() {
        val txt = "مطمئنید؟ برنامه کاملاً بسته می‌شود." +
            (if (role == "host" && succSeat() > 0) " میزبانی به بازیکن بعدی داده می‌شود."
            else if (role == "guest") " ربات جای شما بازی می‌کند."
            else if (role == "solo") " بازی تا پایان دست قبل ذخیره شده است." else "")
        app.dlg.confirm(txt, {
            net?.leave()
            act.root.postDelayed({ act.bridge.exitApp() }, 500)
        })
    }

    // ---- names ----

    private fun uniqueName(nm: String, seat: Int): String {
        var x = nm; var i = 2
        while (names.indices.any { it != seat && names[it] == x }) { x = nm + " " + Cards.fa(i); i++ }
        return x
    }

    private fun broadcastNames() {
        val a = JSONArray(); for (x in names) a.put(x)
        sendAll(JSONObject().put("t", "names").put("a", a))
    }

    private fun setName(seat: Int, nm: String) {
        if (seat < 0 || seat >= names.size) return
        val l = names.toMutableList(); l[seat] = uniqueName(nm, seat); names = l
        if (role == "host") broadcastNames()
        draw()
    }

    private fun renameAsk() {
        app.dlg.nameAsk(true) { v ->
            val nm = v.trim()
            if (nm.isNotEmpty()) {
                Prefs.name = nm
                if (role == "guest") net?.toHost(JSONObject().put("t", "name").put("v", nm)) else setName(0, nm)
            }
        }
    }

    // ---- players come and go (applied at the start of the next hand) ----

    // ---- the host adds a waiting phone in the place of a robot / removes a player (like the Hokm game: the seats stay fixed) ----

    private fun freeSeats(): List<Int> { val l = ArrayList<Int>(); for (q in 1 until n) if (!remote[q]) l.add(q); return l }

    private fun addAsk() {
        if (role != "host" || !started) return
        val seats = freeSeats()
        if (seats.isEmpty()) { app.dlg.message("ربات آزادی نیست."); return }
        val w = net?.waiting() ?: emptyList()
        if (w.isEmpty()) {
            app.dlg.list("بازیکن جدیدی وصل نیست. از او بخواهید «به بازی دیگری می‌پیوندم» را بزند و گوشی میزبان را انتخاب کند؛ بعد «بررسی دوباره» را بزنید.",
                listOf("بررسی دوباره" to { addAsk() }))
            return
        }
        val pick = { cid: Int, nm: String ->
            if (seats.size == 1) addPlayer(cid, seats[0])
            else app.dlg.list("«" + nm + "» جای کدام ربات بنشیند؟", seats.map { x -> names[x] to { addPlayer(cid, x) } })
        }
        if (w.size == 1) { pick(w[0].first, w[0].second); return }
        app.dlg.list("کدام بازیکن به بازی اضافه شود؟", w.map { p -> p.second to { pick(p.first, p.second) } })
    }

    /** the waiting phone [cid] takes the place of the robot on [seat] */
    private fun addPlayer(cid: Int, seat: Int) {
        if (role != "host" || !started || seat < 1 || seat >= n || remote[seat] || cidOf.indexOf(cid) >= 1) return
        val info = net?.peerInfo(cid) ?: return
        remote[seat] = true; cidOf[seat] = cid; idOf[seat] = info.id
        val cc = chips.copyOf(); cc[seat] = info.wallet; chips = cc
        val l = names.toMutableList(); l[seat] = uniqueName(info.name, seat); names = l
        sendSeat(seat, goMsg(seat)); sendSeat(seat, snapFor(seat))
        broadcastNames()
        say(names[seat] + " به بازی اضافه شد و بازی را ادامه می‌دهد.")
        syncSucc()
        draw()
    }

    private fun removeAsk() {
        if (role != "host" || !started) return
        val ids = ArrayList<Int>(); for (q in 1 until n) if (remote[q]) ids.add(q)
        if (ids.isEmpty()) { app.dlg.message("بازیکن دیگری با گوشی در بازی نیست."); return }
        val q = { s: Int -> app.dlg.confirm("«" + names[s] + "» از بازی حذف شود؟ ربات جای او بازی می‌کند. او می‌تواند دوباره وارد بازی شود.", { kickPlayer(s) }) }
        if (ids.size == 1) { q(ids[0]); return }
        app.dlg.list("کدام بازیکن از بازی حذف شود؟", ids.map { s -> names[s] to { q(s) } })
    }

    private fun kickPlayer(s: Int) {
        if (role != "host" || !started || s < 1 || s >= n || !remote[s]) return
        sendSeat(s, JSONObject().put("t", "kick"))
        remote[s] = false; cidOf[s] = -1; idOf[s] = ""
        ansQ[s].offer("drop")
        say(names[s] + " از بازی حذف شد و ربات جای او آمد.")
        syncSucc()
        draw()
    }

    // ---- the host hands the game to a player he chooses ----

    private fun xferAsk() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (i in 1 until n) if (remote[i]) {
            val s = i
            items.add(names[i] to { app.dlg.confirm("میزبانی همین الان به «" + names[s] + "» منتقل شود؟ بعد از آن شما بازیکن عادی هستید و تا وصل شدن دوباره‌ی بازیکن‌ها، ربات جایشان بازی می‌کند.", { transferTo(s) }) })
        }
        app.dlg.list("میزبانی به کدام بازیکن منتقل شود؟", items, "بستن")
    }

    private fun transferTo(s: Int) {
        sendAll(JSONObject().put("t", "unsucc"))
        sendSeat(s, JSONObject().put("t", "sync").put("snap", snapshot()))
        sendSeat(s, JSONObject().put("t", "xfer"))
        say("میزبانی در حال انتقال به " + names[s] + " است...")
        Sched.laterRaw(1200L) { net?.leave(); close() }
    }

    companion object {
        /** the guide as a list of topics (each opens its own text) */
        fun guideDialog(dlg: Dialogs) {
            dlg.list("راهنمای بازی", TOPICS.map { t -> t.first to { dlg.message(t.first + "\n\n" + t.second) } }, "بستن")
        }

        val TOPICS = listOf(
            "برگ‌ها و ارزش‌ها" to "دستهٔ ۳۶ برگی: ۶ تا ۱۰، سرباز، بی‌بی، شاه و تک. ارزش‌ها: سرباز ۲، بی‌بی ۳، شاه ۴، تک ۱۱. دو تک (فقط با دو برگ) می‌شود ۲۱. هدف این است که جمع برگ‌هایتان به ۲۱ نزدیک‌تر از بانکدار باشد؛ بیشتر از ۲۱ یعنی سوختن و باخت.",
            "بانکدار و بانک" to "بانکدار نوبتی می‌چرخد و می‌تواند قبول نکند. او مبلغی را به‌عنوان بانک وسط می‌گذارد. وقتی بانک سه برابر شد، می‌تواند «بانک خبره» بگوید و دور را تمام کند. در پایان کل بانک را برمی‌دارد.",
            "شرط و بازی" to "هر بازیکن مبلغی از کمترین شرط تا کل بانک شرط می‌بندد و بعد «کارت بده» یا «بس است» می‌گوید. بعد بانکدار بازی می‌کند. مساوی همیشه به نفع بانکدار است. بانکدار می‌تواند برگ اولش را یک بار عوض کند.",
            "قانون‌های ویژه" to "اگر بازیکنی سه برگ دارد و باز برگ می‌خواهد، باید یکی از برگ‌هایش را رو کند، وگرنه بانکدار برگ جدید را رو می‌کند. اختیاری: شرط روی دست دیگران (خواندن) تا اندازهٔ شرط خودِ او. بازی با ژتون مجازی است.",
            "بازی چندگوشی" to "یک گوشی میزبان است و بازی را اجرا می‌کند. اگر بازیکنی قطع شود، ربات جایش بازی می‌کند و بازی تا «ادامه بازی» میزبان می‌ایستد. اگر میزبان برود، بازیکن بعدی میزبان می‌شود. تعداد بازیکن‌ها در طول بازی ثابت است. از «گزینه‌های بیشتر» می‌توانید گوشی منتظر را به جای یک ربات اضافه کنید، یک بازیکن را حذف کنید (ربات جایش می‌نشیند) و میزبانی را به کسی بدهید.",
            "سکه‌های شما" to "اولین بار که وارد بازی می‌شوید ۱۰ هزار سکه می‌گیرید. سکه‌ها بین بازی‌ها می‌مانند: هرچه ببرید بیشتر می‌شود و هرچه ببازید کم می‌شود. اگر سکه‌هایتان تمام شود دیگر نمی‌توانید بازی کنید و برای گرفتن دوبارهٔ ۱۰ هزار سکه باید برنامه را حذف و دوباره نصب کنید. ربات‌ها هر بازی با ۱۰ هزار سکه شروع می‌کنند. سکه‌ها بعد از پایان هر دست ذخیره می‌شوند."
        )

        /** coins a new player gets the first time he enters (and the robots get in every game) */
        const val START = 10000
        /** below this a player cannot even make the smallest bet: his coins are finished */
        const val MIN_PLAY = 25
        const val BROKE = "سکه‌های شما تمام شده است و دیگر نمی‌توانید بازی کنید. برای گرفتن دوبارهٔ ۱۰ هزار سکه باید برنامه را حذف و دوباره نصب کنید."
    }
}
