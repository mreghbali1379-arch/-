package com.example.hokm

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject

/**
 * The multi-phone side of the Hokm (3, 5 and 6 players) game: lobby screens (host / join), the transport events of the
 * bridge (Bluetooth, Wi-Fi, Wi-Fi Direct) and the messages.
 * The host phone runs the game; guests only show the table and answer the questions they are asked.
 */
class NetHn(private val act: MainActivity, private val app: App, private val g: HokmN) {
    class Peer(@JvmField val cid: Int, @JvmField var name: String, @JvmField var addr: String) {
        @JvmField var id = ""
        @JvmField var joined = false
        @JvmField var wallet = 1000000L
    }

    private val NETN = mapOf("bt" to "بلوتوث", "lan" to "وای‌فای (یک شبکهٔ مشترک)", "direct" to "وای‌فای مستقیم")
    private val NETH = mapOf(
        "bt" to "گوشی‌ها باید نزدیک هم باشند و بلوتوث (و در بعضی گوشی‌ها موقعیت‌مکانی) روشن باشد. نیازی به جفت‌کردن در تنظیمات بلوتوث نیست.",
        "lan" to "همه‌ی گوشی‌ها باید به یک شبکه‌ی وای‌فای وصل باشند، مثلاً یک مودم یا هات‌اسپات یکی از گوشی‌ها. بعد میزبان بازی را باز می‌کند و بقیه نامش را در فهرست می‌بینند.",
        "direct" to "وای‌فای همه‌ی گوشی‌ها باید روشن و گوشی‌ها نزدیک هم باشند. لازم نیست به مودم یا شبکه‌ای وصل شوید؛ بقیه مستقیم به گوشی میزبان وصل می‌شوند."
    )

    private val peers = LinkedHashMap<Int, Peer>()
    private val found = LinkedHashMap<String, Array<String>>()   // endpoint -> [room, name]
    private var role = "off"                                      // "host" | "client" | "off"
    private var conn = false
    private var leaving = false
    private var room = ""
    private var lastAddr = ""
    private var myName = ""
    private var netMode = Prefs.net
    private var retry: ((Boolean) -> Unit)? = null
    private var tries = 0
    private var rcN = 0
    private var screen = ""

    private var info: TextView? = null
    private var listBox: LinearLayout? = null
    private var spKind: Spinner? = null
    private var spStake: android.widget.EditText? = null
    private val kinds = listOf(3, 5, 62, 63)
    /** the Hokm kind of this lobby (3, 5, 62, 63): chosen with the game type of the host page, or in the waiting room's own list */
    private var fixedKind = 3
    private var inPage = false
    private var hostBox: LinearLayout? = null
    private var seatStep = false
    private val seatSp = ArrayList<android.widget.Spinner>()
    private var seatPlay: List<Peer> = emptyList()
    /** the six-player game: choose the partners by the draw of the aces (0, the default) or by the seating alone (1) */
    private var spDraw: Spinner? = null

    private val br get() = act.bridge

    // ------------------------------------------------------------------ plumbing

    fun show() {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        showRoles()
    }

    /** send a message to the phone with connection id cid (0 = the host, from a guest) */
    fun send(cid: Int, j: JSONObject) {
        act.runOnUiThread { try { br.send(cid, j.toString()) } catch (e: Exception) { } }
    }

    fun toHost(j: JSONObject) { send(0, j) }

    fun close() {
        try { br.stopHost() } catch (e: Exception) { }
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        role = "off"; conn = false; peers.clear(); found.clear()
    }

    fun leave() {
        leaving = true
        if (role == "client" && conn) { try { send(0, JSONObject().put("t", "bye")) } catch (e: Exception) { } }
    }

    /** the phone's back button inside the lobby; true = handled here */
    fun back(): Boolean {
        if (role == "off") return false
        leaving = true
        close()
        showRoles()
        return true
    }

    private fun setInfo(t: String) {
        info?.text = t
        try { if (Prefs.a11y) info?.announceForAccessibility(t) } catch (e: Exception) { }
    }

    /** a lobby screen: the ⋮ button and the title, as in the Hokm lobby */
    private fun lobbyBase(): LinearLayout {
        val v = column()
        v.addView(app.moreButtonView())
        v.addView(g.heading("بازی با چند گوشی"))
        return v
    }

    /** the status line under the content (a polite live region, like the lobby message of the Hokm game) */
    private fun statusTv(): TextView {
        val t = g.tv("", 15f)
        t.gravity = Gravity.CENTER
        t.setPadding(Px.dp(8), Px.dp(10), Px.dp(8), Px.dp(10))
        t.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        info = t
        return t
    }

    private fun column(): LinearLayout {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        return v
    }

    // ------------------------------------------------------------------ lobby screens

    private fun showRoles() {
        screen = "roles"; role = "off"; leaving = false
        val v = lobbyBase()
        // name and gender, as in the Hokm lobby (hidden once both are saved)
        val nmrow = column()
        nmrow.addView(g.tv("نام شما در بازی (بقیه‌ی بازیکنان همین نام را می‌بینند):", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val et = EndEdit(act)
        et.onDone(null)
        et.filters = arrayOf(android.text.InputFilter.LengthFilter(20)); et.textSize = 16f
        et.setTextColor(Px.tx); et.isSingleLine = true; et.contentDescription = "نام شما در بازی"
        et.setText(Prefs.name)
        nmrow.addView(et, fieldLp())
        nmrow.addView(g.tv("جنسیت شما:", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val gs = Spinner(act)
        gs.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf("زن", "مرد"))
        gs.speakLabel("جنسیت شما")
        gs.setSelection(if (Prefs.gender == "m") 1 else 0)
        nmrow.addView(gs, fieldLp())
        nmrow.visibility = if (Prefs.name.isNotEmpty() && Prefs.gender.isNotEmpty()) View.GONE else View.VISIBLE
        nameEt = et; genderSp = gs
        v.addView(nmrow)
        v.addView(g.tv("برای بازی با چند گوشی، همه‌ی گوشی‌ها باید این برنامه را داشته باشند و همه یک «روش اتصال» را انتخاب کنند. توضیح روش انتخاب‌شده را زیر دکمهٔ «روش اتصال» می‌بینید.", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        v.addView(g.mbtn("روش اتصال: " + (NETN[netMode] ?: "")) { netChoose() })
        val t = statusTv()
        t.text = NETH[netMode] ?: ""
        v.addView(t)
        v.addView(g.mbtn("میزبان بازی می‌شوم") { startHost(false) })
        v.addView(g.mbtn("به بازی دیگری می‌پیوندم") { startJoin(false) })
        v.addView(g.mbtn("بازی‌های قبلی") { if (SavesHn.all(true).isEmpty()) app.dlg.list("بازی ذخیره‌شده‌ای نیست. میزبان باید در بازی از «گزینه‌های بیشتر» دکمهٔ «ذخیره» را بزند.", listOf(), "باشه") else showSavedMulti() })
        g.setScreen("net", v)
    }

    private var hostNm = "میزبان"
    private var nameEt: android.widget.EditText? = null
    private var genderSp: Spinner? = null

    private fun fieldLp() = LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), Px.dp(48)).also {
        it.gravity = Gravity.CENTER_HORIZONTAL; it.setMargins(0, Px.dp(6), 0, Px.dp(6))
    }

    /** the name (and gender) typed on the lobby screen are saved and used in the game */
    private fun myNm(): String {
        val et = nameEt; val gs = genderSp
        if (et != null && gs != null) {
            var v = et.text.toString().trim().take(20)
            if (v.isEmpty()) v = Prefs.name.ifEmpty { "بازیکن" }
            Prefs.name = v
            Prefs.gender = if (gs.selectedItemPosition == 1) "m" else "f"
            Av.GN[v] = Prefs.gender
            return v
        }
        return Prefs.name.ifEmpty { "بازیکن" }
    }

    private fun netChoose() {
        app.dlg.list("روش اتصال", listOf(
            "بلوتوث" to { setNet("bt") },
            "وای‌فای: همهٔ گوشی‌ها به یک مودم یا هات‌اسپات وصل باشند" to { setNet("lan") },
            "وای‌فای مستقیم: بدون مودم، گوشی‌ها مستقیم به میزبان وصل می‌شوند" to { setNet("direct") }
        ))
    }

    private fun setNet(v: String) {
        netMode = v; Prefs.net = v
        try { br.setNet(v) } catch (e: Exception) { }
        showRoles()
    }

    /** permissions / Bluetooth / Wi-Fi checks; false = something is still needed (the user was told) */
    private fun ready(r: ((Boolean) -> Unit)?): Boolean {
        retry = r
        br.setNet(netMode)
        val st = br.state()
        if (st == "nogms") { setInfo("این گوشی خدمات گوگل پلی (Google Play Services) ندارد یا به‌روز نیست و اتصال نزدیک کار نمی‌کند."); return false }
        if (st == "noperm") {
            br.ensure()
            setInfo(if (netMode == "bt") "اجازه‌های درخواست‌شده (بلوتوث و دستگاه‌های نزدیک) را بدهید." else "اجازه‌های درخواست‌شده (دستگاه‌های نزدیک و موقعیت مکانی) را بدهید.")
            return false
        }
        if (st == "off") { br.enableBt(); setInfo("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن بلوتوث را بدهید."); return false }
        if (st == "locoff") { br.enableLoc(); setInfo("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن موقعیت مکانی را بدهید."); return false }
        if (st == "wifioff") {
            br.enableWifi()
            setInfo(if (netMode == "lan") "در پنجره‌ی باز‌شده وای‌فای را روشن کنید و به همان شبکه‌ای وصل شوید که بقیه‌ی بازیکن‌ها هستند (مودم یا هات‌اسپات). با بستن پنجره، برنامه خودش ادامه می‌دهد."
            else "در پنجره‌ی باز‌شده وای‌فای را روشن کنید (لازم نیست به شبکه‌ای وصل شوید). با بستن پنجره، برنامه خودش ادامه می‌دهد.")
            return false
        }
        if (st == "nobt") { setInfo("این گوشی بلوتوث ندارد."); return false }
        retry = null; tries = 0
        return true
    }

    private fun startHost(auto: Boolean) {
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> startHost(a) }) return
        role = "host"; peers.clear(); conn = false
        myName = myNm()
        room = java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, myName)
        showHostLobby()
    }

    private fun showSavedMulti() {
        val l = SavesHn.all(true)
        screen = "saved"
        val v = column()
        v.addView(g.heading("بازی‌های قبلی"))
        for (e in l) v.addView(g.mbtn(SavesHn.describe(e)) {
            app.dlg.list(SavesHn.describe(e), listOf(
                "ادامه بازی (میزبان می‌شوم)" to { resumeHost(false, e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { SavesHn.del(e.id); showRoles() }) }
            ), "بستن")
        })
        v.addView(g.mbtn("بازگشت") { showRoles() })
        g.setScreen("net", v)
    }

    private var resumeE: SavesHn.E? = null

    private fun resumeHost(auto: Boolean, e: SavesHn.E? = null) {
        if (e != null) resumeE = e
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> resumeHost(a) }) return
        val en = resumeE ?: return
        val sv = try { JSONObject(en.data) } catch (x: Exception) { setInfo("بازی ذخیره‌شده خراب است."); return }
        role = "host"; peers.clear(); conn = false
        myName = myNm()
        room = java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, myName)
        g.resumeHostGame(sv, false)
    }

    fun resumeSaved(e: SavesHn.E) { resumeHost(false, e) }

    fun curRoom(): String = room

    /** this phone is the host now (the old host handed the game over): advertise the same room so the others find us again */
    /** the host handed the game over: this phone connects to the new host (by the room) as a normal player */
    fun becomeClient(rm: String, name: String) {
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        peers.clear()
        role = "client"; leaving = false; conn = false; rcN = 0
        myName = name; room = rm; lastAddr = "room:$rm"
        Sched.laterRaw(1500) { if (!conn && !leaving && role == "client") reconnect() }
        autoReconnect()
    }

    fun becomeHost(rm: String, name: String) {
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        role = "host"; conn = false; leaving = false; peers.clear()
        myName = name; room = if (rm.isNotEmpty()) rm else java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, name)
    }

    private fun showHostLobby() {
        screen = "host"
        val v = lobbyBase()
        v.addView(g.tv("ژتون شما: " + Cards.fa(Prefs.wallet), 15f, Px.GOLD, true).also { it.gravity = Gravity.CENTER })
        v.addView(g.tv("نام شما در بازی: " + myName + ". منتظر ورود بازیکنان هستید. بازیکنان باید از بخش «به بازی دیگری می‌پیوندم» بازی «" + myName + "» را از فهرست بازی‌های نزدیک انتخاب کنند (گوشی‌ها باید نزدیک هم باشند). بازی تا وقتی دست‌کم یک بازیکن انسانی نپیوندد شروع نمی‌شود. جاهای خالی میز را ربات پر می‌کند.", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val lb = column(); listBox = lb
        v.addView(lb)
        v.addView(g.tv("نوع بازی (می‌توانید هر وقت خواستید عوض کنید؛ اتصال بازیکنان قطع نمی‌شود)", 16f))
        v.addView(app.kindSpinner("hn" + fixedKind) { k -> app.switchLobbyHost("hn" + fixedKind, k, room, myName, handPeers()) }, fieldLp())
        buildHostSettings(v)
        v.addView(g.mbtn("شروع بازی") { hostGo() })
        v.addView(g.mbtn("بستن") { back() })
        v.addView(statusTv())
        g.setScreen("net", v)
        refreshHost()
    }

    /** the settings of the host room (the chips of every player); the game type is chosen in the list above them */
    private fun buildHostSettings(v: LinearLayout) {
        v.addView(g.tv("ژتون هر بازیکن برای این بازی", 16f))
        val s1 = numField(act, "ژتون هر بازیکن برای این بازی", app.hokmStake); spStake = s1
        Mem.field("l.stake", s1); s1.onDone(null)      // the last choice stays; the keyboard's Done key closes it
        v.addView(s1, fieldLp())
    }

    /** the host page of the main menu shows this game's settings and players (no screen of this game until the game starts) */
    fun adoptHostInPage(rm: String, name: String, list: List<HandPeer>, box: LinearLayout, plist: LinearLayout, infoTv: TextView, k: Int) {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        role = "host"; conn = false; leaving = false
        peers.clear()
        for (p in list) peers[p.cid] = Peer(p.cid, p.name, p.addr)
        myName = name; room = rm; fixedKind = k
        g.roomCode = room
        screen = "host"; inPage = true
        listBox = plist; info = infoTv; hostBox = box; seatStep = false
        box.removeAllViews()
        buildHostSettings(box)
        refreshHost()
    }

    fun startFromPage() { hostGo() }

    /** back from the seating step to the settings (the big button is "مرحله بعد" again) */
    fun seatBack(): Boolean {
        if (!seatStep) return false
        seatStep = false
        val bx = hostBox; if (bx != null) { bx.removeAllViews(); buildHostSettings(bx) }
        app.lobby.setGoText("مرحله بعد")
        setInfo("")
        return true
    }

    /** room, host name and the connected phones (to hand them over to another game) */
    fun handoff(): Triple<String, String, List<HandPeer>> = Triple(room, myName, handPeers())

    /** the phones that are connected now, for the lobby of another game */
    private fun handPeers(): List<HandPeer> = peers.values.map { HandPeer(it.cid, it.name, it.addr) }

    /** another game's lobby has handed its phones over: this is the host lobby of this game with the same room; each phone says hello again */
    fun adoptHost(rm: String, name: String, list: List<HandPeer>, k: Int) {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        role = "host"; conn = false; leaving = false
        peers.clear()
        for (p in list) peers[p.cid] = Peer(p.cid, p.name, p.addr)
        myName = name; room = rm; fixedKind = k
        g.roomCode = room
        showHostLobby()
    }

    /** the host changed the game of the waiting room: this phone is a guest of this game now and says hello to the host again */
    fun adoptClient(name: String, rm: String, addr: String, hostName: String, k: Int) {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        role = "client"; leaving = false; conn = true; rcN = 0
        myName = name; room = rm; lastAddr = addr; fixedKind = k
        hostNm = hostName.ifEmpty { "میزبان" }
        waitScreen(hostNm, "نوع بازی عوض شد. در حال پیوستن به بازی «" + hostNm + "» ...")
        toHost(helloMsg())
    }

    private fun helloMsg(): JSONObject = JSONObject().put("t", "hello").put("k", "hn" + fixedKind).put("name", myName).put("id", Prefs.devId()).put("g", Prefs.gender).put("w", Prefs.wallet)

    private fun joined(): List<Peer> = peers.values.filter { it.joined }

    class PeerInfo(@JvmField val id: String, @JvmField val name: String, @JvmField val wallet: Long)

    /** phones that are connected to a running game but have no seat yet: (connection id, name) */
    fun waiting(): List<Pair<Int, String>> = peers.values.filter { it.joined && !g.hasSeat(it.cid) }.map { it.cid to it.name }

    /** the saved multi-phone games (called from the game class) */
    fun showSaved() { showSavedMulti() }

    fun peerInfo(cid: Int): PeerInfo? = peers[cid]?.let { PeerInfo(it.id, it.name, it.wallet) }

    private fun refreshHost() {
        if (screen != "host") return
        if (seatStep) seatBack()
        val ps = joined()
        val lb = listBox ?: return
        lb.removeAllViews()
        for (p in ps) lb.addView(g.tv(p.name, 15f).also { it.gravity = Gravity.CENTER })
        setInfo(if (ps.isNotEmpty()) "${ps.size} بازیکن وارد شده است." else "هنوز کسی وارد نشده است.")
    }

    private fun hostGo() {
        val ps = joined()
        val kind = fixedKind
        val total = HokmN.players(kind)
        if (ps.isEmpty()) { setInfo("برای شروع بازی باید دست‌کم یک بازیکن انسانی بپیوندد."); return }
        val st = Cards.num(spStake?.text?.toString() ?: app.hokmStake.toString())
        if (st < 1) { setInfo("ژتون هر بازیکن را به‌صورت عدد و دست‌کم ۱ تایپ کنید."); return }
        val need = HokmN.need(kind, st)
        if (Prefs.wallet < need) { setInfo("ژتون شما برای این مبلغ کافی نیست (دست‌کم " + Cards.fa(need) + " لازم است). مبلغ را کمتر کنید."); return }
        val able = ps.filter { it.wallet >= need }      // people must have the chips (robots have no limit)
        if (able.isEmpty()) {
            for (p in ps) send(p.cid, JSONObject().put("t", "welcome").put("name", p.name).put("x", "ژتون شما برای این مبلغ کافی نیست (دست‌کم " + Cards.fa(need) + " لازم است). میزبان باید مبلغ را کمتر کند."))
            setInfo(ps.joinToString("، ") { it.name } + " ژتون کافی برای این مبلغ ندارد (دست‌کم " + Cards.fa(need) + " لازم است). مبلغ را کمتر کنید.")
            return
        }
        val play = able.take(total - 1)      // the others stay connected and the host can add them later
        for (p in ps) if (p !in play) send(p.cid, JSONObject().put("t", "welcome").put("name", p.name).put("x",
            if (p.wallet < need) "ژتون شما برای این مبلغ کافی نیست. بازی بدون شما شروع شد و وصل می‌مانید."
            else "جای خالی میز پر بود. بازی بدون شما شروع شد و وصل می‌مانید تا میزبان شما را اضافه کند."))
        if (total > 2 && !seatStep) {      // as in the four-player game: the host places the players first
            val bx = hostBox
            if (bx != null) {
                seatStep = true; seatPlay = play; seatSp.clear()
                bx.addView(g.tv((if (HokmN.teamsOf(kind) < total) "شما همیشه پایین میز هستید و هم‌تیمی‌هایتان طبق چینش کنار شما می‌نشینند. " else "شما همیشه پایین میز هستید. ") + "برای هر جایگاه بازیکن را انتخاب کنید. جای خالی را ربات پر می‌کند.", 15f))
                val items = listOf("ربات") + play.map { it.name }
                spDraw = null
                if (kind == 62 || kind == 63) {
                    bx.addView(g.tv("تعیین یار:", 15f))
                    val dsp = Spinner(act)
                    dsp.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf(
                        "با قرعه (آس‌ها: حاکم و یارهایش)",
                        if (kind == 63) "بدون قرعه (یار همان نفرِ روبه‌رو طبق چینش شماست)" else "بدون قرعه (یارها همان نفرهای یکی در میان طبق چینش شما هستند)"))
                    dsp.contentDescription = "تعیین یار"
                    Mem.spinner("hn.draw", dsp)
                    bx.addView(dsp, fieldLp()); spDraw = dsp
                }
                for (sd in 1 until total) {
                    bx.addView(g.tv(HokmN.seatTitle(kind, sd) + ":", 15f))
                    val sp = android.widget.Spinner(act)
                    sp.adapter = android.widget.ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, items)
                    sp.setSelection(if (sd - 1 < play.size) sd else 0)
                    sp.contentDescription = HokmN.seatTitle(kind, sd)
                    bx.addView(sp, fieldLp()); seatSp.add(sp)
                }
                app.lobby.setGoText("شروع بازی")
                setInfo("")
                return
            }
        }
        val seated: List<Peer?> = if (seatStep && seatSp.size == total - 1) {
            val used = HashSet<Int>()
            seatSp.map { sp -> val i = sp.selectedItemPosition - 1; if (i in seatPlay.indices && used.add(i)) seatPlay[i] else null }
        } else play
        val byDraw = (spDraw?.selectedItemPosition ?: 0) == 0
        spDraw = null
        seatStep = false
        if (inPage) { inPage = false; g.ensureHostShown() }
        app.hokmStake = st
        g.startHostGame(seated, kind, st, byDraw)
    }

    private fun startJoin(auto: Boolean) {
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> startJoin(a) }) return
        role = "client"; leaving = false; conn = false
        myName = myNm()
        found.clear()
        showJoin()
        br.scan()
    }

    private fun showJoin() {
        screen = "join"
        val v = lobbyBase()
        v.addView(g.tv("بازی نزدیک را از فهرست انتخاب کنید (جست‌وجو ادامه دارد):", 15f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(6), 0, Px.dp(6)) })
        val lb = column(); listBox = lb
        v.addView(lb)
        v.addView(g.mbtn("بستن") { back() })
        v.addView(statusTv())
        g.setScreen("net", v)
        refreshJoin()
    }

    private fun refreshJoin() {
        if (screen != "join") return
        val lb = listBox ?: return
        lb.removeAllViews()
        for ((ep, f) in found) lb.addView(g.mbtn(if (f[1].isEmpty()) "بازی بدون نام" else f[1]) { joinDev(ep, f[0], f[1]) })
        val n = found.size
        setInfo(if (n > 0) "$n بازی نزدیک پیدا شد." else "در حال جست‌وجو. میزبان باید «میزبان بازی می‌شوم» را باز کرده باشد.")
    }

    private fun joinDev(ep: String, rm: String, name: String) {
        room = rm
        lastAddr = if (rm.isNotEmpty()) "room:$rm" else ep
        rcN = 0
        hostNm = name.ifEmpty { "میزبان" }
        setInfo("در حال اتصال به " + name.ifEmpty { "بازی" } + " ...")
        br.connect(ep)
    }

    // ------------------------------------------------------------------ transport events

    fun onEvt(type: String, cid: Int, data: String) {
        when (type) {
            "conn" -> if (role == "host") {
                val pr = data.split("\u0001")
                peers[cid] = Peer(cid, pr.getOrNull(0).orEmpty().ifEmpty { "بازیکن" }, pr.getOrNull(1).orEmpty())
            }
            "found" -> if (role == "client" && !conn) {
                val pr = data.split("\u0001")
                found[pr[0]] = arrayOf(pr.getOrNull(1).orEmpty(), pr.getOrNull(2).orEmpty())
                refreshJoin()
            }
            "lost" -> if (found.remove(data) != null) refreshJoin()
            "open" -> if (role == "client") {
                Sched.cancel(foT)
                br.stopScan(); conn = true; rcN = 0; rcOn = false; rcGen++
                toHost(helloMsg())
            }
            "msg" -> {
                val m = try { JSONObject(data) } catch (e: Exception) { return }
                if (role == "host") onHostSide(cid, m) else if (role == "client") onClientSide(m)
            }
            "drop" -> {
                if (role == "host") hostDrop(cid)
                else if (role == "client" && !leaving) {
                    conn = false
                    if (g.started) { g.showReconnect(); autoReconnect(); failoverTimer() }
                    else setInfo("اتصال برقرار نشد یا قطع شد. دوباره امتحان کنید.")
                }
            }
            "err" -> setInfo("خطا: $data")
            "perm" -> {
                val r = retry
                if (data == "1" && r != null && tries < 5) { retry = null; tries++; Sched.laterRaw(700) { r(true) } }
                else if (data == "s0") setInfo("برای ادامه باید مجوزها را در تنظیمات برنامه روشن کنید. صفحهٔ تنظیمات باز شد؛ مجوزها را بدهید و برگردید تا برنامه خودش ادامه دهد.")
                else {
                    retry = null
                    setInfo(if (data == "1") "اجازه داده شد. دوباره دکمه را بزنید."
                    else if (data == "w0") "وای‌فای هنوز خاموش است. برای وای‌فای مستقیم باید روشن باشد. دوباره دکمه را بزنید و آن را روشن کنید."
                    else if (data == "l0") "موقعیت مکانی روشن نشد. برای وای‌فای مستقیم باید روشن باشد. دوباره دکمه را بزنید."
                    else "اجازه‌ها داده نشد. بدون آن‌ها اتصال نزدیک کار نمی‌کند.")
                }
            }
        }
    }

    private fun unique(base: String, me: Peer): String {
        var nm = base; var i = 2
        while (nm == myName || peers.values.any { it !== me && it.joined && it.name == nm }) { nm = base + " " + Cards.fa(i); i++ }
        return nm
    }

    private fun hostDrop(cid: Int) {
        peers.remove(cid)
        g.onGuestDrop(cid)
        if (!g.started) refreshHost()
    }

    private fun onHostSide(cid: Int, m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> {
                val p = peers[cid] ?: return
                val gk = m.optString("k")
                if (gk.isNotEmpty() && gk != "hn" + fixedKind) { send(cid, JSONObject().put("t", "kind").put("k", "hn" + fixedKind).put("host", myName)); return }      // the guest chose another game: it opens this game's lobby and says hello again
                p.id = m.optString("id")
                p.wallet = m.optLong("w", 0L)
                p.name = unique(m.optString("name").ifEmpty { "بازیکن" }, p)
                if (g.onGuestHello(cid, p.id)) { p.joined = true; send(cid, JSONObject().put("t", "welcome").put("name", p.name).put("x", if (g.resuming) "به بازی ادامه‌دار پیوستید. منتظر بمانید تا میزبان بازی را شروع کند." else "")); return }          // a player who dropped out came back
                if (g.started) {      // the game is running: this phone waits until the host adds it ("افزودن بازیکن")
                    p.joined = true
                    send(cid, JSONObject().put("t", "welcome").put("name", p.name).put("x", "بازی در جریان است. وصل می‌مانید تا میزبان شما را به بازی اضافه کند."))
                    return
                }
                if (g.resuming || joined().size >= 9) { send(cid, JSONObject().put("t", "busy")); return }
                p.joined = true
                send(cid, JSONObject().put("t", "welcome").put("name", p.name))
                refreshHost()
            }
            "ans", "cv", "free", "rn" -> g.onGuestMsg(cid, m)      // the move, a vote about the chips, the screen reader's free time, a new name
            "bye" -> hostDrop(cid)
        }
    }

    private fun onClientSide(m: JSONObject) {
        when (m.optString("t")) {
            "welcome" -> waitScreen(m.optString("name"), m.optString("x"))
            "busy" -> setInfo("این بازی پر است یا جای شما در آن دیگر خالی نیست.")
            "kind" -> if (!g.started) app.switchLobbyGuest("hn" + fixedKind, m.optString("k"), myName, room, lastAddr, m.optString("host"))
            else -> g.onHostMsg(m)
        }
    }

    private var foT: Runnable? = null

    /** the first guest in the line takes over only after the host has been gone for a while (a short break of the link is not enough); the next ones wait longer (as in the Hokm of two and four players) */
    private fun failoverTimer() {
        if (!g.isSucc) return
        Sched.cancel(foT)
        foT = Sched.laterRaw(g.failMs) { if (!conn && !leaving && role == "client" && g.started && g.isSucc) g.adoptFromSync() }
    }

    fun peerRename(cid: Int, nm: String) { peers[cid]?.name = nm }

    fun dropPeer(cid: Int) { try { br.drop(cid) } catch (e: Exception) { } }

    /** the waiting room of a guest with a message (the game is over, or the host removed him) */
    fun showWait(msg: String) { waitScreen(hostNm, msg) }

    private fun waitScreen(nm: String, x: String = "") {
        screen = "wait"
        val v = lobbyBase()
        v.addView(g.mbtn("بستن") { back() })
        v.addView(statusTv())
        g.setScreen("net", v)
        setInfo(if (x.isNotEmpty()) x else "به بازی " + HokmN.title(fixedKind) + " پیوستید. منتظر شروع بازی توسط " + hostNm + " باشید...")
    }

    // ------------------------------------------------------------------ reconnecting a guest

    fun reconnect() {
        if (role != "client") return
        rcN++
        try { br.connect(if (lastAddr.isNotEmpty()) lastAddr else null) } catch (e: Exception) { }
    }

    // as the guest of the Hokm of two and four players (Client5): the first try after 2.5 seconds, then every 6 seconds, 40 tries; after 10 seconds the guests behind the first successor are told that they connect to the new host
    private var rcOn = false
    private var rcT0 = 0L
    private var rcNext = 0L
    private var foMsg = false
    private var rcGen = 0

    fun manualReconnect() {
        rcN = 0
        reconnect()
        rcNext = Sched.now() + 6000L
        if (!rcOn) { rcOn = true; val g0 = ++rcGen; Sched.laterRaw(1000) { rcTick(g0) } }
    }

    private fun autoReconnect() {
        if (rcOn) return
        rcOn = true; rcT0 = Sched.now(); rcNext = rcT0 + 2500L; foMsg = false
        val g0 = ++rcGen; Sched.laterRaw(1000) { rcTick(g0) }
    }

    private fun rcTick(g0: Int) {
        if (g0 != rcGen) return
        if (conn || leaving || role != "client" || !g.started) { rcOn = false; return }
        val now = Sched.now()
        if (!foMsg && now - rcT0 > 10000L && g.isSucc && g.failMs > 10000L) { foMsg = true; g.netNote("میزبان قبلی قطع شد. در حال اتصال به میزبان جدید...") }
        if (now >= rcNext) {
            if (rcN >= 40) {
                rcOn = false
                g.netNote("اتصال دوباره ممکن نشد. می‌توانید دکمه‌ی «اتصال دوباره» را بزنید.")
                return
            }
            reconnect()
            rcNext = now + 6000L
        }
        Sched.laterRaw(1000) { rcTick(g0) }
    }
}
