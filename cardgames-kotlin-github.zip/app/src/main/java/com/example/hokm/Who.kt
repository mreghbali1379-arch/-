package com.example.hokm

/**
 * Messages that say who did something, written once and read by each player in his own way (as in Hokm):
 * the viewer himself is "شما" and the verb is in the second person ("بازی کردید"), the others are called by name
 * ("بازی کرد"). A message holds tokens: [n] for a name and [v] for a verb; [resolve] turns them into text for one viewer.
 */
object Who {
    private const val N0 = '\u0001'; private const val N1 = '\u0002'
    private const val V0 = '\u0003'; private const val V1 = '\u0004'

    /** the name of [seat] (becomes "شما" for the seat itself) */
    fun n(seat: Int): String = "$N0$seat$N1"

    /** a verb: [third] for the others, [second] for the seat itself */
    fun v(seat: Int, third: String, second: String): String = "$V0$seat|$third|$second$V1"

    private val nameRx = Regex("$N0(\\d+)$N1")
    private val verbRx = Regex("$V0(\\d+)\\|([^|$V1]*)\\|([^$V1]*)$V1")

    /** the text for the player sitting on [viewer]; [suffix] adds something after a name (for example " (یار)") */
    fun resolve(m: String, viewer: Int, names: List<String>, suffix: (Int, Int) -> String = { _, _ -> "" }): String {
        if (m.indexOf(N0) < 0 && m.indexOf(V0) < 0) return m
        var t = verbRx.replace(m) { r ->
            val s = r.groupValues[1].toInt()
            if (s == viewer) r.groupValues[3] else r.groupValues[2]
        }
        t = nameRx.replace(t) { r ->
            val s = r.groupValues[1].toInt()
            if (s == viewer) "شما" else (if (s in names.indices) names[s] else "") + suffix(s, viewer)
        }
        return t
    }
}
