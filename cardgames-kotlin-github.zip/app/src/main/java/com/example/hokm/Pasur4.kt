package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue

/**
 * Rules of "چهار برگ" (Pasur). Pure logic, no UI.
 * Cards: Card(s, r) with r 2..10 numbers, 11 jack, 12 queen, 13 king, 14 ace (worth 1).
 * A card played from the hand may capture: a king a king, a queen a queen, a jack everything except kings and queens,
 * a number (or ace) cards that add up to 11 together with it (several groups at once are allowed).
 */
object Pasur {
    /** value of a card for the "adds up to 11" rule (ace 1; face cards 0 = they do not count) */
    fun value(c: Card): Int = if (c.r == 14) 1 else if (c.r >= 11) 0 else c.r

    private fun isFace(c: Card) = c.r in 11..13

    /** can these values be split into groups that each add up to target? */
    private fun canSplit(v: List<Int>, target: Int): Boolean {
        if (v.isEmpty()) return true
        if (target <= 0) return false
        val first = v[0]
        val rest = v.subList(1, v.size)
        return pick(first, rest, 0, target, v)
    }

    /** choose a group that contains v[0]; the rest must split too */
    private fun pick(first: Int, rest: List<Int>, from: Int, target: Int, all: List<Int>): Boolean {
        // enumerate subsets of rest that complete first to target
        val m = rest.size
        for (mask in 0 until (1 shl m)) {
            var s = first
            for (i in 0 until m) if ((mask shr i) and 1 == 1) s += rest[i]
            if (s != target) continue
            val left = ArrayList<Int>()
            for (i in 0 until m) if ((mask shr i) and 1 == 0) left.add(rest[i])
            if (canSplit(left, target)) return true
        }
        return false
    }

    /** is capturing exactly the table cards at indexes sel with card c a legal move? */
    fun isValid(c: Card, table: List<Card>, sel: List<Int>): Boolean {
        if (sel.isEmpty()) return false
        for (i in sel) if (i < 0 || i >= table.size) return false
        if (c.r == 11) {
            val all = ArrayList<Int>()
            for (i in table.indices) if (table[i].r != 12 && table[i].r != 13) all.add(i)
            return all.size == sel.size && all.containsAll(sel)
        }
        if (c.r == 12 || c.r == 13) return sel.size == 1 && table[sel[0]].r == c.r
        val v = ArrayList<Int>()
        for (i in sel) { if (isFace(table[i])) return false; v.add(value(table[i])) }
        return canSplit(v, 11 - value(c))
    }

    /** every legal capture of card c (each as a list of table indexes) */
    fun options(c: Card, table: List<Card>): List<List<Int>> {
        val r = ArrayList<List<Int>>()
        if (c.r == 11) {
            val all = ArrayList<Int>()
            for (i in table.indices) if (table[i].r != 12 && table[i].r != 13) all.add(i)
            if (all.isNotEmpty()) r.add(all)
            return r
        }
        if (c.r == 12 || c.r == 13) {
            for (i in table.indices) if (table[i].r == c.r) r.add(listOf(i))
            return r
        }
        val idx = ArrayList<Int>()
        for (i in table.indices) if (!isFace(table[i])) idx.add(i)
        val m = Math.min(idx.size, 13)
        val target = 11 - value(c)
        for (mask in 1 until (1 shl m)) {
            val sel = ArrayList<Int>(); val v = ArrayList<Int>()
            var sum = 0
            for (i in 0 until m) if ((mask shr i) and 1 == 1) { sel.add(idx[i]); v.add(value(table[idx[i]])); sum += value(table[idx[i]]) }
            if (sum % target != 0) continue
            if (canSplit(v, target)) r.add(sel)
        }
        return r
    }

    /** points of the cards a side has taken (not counting the clubs bonus and surs) */
    fun cardPoints(cards: List<Card>): Int {
        var p = 0
        for (c in cards) {
            if (c.r == 14) p += 1
            if (c.r == 11) p += 1
            if (c.s == 3 && c.r == 2) p += 2
            if (c.s == 2 && c.r == 10) p += 3
        }
        return p
    }

    fun clubs(cards: List<Card>): Int { var k = 0; for (c in cards) if (c.s == 3) k++; return k }

    fun newDeck(): MutableList<Card> {
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
        Cards.shuf(d)
        return d
    }
}

/**
 * The Chahar Barg game screen: drawn over the other screens (a full-screen overlay) and sharing the settings.
 * The game runs on a worker thread that waits for the player's moves.
 */
class Pasur4(private val act: MainActivity, private val app: App) {
    private val NM = listOf("علی", "ندا", "رضا", "سارا", "امیر", "مینا", "کیان", "نرگس")

    // ---- options and state ----
    private var n = 2
    private var target = 62
    private var stake = 1000                      // chips of each player for this game (robots have no limit)
    private var names: List<String> = emptyList()
    private var score = IntArray(0)               // per side
    private var dealer = 0
    private var hands: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
    @Volatile private var table: MutableList<Card> = ArrayList()
    private var taken: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
    private var surs = IntArray(4)
    private var deckLeft = 0
    private var turn = -1
    private var lastTaker = -1
    private var msg = ""
    private val logLines = ArrayList<String>()
    private val gameId = System.currentTimeMillis().toString()

    // ---- several phones: "solo" (robots only), "host" (runs the game) or "client" (only shows the table and sends its moves)
    @JvmField var role = "solo"
    @JvmField var roomCode = ""
    @Volatile @JvmField var resuming = false            // a saved game was loaded and the host waits for the players to come back
    private var lastSave = ""
    private var syncSv = ""                            // the host's last save (guest side): used to take over if the host drops out suddenly
    private var succSeat = -1
    val isSucc: Boolean get() = role == "client" && syncSv.isNotEmpty() && me == succSeat
    private var me = 0                                  // my seat (the host and a solo player sit at 0)
    private val remote = BooleanArray(4)
    private val cidOf = IntArray(4) { -1 }
    private val idOf = Array(4) { "" }
    private val ansQ = Array(4) { LinkedBlockingQueue<String>() }
    @Volatile private var waitSeat = -1
    private var net: NetCb? = null
    private fun isRemote(s: Int) = role == "host" && remote[s]

    @Volatile private var alive = false
    @Volatile var started = false
    private var worker: Thread? = null
    private val moveQ = LinkedBlockingQueue<String>()
    @Volatile private var myTurn = false

    // selection while it is my turn (UI thread only)
    private var selHand = -1
    private val selTbl = HashSet<Int>()

    // ---- views ----
    private val ov = FrameLayout(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)
    private lateinit var gameV: LinearLayout
    private lateinit var scoreTv: TextView
    private lateinit var msgTv: TextView
    private lateinit var playersV: FlowLayout
    private lateinit var infoTv: TextView
    private lateinit var tableV: FlowLayout
    private lateinit var handV: FlowLayout
    private lateinit var ctl: LinearLayout
    private lateinit var logTv: TextView
    private var screen = "setup"
    private var lastMsg = ""
    private var lastHandKey = ""
    @JvmField var hidden = false
    val running: Boolean get() = started && ov.parent != null

    private fun sideOf(seat: Int) = if (n == 4) seat % 2 else seat
    private val sides: Int get() = if (n == 4) 2 else n

    // ------------------------------------------------------------------ shell

    fun show(start: String) {
        ov.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ov.setBackgroundColor(Px.bg)
        ov.isClickable = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        val sc = ScrollView(act)
        sc.isFillViewport = true
        sc.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.addView(sc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        app.menuShown(false)
        act.onBack = { back() }
        if (start == "resume") showSaves()
        else if (start == "net") { val nt = NetCb(act, app, this); net = nt; nt.show() }
        else showSetup()
    }

    fun close(notify: Boolean = true) {
        if (role == "host" && notify) sendAll(JSONObject().put("t", "end").put("m", "میزبان بازی را بست."))
        resuming = false
        stopGame()
        net?.close(); net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
        app.menuShown(true)
        app.syncBg()
    }

    private fun back(): Boolean {
        if (screen == "net" && net?.back() == true) return true
        if (screen == "game") { gameMenu(); return true }
        net?.leave(); close()
        return true
    }

    private fun ui(f: () -> Unit) { act.runOnUiThread { try { f() } catch (e: Exception) { } } }

    /** runs f on the UI thread and waits until it is done (used before the state changes under an animation) */
    private fun uiWait(f: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) { try { f() } catch (e: Exception) { }; return }
        val l = CountDownLatch(1)
        act.runOnUiThread { try { f() } catch (e: Exception) { }; l.countDown() }
        l.await()
    }

    fun tv(t: String, size: Float = 15f, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun setScreen(name: String, v: View) { screen = name; content.removeAllViews(); content.addView(v) }

    fun heading(t: String): TextView {
        val h = tv(t, 26f, Px.tx, true)
        h.gravity = Gravity.CENTER
        h.setPadding(0, Px.dp(12), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) h.isAccessibilityHeading = true
        return h
    }

    fun mbtn(t: String, f: () -> Unit): View {
        val b = app.dlg.btn(t, true, f)
        val l = LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    // ------------------------------------------------------------------ setup and saved games

    private fun showSetup() {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL
        v.addView(heading("بازی جدید"))
        val counts = listOf(2, 3, 4)
        val targets = listOf(62, 100)
        v.addView(tv("تعداد بازیکن‌ها (با ربات). در بازی چهار نفره دو تیم دو نفره‌اید و هم‌تیمی شما ربات است.", 15f))
        val sp1 = Spinner(act)
        sp1.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, counts.map { Cards.fa(it) + " نفره" })
        sp1.setSelection(0)      // as in Hokm: the first option is preselected
        sp1.speakLabel("تعداد بازیکن‌ها")
        v.addView(sp1)
        v.addView(tv("امتیاز برد", 16f))
        val sp2 = Spinner(act)
        sp2.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, targets.map { Cards.fa(it) })
        sp2.setSelection(Math.max(0, targets.indexOf(target)))
        sp2.speakLabel("امتیاز برد")
        v.addView(sp2)
        v.addView(tv("ژتون هر بازیکن برای این بازی (عدد را تایپ کنید، دست‌کم ۱):", 15f))
        val stEt = numField(act, "ژتون هر بازیکن برای این بازی", stake)
        v.addView(stEt)
        v.addView(tv("دو نفره: برنده از بازنده همین مقدار می‌گیرد. سه نفره: برنده از هر بازنده. چهار نفره: تیم بازنده روی هم یک مبلغ می‌دهد و تیم برنده نصف‌نصف تقسیم می‌کند. ربات‌ها ژتون نامحدود دارند.", 13f))
        v.addView(mbtn("شروع بازی") {
            n = counts[sp1.selectedItemPosition]; target = targets[sp2.selectedItemPosition]
            val st = Cards.num(stEt.text.toString())
            if (!checkStake(st, n)) return@mbtn
            stake = st
            role = "solo"; me = 0; for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
            names = listOf(if (Prefs.name.isEmpty()) "شما" else Prefs.name) + NM.subList(0, n - 1)
            score = IntArray(sides); dealer = (Math.random() * n).toInt()
            startGame()
        })
        v.addView(mbtn("بازگشت") { close() })
        setScreen("setup", v)
    }

    private fun saveJson(): JSONObject {
        val j = JSONObject().put("n", n).put("target", target).put("dealer", dealer).put("stake", stake)
        val nm = JSONArray(); for (x in names) nm.put(x)
        val sc = JSONArray(); for (x in score) sc.put(x)
        val ids = JSONArray(); for (i in 0 until n) ids.put(if (role == "host" && i == 0) Prefs.devId() else idOf[i])
        return j.put("names", nm).put("score", sc).put("ids", ids).put("multi", role == "host")
    }

    private fun manualSave() {
        if (!started) return
        SavesCb.put("m" + System.currentTimeMillis(), role == "host", saveJson().toString())
        app.dlg.message("بازی ذخیره شد.")
    }

    private fun showSaves() {
        val l = SavesCb.all(false)
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("بازی‌های قبلی"))
        if (l.isEmpty()) v.addView(tv("بازی ذخیره‌شده‌ای وجود ندارد.", 15f))
        for (e in l) v.addView(mbtn(SavesCb.describe(e)) {
            app.dlg.list(SavesCb.describe(e), listOf(
                "ادامه بازی" to { resumeFrom(e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { SavesCb.del(e.id); showSaves() }) }
            ), "بستن")
        })
        v.addView(mbtn("بازگشت") { close() })
        setScreen("saves", v)
    }

    private fun resumeFrom(e: SavesCb.E) {
        try {
            val j = JSONObject(e.data)
            n = j.getInt("n"); target = j.getInt("target"); dealer = j.getInt("dealer"); stake = j.optInt("stake", 1000)
            if (!checkStake(stake, n)) return
            role = "solo"; me = 0; for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
            val nm = j.getJSONArray("names"); val sc = j.getJSONArray("score")
            names = List(n) { nm.getString(it) }
            if (names.isNotEmpty() && Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            score = IntArray(sides) { if (it < sc.length()) sc.getInt(it) else 0 }
            startGame()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده پیدا نشد."); showSaves() }
    }

    // ------------------------------------------------------------------ game view

    private fun startGame() {
        stopGame()
        logLines.clear(); lastMsg = ""; lastHandKey = ""; msg = ""
        Spk.reset(); Sound.resetQueue()
        buildGameView()
        alive = true; started = true
        val t = Thread { try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { } }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun stopGame() { alive = false; myTurn = false; worker?.interrupt(); worker = null }

    private fun buildGameView() {
        gameV = LinearLayout(act); gameV.orientation = LinearLayout.VERTICAL
        gameV.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val bmp = if (Prefs.bg > 0) Assets.bitmap(act, Assets.bgPath(Prefs.bg)) else null
        gameV.background = if (bmp != null) CoverDrawable(bmp, 0x1F000000) else Px.rounded(Px.FELT, 16)
        val more = LinearLayout(act); more.orientation = LinearLayout.HORIZONTAL
        more.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val mb = TextView(act)
        mb.text = "⋮"; mb.textSize = 26f; mb.setTextColor(Color.WHITE); mb.gravity = Gravity.CENTER
        mb.background = Px.rounded(0x59000000, 20)
        mb.contentDescription = "گزینه‌های بیشتر"
        mb.isClickable = true; mb.isFocusable = true
        mb.setOnClickListener { gameMenu() }
        more.addView(mb, LinearLayout.LayoutParams(Px.dp(40), Px.dp(40)))
        gameV.addView(more)
        val top = LinearLayout(act); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        scoreTv = tv("", 15f, Px.GOLD, true)
        top.addView(scoreTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        gameV.addView(top)
        msgTv = tv("", 15f, Color.WHITE)
        gameV.addView(msgTv)
        playersV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(playersV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        infoTv = tv("", 13f, 0xFFD8CDB4.toInt())
        gameV.addView(infoTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        tableV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(tableV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(150)).also { it.topMargin = Px.dp(4) })
        gameV.addView(tv("برگ‌های شما", 14f, 0xFFD8CDB4.toInt()), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        handV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(handV)
        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL
        gameV.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        logTv = tv("", 13f, 0xFFE8DCC4.toInt())
        gameV.addView(logTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        setScreen("game", gameV)
    }

    private fun cardView(c: Card, w: Int, h: Int, selected: Boolean, onTap: (() -> Unit)?): View {
        val iv = ImageView(act)
        val bmp = Assets.bitmap(act, Assets.cardPath(c))
        if (bmp != null) iv.setImageBitmap(bmp)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setPadding(Px.dp(2), Px.dp(2), Px.dp(2), Px.dp(2))
        iv.background = if (selected) Px.rounded(0x33FFD34D, 8, 3, Px.GOLD) else null
        iv.contentDescription = Cards.cname(c) + (if (selected) "، انتخاب شده" else "")
        iv.layoutParams = ViewGroup.LayoutParams(Px.dp(w), Px.dp(h))
        if (onTap != null) { iv.isClickable = true; iv.isFocusable = true; iv.setOnClickListener { onTap() } }
        return iv
    }

    /** the chips a person must have to take part: four players = half the stake (his partner pays the other half) */
    fun need(st: Int, players: Int): Int = if (players == 4) Math.max(1, st / 2) else st

    private fun checkStake(st: Int, players: Int): Boolean {
        if (Prefs.wallet < Bist21.MIN_PLAY) { app.dlg.message(Bist21.BROKE); return false }
        if (st < 1) { app.dlg.message("ژتون هر بازیکن را به‌صورت عدد و دست‌کم ۱ تایپ کنید."); return false }
        if (Prefs.wallet < need(st, players)) {
            app.dlg.message("ژتون شما برای این مبلغ کافی نیست (ژتون شما: " + Cards.fa(Prefs.wallet) + (if (players == 4) "؛ در بازی چهار نفره دست‌کم نصف مبلغ لازم است" else "") + "). مبلغ کمتری انتخاب کنید.")
            return false
        }
        return true
    }

    private fun sidePoints(side: Int): String = Cards.fa(score[side])

    private fun render() {
        if (screen != "game" || !::playersV.isInitialized) return
        val sb = StringBuilder()
        if (n == 4) sb.append("ما ").append(sidePoints(sideOf(me))).append(" — آن‌ها ").append(sidePoints(1 - sideOf(me)))
        else for (i in 0 until n) { if (i > 0) sb.append(" — "); sb.append(names[i]).append(' ').append(sidePoints(i)) }
        sb.append("  (هدف ").append(Cards.fa(target)).append(")")
        if (stake > 0) sb.append("  — ژتون شما ").append(Cards.fa(Prefs.wallet))
        scoreTv.text = sb.toString()
        msgTv.text = msg
        if (msg.isNotEmpty() && msg != lastMsg) { lastMsg = msg; ann(msg) }
        // players
        playersV.removeAllViews()
        for (k in 1 until n) {
            val i = (me + k) % n
            val cell = LinearLayout(act)
            cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER
            cell.setPadding(Px.dp(8), Px.dp(4), Px.dp(8), Px.dp(4))
            val isD = i == dealer
            cell.background = Px.rounded(0x8C000000.toInt(), 10, if (i == turn) 2 else 0, Px.GOLD)
            val team = if (n == 4 && i % 2 == me % 2) "، هم‌تیمی شما" else ""
            val cnt = hands[i].size
            cell.contentDescription = names[i] + team + (if (isD) "، پخش‌کننده" else "") + "، " + Cards.fa(cnt) + " برگ در دست، " +
                Cards.fa(taken[sideOf(i)].size) + " برگ برداشته" + (if (surs[sideOf(i)] > 0) "، " + Cards.fa(surs[sideOf(i)]) + " سور" else "")
            cell.isFocusable = true
            try { cell.addView(Av.view(act, names[i], 34, i == turn, i == turn)) } catch (e: Exception) { }
            val t = tv(names[i] + (if (isD) " 🂠" else "") + "\n" + Cards.fa(cnt) + " برگ", 12f, Color.WHITE)
            t.gravity = Gravity.CENTER
            t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            cell.addView(t)
            playersV.addView(cell)
        }
        infoTv.text = "دسته: " + Cards.fa(deckLeft) + " برگ — برداشته‌های شما: " + Cards.fa(taken[sideOf(me)].size) +
            (if (surs[sideOf(me)] > 0) " — سور: " + Cards.fa(surs[sideOf(me)]) else "")
        // the table
        tableV.removeAllViews()
        val tl = ArrayList(table)
        val myHand = ArrayList(hands[me])
        val sel = if (myTurn && selHand in myHand.indices) selTbl else HashSet<Int>()
        for ((i, c) in tl.withIndex()) {
            tableV.addView(cardView(c, 46, 64, sel.contains(i), if (myTurn && selHand >= 0) ({ toggleTable(i) }) else null))
        }
        if (tl.isEmpty()) tableV.addView(tv("میز خالی است", 14f, 0xFFD8CDB4.toInt()))
        // my hand
        handV.removeAllViews()
        for ((i, c) in myHand.withIndex()) {
            handV.addView(cardView(c, 52, 72, myTurn && i == selHand, if (myTurn) ({ pickHand(i) }) else null))
        }
        val hk = myHand.joinToString(" ") { Cards.idc(it).toString() }
        if (hk.isNotEmpty() && hk != lastHandKey) { lastHandKey = hk; ann("برگ‌های شما: " + myHand.joinToString("، ") { Cards.cname(it) }) } else if (hk.isEmpty()) lastHandKey = ""
        logTv.text = logLines.takeLast(6).joinToString("\n")
        renderButtons()
    }

    // ------------------------------------------------------------------ my move

    private fun pickHand(i: Int) {
        if (!myTurn || i >= hands[me].size) return
        selHand = i; selTbl.clear()
        val c = hands[me][i]
        val o = Pasur.options(c, ArrayList(table))
        if (o.size == 1) selTbl.addAll(o[0])
        render()
        if (Prefs.a11y) ann(Cards.cname(c) + " انتخاب شد" + (if (o.isEmpty()) ". این برگ چیزی برنمی‌دارد." else if (o.size == 1) ". برداشتن آماده است." else ". برگ‌های میز را برای برداشتن انتخاب کنید."))
    }

    private fun toggleTable(i: Int) {
        if (!myTurn || selHand < 0) return
        if (!selTbl.remove(i)) selTbl.add(i)
        render()
    }

    private fun renderButtons() {
        ctl.removeAllViews()
        if (!myTurn) return
        val canTake = selHand in hands[me].indices && selTbl.isNotEmpty() && Pasur.isValid(hands[me][selHand], ArrayList(table), selTbl.sorted())
        val canThrow = selHand in hands[me].indices && selTbl.isEmpty()
        val b1 = app.dlg.btn("بردار", true) { if (canTake) submit(true) else ann("این انتخاب درست نیست.") }
        b1.alpha = if (canTake) 1f else 0.4f
        val b2 = app.dlg.btn("بینداز روی میز", true) { if (canThrow) submit(false) else ann("برای انداختن، انتخاب میز را خالی کنید.") }
        b2.alpha = if (canThrow) 1f else 0.4f
        ctl.addView(b1); ctl.addView(b2)
    }

    private fun submit(take: Boolean) {
        if (!myTurn || selHand !in hands[me].indices) return
        val s = if (take) selTbl.sorted().joinToString(",") else ""
        val msgv = selHand.toString() + "|" + s
        myTurn = false
        selHand = -1; selTbl.clear()
        if (role == "client") net?.toHost(JSONObject().put("t", "ans").put("m", msgv)) else moveQ.offer(msgv)
        render()
    }

    // ------------------------------------------------------------------ speech (the same queue as the Hokm game)

    private fun ann(t: String) {
        val d = Spk.slot(t, 0L)
        Sched.laterRaw(d) { speak(t) }
    }

    private fun speak(t: String) {
        if (!Prefs.a11y) return
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logTv.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    private fun idle(): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now())

    private fun say(m: String) { ui { logLines.add(m); ann(m); render() }; if (role == "host") sendAll(JSONObject().put("t", "say").put("m", m)) }
    private fun localSay(m: String) { ui { logLines.add(m); ann(m); render() } }
    private fun draw() { ui { render() }; if (role == "host") sendStates() }
    /** how long the sound queue is still busy (the next action waits for it, as in Hokm; at most 4 s) */
    private fun soundWait(): Long = Math.max(0L, Math.min(4000L, Sound.sq() - Sched.now()))
    private fun pace(ms: Long) { Thread.sleep(Math.max(Math.max(Anim.ad(ms), idle()), soundWait())) }
    private fun snd(name: String) { Sched.post { Sound.game(name) }; if (role == "host") sendAll(JSONObject().put("t", "snd").put("n", name)) }
    private fun bannerAll(t: String) { ui { banner(t) }; if (role == "host") sendAll(JSONObject().put("t", "ban").put("m", t)) }

    // ------------------------------------------------------------------ several phones

    private fun cardOf(id: Int) = Card(id / 20, id % 20)

    private fun sendAll(j: JSONObject) { for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], j) }

    private fun teamName(side: Int): String =
        if (n == 4) (0 until n).filter { sideOf(it) == side }.joinToString(" و ") { names[it] } else names[side]

    /** what seat [seat] sees: its own hand, the table, the counts of the others */
    private fun snapFor(seat: Int, mt: Boolean): JSONObject {
        val j = JSONObject().put("t", "st").put("me", seat).put("n", n).put("target", target).put("stake", stake)
            .put("dealer", dealer).put("turn", turn).put("deck", deckLeft).put("mt", mt)
        val nm = JSONArray(); for (x in names) nm.put(x)
        val sc = JSONArray(); for (x in score) sc.put(x)
        val tb = JSONArray(); for (c in ArrayList(table)) tb.put(Cards.idc(c))
        val hd = JSONArray(); for (c in ArrayList(hands[seat])) hd.put(Cards.idc(c))
        val cn = JSONArray(); for (i in 0 until n) cn.put(hands[i].size)
        val tk = JSONArray(); for (i in 0 until sides) tk.put(taken[i].size)
        val sr = JSONArray(); for (i in 0 until sides) sr.put(surs[i])
        val m = if (mt) "نوبت شماست" else if (turn in 0 until n) "نوبت " + names[turn] else msg
        return j.put("names", nm).put("score", sc).put("table", tb).put("hand", hd).put("cnt", cn).put("tk", tk).put("surs", sr).put("msg", m)
    }

    private fun sendStates() {
        for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], snapFor(s, waitSeat == s))
    }

    private fun startMsg(seat: Int): JSONObject = JSONObject().put("t", "start").put("me", seat)

    /** the host starts a game: seats 1.. are the phones that joined, the other seats are robots */
    fun startHostGame(ps: List<NetCb.Peer>, total: Int, tg: Int, st: Int) {
        role = "host"; me = 0; n = total; target = tg; stake = st
        for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
        val nm = ArrayList<String>()
        nm.add(if (Prefs.name.isEmpty()) "شما" else Prefs.name)
        for ((i, p) in ps.withIndex()) { nm.add(p.name); remote[i + 1] = true; cidOf[i + 1] = p.cid; idOf[i + 1] = p.id }
        for (x in NM.shuffled()) { if (nm.size >= n) break; if (!nm.contains(x)) nm.add(x) }
        names = nm
        score = IntArray(sides); dealer = (Math.random() * n).toInt()
        for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], startMsg(s))
        lastSave = saveJson().toString()
        startGame()
        sendSync()
    }

    // ---- a saved multi-phone game, or a game handed over by the old host

    /** load a save: the host waits until the players are back (they are known by their device ids) */
    fun resumeHostGame(j: JSONObject, handedOver: Boolean) {
        try {
            n = j.getInt("n"); target = j.getInt("target"); stake = j.optInt("stake", 1000)
            val nm = j.getJSONArray("names"); val sc = j.getJSONArray("score"); val ids = j.optJSONArray("ids")
            var k = 0
            if (handedOver && ids != null) for (i in 0 until n) if (ids.optString(i) == Prefs.devId()) k = i
            names = List(n) { nm.getString((it + k) % n) }
            val oldScore = IntArray(sides) { if (it < sc.length()) sc.getInt(it) else 0 }
            score = IntArray(sides) { oldScore[(it + k) % sides] }
            dealer = ((j.getInt("dealer") - k) % n + n) % n
            for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
            if (ids != null) for (i in 0 until n) idOf[i] = ids.optString((i + k) % n)
            idOf[0] = ""                                  // this phone is the host
            if (Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            role = "host"; me = 0; resuming = true; started = false
            showResumeLobby()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده خراب است."); net?.leave(); close() }
    }

    private fun showResumeLobby() {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("ادامهٔ بازی ذخیره‌شده"))
        v.addView(tv("بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند و بازی «" + (if (Prefs.name.isEmpty()) "میزبان" else Prefs.name) + "» را انتخاب کنند. وقتی آماده بودید «ادامه بازی» را بزنید؛ جای کسانی که نیامده‌اند ربات بازی می‌کند.", 15f))
        for (i in 1 until n) {
            val st = if (remote[i]) "وصل شد" else if (idOf[i].isNotEmpty()) "منتظر است" else "ربات"
            v.addView(tv(names[i] + " — " + st, 15f))
        }
        v.addView(mbtn("ادامه بازی") {
            resuming = false
            for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], startMsg(s))
            lastSave = saveJson().toString()
            startGame()
            sendSync()
        })
        v.addView(mbtn("لغو") { net?.leave(); close() })
        setScreen("net", v)
    }

    /** the old host hands the game over to the phone [seat]: it loads the last saved state and the others reconnect to it */
    private fun xferTo(seat: Int) {
        val cid = cidOf[seat]
        if (cid < 0 || lastSave.isEmpty()) return
        net?.send(cid, JSONObject().put("t", "xfer").put("sv", lastSave))
        Sched.laterRaw(1200) { act.runOnUiThread { net?.leave(); close(false) } }
    }

    private fun exitHostAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.confirm("از بازی خارج می‌شوید؟", { net?.leave(); close() }); return }
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (s in seats) items.add(("میزبانی را به «" + names[s] + "» بدهم و خارج شوم (دست فعلی از نو پخش می‌شود)") to { xferTo(s) })
        items.add("بازی را ببندم (برای همه تمام می‌شود)" to { net?.leave(); close() })
        app.dlg.list("قبل از رفتن", items, "بستن")
    }

    fun onGuestDrop(cid: Int) {
        val s = cidOf.indexOf(cid)
        if (s < 1) return
        remote[s] = false; cidOf[s] = -1
        ansQ[s].offer("drop")
        if (resuming) { ui { showResumeLobby() }; return }
        if (started) say(names[s] + " قطع شد؛ ربات جایش بازی می‌کند تا برگردد.")
    }

    /** a phone that sat here before says hello again: it takes its seat back. true when it was one of ours */
    fun onGuestHello(cid: Int, id: String): Boolean {
        if ((!started && !resuming) || role != "host" || id.isEmpty()) return false
        for (s in 1 until n) if (idOf[s] == id) {
            remote[s] = true; cidOf[s] = cid
            if (resuming) { ui { showResumeLobby() }; return true }
            net?.send(cid, startMsg(s))
            say(names[s] + " به بازی برگشت.")
            sendStates()
            sendSync()
            return true
        }
        return false
    }

    fun onGuestMsg(cid: Int, m: JSONObject) {
        val s = cidOf.indexOf(cid)
        if (s >= 1 && m.optString("t") == "ans") ansQ[s].offer(m.optString("m"))
    }

    fun netNote(t: String) { localSay(t) }

    /** the connection to the host dropped during a game */
    fun showReconnect() {
        if (screen != "game" || role != "client") return
        val t = "اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید از بازی کنار هستید. در حال اتصال دوباره..."
        ui {
            ctl.removeAllViews()
            ctl.addView(tv(t, 14f, Color.WHITE))
            ctl.addView(app.dlg.btn("اتصال دوباره", false) { net?.reconnect() })
            ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
            ann(t)
        }
        myTurn = false
    }

    /** the host's messages, on the guest phone */
    fun onHostMsg(m: JSONObject) {
        when (m.optString("t")) {
            "start" -> {
                role = "client"; me = m.optInt("me", 1)
                if (screen != "game") { ui { stopGame(); logLines.clear(); lastMsg = ""; lastHandKey = ""; Spk.reset(); Sound.resetQueue(); buildGameView(); started = true } }
            }
            "st" -> {
                role = "client"
                if (screen != "game" || !started) { stopGame(); logLines.clear(); lastMsg = ""; lastHandKey = ""; Spk.reset(); Sound.resetQueue(); me = m.optInt("me", me); n = m.getInt("n"); buildGameView(); started = true }
                applySnap(m)
            }
            "say" -> localSay(m.optString("m"))
            "sync" -> { syncSv = m.optString("sv"); succSeat = m.optInt("succ", -1) }
            "snd" -> Sched.post { Sound.game(m.optString("n")) }
            "ban" -> ui { banner(m.optString("m")) }
            "mv" -> {
                val seat = m.getInt("seat"); val card = cardOf(m.getInt("c"))
                val a = m.getJSONArray("cap"); val cap = List(a.length()) { a.getInt(it) }
                ui { if (cap.isNotEmpty()) flyCapture(seat, cap); if (seat != me) flyPlay(seat, card) }
            }
            "fin" -> {
                val won = m.optBoolean("w"); val d = m.optInt("d")
                Prefs.wallet = Prefs.wallet + d
                ui { banner(if (won) "بردید!" else "باختید!") }
                Sched.post { Sound.game(if (won) "fwin" else "flose") }
                localSay(chipText(d))
                myTurn = false
            }
            "xfer" -> {
                val nt = net ?: return
                nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
                stopGame(); started = false
                resumeHostGame(JSONObject(m.getString("sv")), true)
            }
            "end" -> { app.dlg.message(m.optString("m", "بازی تمام شد.")); net?.leave(); close() }
        }
    }

    private fun applySnap(m: JSONObject) {
        ui {
            me = m.optInt("me", me); n = m.getInt("n"); target = m.optInt("target", target); stake = m.optInt("stake", stake)
            val nm = m.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
            val sc = m.getJSONArray("score"); score = IntArray(sides) { if (it < sc.length()) sc.getInt(it) else 0 }
            dealer = m.optInt("dealer"); turn = m.optInt("turn", -1); deckLeft = m.optInt("deck")
            val tb = m.getJSONArray("table"); table = ArrayList<Card>().also { l -> for (i in 0 until tb.length()) l.add(cardOf(tb.getInt(i))) }
            val cn = m.getJSONArray("cnt"); val hd = m.getJSONArray("hand")
            for (i in 0 until 4) hands[i] = if (i == me) ArrayList<Card>().also { l -> for (k in 0 until hd.length()) l.add(cardOf(hd.getInt(k))) }
                else ArrayList<Card>().also { l -> for (k in 0 until (if (i < cn.length()) cn.getInt(i) else 0)) l.add(Card(0, 2)) }
            val tk = m.getJSONArray("tk"); val sr = m.getJSONArray("surs")
            for (i in 0 until sides) { taken[i] = ArrayList<Card>().also { l -> for (k in 0 until tk.getInt(i)) l.add(Card(0, 2)) }; surs[i] = sr.getInt(i) }
            msg = m.optString("msg")
            val mt = m.optBoolean("mt")
            if (mt && !myTurn) { selHand = -1; selTbl.clear() }
            myTurn = mt
            render()
        }
    }

    private fun parseMove(seat: Int, a: String): Pair<Int, List<Int>>? {
        try {
            val p = a.indexOf('|')
            val ci = a.substring(0, p).toInt()
            val rest = a.substring(p + 1)
            val cap = if (rest.isEmpty()) emptyList() else rest.split(",").map { it.toInt() }
            if (ci !in hands[seat].indices) return null
            if (cap.isNotEmpty() && !Pasur.isValid(hands[seat][ci], ArrayList(table), cap.sorted())) return null
            return Pair(ci, cap)
        } catch (e: Exception) { return null }
    }

    private fun chipDelta(won: Boolean): Int {
        val d = when (n) { 4 -> Math.max(1, stake / 2); 3 -> if (won) stake * 2 else stake; else -> stake }
        return if (won) d else -d
    }

    private fun chipText(d: Int): String = "ژتون شما " + Cards.fa(Math.abs(d)) + (if (d >= 0) " اضافه شد" else " کم شد") + ". ژتون شما: " + Cards.fa(Prefs.wallet)

    // ------------------------------------------------------------------ animations

    private fun loc(v: View): IntArray { val a = IntArray(2); v.getLocationInWindow(a); return a }

    private fun cellOf(seat: Int): View? {
        val rel = (seat - me + n) % n
        if (rel == 0 || !::playersV.isInitialized) return null
        return if (rel - 1 < playersV.childCount) playersV.getChildAt(rel - 1) else null
    }

    /** a copy of a picture flies from one view to another and fades */
    private fun flyCopy(src: View, dst: View?, delay: Long, shrink: Boolean) {
        val d = (src as? ImageView)?.drawable ?: return
        val o = loc(ov); val a = loc(src)
        val iv = ImageView(act)
        iv.setImageDrawable(d.constantState?.newDrawable() ?: d)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val w = src.width; val h = src.height
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        iv.x = (a[0] - o[0]).toFloat(); iv.y = (a[1] - o[1]).toFloat()
        val tx: Float; val ty: Float
        if (dst != null) { val t = loc(dst); tx = t[0] - o[0] + (dst.width - w) / 2f; ty = t[1] - o[1] + (dst.height - h) / 2f }
        else { tx = (ov.width - w) / 2f; ty = ov.height - h * 1.6f }       // my own seat: the bottom of the screen
        iv.animate().x(tx).y(ty).alpha(if (shrink) 0f else 1f).scaleX(if (shrink) 0.6f else 1f).scaleY(if (shrink) 0.6f else 1f)
            .setStartDelay(Anim.ad(delay)).setDuration(Anim.ad(380L))
            .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** the captured table cards fly to the player who took them */
    private fun flyCapture(seat: Int, idx: List<Int>) {
        val dst = cellOf(seat)
        var k = 0
        for (i in idx) {
            if (i >= tableV.childCount) continue
            val v = tableV.getChildAt(i)
            flyCopy(v, dst, 70L * k, true)
            v.visibility = View.INVISIBLE
            k++
        }
    }

    /** the played card flies from the player's seat to the table */
    private fun flyPlay(seat: Int, c: Card) {
        val dstView = tableV
        val o = loc(ov); val t = loc(dstView)
        val w = Px.dp(46); val h = Px.dp(64)
        val iv = ImageView(act)
        val bmp = Assets.bitmap(act, Assets.cardPath(c)) ?: return
        iv.setImageBitmap(bmp)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        val src = cellOf(seat)
        val sx: Float; val sy: Float
        if (src != null) { val a = loc(src); sx = (a[0] - o[0] + (src.width - w) / 2f); sy = (a[1] - o[1] + (src.height - h) / 2f) }
        else { val a = loc(handV); sx = (a[0] - o[0] + handV.width / 2f - w / 2f); sy = (a[1] - o[1]).toFloat() }
        iv.x = sx; iv.y = sy
        iv.animate().x(t[0] - o[0] + dstView.width / 2f - w / 2f).y(t[1] - o[1] + dstView.height / 2f - h / 2f)
            .setDuration(Anim.ad(320L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    private fun banner(text: String) {
        val e = TextView(act)
        e.text = text; e.textSize = 26f; e.setTextColor(0xFFFFE36B.toInt()); e.setTypeface(e.typeface, Typeface.BOLD)
        e.gravity = Gravity.CENTER
        e.setPadding(Px.dp(22), Px.dp(14), Px.dp(22), Px.dp(14))
        e.background = Px.rounded(0xCC000000.toInt(), 16, 2, Px.GOLD)
        e.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        e.alpha = 0f; e.scaleX = 0.5f; e.scaleY = 0.5f
        ov.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        e.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(Anim.ad(250L)).withEndAction {
            e.animate().alpha(0f).setStartDelay(Anim.ad(1300L)).setDuration(Anim.ad(350L)).withEndAction { try { ov.removeView(e) } catch (x: Exception) { } }.start()
        }.start()
    }

    // ------------------------------------------------------------------ menu inside the game

    private fun gameMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("بازگشت به بازی" to { })
        if (role != "client") items.add("بازی جدید" to { askNew() })
        items.add("تغییر نام" to { renameAsk() })
        if (role == "host") {
            if ((1 until n).any { !remote[it] }) items.add("افزودن بازیکن" to { addAsk() })
            if ((1 until n).any { remote[it] }) {
                items.add("حذف بازیکن" to { kickAsk() })
                items.add("انتقال میزبانی" to { xferAsk() })
            }
        }
        if (role != "client") items.add("ذخیرهٔ بازی" to { manualSave() })
        items.add(("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) to { app.a11yToggle() })
        items.add("سرعت انیمیشن" to { app.animSpeedAsk() })
        items.add("تنظیمات صدا" to { app.dlg.sound() })
        items.add("تنظیمات تصویر زمینه" to { app.dlg.cards("bg") { } })
        items.add("تنظیمات پشت کارت" to { app.dlg.cards("back") { render() } })
        items.add("راهنما" to { guideDialog(app.dlg) })
        items.add("خروج از بازی" to {
            if (role == "host") exitHostAsk()
            else app.dlg.confirm((if (role == "solo") "از بازی خارج می‌شوید؟ بازی تا پایان دست قبل ذخیره شده است." else "از بازی خارج می‌شوید؟"), { net?.leave(); close() })
        })
        app.dlg.list("گزینه‌های بیشتر", items, "بستن")
    }

    /** a new game: robots only = back to the setup; with other phones = the same table starts from zero */
    private fun askNew() {
        app.dlg.confirm("بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.", { newGameNow() })
    }

    private fun newGameNow() {
        stopGame()
        if (role == "solo") { try { SavesCb.del("auto") } catch (e: Exception) { }; showSetup() }
        else if (role == "host") {
            score = IntArray(sides); dealer = (Math.random() * n).toInt()
            lastSave = saveJson().toString()
            startGame()
            sendSync()
        }
    }

    /** a phone that is connected to the running game but has no seat yet takes the seat of a robot */
    fun hasSeat(cid: Int): Boolean = cidOf.indexOf(cid) >= 0

    private fun addAsk() {
        val nt = net ?: return
        val seats = (1 until n).filter { !remote[it] }
        if (seats.isEmpty()) { app.dlg.message("جای خالی نیست."); return }
        val w = nt.waiting()
        if (w.isEmpty()) { app.dlg.message("گوشی منتظری نیست. بازیکن باید «به بازی دیگری می‌پیوندم» را بزند و بازی شما را انتخاب کند."); return }
        fun pickSeat(cid: Int, nm: String) {
            if (seats.size == 1) { addPlayer(cid, seats[0]); return }
            app.dlg.list("«" + nm + "» جای کدام بازیکن یا ربات بنشیند؟", seats.map { x -> names[x] to { addPlayer(cid, x) } }, "بستن")
        }
        if (w.size == 1) pickSeat(w[0].first, w[0].second)
        else app.dlg.list("کدام گوشی اضافه شود؟", w.map { (cid, nm) -> nm to { pickSeat(cid, nm) } }, "بستن")
    }

    private fun addPlayer(cid: Int, seat: Int) {
        val info = net?.peerInfo(cid) ?: return
        if (remote[seat]) return
        if (info.wallet < need(stake, n)) { app.dlg.message("«" + info.name + "» ژتون کافی ندارد (دست‌کم " + Cards.fa(need(stake, n)) + " لازم است) و نمی‌تواند وارد بازی شود."); return }
        remote[seat] = true; cidOf[seat] = cid; idOf[seat] = info.id
        val l = names.toMutableList(); l[seat] = info.name; names = l
        net?.send(cid, startMsg(seat))
        say(info.name + " به بازی پیوست.")
        sendStates(); sendSync()
    }

    private fun kickAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { s: Int -> app.dlg.confirm("«" + names[s] + "» از بازی حذف شود؟ ربات جای او بازی می‌کند.", { kickPlayer(s) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("کدام بازیکن حذف شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }

    private fun kickPlayer(s: Int) {
        if (!remote[s]) return
        net?.send(cidOf[s], JSONObject().put("t", "end").put("m", "میزبان شما را از بازی حذف کرد."))
        remote[s] = false; cidOf[s] = -1; idOf[s] = ""
        ansQ[s].offer("drop")
        say(names[s] + " از بازی حذف شد و ربات جای او آمد.")
        sendSync()
    }

    private fun xferAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { s: Int -> app.dlg.confirm("میزبانی به «" + names[s] + "» داده شود و شما از بازی خارج شوید؟ دست فعلی از نو پخش می‌شود.", { xferTo(s) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("میزبانی به چه کسی داده شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }

    private fun renameAsk() {
        app.dlg.nameAsk(true) { v ->
            val nm = v.trim()
            if (nm.isNotEmpty()) { Prefs.name = nm; val l = names.toMutableList(); l[me] = nm; names = l; draw() }
        }
    }

    // ------------------------------------------------------------------ the game (worker thread)

    private fun loop() {
        while (alive) {
            playHand()
            if (!alive) return
            // somebody reached the target?
            var best = -1; var bi = -1; var tie = false
            for (s in 0 until sides) { if (score[s] > best) { best = score[s]; bi = s; tie = false } else if (score[s] == best) tie = true }
            saveAuto()
            if (best >= target && !tie) {
                val who = if (n == 4) "تیم " + teamName(bi) else names[bi]
                say(who + " برنده شد با " + Cards.fa(best) + " امتیاز.")
                for (seat in 0 until n) {
                    val won = bi == sideOf(seat)
                    val d = chipDelta(won)
                    if (seat == me) {
                        Prefs.wallet = Prefs.wallet + d
                        ui { banner(if (won) "بردید!" else "باختید!") }
                        Sched.post { Sound.game(if (won) "fwin" else "flose") }
                        localSay(chipText(d))
                    } else if (isRemote(seat)) {
                        net?.send(cidOf[seat], JSONObject().put("t", "fin").put("w", won).put("d", d))
                    }
                }
                try { SavesCb.del("auto"); SavesCb.del("autoM") } catch (e: Exception) { }
                if (role != "client") {      // as in Hokm: the game is over, ask for a new one
                    Thread.sleep(Anim.ad(3500L))
                    ui { app.dlg.confirm("بازی تمام شد. بازی جدید شروع شود؟", { newGameNow() }) }
                }
                return
            }
            dealer = (dealer + 1) % n
            pace(1200)
        }
    }

    private fun saveAuto() {
        try {
            lastSave = saveJson().toString()
            if (role == "solo") SavesCb.put("auto", false, lastSave) else if (role == "host") { SavesCb.put("autoM", true, lastSave); sendSync() }
        } catch (e: Exception) { }
    }

    /** every guest gets the last save; the first guest takes over as host if the host disappears */
    private fun sendSync() {
        if (role != "host" || lastSave.isEmpty()) return
        val succ = (1 until n).firstOrNull { remote[it] } ?: return
        sendAll(JSONObject().put("t", "sync").put("sv", lastSave).put("succ", succ))
    }

    /** the host dropped out without handing over: this phone (the first guest) hosts from the last save */
    fun adoptFromSync() {
        val nt = net
        if (nt == null || syncSv.isEmpty()) { showReconnect(); return }
        try {
            nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
            stopGame(); started = false
            resumeHostGame(JSONObject(syncSv), true)
        } catch (e: Exception) { showReconnect() }
    }

    private fun playHand() {
        val deck = Pasur.newDeck()
        for (i in 0 until 4) { hands[i] = ArrayList(); taken[i] = ArrayList(); surs[i] = 0 }
        table = ArrayList(); lastTaker = -1
        // four cards to the table (re-dealt when it holds too many jacks, queens or kings; a lone jack goes under the deck)
        while (true) {
            val t = ArrayList<Card>()
            for (i in 0 until 4) t.add(deck.removeAt(deck.size - 1))
            var j = 0; var q = 0; var k = 0
            for (c in t) { if (c.r == 11) j++; if (c.r == 12) q++; if (c.r == 13) k++ }
            if (j > 1 || q > 2 || k > 2) { deck.addAll(t); Cards.shuf(deck); continue }
            if (j == 1) {
                val jc = t.first { it.r == 11 }
                t.remove(jc); deck.add(0, jc)
                t.add(deck.removeAt(deck.size - 1))
                if (t.count { it.r == 11 } > 0) { deck.addAll(t); Cards.shuf(deck); continue }
            }
            table = t
            break
        }
        deckLeft = deck.size
        snd("shuffle")
        say(names[dealer] + " کارت‌ها را پخش می‌کند. روی میز: " + table.joinToString("، ") { Cards.cname(it) })
        draw(); pace(700)
        while (deck.isNotEmpty() && alive) {
            for (s in 0 until n) { val p = (dealer + 1 + s) % n; for (i in 0 until 4) hands[p].add(deck.removeAt(deck.size - 1)) }
            deckLeft = deck.size
            snd("card"); draw(); pace(500)
            for (t in 0 until 4 * n) {
                if (!alive) return
                val seat = (dealer + 1 + t) % n
                val last = deck.isEmpty() && (0 until n).sumOf { hands[it].size } == 1
                playTurn(seat, last)
            }
        }
        // what is left on the table goes to the last player who took cards
        if (table.isNotEmpty() && lastTaker >= 0) {
            say("برگ‌های مانده روی میز به " + names[lastTaker] + " می‌رسد.")
            taken[sideOf(lastTaker)].addAll(table)
            table = ArrayList()
            draw(); pace(700)
        }
        scoreHand()
    }

    private fun playTurn(seat: Int, last: Boolean) {
        turn = seat
        val hand = hands[seat]
        if (hand.isEmpty()) return
        var ci: Int; var cap: List<Int>
        if (seat == me) {
            msg = "نوبت شماست"
            selHand = -1; selTbl.clear()
            moveQ.clear()
            myTurn = true
            draw()
            val m = moveQ.take()
            val p = m.indexOf('|')
            ci = m.substring(0, p).toInt()
            val rest = m.substring(p + 1)
            cap = if (rest.isEmpty()) emptyList() else rest.split(",").map { it.toInt() }
        } else if (isRemote(seat)) {      // a person on another phone: wait for his move
            msg = "نوبت " + names[seat]
            var mv: Pair<Int, List<Int>>? = null
            while (mv == null && alive) {
                ansQ[seat].clear(); waitSeat = seat; draw()
                val a = ansQ[seat].take()
                if (a == "drop") break
                mv = parseMove(seat, a)
            }
            waitSeat = -1
            if (mv == null) { draw(); pace(700); mv = botMove(seat, last) }      // he left: a robot plays his turn
            ci = mv.first; cap = mv.second
        } else {
            msg = "نوبت " + names[seat]
            draw(); pace(700)
            val mv = botMove(seat, last)
            ci = mv.first; cap = mv.second
        }
        applyMove(seat, ci, cap, last)
    }

    private fun applyMove(seat: Int, ci: Int, cap: List<Int>, last: Boolean) {
        val card = hands[seat][ci]
        val tableNow = ArrayList(table)
        val capCards = cap.map { tableNow[it] }
        if (role == "host") sendAll(JSONObject().put("t", "mv").put("seat", seat).put("c", Cards.idc(card)).put("cap", JSONArray(cap)))
        // animations first, then the state changes
        uiWait {
            if (cap.isNotEmpty()) flyCapture(seat, cap)
            if (seat != me) flyPlay(seat, card)
        }
        snd(if (cap.isEmpty()) "card" else "trick")
        hands[seat].removeAt(ci)
        if (cap.isEmpty()) {
            val t = ArrayList(table); t.add(card); table = t
            say(names[seat] + " " + Cards.cname(card) + " را روی میز انداخت.")
        } else {
            val t = ArrayList<Card>()
            for (i in tableNow.indices) if (!cap.contains(i)) t.add(tableNow[i])
            table = t
            taken[sideOf(seat)].addAll(capCards); taken[sideOf(seat)].add(card)
            lastTaker = seat
            say(names[seat] + " با " + Cards.cname(card) + " این برگ‌ها را برداشت: " + capCards.joinToString("، ") { Cards.cname(it) })
            if (table.isEmpty() && card.r != 11 && !last && score[sideOf(seat)] < 50) {
                surs[sideOf(seat)]++
                say("سور! " + names[seat])
                bannerAll("سور!")
                snd("win")
            }
        }
        turn = -1
        draw()
        say("روی میز: " + (if (table.isEmpty()) "هیچ برگی نیست" else table.joinToString("، ") { Cards.cname(it) }))
        pace(600)
    }

    private fun scoreHand() {
        val pts = IntArray(sides)
        val cl = IntArray(sides)
        for (s in 0 until sides) {            // the cards are kept per side (a team shares them)
            pts[s] = Pasur.cardPoints(taken[s])
            cl[s] = Pasur.clubs(taken[s])
        }
        var topC = 0; var topS = -1; var tieC = false
        for (s in 0 until sides) { if (cl[s] > topC) { topC = cl[s]; topS = s; tieC = false } else if (cl[s] == topC) tieC = true }
        if (topC >= 7 && !tieC && topS >= 0) pts[topS] += 7
        val sr = IntArray(sides)
        for (s in 0 until sides) sr[s] = surs[s]
        if (sides == 2) { val m = Math.min(sr[0], sr[1]); sr[0] -= m; sr[1] -= m }
        for (s in 0 until sides) { pts[s] += 5 * sr[s]; score[s] += pts[s] }
        val sb = StringBuilder("پایان دست. امتیاز این دست: ")
        for (s in 0 until sides) { if (s > 0) sb.append("، "); sb.append((if (n == 4) teamName(s) else names[s]) + " ").append(Cards.fa(pts[s])) }
        say(sb.toString())
        draw(); pace(1200)
    }

    // ------------------------------------------------------------------ the robots

    /** how much a capture is worth to a robot (in points) */
    private fun gain(card: Card, cap: List<Card>, side: Int, emptied: Boolean, last: Boolean): Double {
        var g = 0.0
        val all = ArrayList(cap); all.add(card)
        for (c in all) {
            if (c.r == 14) g += 1.0
            else if (c.r == 11) g += 1.0
            else if (c.s == 3 && c.r == 2) g += 2.0
            else if (c.s == 2 && c.r == 10) g += 3.0
            if (c.s == 3) g += 0.7 else g += 0.15
        }
        if (emptied && card.r != 11 && !last && score[side] < 50) g += 5.0
        return g
    }

    /** cost of leaving a card on the table (it may be taken by the opponents) */
    private fun cost(c: Card): Double {
        var k = 0.1
        if (c.r == 11) k += 3.0
        if (c.s == 2 && c.r == 10) k += 4.0
        if (c.s == 3 && c.r == 2) k += 3.0
        if (c.r == 14) k += 1.2
        if (c.s == 3) k += 0.6
        return k
    }

    private fun botMove(seat: Int, last: Boolean): Pair<Int, List<Int>> {
        val hand = hands[seat]
        val tb = ArrayList(table)
        val side = sideOf(seat)
        var bestScore = -1e9; var bi = 0; var bc: List<Int> = emptyList()
        for ((i, c) in hand.withIndex()) {
            val opts = Pasur.options(c, tb)
            for (o in opts) {
                val cap = o.map { tb[it] }
                val emptied = o.size == tb.size
                val g = gain(c, cap, side, emptied, last) + Math.random() * 0.05
                if (g > bestScore) { bestScore = g; bi = i; bc = o }
            }
            if (opts.isEmpty()) {
                val g = -cost(c) + Math.random() * 0.05
                if (g > bestScore) { bestScore = g; bi = i; bc = emptyList() }
            }
        }
        // if every card could capture, a capture was chosen above; otherwise the cheapest throw was
        return Pair(bi, bc)
    }

    companion object {
        /** the guide as a list of topics (each opens its own text) */
        fun guideDialog(dlg: Dialogs) {
            dlg.list("راهنمای بازی", TOPICS.map { t -> t.first to { dlg.message(t.first + "\n\n" + t.second) } }, "بستن")
        }

        val TOPICS = listOf(
            "پخش و بازی" to "دستهٔ ۵۲ برگی. چهار برگ رو به میز می‌آید و به هر بازیکن چهار برگ داده می‌شود. هر بازیکن در نوبتش یک برگ از دستش می‌اندازد. وقتی همه برگ‌هایشان تمام شد، دوباره چهار برگ داده می‌شود تا دسته تمام شود. اگر روی میز بیش از یک سرباز، یا بیش از دو بی‌بی یا دو شاه باشد، دوباره پخش می‌شود.",
            "برداشتن برگ‌ها" to "شاه فقط شاه را برمی‌دارد و بی‌بی فقط بی‌بی را. سرباز همهٔ برگ‌های میز را برمی‌دارد، به‌جز شاه و بی‌بی. آس و ۲ تا ۱۰ برگ‌هایی را برمی‌دارند که مجموعشان با آن برگ ۱۱ شود (آس ۱ حساب می‌شود). مثلاً ۴ می‌تواند ۷ را بردارد، یا ۳ و ۴ را. چند گروه را می‌شود با هم برداشت. برداشتن اجباری نیست؛ می‌توانید برگ را روی میز بیندازید.",
            "سور" to "اگر با برگی غیر از سرباز همهٔ میز را خالی کنید، یک سور (۵ امتیاز) می‌گیرید. در آخرین برگ دست و برای کسی که ۵۰ امتیاز یا بیشتر دارد سور حساب نمی‌شود. در بازی دو تیمه، سور هر تیم یکی از سورهای تیم دیگر را خنثی می‌کند.",
            "امتیازها" to "بیشترین خاج (۷ برگ یا بیشتر): ۷ امتیاز. هر آس: ۱. هر سرباز: ۱. دوی خاج: ۲. ده خشت: ۳. هر سور: ۵. برگ‌های مانده روی میز در پایان دست به آخرین کسی می‌رسد که برگ برداشته. اولین بازیکن یا تیمی که به امتیاز هدف برسد، برنده است.",
            "کار با صفحه" to "برگی را از دستتان انتخاب کنید. اگر فقط یک برداشتن ممکن باشد، خودش انتخاب می‌شود. برای برداشتن چند برگ، آن‌ها را روی میز لمس کنید و «بردار» را بزنید. برای انداختن، انتخاب میز را خالی کنید و «بینداز روی میز» را بزنید."
        )
    }
}
