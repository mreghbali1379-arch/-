package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue

/**
 * Rules of "چهار برگ" (Pasur). Pure logic, no UI.
 * Cards: Card(s, r) with r 2..10 numbers, 11 jack, 12 queen, 13 king, 14 ace (worth 1).
 * A card played from the hand may capture: a king a king, a queen a queen, a jack everything except kings and queens,
 * a number (or ace) cards that add up to 11 together with it (several groups at once are allowed).
 */
object Pasur {
    /** value of a card for the "adds up to 11" rule (ace 1; face cards 0 = they do not count) */
    fun value(c: Card): Int = if (c.r == 14) 1 else if (c.r >= 11) 0 else c.r

    private fun isFace(c: Card) = c.r in 11..13

    /** can these values be split into groups that each add up to target? */
    private fun canSplit(v: List<Int>, target: Int): Boolean {
        if (v.isEmpty()) return true
        if (target <= 0) return false
        val first = v[0]
        val rest = v.subList(1, v.size)
        return pick(first, rest, 0, target, v)
    }

    /** choose a group that contains v[0]; the rest must split too */
    private fun pick(first: Int, rest: List<Int>, from: Int, target: Int, all: List<Int>): Boolean {
        // enumerate subsets of rest that complete first to target
        val m = rest.size
        for (mask in 0 until (1 shl m)) {
            var s = first
            for (i in 0 until m) if ((mask shr i) and 1 == 1) s += rest[i]
            if (s != target) continue
            val left = ArrayList<Int>()
            for (i in 0 until m) if ((mask shr i) and 1 == 0) left.add(rest[i])
            if (canSplit(left, target)) return true
        }
        return false
    }

    /** is capturing exactly the table cards at indexes sel with card c a legal move? */
    fun isValid(c: Card, table: List<Card>, sel: List<Int>): Boolean {
        if (sel.isEmpty()) return false
        for (i in sel) if (i < 0 || i >= table.size) return false
        if (c.r == 11) {
            val all = ArrayList<Int>()
            for (i in table.indices) if (table[i].r != 12 && table[i].r != 13) all.add(i)
            return all.size == sel.size && all.containsAll(sel)
        }
        if (c.r == 12 || c.r == 13) return sel.size == 1 && table[sel[0]].r == c.r
        val v = ArrayList<Int>()
        for (i in sel) { if (isFace(table[i])) return false; v.add(value(table[i])) }
        return canSplit(v, 11 - value(c))
    }

    /** every legal capture of card c (each as a list of table indexes) */
    fun options(c: Card, table: List<Card>): List<List<Int>> {
        val r = ArrayList<List<Int>>()
        if (c.r == 11) {
            val all = ArrayList<Int>()
            for (i in table.indices) if (table[i].r != 12 && table[i].r != 13) all.add(i)
            if (all.isNotEmpty()) r.add(all)
            return r
        }
        if (c.r == 12 || c.r == 13) {
            for (i in table.indices) if (table[i].r == c.r) r.add(listOf(i))
            return r
        }
        val idx = ArrayList<Int>()
        for (i in table.indices) if (!isFace(table[i])) idx.add(i)
        val m = Math.min(idx.size, 13)
        val target = 11 - value(c)
        for (mask in 1 until (1 shl m)) {
            val sel = ArrayList<Int>(); val v = ArrayList<Int>()
            var sum = 0
            for (i in 0 until m) if ((mask shr i) and 1 == 1) { sel.add(idx[i]); v.add(value(table[idx[i]])); sum += value(table[idx[i]]) }
            if (sum % target != 0) continue
            if (canSplit(v, target)) r.add(sel)
        }
        return r
    }

    /** points of the cards a side has taken (not counting the clubs bonus and surs) */
    fun cardPoints(cards: List<Card>): Int {
        var p = 0
        for (c in cards) {
            if (c.r == 14) p += 1
            if (c.r == 11) p += 1
            if (c.s == 3 && c.r == 2) p += 2
            if (c.s == 2 && c.r == 10) p += 3
        }
        return p
    }

    fun clubs(cards: List<Card>): Int { var k = 0; for (c in cards) if (c.s == 3) k++; return k }

    fun newDeck(): MutableList<Card> {
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
        Cards.shuf(d)
        return d
    }
}

/**
 * The Chahar Barg game screen: drawn over the other screens (a full-screen overlay) and sharing the settings.
 * The game runs on a worker thread that waits for the player's moves.
 */
/** The rules of the Chahar Barg game: fixed, as on pagat.com (no options). */
object CbRules {
    const val surLimit = 50     // a side with 50 points or more cannot score a sur
    const val cancel = true     // a sur cancels a sur of the opponents
    const val surValue = 5      // points of a sur
    const val redeal = 0        // the first table is dealt again with more than one jack, more than two queens or more than two kings
    val targets = listOf(62, 61, 100)    // the points that win a game
    const val lastCancel = false         // no sur counts in the last deal
}

class Pasur4(private val act: MainActivity, private val app: App) {
    private val NM = listOf("علی", "ندا", "رضا", "سارا", "امیر", "مینا", "کیان", "نرگس")

    // ---- options and state ----
    private var n = 2
    private var target = 62
    private var stake = 1000                      // chips of each player for this game (robots have no limit)
    private var names: List<String> = emptyList()
    private var score = IntArray(0)               // per side
    private var dealer = 0
    private var hands: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
    @Volatile private var table: MutableList<Card> = ArrayList()
    private var taken: Array<MutableList<Card>> = Array(4) { ArrayList<Card>() }
    private var surs = IntArray(4)
    private var deckLeft = 0
    private var turn = -1
    private var lastTaker = -1
    private var msg = ""
    private var over = false      // the game is over: a "بازی جدید" button stays in place of the buttons (as in Hokm)
    private val logLines = ArrayList<String>()
    private val gameId = System.currentTimeMillis().toString()

    // ---- several phones: "solo" (robots only), "host" (runs the game) or "client" (only shows the table and sends its moves)
    @JvmField var role = "solo"
    @JvmField var roomCode = ""
    @Volatile @JvmField var resuming = false            // a saved game was loaded and the host waits for the players to come back
    private var lastSave = ""
    private var syncSv = ""                            // the host's last save (guest side): used to take over if the host drops out suddenly
    private var succSeat = -1
    val isSucc: Boolean get() = role == "client" && syncSv.isNotEmpty() && me == succSeat
    private var me = 0                                  // my seat (the host and a solo player sit at 0)
    private val remote = BooleanArray(4)
    private val cidOf = IntArray(4) { -1 }
    private val idOf = Array(4) { "" }
    private val ansQ = Array(4) { LinkedBlockingQueue<String>() }
    @Volatile private var waitSeat = -1
    private var net: NetCb? = null
    private fun isRemote(s: Int) = role == "host" && remote[s]

    @Volatile private var alive = false
    @Volatile var started = false
    private var worker: Thread? = null
    private val moveQ = LinkedBlockingQueue<String>()
    @Volatile private var myTurn = false

    // selection while it is my turn (UI thread only)
    private var selHand = -1
    private val selTbl = HashSet<Int>()

    // ---- views ----
    private val ov = FrameLayout(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)
    private lateinit var gameV: LinearLayout
    private lateinit var scoreTv: TextView
    private lateinit var msgTv: TextView
    private lateinit var playersV: FlowLayout
    private lateinit var infoTv: TextView
    private lateinit var tableV: FlowLayout
    private lateinit var handV: FlowLayout
    private lateinit var ctl: LinearLayout
    private lateinit var logTv: TextView
    private var screen = "setup"
    private var lastMsg = ""
    private var lastHandKey = ""
    @JvmField var hidden = false
    val running: Boolean get() = started && ov.parent != null

    private fun sideOf(seat: Int) = if (n == 4) seat % 2 else seat
    private val sides: Int get() = if (n == 4) 2 else n

    // ------------------------------------------------------------------ shell

    fun show(start: String, ad: ((NetCb) -> Unit)? = null) {
        ov.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ov.setBackgroundColor(Px.bg)
        ov.isClickable = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        val sc = ScrollView(act)
        sc.isFillViewport = true
        sc.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.addView(sc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        app.menuShown(false)
        act.onBack = { back() }
        if (start == "resume") showSaves()
        else if (start == "net") { val nt = NetCb(act, app, this); net = nt; nt.show() }
        else if (start == "adopt") { val nt = NetCb(act, app, this); net = nt; ad?.invoke(nt) }
        else if (start == "blank") { }
        else showSetup()
    }

    /** closes this screen but keeps the links: the lobby has changed to another game (the other game takes the phones over) */
    fun detach() {
        resuming = false
        stopGame()
        net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
    }

    fun close(notify: Boolean = true) {
        if (role == "host" && notify) sendAll(JSONObject().put("t", "end").put("m", "میزبان بازی را بست."))
        resuming = false
        stopGame()
        net?.close(); net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
        app.menuShown(true)
        app.syncBg()
        app.pageClosed()
    }

    private fun back(): Boolean {
        if (screen == "net" && net?.back() == true) return true
        if (screen == "game") {
            if (role == "solo") app.dlg.confirm("بازی فعلی از بین می‌رود. به مرحله‌ی قبل برگردیم؟", { newGameNow() })
            else if (role == "host") exitHostAsk()
            else app.dlg.confirm("از بازی خارج می‌شوید؟", { net?.leave(); close() })
            return true
        }
        net?.leave(); close()
        return true
    }

    private fun ui(f: () -> Unit) { act.runOnUiThread { try { f() } catch (e: Exception) { } } }

    /** runs f on the UI thread and waits until it is done (used before the state changes under an animation) */
    private fun uiWait(f: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) { try { f() } catch (e: Exception) { }; return }
        val l = CountDownLatch(1)
        act.runOnUiThread { try { f() } catch (e: Exception) { }; l.countDown() }
        l.await()
    }

    fun tv(t: String, size: Float = 15f, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun setScreen(name: String, v: View) { screen = name; content.removeAllViews(); content.addView(v) }

    fun heading(t: String): TextView {
        val h = tv(t, 26f, Px.tx, true)
        h.gravity = Gravity.CENTER
        h.setPadding(0, Px.dp(12), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) h.isAccessibilityHeading = true
        return h
    }

    fun mbtn(t: String, f: () -> Unit): View {
        val b = app.dlg.btn(t, true, f)
        val l = LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    // ------------------------------------------------------------------ setup and saved games

    /** the setup page is built into the main menu's "بازی جدید" page (under the game type); the screen of this game opens when "شروع بازی" is pressed */
    private var embedded = false
    private fun ensureShown() { if (embedded) { embedded = false; show("blank") } }
    fun setupBody(): LinearLayout { embedded = true; return buildSetup() }

    private fun showSetup() {
        embedded = false
        val v0 = LinearLayout(act); v0.orientation = LinearLayout.VERTICAL
        v0.addView(heading("بازی جدید"))
        v0.addView(buildSetup())
        setScreen("setup", v0)
    }

    private fun buildSetup(): LinearLayout {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL
        val counts = listOf(2, 3, 4)
        val targets = CbRules.targets
        v.addView(tv("تعداد بازیکن‌ها (با ربات). در بازی چهار نفره دو تیم دو نفره‌اید و هم‌تیمی شما ربات است.", 15f))
        val sp1 = Spinner(act)
        sp1.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, counts.map { Cards.fa(it) + " نفره" })
        sp1.setSelection(0)      // as in Hokm: the first option is preselected
        sp1.speakLabel("تعداد بازیکن‌ها")
        v.addView(sp1)
        v.addView(tv("امتیاز برد", 16f))
        val sp2 = Spinner(act)
        sp2.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, targets.map { Cards.fa(it) })
        sp2.setSelection(Math.max(0, targets.indexOf(target)))
        sp2.speakLabel("امتیاز برد")
        v.addView(sp2)
        v.addView(tv("ژتون هر بازیکن برای این بازی (عدد را تایپ کنید، دست‌کم ۱):", 15f))
        val stEt = numField(act, "ژتون هر بازیکن برای این بازی", stake)
        v.addView(stEt)
        v.addView(tv("دو نفره: برنده از بازنده همین مقدار می‌گیرد. سه نفره: برنده از هر بازنده. چهار نفره: تیم بازنده روی هم یک مبلغ می‌دهد و تیم برنده نصف‌نصف تقسیم می‌کند. ربات‌ها ژتون نامحدود دارند.", 13f))
        v.addView(mbtn("شروع بازی") {
            n = counts[sp1.selectedItemPosition]; target = targets[sp2.selectedItemPosition]
            val st = Cards.num(stEt.text.toString())
            if (!checkStake(st, n)) return@mbtn
            stake = st
            role = "solo"; me = 0; for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
            names = listOf(if (Prefs.name.isEmpty()) "شما" else Prefs.name) + NM.subList(0, n - 1)
            score = IntArray(sides); dealer = (Math.random() * n).toInt()
            ensureShown()
            startGame()
        })
        return v
    }

    /** the host page of the main menu uses this game: its settings and players are shown there; this game's own screen opens when the game starts */
    fun hostInPage(room: String, name: String, ps: List<HandPeer>, box: LinearLayout, plist: LinearLayout, infoTv: TextView) {
        val nt = NetCb(act, app, this); net = nt
        nt.adoptHostInPage(room, name, ps, box, plist, infoTv)
    }
    fun hostStartFromPage() { net?.startFromPage() }
    fun hostState(): Triple<String, String, List<HandPeer>>? = net?.handoff()
    fun ensureHostShown() { show("blank") }

    /** a saved game chosen in the common list of saved games */
    fun resumeExternal(e: SavesCb.E) { show("blank"); resumeFrom(e) }
    fun resumeMultiExternal(e: SavesCb.E) { show("net"); net?.resumeSaved(e) }

    private fun saveJson(): JSONObject {
        val j = JSONObject().put("n", n).put("target", target).put("dealer", dealer).put("stake", stake)
        val nm = JSONArray(); for (x in names) nm.put(x)
        val sc = JSONArray(); for (x in score) sc.put(x)
        val ids = JSONArray(); for (i in 0 until n) ids.put(if (role == "host" && i == 0) Prefs.devId() else idOf[i])
        return j.put("names", nm).put("score", sc).put("ids", ids).put("multi", role == "host")
    }

    private fun manualSave() {
        if (!started) return
        SavesCb.put("m" + System.currentTimeMillis(), role == "host", saveJson().toString())
        app.dlg.message("بازی ذخیره شد.")
    }

    private fun showSaves() {
        val l = SavesCb.all(false)
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("بازی‌های قبلی"))
        if (l.isEmpty()) v.addView(tv("بازی ذخیره‌شده‌ای وجود ندارد.", 15f))
        for (e in l) v.addView(mbtn(SavesCb.describe(e)) {
            app.dlg.list(SavesCb.describe(e), listOf(
                "ادامه بازی" to { resumeFrom(e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { SavesCb.del(e.id); showSaves() }) }
            ), "بستن")
        })
        setScreen("saves", v)
    }

    private fun resumeFrom(e: SavesCb.E) {
        try {
            val j = JSONObject(e.data)
            n = j.getInt("n"); target = j.getInt("target"); dealer = j.getInt("dealer"); stake = j.optInt("stake", 1000)
            if (!checkStake(stake, n)) return
            role = "solo"; me = 0; for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = "" }
            val nm = j.getJSONArray("names"); val sc = j.getJSONArray("score")
            names = List(n) { nm.getString(it) }
            if (names.isNotEmpty() && Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            score = IntArray(sides) { if (it < sc.length()) sc.getInt(it) else 0 }
            startGame()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده پیدا نشد."); showSaves() }
    }

    // ------------------------------------------------------------------ game view

    private fun startGame() {
        stopGame()
        logLines.clear(); lastMsg = ""; lastHandKey = ""; msg = ""; over = false
        Spk.reset(); Sound.resetQueue()
        buildGameView()
        alive = true; started = true
        val t = Thread { try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { } }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun stopGame() { alive = false; myTurn = false; worker?.interrupt(); worker = null }

    private fun buildGameView() {
        gameV = LinearLayout(act); gameV.orientation = LinearLayout.VERTICAL
        gameV.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        applyBg()
        val more = LinearLayout(act); more.orientation = LinearLayout.HORIZONTAL
        more.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val mb = TextView(act)
        mb.text = "⋮"; mb.textSize = 26f; mb.setTextColor(Color.WHITE); mb.gravity = Gravity.CENTER
        mb.background = Px.rounded(0x59000000, 20)
        mb.contentDescription = "گزینه‌های بیشتر"
        mb.isClickable = true; mb.isFocusable = true
        mb.setOnClickListener { gameMenu() }
        more.addView(mb, LinearLayout.LayoutParams(Px.dp(40), Px.dp(40)))
        gameV.addView(more)
        val top = LinearLayout(act); top.orientation = LinearLayout.HORIZONTAL; top.gravity = Gravity.CENTER_VERTICAL
        scoreTv = tv("", 15f, Px.GOLD, true)
        top.addView(scoreTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        gameV.addView(top)
        msgTv = tv("", 14f, Color.WHITE); msgTv.gravity = Gravity.CENTER; msgTv.minimumHeight = Px.dp(44)
        gameV.addView(msgTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8); it.bottomMargin = Px.dp(8) })
        playersV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(playersV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        infoTv = tv("", 13f, 0xFFD8CDB4.toInt())
        infoTv.gravity = Gravity.CENTER
        gameV.addView(infoTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        tableV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(tableV, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(150)).also { it.topMargin = Px.dp(4) })
        gameV.addView(tv("برگ‌های شما", 14f, 0xFFD8CDB4.toInt()), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        handV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(handV)
        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL
        gameV.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        logTv = tv("", 13f, 0xFFE8DCC4.toInt())
        gameV.addView(logTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        setScreen("game", gameV)
    }

    private fun cardView(c: Card, w: Int, h: Int, selected: Boolean, onTap: (() -> Unit)?): View {
        val iv = ImageView(act)
        val bmp = Assets.bitmap(act, Assets.cardPath(c))
        if (bmp != null) iv.setImageBitmap(bmp)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setPadding(Px.dp(2), Px.dp(2), Px.dp(2), Px.dp(2))
        iv.background = if (selected) Px.rounded(0x33FFD34D, 8, 3, Px.GOLD) else null
        iv.contentDescription = Cards.cname(c) + (if (selected) "، انتخاب شده" else "")
        iv.layoutParams = ViewGroup.LayoutParams(Px.dp(w), Px.dp(h))
        if (onTap != null) { iv.isClickable = true; iv.isFocusable = true; iv.setOnClickListener { onTap() } }
        return iv
    }

    /** the chips a person must have to take part: four players = half the stake (his partner pays the other half) */
    fun need(st: Int, players: Int): Int = if (players == 4) Math.max(1, st / 2) else st

    private fun checkStake(st: Int, players: Int): Boolean {
        if (Prefs.wallet < Bist21.MIN_PLAY) { app.dlg.message(Bist21.BROKE); return false }
        if (st < 1) { app.dlg.message("ژتون هر بازیکن را به‌صورت عدد و دست‌کم ۱ تایپ کنید."); return false }
        if (Prefs.wallet < need(st, players)) {
            app.dlg.message("ژتون شما برای این مبلغ کافی نیست (ژتون شما: " + Cards.fa(Prefs.wallet) + (if (players == 4) "؛ در بازی چهار نفره دست‌کم نصف مبلغ لازم است" else "") + "). مبلغ کمتری انتخاب کنید.")
            return false
        }
        return true
    }

    private fun sidePoints(side: Int): String = Cards.fa(score[side])

    private fun render() {
        if (screen != "game" || !::playersV.isInitialized) return
        val sb = StringBuilder()
        if (n == 4) sb.append("ما ").append(sidePoints(sideOf(me))).append(" — آن‌ها ").append(sidePoints(1 - sideOf(me)))
        else for (i in 0 until n) { if (i > 0) sb.append(" — "); sb.append(names[i]).append(' ').append(sidePoints(i)) }
        sb.append("  (هدف ").append(Cards.fa(target)).append(")")
        if (stake > 0) sb.append("  — ژتون شما ").append(Cards.fa(Prefs.wallet))
        scoreTv.text = sb.toString()
        msgTv.text = msg
        // like Hokm: the status and the information lines are only there with the accessibility option on
        msgTv.visibility = if (Prefs.a11y || over) View.VISIBLE else View.GONE
        infoTv.visibility = if (Prefs.a11y) View.VISIBLE else View.GONE
        if (msg.isNotEmpty() && msg != lastMsg) { lastMsg = msg; ann(msg) }
        // players
        playersV.removeAllViews()
        for (k in 1 until n) {
            val i = (me + k) % n
            val cell = LinearLayout(act)
            cell.orientation = LinearLayout.VERTICAL; cell.gravity = Gravity.CENTER
            cell.setPadding(Px.dp(8), Px.dp(4), Px.dp(8), Px.dp(4))
            val isD = i == dealer
            cell.background = Px.rounded(0x8C000000.toInt(), 10, if (i == turn) 2 else 0, Px.GOLD)
            val team = if (n == 4 && i % 2 == me % 2) "، هم‌تیمی شما" else ""
            val cnt = hands[i].size
            cell.contentDescription = names[i] + team + (if (isD) "، پخش‌کننده" else "") + "، " + Cards.fa(cnt) + " برگ در دست، " +
                Cards.fa(taken[sideOf(i)].size) + " برگ برداشته" + (if (surs[sideOf(i)] > 0) "، " + Cards.fa(surs[sideOf(i)]) + " سور" else "")
            cell.isFocusable = true
            try { cell.addView(Av.view(act, names[i], 34, i == turn, i == turn)) } catch (e: Exception) { }
            val t = tv(names[i] + (if (isD) " 🂠" else "") + "\n" + Cards.fa(cnt) + " برگ", 12f, Color.WHITE)
            t.gravity = Gravity.CENTER
            t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            cell.addView(t)
            playersV.addView(cell)
        }
        infoTv.text = "دسته: " + Cards.fa(deckLeft) + " برگ — برداشته‌های شما: " + Cards.fa(taken[sideOf(me)].size) +
            (if (surs[sideOf(me)] > 0) " — سور: " + Cards.fa(surs[sideOf(me)]) else "")
        // the table
        tableV.removeAllViews()
        val tl = ArrayList(table)
        val myHand = ArrayList(hands[me])
        val sel = if (myTurn && selHand in myHand.indices) selTbl else HashSet<Int>()
        for ((i, c) in tl.withIndex()) {
            tableV.addView(cardView(c, 46, 64, sel.contains(i), if (myTurn && selHand >= 0) ({ toggleTable(i) }) else null))
        }
        if (tl.isEmpty()) tableV.addView(tv("میز خالی است", 14f, 0xFFD8CDB4.toInt()))
        // my hand
        handV.removeAllViews()
        for ((i, c) in myHand.withIndex()) {
            handV.addView(cardView(c, 52, 72, myTurn && i == selHand, if (myTurn) ({ pickHand(i) }) else null))
        }
        val hk = myHand.joinToString(" ") { Cards.idc(it).toString() }
        if (hk.isNotEmpty() && hk != lastHandKey) { lastHandKey = hk; ann("برگ‌های شما: " + myHand.joinToString("، ") { Cards.cname(it) }) } else if (hk.isEmpty()) lastHandKey = ""
        logTv.text = if (Prefs.a11y) logLines.takeLast(6).joinToString("\n") else ""
        renderButtons()
    }

    // ------------------------------------------------------------------ my move

    private fun pickHand(i: Int) {
        if (!myTurn || i >= hands[me].size) return
        selHand = i; selTbl.clear()
        val c = hands[me][i]
        val o = Pasur.options(c, ArrayList(table))
        if (o.size == 1) selTbl.addAll(o[0])
        render()
        if (Prefs.a11y) ann(Cards.cname(c) + " انتخاب شد" + (if (o.isEmpty()) ". این برگ چیزی برنمی‌دارد." else if (o.size == 1) ". برداشتن آماده است." else ". برگ‌های میز را برای برداشتن انتخاب کنید."))
    }

    private fun toggleTable(i: Int) {
        if (!myTurn || selHand < 0) return
        if (!selTbl.remove(i)) selTbl.add(i)
        render()
    }

    private fun renderButtons() {
        ctl.removeAllViews()
        if (over) {
            if (role == "host") {      // the same page as the first time: game type and settings (the phones stay connected)
                ctl.addView(app.dlg.btn("بازی جدید", false) { app.hostPageAfterGame("cb") })
                ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
            } else ctl.addView(app.dlg.btn("بازی جدید", false) { newGameNow() })
            return
        }
        if (!myTurn) return
        val canTake = selHand in hands[me].indices && selTbl.isNotEmpty() && Pasur.isValid(hands[me][selHand], ArrayList(table), selTbl.sorted())
        val mustTake = selHand in hands[me].indices && Pasur.options(hands[me][selHand], ArrayList(table)).isNotEmpty()      // a card that can capture may not be thrown on the table
        val canThrow = selHand in hands[me].indices && selTbl.isEmpty() && !mustTake
        val b1 = app.dlg.btn("بردار", true) { if (canTake) submit(true) else ann("این انتخاب درست نیست.") }
        b1.alpha = if (canTake) 1f else 0.4f
        val b2 = app.dlg.btn("بینداز روی میز", true) { if (canThrow) submit(false) else if (mustTake) ann("این برگ می‌تواند برگی بردارد؛ باید برداشت کنید، یا برگ دیگری بیندازید.") else ann("برای انداختن، انتخاب میز را خالی کنید.") }
        b2.alpha = if (canThrow) 1f else 0.4f
        ctl.addView(b1); ctl.addView(b2)
    }

    private fun submit(take: Boolean) {
        if (!myTurn || selHand !in hands[me].indices) return
        val s = if (take) selTbl.sorted().joinToString(",") else ""
        val msgv = selHand.toString() + "|" + s
        myTurn = false
        selHand = -1; selTbl.clear()
        if (role == "client") net?.toHost(JSONObject().put("t", "ans").put("m", msgv)) else moveQ.offer(msgv)
        render()
    }

    // ------------------------------------------------------------------ speech (the same queue as the Hokm game)

    private fun ann(t: String) {
        val d = Spk.slot(t, 0L)
        Sched.laterRaw(d) { speak(t) }
    }

    private fun speak(t: String) {
        if (!Prefs.a11y) return
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logTv.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    /** on the player's turn the screen reader goes to the first card of the hand once the speech is done (as in Hokm) */
    private fun focusHand() {
        if (!Prefs.a11y) return
        Sched.laterRaw(idle() + 50L) {
            ui {
                try {
                    if (myTurn && handV.childCount > 0)
                        handV.getChildAt(0).performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
                } catch (e: Exception) { }
            }
        }
    }

    private fun idle(): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now())

    /** a log line shows for 6 seconds, and only with the accessibility option on (as the Hokm log) */
    private fun addLog(m: String) {
        logLines.add(m)
        Sched.laterRaw(6000) { ui { logLines.remove(m); render() } }
    }

    private fun say(m: String) { ui { addLog(m); ann(m); render() }; if (role == "host") sendAll(JSONObject().put("t", "say").put("m", m)) }
    private fun localSay(m: String) { ui { addLog(m); ann(m); render() } }
    private fun draw() { ui { render() }; if (role == "host") sendStates() }
    /** how long the sound queue is still busy (the next action waits for it, as in Hokm; at most 4 s) */
    private fun soundWait(): Long = Math.max(0L, Math.min(4000L, Sound.sq() - Sched.now()))
    /** with announcements on, waits until the voice has said what was queued (a sound does not start over the voice) */
    private fun waitSpeech() {
        if (!Prefs.a11y) return
        uiWait { }
        val w = Spk.end - Sched.now()
        if (w > 0) Thread.sleep(Math.min(w, 9000L))
    }
    private fun pace(ms: Long) { Thread.sleep(Math.max(Math.max(Anim.ad(ms), idle()), soundWait())) }
    /** plays a game sound on this phone: the card sound is timed so its peak meets the card landing on the table (as in Hokm), the shuffle comes with Hokm's shuffle picture, and dealing flies the cards with a sound for each */
    private fun playSnd(name: String, dl: Int = dealer, who: Int = -1) {
        if (name == "dealT") { dealFx(emptyList(), 4, true); return }
        if (name == "dealOne") { dealFx(emptyList(), 1, true, false); return }      // one card: the plain card sound, not the recording
        if (name == "dealH") { dealFx((0 until n).map { (dl + 1 + it) % n }, 4, false); return }
        // as in Hokm the sound depends on who gains: trick / win for my side, tlose / lose for the others
        var nm = name
        if (who >= 0) {
            val mine = sideOf(who) == sideOf(me)
            if (name == "trick") nm = if (mine) "trick" else "tlose"
            else if (name == "win") nm = if (mine) "win" else "lose"
        }
        val d = if (nm == "card") Math.max(0L, Anim.ad(340L) - Sound.CSO.toLong()) else 0L
        if (d > 0L) Sched.later(d) { Sound.game(nm) } else Sched.post { Sound.game(nm) }
        if (nm == "shuffle") ui { Fx.shuffle(450, ov) }
        if (nm == "trick" || nm == "tlose" || nm == "win" || nm == "lose" || nm == "fwin" || nm == "flose") Sched.post { faces(nm) }
    }
    private fun snd(name: String, who: Int = -1) {
        playSnd(name, dealer, who)
        if (role == "host") sendAll(JSONObject().put("t", "snd").put("n", name).put("dl", dealer).put("who", who))
    }

    /** the faces of the players react to what happens, as in Hokm (Av.outcome): my side against the others */
    private fun faces(nm: String) {
        try {
            val al = ArrayList<String>(); val op = ArrayList<String>()
            for (s in 0 until n) if (sideOf(s) == sideOf(me)) al.add(names[s]) else op.add(names[s])
            Av.outcome(nm, Pair(al, op))
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ several phones

    private fun cardOf(id: Int) = Card(id / 20, id % 20)

    private fun sendAll(j: JSONObject) { for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], j) }

    private fun teamName(side: Int): String =
        if (n == 4) (0 until n).filter { sideOf(it) == side }.joinToString(" و ") { names[it] } else names[side]

    /** what seat [seat] sees: its own hand, the table, the counts of the others */
    private fun snapFor(seat: Int, mt: Boolean): JSONObject {
        val j = JSONObject().put("t", "st").put("me", seat).put("n", n).put("target", target).put("stake", stake)
            .put("dealer", dealer).put("turn", turn).put("deck", deckLeft).put("mt", mt)
        val nm = JSONArray(); for (x in names) nm.put(x)
        val sc = JSONArray(); for (x in score) sc.put(x)
        val tb = JSONArray(); for (c in ArrayList(table)) tb.put(Cards.idc(c))
        val hd = JSONArray(); for (c in ArrayList(hands[seat])) hd.put(Cards.idc(c))
        val cn = JSONArray(); for (i in 0 until n) cn.put(hands[i].size)
        val tk = JSONArray(); for (i in 0 until sides) tk.put(taken[i].size)
        val sr = JSONArray(); for (i in 0 until sides) sr.put(surs[i])
        val m = if (mt) "نوبت شماست" else if (turn in 0 until n) "نوبت " + names[turn] else msg
        return j.put("names", nm).put("score", sc).put("table", tb).put("hand", hd).put("cnt", cn).put("tk", tk).put("surs", sr).put("msg", m)
    }

    private fun sendStates() {
        for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], snapFor(s, waitSeat == s))
    }

    private fun startMsg(seat: Int): JSONObject = JSONObject().put("t", "start").put("me", seat)

    /** the host starts a game: seats 1.. are the phones that joined, the other seats are robots */
    fun startHostGame(ps: List<NetCb.Peer>, total: Int, tg: Int, st: Int) {
        role = "host"; me = 0; n = total; target = tg; stake = st
        for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
        val nm = ArrayList<String>()
        nm.add(if (Prefs.name.isEmpty()) "شما" else Prefs.name)
        for ((i, p) in ps.withIndex()) { nm.add(p.name); remote[i + 1] = true; cidOf[i + 1] = p.cid; idOf[i + 1] = p.id }
        for (x in NM.shuffled()) { if (nm.size >= n) break; if (!nm.contains(x)) nm.add(x) }
        names = nm
        score = IntArray(sides); dealer = (Math.random() * n).toInt()
        for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], startMsg(s))
        lastSave = saveJson().toString()
        startGame()
        sendSync()
    }

    // ---- a saved multi-phone game, or a game handed over by the old host

    /** load a save: the host waits until the players are back (they are known by their device ids) */
    fun resumeHostGame(j: JSONObject, handedOver: Boolean) {
        try {
            n = j.getInt("n"); target = j.getInt("target"); stake = j.optInt("stake", 1000)
            val nm = j.getJSONArray("names"); val sc = j.getJSONArray("score"); val ids = j.optJSONArray("ids")
            var k = 0
            if (handedOver && ids != null) for (i in 0 until n) if (ids.optString(i) == Prefs.devId()) k = i
            names = List(n) { nm.getString((it + k) % n) }
            val oldScore = IntArray(sides) { if (it < sc.length()) sc.getInt(it) else 0 }
            score = IntArray(sides) { oldScore[(it + k) % sides] }
            dealer = ((j.getInt("dealer") - k) % n + n) % n
            for (i in 0 until 4) { remote[i] = false; cidOf[i] = -1; idOf[i] = ""; ansQ[i].clear() }
            if (ids != null) for (i in 0 until n) idOf[i] = ids.optString((i + k) % n)
            idOf[0] = ""                                  // this phone is the host
            if (Prefs.name.isNotEmpty()) { val l = names.toMutableList(); l[0] = Prefs.name; names = l }
            role = "host"; me = 0; resuming = true; started = false
            showResumeLobby()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده خراب است."); net?.leave(); close() }
    }

    private fun showResumeLobby() {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("ادامهٔ بازی ذخیره‌شده"))
        v.addView(tv("بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند و بازی «" + (if (Prefs.name.isEmpty()) "میزبان" else Prefs.name) + "» را انتخاب کنند. وقتی آماده بودید «ادامه بازی» را بزنید؛ جای کسانی که نیامده‌اند ربات بازی می‌کند.", 15f))
        for (i in 1 until n) {
            val st = if (remote[i]) "وصل شد" else if (idOf[i].isNotEmpty()) "منتظر است" else "ربات"
            v.addView(tv(names[i] + " — " + st, 15f))
        }
        v.addView(mbtn("ادامه بازی") {
            resuming = false
            for (s in 1 until n) if (remote[s]) net?.send(cidOf[s], startMsg(s))
            lastSave = saveJson().toString()
            startGame()
            sendSync()
        })
        v.addView(mbtn("لغو") { net?.leave(); close() })
        setScreen("net", v)
    }

    /** the old host hands the game over to the phone [seat]: it loads the last saved state and the others reconnect to it */
    private fun xferTo(seat: Int) {
        val cid = cidOf[seat]
        if (cid < 0 || lastSave.isEmpty()) return
        net?.send(cid, JSONObject().put("t", "xfer").put("sv", lastSave))
        Sched.laterRaw(1200) { act.runOnUiThread { net?.leave(); close(false) } }
    }

    private fun exitHostAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.confirm("از بازی خارج می‌شوید؟", { net?.leave(); close() }); return }
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (s in seats) items.add(("میزبانی را به «" + names[s] + "» بدهم و خارج شوم (دست فعلی از نو پخش می‌شود)") to { xferTo(s) })
        items.add("بازی را ببندم (برای همه تمام می‌شود)" to { net?.leave(); close() })
        app.dlg.list("قبل از رفتن", items, "بستن")
    }

    fun onGuestDrop(cid: Int) {
        val s = cidOf.indexOf(cid)
        if (s < 1) return
        remote[s] = false; cidOf[s] = -1
        ansQ[s].offer("drop")
        if (resuming) { ui { showResumeLobby() }; return }
        if (started) say(names[s] + " قطع شد؛ ربات جایش بازی می‌کند تا برگردد.")
    }

    /** a phone that sat here before says hello again: it takes its seat back. true when it was one of ours */
    fun onGuestHello(cid: Int, id: String): Boolean {
        if ((!started && !resuming) || role != "host" || id.isEmpty()) return false
        for (s in 1 until n) if (idOf[s] == id) {
            remote[s] = true; cidOf[s] = cid
            if (resuming) { ui { showResumeLobby() }; return true }
            net?.send(cid, startMsg(s))
            say(names[s] + " به بازی برگشت.")
            sendStates()
            sendSync()
            return true
        }
        return false
    }

    fun onGuestMsg(cid: Int, m: JSONObject) {
        val s = cidOf.indexOf(cid)
        if (s >= 1 && m.optString("t") == "ans") ansQ[s].offer(m.optString("m"))
    }

    fun netNote(t: String) { localSay(t) }

    /** the connection to the host dropped during a game */
    fun showReconnect() {
        if (screen != "game" || role != "client") return
        val t = "اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید از بازی کنار هستید. در حال اتصال دوباره..."
        ui {
            ctl.removeAllViews()
            ctl.addView(tv(t, 14f, Color.WHITE))
            ctl.addView(app.dlg.btn("اتصال دوباره", false) { net?.reconnect() })
            ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
            ann(t)
        }
        myTurn = false
    }

    /** the host's messages, on the guest phone */
    fun onHostMsg(m: JSONObject) {
        when (m.optString("t")) {
            "start" -> {
                role = "client"; me = m.optInt("me", 1)
                if (screen != "game") { ui { stopGame(); logLines.clear(); lastMsg = ""; lastHandKey = ""; Spk.reset(); Sound.resetQueue(); buildGameView(); started = true } }
            }
            "st" -> {
                role = "client"
                if (screen != "game" || !started) { stopGame(); logLines.clear(); lastMsg = ""; lastHandKey = ""; Spk.reset(); Sound.resetQueue(); me = m.optInt("me", me); n = m.getInt("n"); buildGameView(); started = true }
                applySnap(m)
            }
            "say" -> localSay(m.optString("m"))
            "sync" -> { syncSv = m.optString("sv"); succSeat = m.optInt("succ", -1) }
            "snd" -> playSnd(m.optString("n"), m.optInt("dl", 0), m.optInt("who", -1))
            "mv" -> {
                val seat = m.getInt("seat"); val card = cardOf(m.getInt("c"))
                val a = m.getJSONArray("cap"); val cap = List(a.length()) { a.getInt(it) }
                ui { if (seat != me) flyPlay(seat, card) }
            }
            "cp" -> { val seat = m.getInt("seat"); val a = m.getJSONArray("idx"); val idx = List(a.length()) { a.getInt(it) }; ui { flyCapture(seat, idx) } }
            "lo" -> { val seat = m.getInt("seat"); ui { flyCapture(seat, (0 until tableV.childCount).toList()) } }
            "fin" -> {
                val won = m.optBoolean("w"); val d = m.optInt("d")
                Prefs.wallet = Prefs.wallet + d
                localSay(if (won) "بردید!" else "باختید!")
                Sched.post { val e = if (won) "fwin" else "flose"; Sound.game(e); faces(e) }
                localSay(chipText(d))
                myTurn = false
            }
            "xfer" -> {
                val nt = net ?: return
                nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
                stopGame(); started = false
                resumeHostGame(JSONObject(m.getString("sv")), true)
            }
            "end" -> { app.dlg.message(m.optString("m", "بازی تمام شد.")); net?.leave(); close() }
        }
    }

    private fun applySnap(m: JSONObject) {
        ui {
            me = m.optInt("me", me); n = m.getInt("n"); target = m.optInt("target", target); stake = m.optInt("stake", stake)
            val nm = m.getJSONArray("names"); names = List(nm.length()) { nm.getString(it) }
            val sc = m.getJSONArray("score"); score = IntArray(sides) { if (it < sc.length()) sc.getInt(it) else 0 }
            dealer = m.optInt("dealer"); turn = m.optInt("turn", -1); deckLeft = m.optInt("deck")
            val tb = m.getJSONArray("table"); table = ArrayList<Card>().also { l -> for (i in 0 until tb.length()) l.add(cardOf(tb.getInt(i))) }
            val cn = m.getJSONArray("cnt"); val hd = m.getJSONArray("hand")
            for (i in 0 until 4) hands[i] = if (i == me) ArrayList<Card>().also { l -> for (k in 0 until hd.length()) l.add(cardOf(hd.getInt(k))) }
                else ArrayList<Card>().also { l -> for (k in 0 until (if (i < cn.length()) cn.getInt(i) else 0)) l.add(Card(0, 2)) }
            val tk = m.getJSONArray("tk"); val sr = m.getJSONArray("surs")
            for (i in 0 until sides) { taken[i] = ArrayList<Card>().also { l -> for (k in 0 until tk.getInt(i)) l.add(Card(0, 2)) }; surs[i] = sr.getInt(i) }
            msg = m.optString("msg")
            val mt = m.optBoolean("mt")
            if (mt && !myTurn) { selHand = -1; selTbl.clear() }
            myTurn = mt
            render()
        }
    }

    private fun parseMove(seat: Int, a: String): Pair<Int, List<Int>>? {
        try {
            val p = a.indexOf('|')
            val ci = a.substring(0, p).toInt()
            val rest = a.substring(p + 1)
            val cap = if (rest.isEmpty()) emptyList() else rest.split(",").map { it.toInt() }
            if (ci !in hands[seat].indices) return null
            if (cap.isNotEmpty() && !Pasur.isValid(hands[seat][ci], ArrayList(table), cap.sorted())) return null
            if (cap.isEmpty() && Pasur.options(hands[seat][ci], ArrayList(table)).isNotEmpty()) return null      // a card that can capture may not be thrown
            return Pair(ci, cap)
        } catch (e: Exception) { return null }
    }

    private fun chipDelta(won: Boolean): Int {
        val d = when (n) { 4 -> Math.max(1, stake / 2); 3 -> if (won) stake * 2 else stake; else -> stake }
        return if (won) d else -d
    }

    private fun chipText(d: Int): String = "ژتون شما " + Cards.fa(Math.abs(d)) + (if (d >= 0) " اضافه شد" else " کم شد") + ". ژتون شما: " + Cards.fa(Prefs.wallet)

    // ------------------------------------------------------------------ animations

    private fun loc(v: View): IntArray { val a = IntArray(2); v.getLocationInWindow(a); return a }

    private fun cellOf(seat: Int): View? {
        val rel = (seat - me + n) % n
        if (rel == 0 || !::playersV.isInitialized) return null
        return if (rel - 1 < playersV.childCount) playersV.getChildAt(rel - 1) else null
    }

    /** a copy of a picture flies from one view to another and fades */
    private fun flyCopy(src: View, dst: View?, delay: Long, shrink: Boolean) {
        val d = (src as? ImageView)?.drawable ?: return
        val o = loc(ov); val a = loc(src)
        val iv = ImageView(act)
        iv.setImageDrawable(d.constantState?.newDrawable() ?: d)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val w = src.width; val h = src.height
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        iv.x = (a[0] - o[0]).toFloat(); iv.y = (a[1] - o[1]).toFloat()
        val tx: Float; val ty: Float
        if (dst != null) { val t = loc(dst); tx = t[0] - o[0] + (dst.width - w) / 2f; ty = t[1] - o[1] + (dst.height - h) / 2f }
        else { tx = (ov.width - w) / 2f; ty = ov.height - h * 1.6f }       // my own seat: the bottom of the screen
        iv.animate().x(tx).y(ty).alpha(if (shrink) 0f else 1f).scaleX(if (shrink) 0.6f else 1f).scaleY(if (shrink) 0.6f else 1f)
            .setStartDelay(Anim.ad(delay)).setDuration(Anim.ad(380L))
            .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** the captured table cards fly to the player who took them */
    private fun flyCapture(seat: Int, idx: List<Int>) {
        val dst = cellOf(seat)
        var k = 0
        for (i in idx) {
            if (i >= tableV.childCount) continue
            val v = tableV.getChildAt(i)
            flyCopy(v, dst, 70L * k, true)
            v.visibility = View.INVISIBLE
            k++
        }
    }

    /** the played card flies from the player's seat to the table */
    private fun flyPlay(seat: Int, c: Card) {
        val dstView = tableV
        val o = loc(ov); val t = loc(dstView)
        val w = Px.dp(46); val h = Px.dp(64)
        val iv = ImageView(act)
        val bmp = Assets.bitmap(act, Assets.cardPath(c)) ?: return
        iv.setImageBitmap(bmp)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp)
        val src = cellOf(seat)
        val sx: Float; val sy: Float
        if (src != null) { val a = loc(src); sx = (a[0] - o[0] + (src.width - w) / 2f); sy = (a[1] - o[1] + (src.height - h) / 2f) }
        else { val a = loc(handV); sx = (a[0] - o[0] + handV.width / 2f - w / 2f); sy = (a[1] - o[1]).toFloat() }
        iv.x = sx; iv.y = sy
        iv.animate().x(t[0] - o[0] + dstView.width / 2f - w / 2f).y(t[1] - o[1] + dstView.height / 2f - h / 2f)
            .setDuration(Anim.ad(340L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** when (in seconds) card number [i] of a deal lands: the timing of Hokm's deal recordings (four players: the 20-card one, two players: the 10-card one), after the last of them the same rhythm goes on */
    private fun dealSec(i: Int): Double {
        val T = Deal.DLT["a"]?.T ?: return 0.27 + 0.535 * i      // the recording of the four-player deal (deal4a) for every number of players
        if (i < T.size) return T[i]
        val gap = (T[T.size - 1] - T[0]) / (T.size - 1)
        return T[T.size - 1] + gap * (i - T.size + 1)
    }

    /** raw time (ms) the dealing of [cards] cards takes: the same pace as the deal of Hokm */
    private fun dealMs(cards: Int): Long = (dealSec(Math.max(0, cards - 1)) * 1000 * (if (Sound.on) 1.0 else 0.35)).toLong() + 340L + 150L

    /**
     * Cards fly one after the other from the middle of the screen: [per] cards to the table (toTable) or [per] cards to each of
     * [seats]. They are dealt at the pace of Hokm's deal and with Hokm's recorded deal sound of four players (deal4a, for two, three and four
     * players alike): every card lands where the recording has its card, and the recording is stopped right after the last card
     * of this deal (Hokm's recordings hold more cards than the four of the table or the four of each hand).
     */
    private fun dealFx(seats: List<Int>, per: Int, toTable: Boolean, recorded: Boolean = true) {
        ui {
            try {
                val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back))
                val o = loc(ov)
                val w = Px.dp(40); val h = Px.dp(56)
                val sx = ov.width / 2f - w / 2f; val sy = ov.height * 0.3f - h / 2f
                val list = ArrayList<View>()
                if (toTable) { for (k in 0 until per) list.add(tableV) }
                else for (r in 0 until per) for (seat in seats) list.add(cellOf(seat) ?: handV)
                val land = Anim.ad(340L)
                val f = if (Sound.on) 1.0 else 0.35
                var i = 0
                val part = "a"
                val rec = Deal.DLT[part]
                val g = Sched.GEN
                if (recorded && rec != null && Sound.on) {
                    Sched.laterRaw(Deal.lead()) { if (g == Sched.GEN) Sound.playDeal(rec.f, g) }
                }
                for (dst in list) {
                    val la = Anim.ad(dealSec(i) * 1000 * f) + Deal.lead(); i++       // when this card lands
                    val d = Math.max(0L, la - land)
                    if (!recorded) Sched.later(Math.max(0L, la - Sound.CSO.toLong())) { Sound.cardSnd() }
                    if (bmp == null) continue
                    val iv = ImageView(act); iv.setImageBitmap(bmp)
                    iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    iv.alpha = 0f
                    val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
                    ov.addView(iv, lp)
                    iv.x = sx; iv.y = sy
                    val a = loc(dst)
                    iv.animate().alpha(1f).x(a[0] - o[0] + dst.width / 2f - w / 2f).y(a[1] - o[1] + dst.height / 2f - h / 2f)
                        .setStartDelay(d).setDuration(land).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
                }
                // the recording is cut after the last card of this deal; whatever sounds next (the first card, a shuffle, the voice)
                // waits until then
                val endAt = Anim.ad(dealSec(Math.max(0, list.size - 1)) * 1000 * f).toLong() + Deal.lead() + 280L
                if (recorded && Sound.on) Sched.laterRaw(endAt) { if (g == Sched.GEN) Sound.stopDeal() }
                Sound.reserve(Sched.now() + endAt)
            } catch (e: Exception) { }
        }
    }


    // ------------------------------------------------------------------ menu inside the game

    private fun applyBg() {
        val bmp = if (Prefs.bg > 0) Assets.bitmap(act, Assets.bgPath(Prefs.bg)) else null
        gameV.background = if (bmp != null) CoverDrawable(bmp, 0x1F000000) else Px.rounded(Px.FELT, 16)
    }

    private fun gameMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (role != "client") items.add("بازی جدید" to { askNew() })
        items.add("تغییر نام" to { renameAsk() })
        if (role == "host") {
            if ((1 until n).any { !remote[it] }) items.add("افزودن بازیکن" to { addAsk() })
            if ((1 until n).any { remote[it] }) {
                items.add("حذف بازیکن" to { kickAsk() })
                items.add("انتقال میزبانی" to { xferAsk() })
            }
        }
        if (role != "client") items.add("ذخیرهٔ بازی" to { manualSave() })
        items.add(("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) to { app.a11yToggle(); if (Prefs.a11y) localSay("دسترس‌پذیر بودن برنامه روشن شد."); ui { render() } })
        items.add("سرعت انیمیشن" to { app.animSpeedAsk() })
        items.add("تنظیمات صدا" to { app.dlg.sound() })
        items.add("تنظیمات تصویر زمینه" to { app.dlg.cards("bg") { applyBg() } })
        items.add("تنظیمات پشت کارت" to { app.dlg.cards("back") { render() } })
        items.add("راهنما" to { guideDialog(app.dlg) })
        items.add("خروج از بازی" to {
            if (role == "host") exitHostAsk()
            else app.dlg.confirm((if (role == "solo") "از بازی خارج می‌شوید؟ بازی تا پایان دست قبل ذخیره شده است." else "از بازی خارج می‌شوید؟"), { net?.leave(); close() })
        })
        app.dlg.list("گزینه‌های بیشتر", items)
    }

    /** a new game: robots only = back to the setup; with other phones = the same table starts from zero */
    private fun askNew() {
        app.dlg.confirm("بازی جدید شروع شود؟ بازی فعلی از بین می‌رود.", { newGameNow() })
    }

    private fun newGameNow() {
        stopGame()
        if (role == "solo") { try { SavesCb.del("auto") } catch (e: Exception) { }; close(); app.newGamePage() }
        else if (role == "host") {
            score = IntArray(sides); dealer = (Math.random() * n).toInt()
            lastSave = saveJson().toString()
            startGame()
            sendSync()
        }
    }

    /** a phone that is connected to the running game but has no seat yet takes the seat of a robot */
    fun hasSeat(cid: Int): Boolean = cidOf.indexOf(cid) >= 0

    private fun addAsk() {
        val nt = net ?: return
        val seats = (1 until n).filter { !remote[it] }
        if (seats.isEmpty()) { app.dlg.message("جای خالی نیست."); return }
        val w = nt.waiting()
        if (w.isEmpty()) { app.dlg.message("گوشی منتظری نیست. بازیکن باید «به بازی دیگری می‌پیوندم» را بزند و بازی شما را انتخاب کند."); return }
        fun pickSeat(cid: Int, nm: String) {
            if (seats.size == 1) { addPlayer(cid, seats[0]); return }
            app.dlg.list("«" + nm + "» جای کدام بازیکن یا ربات بنشیند؟", seats.map { x -> names[x] to { addPlayer(cid, x) } }, "بستن")
        }
        if (w.size == 1) pickSeat(w[0].first, w[0].second)
        else app.dlg.list("کدام گوشی اضافه شود؟", w.map { (cid, nm) -> nm to { pickSeat(cid, nm) } }, "بستن")
    }

    private fun addPlayer(cid: Int, seat: Int) {
        val info = net?.peerInfo(cid) ?: return
        if (remote[seat]) return
        if (info.wallet < need(stake, n)) { app.dlg.message("«" + info.name + "» ژتون کافی ندارد (دست‌کم " + Cards.fa(need(stake, n)) + " لازم است) و نمی‌تواند وارد بازی شود."); return }
        remote[seat] = true; cidOf[seat] = cid; idOf[seat] = info.id
        val l = names.toMutableList(); l[seat] = info.name; names = l
        net?.send(cid, startMsg(seat))
        say(info.name + " به بازی پیوست.")
        sendStates(); sendSync()
    }

    private fun kickAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { s: Int -> app.dlg.confirm("«" + names[s] + "» از بازی حذف شود؟ ربات جای او بازی می‌کند.", { kickPlayer(s) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("کدام بازیکن حذف شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }

    private fun kickPlayer(s: Int) {
        if (!remote[s]) return
        net?.send(cidOf[s], JSONObject().put("t", "end").put("m", "میزبان شما را از بازی حذف کرد."))
        remote[s] = false; cidOf[s] = -1; idOf[s] = ""
        ansQ[s].offer("drop")
        say(names[s] + " از بازی حذف شد و ربات جای او آمد.")
        sendSync()
    }

    private fun xferAsk() {
        val seats = (1 until n).filter { remote[it] }
        if (seats.isEmpty()) { app.dlg.message("بازیکن دیگری در بازی نیست."); return }
        val q = { s: Int -> app.dlg.confirm("میزبانی به «" + names[s] + "» داده شود و شما از بازی خارج شوید؟ دست فعلی از نو پخش می‌شود.", { xferTo(s) }) }
        if (seats.size == 1) q(seats[0])
        else app.dlg.list("میزبانی به چه کسی داده شود؟", seats.map { x -> names[x] to { q(x) } }, "بستن")
    }

    private fun renameAsk() {
        app.dlg.nameAsk(true) { v ->
            val nm = v.trim()
            if (nm.isNotEmpty()) { Prefs.name = nm; val l = names.toMutableList(); l[me] = nm; names = l; draw() }
        }
    }

    // ------------------------------------------------------------------ the game (worker thread)

    /** the points reach the target with one side alone at the top: the game ends with this winner */
    private class PerStop(val side: Int, val pts: Int) : RuntimeException()

    /** true while the game goes on because the points were tied at the target or above: the game is not counted again until the hand is over */
    private var tieHold = false

    /**
     * There is no button "پر شدم": after every move the points of the captured cards and the surs (with the score of the earlier
     * hands) are counted, and when one side is alone at the top with at least the target, the game ends by itself and that side wins
     * (what saying "per shodam" does in pagat). When the best sides are tied at the target or above the game goes on, and (as in pagat)
     * it is not counted again before the end of the hand. The last move of a hand is not counted here: the hand is counted at its end.
     */
    private fun autoPer() {
        if (tieHold) return
        if (deckLeft == 0 && (0 until n).all { hands[it].isEmpty() }) return
        val hp = handPoints(false)
        val tot = IntArray(sides) { score[it] + hp[it] }
        var best = -1; var bi = -1; var tie = false
        for (s in 0 until sides) { if (tot[s] > best) { best = tot[s]; bi = s; tie = false } else if (tot[s] == best) tie = true }
        if (best < target) return
        if (tie) { say("امتیازها به " + Cards.fa(target) + " رسید و بالاترین امتیاز برابر است. بازی تا پایان این دست ادامه دارد."); tieHold = true; return }
        throw PerStop(bi, best)
    }

    private fun loop() {
        tieHold = false
        while (alive) {
            var stopSide = -1; var stopPts = 0
            try { playHand() } catch (e: PerStop) { stopSide = e.side; stopPts = e.pts }
            if (!alive) return
            if (stopSide >= 0) { finishGame(stopSide, stopPts); return }
            // somebody reached the target?
            var best = -1; var bi = -1; var tie = false
            for (s in 0 until sides) { if (score[s] > best) { best = score[s]; bi = s; tie = false } else if (score[s] == best) tie = true }
            saveAuto()
            tieHold = best >= target && tie
            if (best >= target && !tie) { finishGame(bi, best); return }
            dealer = (dealer + 1) % n
            pace(1200)
        }
    }

    /** the side [bi] has won the game with [best] points: the chips, the sounds and the button for a new game */
    private fun finishGame(bi: Int, best: Int) {
        val who = if (n == 4) "تیم " + teamName(bi) else names[bi]
        val endTxt = who + " برنده شد با " + Cards.fa(best) + " امتیاز."
        say(endTxt)
        for (seat in 0 until n) {
            val won = bi == sideOf(seat)
            val d = chipDelta(won)
            if (seat == me) {
                Prefs.wallet = Prefs.wallet + d
                localSay(if (won) "بردید!" else "باختید!")
                Sched.post { val e = if (won) "fwin" else "flose"; Sound.game(e); faces(e) }
                localSay(chipText(d))
            } else if (isRemote(seat)) {
                net?.send(cidOf[seat], JSONObject().put("t", "fin").put("w", won).put("d", d))
            }
        }
        try { SavesCb.del("auto"); SavesCb.del("autoM") } catch (e: Exception) { }
        if (role != "client") {      // as in Hokm: when the sounds are done a "بازی جدید" button appears and gets the focus
            Sound.afterSnd {
                ui {
                    over = true; myTurn = false; msg = if (Prefs.a11y) endTxt else ""
                    render()
                    if (Prefs.a11y) Sched.laterRaw(idle() + 50L) { ui { try { ctl.getChildAt(0)?.performAccessibilityAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null) } catch (e: Exception) { } } }
                }
            }
        }
    }

    private fun saveAuto() {
        try {
            lastSave = saveJson().toString()
            if (role == "solo") SavesCb.put("auto", false, lastSave) else if (role == "host") { SavesCb.put("autoM", true, lastSave); sendSync() }
        } catch (e: Exception) { }
    }

    /** every guest gets the last save; the first guest takes over as host if the host disappears */
    private fun sendSync() {
        if (role != "host" || lastSave.isEmpty()) return
        val succ = (1 until n).firstOrNull { remote[it] } ?: return
        sendAll(JSONObject().put("t", "sync").put("sv", lastSave).put("succ", succ))
    }

    /** the host dropped out without handing over: this phone (the first guest) hosts from the last save */
    fun adoptFromSync() {
        val nt = net
        if (nt == null || syncSv.isEmpty()) { showReconnect(); return }
        try {
            nt.becomeHost(nt.curRoom(), if (Prefs.name.isEmpty()) "میزبان" else Prefs.name)
            stopGame(); started = false
            resumeHostGame(JSONObject(syncSv), true)
        } catch (e: Exception) { showReconnect() }
    }

    private fun playHand() {
        val deck = Pasur.newDeck()
        for (i in 0 until 4) { hands[i] = ArrayList(); taken[i] = ArrayList(); surs[i] = 0 }
        table = ArrayList(); lastTaker = -1
        // four cards to the table (pagat: more than one jack, more than two queens or more than two kings: all the cards are gathered,
        // shuffled and dealt again; a single jack goes to the bottom of the undealt cards and the top card takes its place).
        // Everything is shown: the cards fly to the table with their sounds, a table that breaks the rule stays in sight for a moment,
        // then it is gathered (shuffle sound and picture) and dealt again; a lone jack leaves the table and the new card flies in.
        fun bad(t: List<Card>) = t.count { it.r == 11 } > 1 || t.count { it.r == 12 } > 2 || t.count { it.r == 13 } > 2
        say(names[dealer] + " کارت‌ها را پخش می‌کند.")
        waitSpeech()          // the voice finishes first: the sounds of the shuffle and of the deal do not run over it
        snd("shuffle")
        pace(700)
        while (alive) {
            val t = ArrayList<Card>()
            for (i in 0 until 4) t.add(deck.removeAt(deck.size - 1))
            deckLeft = deck.size
            table = ArrayList(t)
            snd("dealT"); pace(dealMs(4))         // the four cards go to the table, each with its sound
            draw(); pace(300)
            say("روی میز: " + t.joinToString("، ") { Cards.cname(it) })
            if (bad(t)) {
                waitSpeech(); pace(900)
                table = ArrayList(); deck.addAll(t); Cards.shuf(deck); deckLeft = deck.size
                draw(); snd("shuffle"); pace(700)
                continue
            }
            if (t.count { it.r == 11 } == 1) {
                waitSpeech(); pace(900)
                val jc = t.first { it.r == 11 }
                t.remove(jc); deck.add(0, jc)
                table = ArrayList(t); deckLeft = deck.size
                draw(); snd("card"); pace(600)       // the jack leaves the table
                val nc = deck.removeAt(deck.size - 1)
                t.add(nc); deckLeft = deck.size
                table = ArrayList(t)
                snd("dealOne"); pace(dealMs(1))      // the new card flies in
                draw(); pace(300)
                say("کارت جدید: " + Cards.cname(nc))
                // the new card may break the rule again (a second jack, or too many queens or kings): then the table is dealt again
                if (bad(t) || t.count { it.r == 11 } > 0) {
                        waitSpeech(); pace(900)
                    table = ArrayList(); deck.addAll(t); Cards.shuf(deck); deckLeft = deck.size
                    draw(); snd("shuffle"); pace(700)
                    continue
                }
            }
            table = t
            break
        }
        if (!alive) return
        deckLeft = deck.size

        while (deck.isNotEmpty() && alive) {
            for (s in 0 until n) { val p = (dealer + 1 + s) % n; for (i in 0 until 4) hands[p].add(deck.removeAt(deck.size - 1)) }
            deckLeft = deck.size
            snd("dealH"); pace(dealMs(4 * n))     // four cards to every player, each with its sound
            draw(); pace(300)
            for (t in 0 until 4 * n) {
                if (!alive) return
                val seat = (dealer + 1 + t) % n
                val last = deck.isEmpty() && (0 until n).sumOf { hands[it].size } == 1
                playTurn(seat, last)
            }
        }
        // what is left on the table goes to the last player who took cards
        if (table.isNotEmpty() && lastTaker >= 0) {
            say("برگ‌های مانده روی میز به " + names[lastTaker] + " می‌رسد.")
            val lt = lastTaker
            if (role == "host") sendAll(JSONObject().put("t", "lo").put("seat", lt))
            uiWait { flyCapture(lt, (0 until tableV.childCount).toList()) }
            snd("trick", lt)
            taken[sideOf(lastTaker)].addAll(table)
            table = ArrayList()
            pace(600); draw(); pace(700)
        }
        scoreHand()
    }

    private fun playTurn(seat: Int, last: Boolean) {
        turn = seat
        val hand = hands[seat]
        if (hand.isEmpty()) return
        var ci: Int; var cap: List<Int>
        if (seat == me) {
            msg = "نوبت شماست"
            selHand = -1; selTbl.clear()
            moveQ.clear()
            myTurn = true
            draw()
            ui { focusHand() }
            val m = moveQ.take()
            val p = m.indexOf('|')
            ci = m.substring(0, p).toInt()
            val rest = m.substring(p + 1)
            cap = if (rest.isEmpty()) emptyList() else rest.split(",").map { it.toInt() }
        } else if (isRemote(seat)) {      // a person on another phone: wait for his move
            msg = "نوبت " + names[seat]
            var mv: Pair<Int, List<Int>>? = null
            while (mv == null && alive) {
                ansQ[seat].clear(); waitSeat = seat; draw()
                val a = ansQ[seat].take()
                if (a == "drop") break
                mv = parseMove(seat, a)
            }
            waitSeat = -1
            if (mv == null) { draw(); pace(700); mv = botMove(seat, last) }      // he left: a robot plays his turn
            ci = mv.first; cap = mv.second
        } else {
            msg = "نوبت " + names[seat]
            draw(); pace(700)
            val mv = botMove(seat, last)
            ci = mv.first; cap = mv.second
        }
        applyMove(seat, ci, cap, last)
        autoPer()
    }

    private fun applyMove(seat: Int, ci: Int, cap: List<Int>, last: Boolean) {
        val card = hands[seat][ci]
        val tableNow = ArrayList(table)
        val capCards = cap.map { tableNow[it] }
        if (role == "host") sendAll(JSONObject().put("t", "mv").put("seat", seat).put("c", Cards.idc(card)).put("cap", JSONArray(cap)))
        // 1) the card is played and lands on the table, with its sound
        uiWait { if (seat != me) flyPlay(seat, card) }
        snd("card")
        hands[seat].removeAt(ci)
        val onTable = ArrayList(tableNow); onTable.add(card); table = onTable
        if (cap.isEmpty()) say(names[seat] + " " + Cards.cname(card) + " را روی میز انداخت.")
        else say(names[seat] + " با " + Cards.cname(card) + " این برگ‌ها را برداشت: " + capCards.joinToString("، ") { Cards.cname(it) })
        turn = -1
        draw()
        if (cap.isNotEmpty()) {
            // 2) as in Hokm: the cards stay on the table for a second, then they are gathered with the "trick" sound
            pace(1000)
            val idx = ArrayList(cap); idx.add(tableNow.size)
            if (role == "host") sendAll(JSONObject().put("t", "cp").put("seat", seat).put("idx", JSONArray(idx)))
            uiWait { flyCapture(seat, idx) }
            snd("trick", seat)
            val t = ArrayList<Card>()
            for (i in tableNow.indices) if (!cap.contains(i)) t.add(tableNow[i])
            table = t
            taken[sideOf(seat)].addAll(capCards); taken[sideOf(seat)].add(card)
            lastTaker = seat
            pace(380L + 70L * idx.size + 100L)
            if (table.isEmpty()) {
                val k = surKind(sideOf(seat), card)
                if (k == 1) {
                    surs[sideOf(seat)]++
                    say("سور! " + names[seat])
                    snd("win", seat)
                } else if (k == 2) {
                    val opp = oppWithSur(sideOf(seat))
                    if (opp >= 0) surs[opp]--
                    say("سور " + names[seat] + " یکی از سورهای حریف را باطل کرد.")
                    snd("win", seat)
                }
            }
            draw()
        }
        say("روی میز: " + (if (table.isEmpty()) "هیچ برگی نیست" else table.joinToString("، ") { Cards.cname(it) }))
        pace(600)
    }

    private fun oppWithSur(side: Int): Int = (0 until sides).firstOrNull { it != side && surs[it] > 0 } ?: -1

    /**
     * What emptying the table with [card] is worth (rules: CbRules): 0 nothing, 1 a sur that counts, 2 a sur that cancels a sur of the
     * opponents. Never with a jack, never for a side that has reached the limit of points, and in the last deal (when the whole pack
     * has been dealt) only the cancelling of a sur of the opponents, if that option is on.
     */
    private fun surKind(side: Int, card: Card): Int {
        if (card.r == 11) return 0
        if (CbRules.surLimit > 0 && score[side] >= CbRules.surLimit) return 0
        val opp = if (CbRules.cancel) oppWithSur(side) else -1
        if (deckLeft > 0) return if (opp >= 0) 2 else 1
        return if (CbRules.cancel && CbRules.lastCancel && opp >= 0) 2 else 0
    }

    /** the points the captured cards and the surs of every side are worth now ([final]: at the end of a hand; during a hand only the points that cannot be lost are counted) */
    private fun handPoints(final: Boolean = true): IntArray {
        val pts = IntArray(sides)
        val cl = IntArray(sides)
        for (s in 0 until sides) {            // the cards are kept per side (a team shares them)
            pts[s] = Pasur.cardPoints(taken[s])
            cl[s] = Pasur.clubs(taken[s])
        }
        var topC = 0; var topS = -1; var tieC = false
        for (s in 0 until sides) { if (cl[s] > topC) { topC = cl[s]; topS = s; tieC = false } else if (cl[s] == topC) tieC = true }
        if (topC >= 7 && !tieC && topS >= 0) pts[topS] += 7
        else if (n == 3 && final) {
            // three players: when nobody has seven clubs the one with the most counts as having them; when two are equal the third one does
            if (!tieC && topS >= 0) pts[topS] += 7
            else if (tieC) {
                val tied = (0 until sides).filter { cl[it] == topC }
                if (tied.size == 2) pts[(0 until sides).first { it !in tied }] += 7
            }
        }
        for (s in 0 until sides) pts[s] += CbRules.surValue * surs[s]
        return pts
    }

    private fun scoreHand() {
        val pts = handPoints()
        for (s in 0 until sides) score[s] += pts[s]
        val sb = StringBuilder("پایان دست. امتیاز این دست: ")
        for (s in 0 until sides) { if (s > 0) sb.append("، "); sb.append((if (n == 4) teamName(s) else names[s]) + " ").append(Cards.fa(pts[s])) }
        say(sb.toString())
        draw(); pace(1200)
    }

    // ------------------------------------------------------------------ the robots

    /** how much a capture is worth to a robot (in points) */
    private fun gain(card: Card, cap: List<Card>, side: Int, emptied: Boolean, last: Boolean): Double {
        var g = 0.0
        val all = ArrayList(cap); all.add(card)
        for (c in all) {
            if (c.r == 14) g += 1.0
            else if (c.r == 11) g += 1.0
            else if (c.s == 3 && c.r == 2) g += 2.0
            else if (c.s == 2 && c.r == 10) g += 3.0
            if (c.s == 3) g += 0.7 else g += 0.15
        }
        if (emptied && surKind(side, card) != 0) g += 5.0
        return g
    }

    /** cost of leaving a card on the table (it may be taken by the opponents) */
    private fun cost(c: Card): Double {
        var k = 0.1
        if (c.r == 11) k += 3.0
        if (c.s == 2 && c.r == 10) k += 4.0
        if (c.s == 3 && c.r == 2) k += 3.0
        if (c.r == 14) k += 1.2
        if (c.s == 3) k += 0.6
        return k
    }

    private fun botMove(seat: Int, last: Boolean): Pair<Int, List<Int>> {
        val hand = hands[seat]
        val tb = ArrayList(table)
        val side = sideOf(seat)
        var bestScore = -1e9; var bi = 0; var bc: List<Int> = emptyList()
        for ((i, c) in hand.withIndex()) {
            val opts = Pasur.options(c, tb)
            for (o in opts) {
                val cap = o.map { tb[it] }
                val emptied = o.size == tb.size
                val g = gain(c, cap, side, emptied, last) + Math.random() * 0.05
                if (g > bestScore) { bestScore = g; bi = i; bc = o }
            }
            if (opts.isEmpty()) {
                val g = -cost(c) + Math.random() * 0.05
                if (g > bestScore) { bestScore = g; bi = i; bc = emptyList() }
            }
        }
        // if every card could capture, a capture was chosen above; otherwise the cheapest throw was
        return Pair(bi, bc)
    }

    companion object {
        /** the guide as a list of topics (each opens its own text) */
        fun guideDialog(dlg: Dialogs) {
            dlg.list("راهنمای بازی", TOPICS.map { t -> t.first to { dlg.message(t.first + "\n\n" + t.second) } }, "بستن")
        }

        val TOPICS = listOf(
            "پخش و بازی" to "دستهٔ ۵۲ برگی. چهار برگ رو به میز می‌آید و به هر بازیکن چهار برگ داده می‌شود. اگر روی میز بیش از یک سرباز، یا بیش از دو بی‌بی یا دو شاه باشد، دوباره پخش می‌شود. اگر فقط یک سرباز باشد، آن را به دسته برمی‌گردانند و برگ دیگری جایش می‌گذارند. هر بازیکن در نوبتش یک برگ از دستش می‌اندازد. وقتی همه برگ‌هایشان تمام شد، دوباره چهار برگ به هر بازیکن (نه به میز) داده می‌شود تا دسته تمام شود.",
            "برداشتن برگ‌ها" to "شاه فقط شاه را برمی‌دارد و بی‌بی فقط بی‌بی را. سرباز همهٔ برگ‌های میز را برمی‌دارد، به‌جز شاه و بی‌بی. اگر میز خالی باشد یا فقط شاه و بی‌بی داشته باشد، سرباز چیزی برنمی‌دارد و روی میز می‌ماند. آس و ۲ تا ۱۰ برگ‌هایی را برمی‌دارند که مجموعشان با آن برگ ۱۱ شود (آس ۱ حساب می‌شود). مثلاً ۴ می‌تواند ۷ را بردارد، یا ۳ و ۴ را. چند گروه را می‌شود با هم برداشت. اجباری نیست که برگی که می‌تواند بردارد را بیندازید؛ می‌توانید برگ دیگری بیندازید. ولی اگر برگی را انداختید که می‌تواند برگی بردارد، باید برداشت کنید. اگر چند برداشتن ممکن باشد، خودتان انتخاب می‌کنید.",
            "سور" to "اگر با برگی غیر از سرباز همهٔ برگ‌های میز را برداشته و میز را خالی کنید، یک سور می‌گیرید، ۵ امتیاز (در قوانین بازی می‌توانید ۱۰ امتیاز انتخاب کنید). اگر حریف سور داشته باشد، سور شما یکی از سورهای او را باطل می‌کند و برای شما چیزی حساب نمی‌شود، پس همیشه فقط یک طرف سور نگه می‌دارد. سور حساب نمی‌شود وقتی با سرباز میز را خالی کنید، در دست آخر (بعد از اینکه همهٔ برگ‌ها پخش شده)، و وقتی ۵۰ امتیاز یا بیشتر دارید. این شرط‌ها را هنگام شروع بازی در بخش قوانین می‌توانید تغییر دهید.",
            "امتیازها" to "بیشترین خاج: ۷ امتیاز. ده خشت: ۳. دوی خاج: ۲. هر آس: ۱. هر سرباز: ۱. هر سور: ۵. جمع امتیازهای یک دست، بدون سور، ۲۰ است. در بازی سه نفره اگر دو نفر تعداد خاجشان برابر باشد، نفر سوم ۷ امتیاز خاج را می‌گیرد، حتی اگر خاج کمتری داشته باشد. برگ‌های مانده روی میز در پایان دست به آخرین کسی می‌رسد که برگ برداشته. بازی تا ۶۲ امتیاز یا بیشتر ادامه دارد (در تنظیمات می‌توانید ۶۱ یا ۱۰۰ انتخاب کنید)؛ اگر برابر شدند ادامه پیدا می‌کند.",
            "پایان خودکار بازی" to "دکمهٔ «پر شدم» ندارد. بعد از هر حرکت، امتیاز برگ‌های برداشته‌شده و سورها با امتیاز دست‌های قبل شمرده می‌شود. اگر یک نفر یا یک تیم به‌تنهایی بالاتر از همه باشد و به امتیاز برد رسیده باشد، بازی همان‌جا تمام می‌شود و او برنده اعلام می‌شود. اگر بالاترین امتیاز برابر باشد یا هیچ‌کس به امتیاز برد نرسیده باشد، بازی ادامه پیدا می‌کند و در حالت برابری تا پایان همان دست دوباره شمرده نمی‌شود.",
            "کار با صفحه" to "برگی را از دستتان انتخاب کنید. اگر فقط یک برداشتن ممکن باشد، خودش انتخاب می‌شود. برای برداشتن چند برگ، آن‌ها را روی میز لمس کنید و «بردار» را بزنید. برای انداختن، انتخاب میز را خالی کنید و «بینداز روی میز» را بزنید."
        )
    }
}
