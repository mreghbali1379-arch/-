package com.example.hokm

/** a phone that is connected to the lobby of a game (kept when the lobby changes to another game) */
class HandPeer(@JvmField val cid: Int, @JvmField val name: String, @JvmField val addr: String)

/** the three games of the app: "hokm", "21" and "cb" (Chahar Barg / Pasur) */
object Kinds {
    val ids = listOf("hokm", "21", "cb")
    val names = listOf("حکم", "بیست‌ویک", "چهار برگ")
    fun index(k: String): Int = Math.max(0, ids.indexOf(k))
    fun name(k: String): String = names[index(k)]
}
