package com.example.hokm

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/**
 * Persistent settings and saved games (replaces the page's localStorage; same keys and meanings).
 */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("hokm", Context.MODE_PRIVATE)
    }

    private fun get(k: String): String? = try { sp.getString(k, null) } catch (e: Exception) { null }
    private fun put(k: String, v: String): Boolean = try { sp.edit().putString(k, v).apply(); true } catch (e: Exception) { false }

    // ---- accessibility / music / volumes ----
    /** screen-reader announcements; on unless explicitly '0' */
    var a11y: Boolean
        get() = get("hokmA11y") != "0"
        set(v) { put("hokmA11y", if (v) "1" else "0") }

    /** the screen reader moves to the card / button by itself (on unless explicitly '0'); off = the app never moves the focus */
    var autoFocus: Boolean
        get() = get("hokmAutoFocus") != "0"
        set(v) { put("hokmAutoFocus", if (v) "1" else "0") }

    /** the sound effects switch (the key keeps its old name "hokmMusic" so an old choice stays) */
    var music: Boolean
        get() = get("hokmMusic") != "0"
        set(v) { put("hokmMusic", if (v) "1" else "0") }

    /** the background sound (music) switch; until it is chosen it follows the old single switch */
    var bgm: Boolean
        get() { val b = get("hokmBgm"); return if (b != null) b != "0" else get("hokmMusic") != "0" }
        set(v) { put("hokmBgm", if (v) "1" else "0") }

    /** music volume 0..1 (default 0.5) */
    var volM: Double
        get() { val m = get("hokmVolM")?.toDoubleOrNull(); return if (m != null && m >= 0 && m <= 1) m else 0.5 }
        set(v) { put("hokmVolM", v.toString()) }

    /** effects volume 0..1 (default 1) */
    var volE: Double
        get() { val e = get("hokmVolE")?.toDoubleOrNull(); return if (e != null && e >= 0 && e <= 1) e else 1.0 }
        set(v) { put("hokmVolE", v.toString()) }

    // ---- look ----
    /** card back design 1..35 (default 25) */
    var back: Int
        get() { val b = get("hokmBack")?.toIntOrNull(); return if (b != null && b in 1..35) b else 25 }
        set(v) { put("hokmBack", v.toString()) }

    /** table background: 0 plain, 1..4 rug (default 2) */
    var bg: Int
        get() { val g = get("hokmBg")?.toIntOrNull(); return if (g != null && g in 0..4) g else 2 }
        set(v) { put("hokmBg", v.toString()) }

    /** animation speed: "slow" | "norm" | "fast" */
    var anim: String
        get() { val v = get("hokmAnim"); return if (v == "slow" || v == "fast") v else "norm" }
        set(v) { put("hokmAnim", v) }

    /** list of saved 21 games (JSON array, see Saves) */
    /** list of saved Chahar Barg games (JSON array, see SavesCb) */
    var cblist: String
        get() = get("hokmCBlist") ?: ""
        set(v) { put("hokmCBlist", v) }

    var b21list: String
        get() = get("hokmB21list") ?: ""
        set(v) { put("hokmB21list", v) }

    /** the player's money in the 21 game: everybody starts with 10 000 and keeps what he wins */
    var wallet: Int
        get() = (get("hokmWallet") ?: "").toIntOrNull() ?: 10000
        set(v) { put("hokmWallet", Math.max(0, v).toString()) }

    /** saved multi-phone 21 game (JSON) or "" */
    var b21m: String
        get() = get("hokmB21m") ?: ""
        set(v) { put("hokmB21m", v) }

    /** saved 21 game (JSON) or "" */
    var b21: String
        get() = get("hokmB21") ?: ""
        set(v) { put("hokmB21", v) }

    // ---- player ----
    var name: String
        get() = (get("hokmName") ?: "").trim()
        set(v) { put("hokmName", v) }

    /** 'f' | 'm' | '' */
    var gender: String
        get() { val v = get("hokmGender") ?: ""; return if (v == "f" || v == "m") v else "" }
        set(v) { put("hokmGender", v) }

    /** "bt" | "lan" | "direct" */
    var net: String
        get() { val v = get("hokmNet"); return if (v == "lan" || v == "direct") v else "bt" }
        set(v) { put("hokmNet", v) }

    /** stable id of this phone */
    fun devId(): String {
        var v = get("hokmDev") ?: ""
        if (v.isEmpty()) {
            v = java.lang.Long.toString(System.currentTimeMillis(), 36) +
                java.lang.Long.toString((Math.random() * 2821109907456.0).toLong(), 36)
            put("hokmDev", v)
        }
        return v
    }

    // ---- saved games (JSON arrays, the page stored them as strings) ----
    private fun loadArr(k: String): JSONArray = try { JSONArray(get(k) ?: "[]") } catch (e: Exception) { JSONArray() }

    /** saved games against the bots */
    fun loadSolo(): JSONArray = loadArr("hokmSolo")
    fun putSolo(a: JSONArray): Boolean = put("hokmSolo", a.toString())

    /** saved multi-phone games (host side) */
    fun loadSaves(): JSONArray = loadArr("hokmSaves")
    fun putSaves(a: JSONArray): Boolean = put("hokmSaves", a.toString())

    /** rooms this phone played before */
    fun loadPrev(): JSONArray = loadArr("hokmPrev")
    fun putPrev(a: JSONArray) { put("hokmPrev", a.toString()) }
}
