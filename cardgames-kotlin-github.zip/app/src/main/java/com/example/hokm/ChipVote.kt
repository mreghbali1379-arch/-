package com.example.hokm

import android.app.Dialog
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * "تغییر ژتون": the chips of a game can be raised while it is played.
 * Whoever asks (the requester) proposes a new stake; the other people vote (3 seconds, counted after the screen reader has read the question).
 * Only the people who said yes take part: with each of them the requester has an EXTRA bet of (new stake - old stake) on top of the normal one.
 * A request: the opponents decide; the partner (team games) only decides whether he shares the extra bet (he never stops the request).
 */
class ChipExtra(@JvmField val req: Int, @JvmField val opps: List<Int>, @JvmField val partner: Int, @JvmField val e: Long) {
    fun toJson(): org.json.JSONObject = org.json.JSONObject().put("r", req).put("o", org.json.JSONArray(opps)).put("p", partner).put("e", e)
    companion object {
        fun fromJson(j: org.json.JSONObject): ChipExtra {
            val a = j.getJSONArray("o")
            return ChipExtra(j.getInt("r"), List(a.length()) { a.getInt(it) }, j.optInt("p", -1), j.getLong("e"))
        }
    }
}

object ChipVote {
    const val VOTE_MS = 3000L
    const val COOLDOWN_MS = 30000L
    private val handler = Handler(Looper.getMainLooper())

    /** how long the screen reader needs to read a text (the vote's 3 seconds start after it) */
    fun readMs(t: String): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now()) + Math.max(900, t.length * 50).toLong()

    /** the sum every pair of people settles at the end of a game: [winners] = the seats that won. d[seat] is added to */
    fun settle(extras: List<ChipExtra>, winners: Set<Int>, d: LongArray) {
        for (x in extras) {
            val reqWon = x.req in winners
            for (o in x.opps) {
                val oWon = o in winners
                if (reqWon == oWon) continue          // both won or both lost: nothing between them
                val sign = if (reqWon) 1 else -1       // the requester's side gains from this opponent (or pays him)
                if (o < d.size) d[o] -= sign * x.e
                val half = if (x.partner >= 0) x.e / 2 else 0L
                if (x.req < d.size) d[x.req] += sign * (x.e - half)
                if (x.partner >= 0 && x.partner < d.size) d[x.partner] += sign * half
            }
        }
    }

    /** the biggest extra that the requester can pay to [k] opponents, when he has [w] chips and the partner has [pw] (-1 = no partner / unknown) */
    fun capExtra(e: Long, k: Int, w: Long, partnerIn: Boolean, pw: Long): Long {
        if (k <= 0) return e
        var r = e
        if (w >= 0L) r = Math.min(r, if (partnerIn) (w * 2) / k else w / k)
        if (partnerIn && pw >= 0L) r = Math.min(r, (pw * 2) / k)
        return Math.max(0L, r)
    }

    // ------------------------------------------------------------------ the host's side of one vote

    /** one vote on the host: sendAsk(seat) asks a seat, answer(seat, ok) is called when it replies, done(answers) once everybody answered or the time is over (not answered = no) */
    class Round(private val voters: List<Int>, private val waitMs: Long, private val done: (Map<Int, Boolean>) -> Unit) {
        private val ans = HashMap<Int, Boolean>()
        private var fin = false
        private val timeout = Runnable { finish() }
        fun start() { handler.postDelayed(timeout, waitMs) ; if (voters.isEmpty()) finish() }
        fun answer(seat: Int, ok: Boolean) {
            if (fin || seat !in voters || ans.containsKey(seat)) return
            ans[seat] = ok
            if (ans.size >= voters.size) finish()
        }
        fun cancel() { fin = true; handler.removeCallbacks(timeout) }
        private fun finish() {
            if (fin) return
            fin = true; handler.removeCallbacks(timeout)
            done(voters.associateWith { ans[it] == true })
        }
    }

    // ------------------------------------------------------------------ dialogs

    /** asks for the new amount: a field, quick buttons and the biggest amount allowed */
    fun requestDialog(act: MainActivity, app: App, title: String, cur: Long, max: Long, ok: (Long) -> Unit) {
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(app.dlg.text(title).also { it.setPadding(0, 0, 0, Px.dp(8)) })
        c.addView(app.dlg.text("ژتون فعلی: " + Cards.fa(cur) + (if (max > 0L) " — بیشترین مبلغ مجاز: " + Cards.fa(max) else ""), 14f).also { it.setPadding(0, 0, 0, Px.dp(8)) })
        val et = numField(act, "مبلغ تازه", cur)
        c.addView(et)
        var d: Dialog? = null
        val row = LinearLayout(act); row.orientation = LinearLayout.HORIZONTAL; row.layoutDirection = View.LAYOUT_DIRECTION_RTL
        for ((lab, f) in listOf("دو برابر" to 2, "پنج برابر" to 5, "ده برابر" to 10)) {
            val b = app.dlg.btn(lab, false) { et.setText(Cards.fa(Math.min(Long.MAX_VALUE / 4, cur * f))) }
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { it.setMargins(Px.dp(3), Px.dp(8), Px.dp(3), Px.dp(8)) })
        }
        c.addView(row)
        c.addView(app.dlg.btn("درخواست تغییر") {
            val v = Cards.num(et.text.toString())
            if (v <= cur) { app.dlg.message("مبلغ تازه باید از ژتون فعلی (" + Cards.fa(cur) + ") بیشتر باشد."); return@btn }
            if (max > 0L && v > max) { app.dlg.message("مبلغ از بیشترین مبلغ مجاز (" + Cards.fa(max) + ") بیشتر است."); return@btn }
            d?.dismiss(); ok(v)
        })
        c.addView(app.dlg.btn("انصراف") { d?.dismiss() })
        d = app.dlg.custom(c)
    }

    /** the question of a vote: yes / no; no answer within 3 seconds (counted after the reading) = no. answer is called once. */
    fun voteDialog(act: MainActivity, app: App, text: String, answer: (Boolean) -> Unit) {
        var done = false
        var d: Dialog? = null
        val reply = { ok: Boolean -> if (!done) { done = true; try { d?.dismiss() } catch (e: Exception) { }; answer(ok) } }
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        val t = app.dlg.text(text)
        t.setPadding(0, 0, 0, Px.dp(10))
        c.addView(t)
        c.addView(app.dlg.btn("رد") { reply(false) })      // "no" comes first: a wrong "yes" is worse than a wrong "no"
        c.addView(app.dlg.btn("قبول") { reply(true) })
        d = app.dlg.custom(c) { reply(false) }
        handler.postDelayed({ reply(false) }, readMs(text) + VOTE_MS)
    }
}
