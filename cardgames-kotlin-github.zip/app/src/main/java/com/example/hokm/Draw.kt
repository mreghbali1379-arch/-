package com.example.hokm

import com.example.hokm.Cards.shuf

/** The draw that decides the first hakem (first ace) and his partner (second ace to another player). */
object Draw {
    class D(
        @JvmField val n: Int, @JvmField val seq: List<TP>, @JvmField val h: Int, @JvmField val pt: Int?,
        @JvmField val i1: Int, @JvmField val i2: Int, @JvmField val mv: IntArray,
        /** the six-player game: the partners of the hakem in the order of their aces (pt = the first) and the places of those aces in the sequence */
        @JvmField val pl: List<Int> = emptyList(), @JvmField val il: List<Int> = emptyList()
    )

    fun reseatPlan(h: Int, a: Int): IntArray {
        if ((h + 2) % 4 == a) return intArrayOf(0, 1, 2, 3)
        var best = intArrayOf(0, 1, 2, 3); var bc = 9
        val qs = listOf(intArrayOf(1, 2, 3), intArrayOf(1, 3, 2), intArrayOf(2, 1, 3), intArrayOf(2, 3, 1), intArrayOf(3, 1, 2), intArrayOf(3, 2, 1))
        for (q in qs) {
            val to = intArrayOf(0, q[0], q[1], q[2])
            if ((to[h] + 2) % 4 == to[a]) {
                var c = 0
                for (o in 0 until 4) if (to[o] != o) c++
                if (c < bc || (c == bc && Math.random() < 0.5)) { bc = c; best = to }
            }
        }
        return best
    }

    fun genDraw(n: Int, pd: Boolean): D {
        val wp = pd
        for (tr in 0 until 200) {
            val d = ArrayList<Card>()
            for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
            shuf(d)
            val st = Math.floor(Math.random() * n).toInt(); val ia = ArrayList<Int>()
            d.forEachIndexed { i, c -> if (c.r == 14) ia.add(i) }
            val own = { i: Int -> (st + i) % n }
            val h = own(ia[0])
            var k2 = -1
            if (n == 4 && wp) for (k in 1 until ia.size) if (own(ia[k]) != h) { k2 = k; break }
            if (n == 4 && wp && k2 < 0) continue
            val pp = n == 4 && wp
            val end = if (pp) ia[k2] else ia[0]
            val seq = d.subList(0, end + 1).mapIndexed { i, c -> TP(own(i), c) }
            val pt = if (pp) own(ia[k2]) else null
            return D(n, seq, h, pt, ia[0], if (pp) ia[k2] else -1,
                if (n == 4) (if (pp) reseatPlan(h, pt!!) else intArrayOf(0, 1, 2, 3)) else intArrayOf(0, 1))
        }
        val wp2 = n == 4 && wp
        return D(n, listOf(TP(0, Card(0, 14))) + (if (wp2) listOf(TP(1, Card(1, 14))) else listOf()), 0,
            if (wp2) 1 else null, 0, if (wp2) 1 else -1,
            if (n == 4) (if (wp) reseatPlan(0, 1) else intArrayOf(0, 1, 2, 3)) else intArrayOf(0, 1))
    }

    /**
     * The draw of the six-player game: the first ace makes the hakem; the next aces (of other players) make his partners:
     * one partner for three teams of two (he sits opposite), two partners for two teams of three (they sit one in between).
     * The seats are then moved (me = seat 0 stays) with the fewest moves, so that the partners sit where the teams are:
     * [mv][r] = the new seat of the player who sat at r.
     */
    fun reseat6(kind: Int, h: Int, pl: List<Int>): IntArray {
        var best = IntArray(6) { it }; var bc = 99
        val rest = intArrayOf(1, 2, 3, 4, 5)
        fun perms(a: IntArray, k: Int, out: MutableList<IntArray>) {
            if (k == a.size) { out.add(a.copyOf()); return }
            for (i in k until a.size) { var t = a[k]; a[k] = a[i]; a[i] = t; perms(a, k + 1, out); t = a[k]; a[k] = a[i]; a[i] = t }
        }
        val all = ArrayList<IntArray>(); perms(rest, 0, all)
        for (q in all) {
            val to = IntArray(6); to[0] = 0; for (i in 0 until 5) to[i + 1] = q[i]
            val ok = if (kind == 63) (to[h] + 3) % 6 == to[pl[0]] else pl.all { to[it] % 2 == to[h] % 2 }
            if (!ok) continue
            var c = 0; for (o in 0 until 6) if (to[o] != o) c++
            if (c < bc) { bc = c; best = to }
        }
        return best
    }

    fun genDraw6(kind: Int): D {
        val n = 6
        val need = if (kind == 62) 2 else 1
        for (tr in 0 until 400) {
            val d = ArrayList<Card>()
            for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
            shuf(d)
            val st = Math.floor(Math.random() * n).toInt(); val ia = ArrayList<Int>()
            d.forEachIndexed { i, c -> if (c.r == 14) ia.add(i) }
            val own = { i: Int -> (st + i) % n }
            val h = own(ia[0])
            val pl = ArrayList<Int>(); val il = ArrayList<Int>()
            for (k in 1 until ia.size) { val o = own(ia[k]); if (o != h && !pl.contains(o)) { pl.add(o); il.add(ia[k]); if (pl.size == need) break } }
            if (pl.size < need) continue
            val end = il.last()
            val seq = d.subList(0, end + 1).mapIndexed { i, c -> TP(own(i), c) }
            return D(n, seq, h, pl[0], ia[0], il[0], reseat6(kind, h, pl), pl, il)
        }
        val pl = if (need == 2) listOf(2, 4) else listOf(3)
        return D(n, listOf(TP(0, Card(0, 14))) + pl.mapIndexed { i, p -> TP(p, Card(i + 1, 14)) }, 0, pl[0], 0, 1, IntArray(6) { it }, pl, pl.indices.map { it + 1 })
    }

    /** the text the draw scene announces when it ends */
    fun describe(D: D, lab: List<String>): String {
        val hm = lab[D.h] == "شما"
        val ps = if (D.pl.isNotEmpty()) D.pl else (if (D.n == 4 && D.pt != null) listOf(D.pt!!) else emptyList())
        val pm = ps.any { lab[it] == "شما" }
        val nm = ps.joinToString(" و ") { lab[it].replace(" (یار)", "") }
        val many = ps.size > 1
        return (if (hm) "شما حاکم شدید" else lab[D.h].replace(" (یار)", "") + " حاکم شد") +
            (if (ps.isNotEmpty()) (if (hm) " و " + nm + (if (many) " یاران شما هستند" else " یار شماست") else if (pm) " و شما یار او هستید"
            else " و " + nm + (if (many) " یاران او هستند" else " یار اوست")) else "") + "."
    }
}
