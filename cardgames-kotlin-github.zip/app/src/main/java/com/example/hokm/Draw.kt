package com.example.hokm

import com.example.hokm.Cards.shuf

/** The draw that decides the first hakem (first ace) and his partner (second ace to another player). */
object Draw {
    class D(
        @JvmField val n: Int, @JvmField val seq: List<TP>, @JvmField val h: Int, @JvmField val pt: Int?,
        @JvmField val i1: Int, @JvmField val i2: Int, @JvmField val mv: IntArray,
        /** the six-player game: the partners of the hakem in the order of their aces (pt = the first) and the places of those aces in the sequence */
        @JvmField val pl: List<Int> = emptyList(), @JvmField val il: List<Int> = emptyList(),
        /** three teams of two: the two players of the second team (the third and the fourth ace) and the places of their aces in the sequence */
        @JvmField val t2: List<Int> = emptyList(), @JvmField val t2i: List<Int> = emptyList()
    )

    fun reseatPlan(h: Int, a: Int): IntArray {
        if ((h + 2) % 4 == a) return intArrayOf(0, 1, 2, 3)
        var best = intArrayOf(0, 1, 2, 3); var bc = 9
        val qs = listOf(intArrayOf(1, 2, 3), intArrayOf(1, 3, 2), intArrayOf(2, 1, 3), intArrayOf(2, 3, 1), intArrayOf(3, 1, 2), intArrayOf(3, 2, 1))
        for (q in qs) {
            val to = intArrayOf(0, q[0], q[1], q[2])
            if ((to[h] + 2) % 4 == to[a]) {
                var c = 0
                for (o in 0 until 4) if (to[o] != o) c++
                if (c < bc || (c == bc && Math.random() < 0.5)) { bc = c; best = to }
            }
        }
        return best
    }

    fun genDraw(n: Int, pd: Boolean): D {
        val wp = pd
        for (tr in 0 until 200) {
            val d = ArrayList<Card>()
            for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
            shuf(d)
            val st = Math.floor(Math.random() * n).toInt(); val ia = ArrayList<Int>()
            d.forEachIndexed { i, c -> if (c.r == 14) ia.add(i) }
            val own = { i: Int -> (st + i) % n }
            val h = own(ia[0])
            var k2 = -1
            if (n == 4 && wp) for (k in 1 until ia.size) if (own(ia[k]) != h) { k2 = k; break }
            if (n == 4 && wp && k2 < 0) continue
            val pp = n == 4 && wp
            val end = if (pp) ia[k2] else ia[0]
            val seq = d.subList(0, end + 1).mapIndexed { i, c -> TP(own(i), c) }
            val pt = if (pp) own(ia[k2]) else null
            return D(n, seq, h, pt, ia[0], if (pp) ia[k2] else -1,
                if (n == 4) (if (pp) reseatPlan(h, pt!!) else intArrayOf(0, 1, 2, 3)) else intArrayOf(0, 1))
        }
        val wp2 = n == 4 && wp
        return D(n, listOf(TP(0, Card(0, 14))) + (if (wp2) listOf(TP(1, Card(1, 14))) else listOf()), 0,
            if (wp2) 1 else null, 0, if (wp2) 1 else -1,
            if (n == 4) (if (wp) reseatPlan(0, 1) else intArrayOf(0, 1, 2, 3)) else intArrayOf(0, 1))
    }

    /**
     * The draw of the six-player game, as in the four-player game: the cards are dealt face up one by one and a player who got an ace
     * gets no more cards. The first ace makes the hakem.
     *  - two teams of three (62): the second and the third ace are his two partners (the dealing ends with the third ace);
     *    they sit one in between; everybody else is the other team.
     *  - three teams of two (63): the second ace is his partner (he sits opposite); the third and the fourth ace are the second team
     *    (the dealing ends with the fourth ace); the two players without an ace are the third team.
     * The seats are then moved (me = seat 0 stays; the hakem keeps his place when that is possible, then the fewest moves),
     * [mv][r] = the new seat of the player who sat at r.
     */
    fun reseat6(kind: Int, h: Int, pl: List<Int>, t2: List<Int> = emptyList()): IntArray {
        var best = IntArray(6) { it }; var bc = Int.MAX_VALUE
        val rest = intArrayOf(1, 2, 3, 4, 5)
        fun perms(a: IntArray, k: Int, out: MutableList<IntArray>) {
            if (k == a.size) { out.add(a.copyOf()); return }
            for (i in k until a.size) { var t = a[k]; a[k] = a[i]; a[i] = t; perms(a, k + 1, out); t = a[k]; a[k] = a[i]; a[i] = t }
        }
        val all = ArrayList<IntArray>(); perms(rest, 0, all)
        for (q in all) {
            val to = IntArray(6); to[0] = 0; for (i in 0 until 5) to[i + 1] = q[i]
            val ok = if (kind == 63) (to[h] + 3) % 6 == to[pl[0]] && t2.all { to[it] % 3 == (to[h] + 1) % 3 }      // the second team takes the seats after the hakem's
                     else pl.all { to[it] % 2 == to[h] % 2 }
            if (!ok) continue
            var c = 0; for (o in 0 until 6) if (to[o] != o) c++
            val cost = c + (if (to[h] != h) 100 else 0)
            if (cost < bc) { bc = cost; best = to }
        }
        return best
    }

    fun genDraw6(kind: Int): D {
        val n = 6
        val aces = if (kind == 62) 3 else 4
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 2..14) d.add(Card(s, r))
        shuf(d)
        val active = BooleanArray(n) { true }
        var cur = Math.floor(Math.random() * n).toInt()
        val seq = ArrayList<TP>(); val ap = ArrayList<Int>(); val ai = ArrayList<Int>()
        for (c in d) {
            while (!active[cur]) cur = (cur + 1) % n
            seq.add(TP(cur, c))
            if (c.r == 14) {
                ap.add(cur); ai.add(seq.size - 1); active[cur] = false
                if (ap.size == aces) break
            }
            cur = (cur + 1) % n
        }
        val h = ap[0]
        val pl = if (kind == 62) ap.subList(1, 3).toList() else listOf(ap[1])
        val il = if (kind == 62) ai.subList(1, 3).toList() else listOf(ai[1])
        val t2 = if (kind == 63) ap.subList(2, 4).toList() else emptyList()
        val t2i = if (kind == 63) ai.subList(2, 4).toList() else emptyList()
        return D(n, seq, h, pl[0], ai[0], il[0], reseat6(kind, h, pl, t2), pl, il, t2, t2i)
    }

    /** the text the draw scene announces when it ends */
    fun describe(D: D, lab: List<String>): String {
        val hm = lab[D.h] == "شما"
        val ps = if (D.pl.isNotEmpty()) D.pl else (if (D.n == 4 && D.pt != null) listOf(D.pt!!) else emptyList())
        val pm = ps.any { lab[it] == "شما" }
        val nm = ps.joinToString(" و ") { lab[it].replace(" (یار)", "") }
        val many = ps.size > 1
        return (if (hm) "شما حاکم شدید" else lab[D.h].replace(" (یار)", "") + " حاکم شد") +
            (if (ps.isNotEmpty()) (if (hm) " و " + nm + (if (many) " یاران شما هستند" else " یار شماست") else if (pm) " و شما یار او هستید"
            else " و " + nm + (if (many) " یاران او هستند" else " یار اوست")) else "") + "."
    }
}
