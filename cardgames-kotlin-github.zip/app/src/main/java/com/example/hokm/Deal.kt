package com.example.hokm

/**
 * The timing of dealing: the recorded deal sounds (deal4a / deal4b / deal2) tell when each card lands,
 * so every card flies to land exactly with "its" sound; the game waits until the dealing is over
 * (DLT / dl / dealStart / dlWait of the page).
 */
object Deal {
    class D(val f: String, val n: Int, val L: Double, val T: DoubleArray)

    // c3a / c3b / c5 / c6 = the same for three, five and six players: made from the recordings of the four-player deal (deal3a, deal3b, deal5a, deal6a)
    // a = the first 20 cards of a four-player hand (5 each, then the hakem picks the trump),
    // b = the 32 cards after the trump, d = the first 10 cards of a two-player hand
    val DLT = mapOf(
        "a" to D("deal4a", 5, 10.65, doubleArrayOf(0.27, 0.92, 1.46, 2.06, 2.58, 3.2, 3.74, 4.26, 4.84, 5.33, 5.86, 6.4, 6.91, 7.43, 7.93, 8.42, 8.98, 9.43, 9.92, 10.43)),
        "b" to D("deal4b", 8, 17.16, doubleArrayOf(0.29, 0.78, 1.3, 1.84, 2.31, 2.84, 3.5, 4.07, 4.58, 5.06, 5.49, 6.04, 6.58, 7.04, 7.52, 8.07, 8.51, 9.01, 9.54, 10.04, 10.48, 10.98, 11.48, 12.0, 12.47, 12.98, 13.46, 14.0, 14.43, 14.96, 15.44, 16.0)),
        "d" to D("deal2", 5, 4.37, doubleArrayOf(0.23, 0.52, 0.74, 1.05, 1.3, 1.56, 2.03, 2.47, 2.93, 3.47)),
        "c3a" to D("deal3a", 5, 8.33, doubleArrayOf(0.27, 0.92, 1.46, 2.06, 2.58, 3.2, 3.74, 4.26, 4.84, 5.33, 5.86, 6.4, 6.91, 7.43, 7.93)),
        "c3b" to D("deal3b", 12, 18.34, doubleArrayOf(0.27, 0.76, 1.28, 1.82, 2.29, 2.82, 3.48, 4.05, 4.56, 5.04, 5.47, 6.02, 6.56, 7.02, 7.5, 8.05, 8.49, 8.99, 9.52, 10.02, 10.46, 10.96, 11.46, 11.98, 12.45, 12.96, 13.44, 13.98, 14.41, 14.94, 15.42, 15.98, 16.4, 16.89, 17.41, 17.95)),
        "c5" to D("deal5a", 5, 13.61, doubleArrayOf(0.27, 0.92, 1.46, 2.06, 2.58, 3.2, 3.74, 4.26, 4.84, 5.33, 5.86, 6.4, 6.91, 7.43, 7.93, 8.42, 8.98, 9.43, 9.92, 10.43, 10.77, 11.42, 11.96, 12.56, 13.08)),
        "c6" to D("deal6a", 4, 13.01, doubleArrayOf(0.27, 0.92, 1.46, 2.06, 2.58, 3.2, 3.74, 4.26, 4.84, 5.33, 5.86, 6.4, 6.91, 7.43, 7.93, 8.42, 8.98, 9.43, 9.92, 10.43, 10.77, 11.42, 11.96, 12.56))
    )

    @JvmField var dealEnd = 0L
    @JvmField var dealGen = -1
    @JvmField var stq = false          // a trump choice is waiting for the dealing to end
    private val dk = HashMap<String, Long>()

    fun lead(): Long = Anim.ad(340).toLong()
    private fun dsf(): Double = if (Sound.on) 1.0 else 0.35

    /** ms until the dealing is over (0 when nothing is being dealt) */
    fun wait(): Long = if (dealGen == Sched.GEN) Math.max(0L, dealEnd - Sched.now()) else 0L

    /** part of the deal sound for N players and nw new cards each (dpart) */
    fun part(N: Int, nw: Int): String? = when (N) {
        4 -> if (nw == 5) "a" else if (nw == 8) "b" else null
        2 -> if (nw == 5) "d" else null
        3 -> if (nw == 5) "c3a" else if (nw == 12) "c3b" else null
        5 -> if (nw == 5) "c5" else null
        6 -> if (nw == 4) "c6" else null
        else -> null
    }

    /** when and how a card is dealt: delay before it flies, whether it needs its own card sound */
    class Plan(val delay: Long, val snd: Boolean, val o: Float?)

    private fun start(p: String) {
        val D = DLT[p] ?: return
        val now = Sched.now()
        if (dealGen == Sched.GEN && now < (dk[p] ?: 0L)) return
        val ld = lead(); val end = now + ld + Anim.ad(D.L * 1000 * dsf()).toLong()
        dk[p] = end; dealGen = Sched.GEN; dealEnd = end
        Sound.reserve(end)
        val g = Sched.GEN
        Sched.laterRaw(ld) { if (g == Sched.GEN && Sound.on) Sound.playDeal(D.f, g) }
    }

    /** the plan for card number k of player oi (dl) */
    fun dl(k: Int, oi: Int, N: Int, part: String?, nw: Int, dur: Long): Plan {
        val D = if (part == null) null else DLT[part]
        val g = k * N + oi
        if (D == null || nw != D.n || oi < 0 || oi >= N || g < 0 || g >= D.T.size) return Plan(Math.max(0, g) * Anim.ad(45).toLong(), true, null)
        start(part!!)
        return Plan(Math.max(0L, Anim.ad(D.T[g] * 1000 * dsf()).toLong() + lead() - dur), false, 0f)
    }

    /** a hand of 13 that arrives at once on a guest's phone: the first 5 quickly, the other 8 with the second sound (dlc) */
    fun dlc(k: Int, oi: Int, N: Int, nw: Int, dur: Long): Plan =
        if (N == 4 && nw == 13) { if (k < 5) Plan(k * Anim.ad(40).toLong(), false, null) else dl(k - 5, oi, 4, "b", 8, dur) }
        else dl(k, oi, N, part(N, nw), nw, dur)

    fun reset() { dk.clear(); dealEnd = 0; stq = false }
}
