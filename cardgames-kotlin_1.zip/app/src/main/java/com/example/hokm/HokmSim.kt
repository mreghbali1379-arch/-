package com.example.hokm

import java.util.Random

/**
 * The robot of the 3, 5 and 6-player Hokm. Like the four-player robot it counts cards and uses what it learns
 * (a player who did not follow a suit has none of it): it deals the cards it cannot see to the other players
 * many times, plays every legal card out to the end of the round with a simple policy, and chooses the card that
 * does best on average. The trump is chosen the same way, from the first cards of the hakem.
 */
class HokmSim(private val n: Int, private val kind: Int, private val trump: Int, private val hakem: Int) {
    private val rnd = Random()
    private val spec = HokmCore.spec(kind)
    private fun teamOf(seat: Int): Int = spec.teamOf(seat)
    private val teams = spec.teams

    fun beats(a: Card, b: Card): Boolean = HokmRules.beats(a, b, trump)

    fun winnerOf(t: List<TC>): TC = HokmRules.winnerOf(t, trump)

    private fun id(c: Card) = c.s * 20 + c.r

    private fun isTop(h: List<Card>, c: Card, seen: BooleanArray): Boolean =
        (c.r + 1..14).all { r -> seen[c.s * 20 + r] || h.any { it.s == c.s && it.r == r } }

    fun legal(h: List<Card>, trick: List<TC>): List<Card> = HokmRules.legal(h, trick)

    /** the simple policy of the rollouts (and of the fallback): top cards first, win cheaply, never take a partner's trick */
    fun policy(seat: Int, h: List<Card>, trick: List<TC>, seen: BooleanArray): Card {
        if (trick.isEmpty()) {
            val nonTrump = h.filter { it.s != trump }
            val tops = nonTrump.filter { isTop(h, it, seen) }.sortedByDescending { it.r }
            if (tops.isNotEmpty()) return tops[0]
            val tr = h.filter { it.s == trump }
            if (tr.isNotEmpty() && teamOf(seat) == teamOf(hakem)) {
                val topTr = tr.filter { isTop(h, it, seen) }
                if (topTr.isNotEmpty()) return topTr.maxByOrNull { it.r }!!
            }
            if (nonTrump.isNotEmpty()) return nonTrump.groupBy { it.s }.maxByOrNull { it.value.size }!!.value.minByOrNull { it.r }!!
            return tr.minByOrNull { it.r }!!
        }
        val led = trick[0].c.s
        val following = h.any { it.s == led }
        val legal = if (following) h.filter { it.s == led } else h
        val w = winnerOf(trick)
        val partnerWins = teamOf(w.seat) == teamOf(seat)
        if (following) {
            if (partnerWins) return legal.minByOrNull { it.r }!!
            val beat = legal.filter { beats(it, w.c) }.sortedBy { it.r }
            return if (beat.isNotEmpty()) beat[0] else legal.minByOrNull { it.r }!!
        }
        val trumps = h.filter { it.s == trump }
        val others = h.filter { it.s != trump }
        if (partnerWins) return (if (others.isNotEmpty()) others else h).minByOrNull { it.r }!!
        if (trumps.isNotEmpty()) {
            val bt = trumps.filter { beats(it, w.c) }.sortedBy { it.r }
            if (bt.isNotEmpty()) return bt[0]
        }
        return (if (others.isNotEmpty()) others else h).minByOrNull { it.r }!!
    }

    // ------------------------------------------------------------------ rollouts

    /** plays the rest of the round with the policy: 1 = the team [my] reached 7 first (a kot a little more), 0 = another did */
    private fun finish(first: Int, hands: Array<MutableList<Card>>, trickIn: List<TC>, seen: BooleanArray, tw: IntArray, my: Int): Double {
        var trick = ArrayList(trickIn)
        var seat = first
        var size = 0
        for (i in 0 until n) size = Math.max(size, hands[i].size)
        var guard = 0
        while (guard++ < 400) {
            // finish the current trick
            while (trick.size < n) {
                val h = hands[seat]
                if (h.isEmpty()) return outcome(tw, my)
                val c = policy(seat, h, trick, seen)
                h.remove(c); seen[id(c)] = true
                trick.add(TC(seat, c))
                seat = (seat + 1) % n
            }
            val w = winnerOf(trick)
            tw[teamOf(w.seat)]++
            val t7 = HokmCore.roundWinnerFor(spec, tw, hands[w.seat].size)
            if (t7 >= 0) {
                val kot = HokmCore.othersZero(tw, teams, t7)
                return if (t7 == my) (if (kot) 1.15 else 1.0) else (if (kot) -0.15 else 0.0)
            }
            trick = ArrayList()
            seat = w.seat
            if (hands[seat].isEmpty()) return outcome(tw, my)
        }
        return outcome(tw, my)
    }

    private fun outcome(tw: IntArray, my: Int): Double {
        var mx = 0; for (t in 0 until teams) mx = Math.max(mx, tw[t])
        var other = 0; for (t in 0 until teams) if (t != my) other = Math.max(other, tw[t])
        return if (tw[my] > other) 0.9 else if (tw[my] == other) 0.5 else 0.05
    }

    /** the unseen cards dealt to the others: nobody gets a suit he has shown he does not have */
    private fun deal(unseen: List<Card>, need: IntArray, seat: Int, voids: Array<BooleanArray>): Array<MutableList<Card>> {
        val hands = Array(6) { ArrayList<Card>() as MutableList<Card> }
        val rest = need.copyOf()
        val cards = unseen.shuffled(rnd)
        // the most restricted cards first
        val order = cards.sortedBy { c -> (0 until n).count { it != seat && !voids[it][c.s] } }
        for (c in order) {
            var tot = 0
            val ok = ArrayList<Int>()
            for (s in 0 until n) if (s != seat && rest[s] > 0 && !voids[s][c.s]) { ok.add(s); tot += rest[s] }
            if (ok.isEmpty()) for (s in 0 until n) if (s != seat && rest[s] > 0) { ok.add(s); tot += rest[s] }
            if (ok.isEmpty()) break
            var r = rnd.nextInt(tot)
            var pick = ok[0]
            for (s in ok) { if (r < rest[s]) { pick = s; break }; r -= rest[s] }
            hands[pick].add(c); rest[pick]--
        }
        return hands
    }

    /**
     * the card for [seat]: [deck] = all the cards of this game, [seenIn] = the cards played so far in this round,
     * [counts] = how many cards each seat holds now, [voids] = suits a seat has shown it does not have
     */
    fun choose(seat: Int, myHand: List<Card>, trick: List<TC>, seenIn: BooleanArray, deck: List<Card>, counts: IntArray, voids: Array<BooleanArray>, tricksWon: IntArray): Card {
        val cands = legal(myHand, trick)
        if (cands.size == 1) return cands[0]
        val unseen = deck.filter { c -> !seenIn[id(c)] && myHand.none { it.s == c.s && it.r == c.r } && trick.none { it.c.s == c.s && it.c.r == c.r } }
        val my = teamOf(seat)
        val samples = Math.max(30, Math.min(160, 3500 / cands.size))
        val score = DoubleArray(cands.size)
        for (k in 0 until samples) {
            val dealt = deal(unseen, counts, seat, voids)
            for ((ci, c) in cands.withIndex()) {
                val hands = Array(6) { i -> if (i == seat) ArrayList(myHand) else ArrayList(dealt[i]) as MutableList<Card> }
                val seen = seenIn.copyOf()
                val tr = ArrayList(trick)
                hands[seat].remove(c); seen[id(c)] = true
                tr.add(TC(seat, c))
                score[ci] += finish((seat + 1) % n, hands, tr, seen, tricksWon.copyOf(), my)
            }
        }
        var best = 0
        for (i in cands.indices) if (score[i] > score[best]) best = i
        return cands[best]
    }

    /** the trump for the hakem [seat], who holds [first] of the cards of this game; every suit is tried on whole rounds */
    fun chooseTrump(seat: Int, first: List<Card>, deck: List<Card>, size: Int): Int {
        val unseen = deck.filter { c -> first.none { it.s == c.s && it.r == c.r } }
        val my = teamOf(seat)
        var bestS = 0; var bestV = -1.0
        val samples = 40
        for (s in 0 until 4) {
            val sim = HokmSim(n, kind, s, hakem)
            var tot = 0.0
            for (k in 0 until samples) {
                val sh = unseen.shuffled(rnd)
                val hands = Array(6) { ArrayList<Card>() as MutableList<Card> }
                hands[seat].addAll(first)
                var p = 0
                val needMine = size - first.size
                for (x in 0 until needMine) hands[seat].add(sh[p++])
                for (o in 0 until n) if (o != seat) for (x in 0 until size) hands[o].add(sh[p++])
                tot += sim.finish(seat, hands, emptyList(), BooleanArray(80), IntArray(6), my)
            }
            if (tot > bestV) { bestV = tot; bestS = s }
        }
        return bestS
    }
}
