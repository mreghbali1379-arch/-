package com.example.hokm

import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner

/**
 * The settings chosen in this run of the app: they stay when a page is opened again (a new game, the waiting room of a multi-phone game)
 * and are forgotten only when the app is closed.
 */
object Mem {
    private val m = HashMap<String, String>()

    fun put(k: String, v: String) { m[k] = v }
    fun str(k: String, d: String): String = m[k] ?: d
    fun int(k: String, d: Int): Int = m[k]?.toIntOrNull() ?: d

    /** [sp] shows the last choice made under [k] and remembers every new choice (call it after the spinner's own listener is set) */
    fun spinner(k: String, sp: Spinner) {
        val c = sp.adapter?.count ?: 0
        val p = int(k, -1)
        if (p in 0 until c) sp.setSelection(p)
        val old = sp.onItemSelectedListener
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                put(k, pos.toString())
                old?.onItemSelected(a, v, pos, id)
            }
            override fun onNothingSelected(a: AdapterView<*>?) { old?.onNothingSelected(a) }
        }
    }

    fun field(k: String, et: EditText) {
        val s = str(k, "")
        if (s.isNotEmpty()) { et.setText(s); et.setSelection(et.text.length) }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { }
            override fun afterTextChanged(s: Editable?) { put(k, s?.toString() ?: "") }
        })
    }

    fun check(k: String, cb: CheckBox) {
        val s = m[k]
        if (s != null) cb.isChecked = s == "1"
        cb.setOnCheckedChangeListener { _, b -> put(k, if (b) "1" else "0") }
    }
}
