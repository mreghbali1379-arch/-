package com.example.hokm

import java.util.Random

/**
 * The numbers that make one engine different from the others. They were tuned by self-play (tens of thousands of
 * hands per kind of the game, the engine against the old HokmSim policy) and the hakem tables were measured on
 * 600,000 simulated deals of the same kind.
 */
class EngineProfile(
    val name: String,
    /** the partner is winning but an opponent behind me may take the trick: how big must the risk be before I secure it */
    @JvmField val secThr: Double,
    /** how much safer the securing card must make the trick */
    @JvmField val secGain: Double,
    /** win the trick with the cheapest card that keeps the risk below this (2.0 = always the cheapest winner) */
    @JvmField val winRisk: Double,
    /** if no cheap card is safe, play the highest winner when its risk is below this (2.0 = always) */
    @JvmField val hiRisk: Double,
    /** discarding: how strongly a short side suit is emptied (when holding trumps) */
    @JvmField val voidW: Double,
    /** lead the top trump to pull the trumps when holding at least this many trumps */
    @JvmField val drawLen: Int,
    /** the side of the hakem always pulls trumps; with true every side does it */
    @JvmField val allDraw: Boolean,
    /** leading: how much a suit that an opponent can ruff is avoided */
    @JvmField val ruffW: Double,
    /** leading a low card: how much a suit with a high card in my hand is avoided */
    @JvmField val hiW: Double,
    /** leading a low card: how much a long suit is preferred */
    @JvmField val lenW: Double,
    /** how likely it is that the hakem holds k cards of the trump he chose (index = k), measured on simulated deals */
    @JvmField val hakemLR: DoubleArray,
    /** the cards left (each) from which the rest of the round is solved exactly */
    @JvmField val exactCards: Int,
    /** the thinking time compared with Engine4.BOT_MS */
    @JvmField val budgetFactor: Double
)

/**
 * The base of the engines of the Hokm games for 3, 5 and 6 players. It holds the machinery that all of them need:
 *  - card counting and the suits a player has shown he does not have,
 *  - many random deals of the hidden cards, weighted by how well they agree with the way the others played,
 *  - rollouts with the engine's own playing policy ([policy]), which knows who can still take the trick,
 *  - an exact search near the end of the round,
 *  - the value of a round as the chance to win the whole game (race to 7).
 * Every kind of the game has its own subclass with its own [EngineProfile] (tuned for that kind), so the decisions of a
 * three-player game are not made with the numbers of a six-player game.
 */
abstract class HokmEngine(
    protected val n: Int,
    protected val kind: Int,
    protected val trump: Int,
    protected val hakem: Int,
    val profile: EngineProfile
) {
    protected val spec = HokmCore.spec(kind)
    protected val teams = spec.teams
    protected fun teamOf(seat: Int): Int = spec.teamOf(seat)
    private var rnd = Random(1L)
    private var sizeR = 0
    /** the points of the sides in the game so far; null = only the points of the round count */
    @JvmField var scores: IntArray? = null

    /** the same engine for another trump (the hakem tries every suit) */
    protected abstract fun forTrump(t: Int): HokmEngine

    /** a small preference for the suit in which the hakem holds more cards, so that equal values are not broken by the order of the suits */
    protected open fun trumpBias(first: List<Card>, suit: Int): Double = 0.01 * first.count { it.s == suit }

    private fun id(c: Card) = c.s * 20 + c.r
    private fun sid(i: Int) = i / 20

    // ------------------------------------------------------------------ the value of a round

    private fun valueOf(winner: Int, kot: Boolean, bam: Boolean, my: Int): Double {
        val p = if (bam) 7 else HokmRules.gain(kot, winner == teamOf(hakem))
        val sc = scores
        if (sc == null) return if (winner == my) 0.5 + p / 14.0 else 0.5 - p / 14.0
        val a = Math.min(7, sc[my])
        var b = 0; for (t in 0 until teams) if (t != my) b = Math.max(b, Math.min(7, sc[t]))
        return if (winner == my) Engine4.MW[Math.min(7, a + p)][b] + 0.004 * p
        else Engine4.MW[a][Math.max(b, Math.min(7, sc[winner] + p))] - 0.004 * p
    }

    private fun finalValue(tw: IntArray, my: Int): Double {
        var mx = 0; for (t in 0 until teams) mx = Math.max(mx, tw[t])
        if (tw[my] == mx) {
            var cnt = 0; for (t in 0 until teams) if (tw[t] == mx) cnt++
            return if (cnt == 1) valueOf(my, false, false, my) else 0.5
        }
        var w = 0; for (t in 0 until teams) if (tw[t] == mx) { w = t; break }
        return valueOf(w, false, false, my)
    }

    // ------------------------------------------------------------------ the playing policy (used in every rollout)

    /** the ranks of the cards that nobody has shown yet and that are not in my hand, per suit */
    private fun unseenOf(h: List<Card>, seen: BooleanArray): Array<ArrayList<Int>> {
        val inH = BooleanArray(80)
        for (c in h) inH[c.s * 20 + c.r] = true
        val un = Array(4) { ArrayList<Int>(13) }
        for (s in 0 until 4) for (r in 2..14) {
            if (r == 2 && spec.outSuits.contains(s)) continue
            val i = s * 20 + r
            if (seen[i] || inH[i]) continue
            un[s].add(r)
        }
        return un
    }

    private fun isTop(h: List<Card>, c: Card, seen: BooleanArray): Boolean {
        for (r in c.r + 1..14) {
            if (seen[c.s * 20 + r]) continue
            if (h.any { it.s == c.s && it.r == r }) continue
            return false
        }
        return true
    }

    /** the chance that one hidden card of [suit] sits in the hand of seat [q] */
    private fun pHold(q: Int, suit: Int, seat: Int, voids: Array<BooleanArray>, cnt: IntArray): Double {
        if (voids[q][suit]) return 0.0
        var tot = 0
        for (o in 0 until n) { if (o == seat || voids[o][suit]) continue; tot += cnt[o] }
        if (tot <= 0) return 0.0
        return Math.min(1.0, cnt[q].toDouble() / tot)
    }

    /** the chance that seat [q], who has still to play, beats the card [wc] that wins the trick now */
    private fun pBeat(q: Int, wc: Card, led: Int, un: Array<ArrayList<Int>>, seat: Int, voids: Array<BooleanArray>, cnt: IntArray): Double {
        if (wc.s == trump) {
            val hi = un[trump].count { it > wc.r }
            if (hi == 0 || voids[q][trump]) return 0.0
            val p = pHold(q, trump, seat, voids, cnt)
            return 1.0 - Math.pow(1.0 - p, hi.toDouble())
        }
        var pf = 0.0
        val pvoid: Double
        val hi = if (wc.s == led) un[led].count { it > wc.r } else 0
        if (!voids[q][led]) {
            val p = pHold(q, led, seat, voids, cnt)
            val pfollow = if (un[led].isNotEmpty()) 1.0 - Math.pow(1.0 - p, un[led].size.toDouble()) else 0.0
            pf = if (hi > 0) 1.0 - Math.pow(1.0 - p, hi.toDouble()) else 0.0
            pvoid = 1.0 - pfollow
        } else {
            pvoid = 1.0
        }
        var ptr = 0.0
        if (un[trump].isNotEmpty() && !voids[q][trump]) {
            val p = pHold(q, trump, seat, voids, cnt)
            ptr = 1.0 - Math.pow(1.0 - p, un[trump].size.toDouble())
        }
        return Math.min(1.0, pf + pvoid * ptr)
    }

    /**
     * The card that the policy plays: it leads the cards that cannot be beaten (not into a ruff), pulls the trumps,
     * wins the trick with the cheapest card, secures a trick of the partner when an opponent behind can still take it,
     * ruffs only when it pays, and throws away the cards that are worth the least.
     * [voids] = the suits a seat has shown it does not have, [cnt] = the cards each seat holds now.
     */
    protected fun policy(seat: Int, h: List<Card>, trick: List<TC>, seen: BooleanArray, voids: Array<BooleanArray>, cnt: IntArray): Card {
        val my = teamOf(seat)
        val un = unseenOf(h, seen)
        if (trick.isEmpty()) return lead(seat, h, seen, voids, cnt, un)
        val led = trick[0].c.s
        val w = HokmRules.winnerOf(trick, trump)
        val wc = w.c
        val pw = teamOf(w.seat) == my
        val laterOpp = ArrayList<Int>()
        for (k in 1 until n - trick.size) { val q = (seat + k) % n; if (teamOf(q) != my) laterOpp.add(q) }
        val lg = HokmRules.legal(h, trick)
        val following = h.any { it.s == led }
        val P = profile
        val risk = { card: Card ->
            var pr = 1.0
            for (q in laterOpp) pr *= (1.0 - pBeat(q, card, led, un, seat, voids, cnt))
            1.0 - pr
        }
        if (following) {
            if (pw) {
                if (laterOpp.isEmpty()) return lg.minByOrNull { it.r }!!
                val r = risk(wc)
                if (r > P.secThr) {
                    val ws = lg.filter { HokmRules.beats(it, wc, trump) }.sortedBy { it.r }
                    for (c in ws) if (risk(c) < r - P.secGain) return c
                }
                return lg.minByOrNull { it.r }!!
            }
            val ws = lg.filter { HokmRules.beats(it, wc, trump) }.sortedBy { it.r }
            if (ws.isEmpty()) return lg.minByOrNull { it.r }!!
            if (laterOpp.isEmpty()) return ws[0]
            for (c in ws) if (risk(c) <= P.winRisk) return c
            if (risk(ws[ws.size - 1]) <= P.hiRisk) return ws[ws.size - 1]
            return lg.minByOrNull { it.r }!!
        }
        // no card of the led suit
        val trs = h.filter { it.s == trump }
        val oth = h.filter { it.s != trump }
        val pool = if (oth.isNotEmpty()) oth else h
        if (pw) {
            if (laterOpp.isNotEmpty() && trs.isNotEmpty()) {
                val r = risk(wc)
                if (r > P.secThr) {
                    val ws = trs.filter { HokmRules.beats(it, wc, trump) }.sortedBy { it.r }
                    for (c in ws) if (risk(c) < r - P.secGain) return c
                }
            }
            return discard(h, seen, pool)
        }
        if (trs.isNotEmpty()) {
            val ws = trs.filter { HokmRules.beats(it, wc, trump) }.sortedBy { it.r }
            if (ws.isNotEmpty()) {
                if (laterOpp.isEmpty()) return ws[0]
                for (c in ws) if (risk(c) <= P.winRisk) return c
                if (risk(ws[ws.size - 1]) <= P.hiRisk) return ws[ws.size - 1]
            }
        }
        return discard(h, seen, pool)
    }

    /** the card that is worth the least: the lowest of a suit without a top card or a king; a short suit is emptied when trumps are held */
    private fun discard(h: List<Card>, seen: BooleanArray, pool: List<Card>): Card {
        val ntr = h.count { it.s == trump }
        val bySuit = pool.groupBy { it.s }
        val lowest = HashMap<Int, Card>()
        for ((s, g) in bySuit) lowest[s] = g.minByOrNull { it.r }!!
        var best: Card? = null
        var b1 = 0.0; var b2 = 0.0; var b3 = 0.0
        for (c in pool) {
            val g = bySuit[c.s]!!
            val k1: Double; val k2: Double; val k3: Double
            if (c !== lowest[c.s]) {
                k1 = 9.0; k2 = c.r.toDouble(); k3 = 0.0
            } else {
                val top = g.maxByOrNull { it.r }!!
                k1 = if (isTop(h, top, seen) || top.r >= 13) 1.0 else 0.0
                val shortb = if (ntr < 2) -g.size.toDouble() else g.size.toDouble()
                k2 = shortb * profile.voidW
                k3 = c.r.toDouble()
            }
            val better = best == null || k1 < b1 || (k1 == b1 && (k2 < b2 || (k2 == b2 && k3 < b3)))
            if (better) { best = c; b1 = k1; b2 = k2; b3 = k3 }
        }
        return best!!
    }

    private fun lead(seat: Int, h: List<Card>, seen: BooleanArray, voids: Array<BooleanArray>, cnt: IntArray, un: Array<ArrayList<Int>>): Card {
        val my = teamOf(seat); val hk = teamOf(hakem)
        val P = profile
        val opps = (0 until n).filter { teamOf(it) != my }
        val non = h.filter { it.s != trump }
        val trs = h.filter { it.s == trump }
        val unT = un[trump]
        // 0 = nobody can ruff this suit, 0.5 = maybe, 1 = an opponent who is void of it still has trumps
        val ruffDanger = { suit: Int ->
            var d = 0.0
            if (unT.isNotEmpty()) {
                for (q in opps) {
                    if (voids[q][suit] && !voids[q][trump]) d = Math.max(d, 1.0)
                    else if (cnt[q] > 0 && un[suit].isEmpty()) d = Math.max(d, 0.5)
                }
            }
            d
        }
        val tops = non.filter { isTop(h, it, seen) }.sortedByDescending { it.r }
        val safe = tops.filter { ruffDanger(it.s) == 0.0 }
        if (safe.isNotEmpty()) {
            var bc = safe[0]; var bn = tops.count { it.s == bc.s }
            for (c in safe) {
                val k = tops.count { it.s == c.s }
                if (k > bn || (k == bn && c.r > bc.r)) { bc = c; bn = k }
            }
            return bc
        }
        val topT = trs.filter { isTop(h, it, seen) }
        if (trs.isNotEmpty() && unT.isNotEmpty() && (my == hk || P.allDraw)) {
            val oppHas = opps.any { !voids[it][trump] && cnt[it] > 0 }
            if (topT.isNotEmpty() && oppHas && trs.size >= P.drawLen) return topT.maxByOrNull { it.r }!!
        }
        if (tops.isNotEmpty()) {
            val t = tops.filter { ruffDanger(it.s) < 1.0 }
            if (t.isNotEmpty()) return t[0]
        }
        if (non.isNotEmpty()) {
            val g = non.groupBy { it.s }
            var bs = -1; var k1 = 0.0; var k2 = 0.0
            for ((s, cs) in g) {
                val mx = cs.maxByOrNull { it.r }!!.r
                val a = -ruffDanger(s) * P.ruffW
                val b = -mx * P.hiW + cs.size * P.lenW
                if (bs < 0 || a > k1 || (a == k1 && b > k2)) { bs = s; k1 = a; k2 = b }
            }
            return g[bs]!!.minByOrNull { it.r }!!
        }
        return trs.minByOrNull { it.r }!!
    }

    // ------------------------------------------------------------------ playing out with the policy

    private fun rollout(hands: Array<MutableList<Card>>, trickIn: List<TC>, first: Int, seenIn: BooleanArray, tw0: IntArray, kt0: Int, my: Int, voidsIn: Array<BooleanArray>): Double {
        val seen = seenIn.copyOf(); val tw = tw0.copyOf(); var kt = kt0
        val vd = Array(n) { voidsIn[it].copyOf() }
        val cnt = IntArray(n)
        var trick = ArrayList(trickIn); var seat = first
        var guard = 0
        while (guard++ < 600) {
            while (trick.size < n) {
                val h = hands[seat]
                if (h.isEmpty()) return finalValue(tw, my)
                for (i in 0 until n) cnt[i] = hands[i].size
                val c = policy(seat, h, trick, seen, vd, cnt)
                if (trick.isNotEmpty() && c.s != trick[0].c.s) vd[seat][trick[0].c.s] = true
                h.remove(c); seen[id(c)] = true
                trick.add(TC(seat, c))
                seat = (seat + 1) % n
            }
            val w = HokmRules.winnerOf(trick, trump)
            tw[teamOf(w.seat)]++
            kt = HokmCore.kotFor(spec, tw, kt)
            val hs = HokmCore.roundWinnerFor(spec, tw, hands[w.seat].size)
            if (hs >= 0) return valueOf(hs, kt == hs || tw[hs] == sizeR, tw[hs] == sizeR, my)
            trick = ArrayList(); seat = w.seat
            if (hands[seat].isEmpty()) return finalValue(tw, my)
        }
        return finalValue(tw, my)
    }

    // ------------------------------------------------------------------ the exact search

    private class Abort : RuntimeException()
    private var nodes = 0
    private var limit = 0

    private fun beatsI(a: Int, b: Int): Boolean = if (sid(a) == sid(b)) a % 20 > b % 20 else sid(a) == trump && sid(b) != trump

    private fun solve(hh: Array<IntArray>, ts: IntArray, ti: IntArray, tn: Int, turn: Int, tw: IntArray, kt: Int, my: Int, alIn: Double, beIn: Double): Double {
        var al = alIn; var be = beIn
        if (++nodes > limit) throw Abort()
        if (tn == n) {
            var b = 0
            for (i in 1 until n) if (beatsI(ti[i], ti[b])) b = i
            val ws = ts[b]
            val tw2 = tw.copyOf(); tw2[teamOf(ws)]++
            val kt2 = HokmCore.kotFor(spec, tw2, kt)
            val hs = HokmCore.roundWinnerFor(spec, tw2, hh[ws].size)
            if (hs >= 0) return valueOf(hs, kt2 == hs || tw2[hs] == sizeR, tw2[hs] == sizeR, my)
            if (hh[ws].isEmpty()) return finalValue(tw2, my)
            return solve(hh, IntArray(n), IntArray(n), 0, ws, tw2, kt2, my, al, be)
        }
        val hand = hh[turn]
        var legal: IntArray = hand
        if (tn > 0) {
            val led = sid(ti[0])
            val f = hand.filter { sid(it) == led }
            if (f.isNotEmpty()) legal = f.toIntArray()
        }
        if (legal.isEmpty()) return finalValue(tw, my)
        var bid = -1
        if (tn > 0) { bid = ti[0]; for (i in 1 until tn) if (beatsI(ti[i], bid)) bid = ti[i] }
        val order = legal.toList().sortedBy { c ->
            if (bid >= 0 && beatsI(c, bid)) (c % 20) + (if (sid(c) == trump) 50 else 0) else 1000 + (c % 20) + (if (sid(c) == trump) 50 else 0)
        }
        val mx = teamOf(turn) == my
        var best = if (mx) -9.0 else 9.0
        for (c in order) {
            hh[turn] = hand.filter { it != c }.toIntArray()
            ts[tn] = turn; ti[tn] = c
            val r = solve(hh, ts, ti, tn + 1, (turn + 1) % n, tw, kt, my, al, be)
            hh[turn] = hand
            if (mx) { if (r > best) best = r; if (best > al) al = best } else { if (r < best) best = r; if (best < be) be = best }
            if (al >= be) break
        }
        return best
    }

    private fun exactValue(hs: Array<MutableList<Card>>, seat: Int, c: Card, trick: List<TC>, tw: IntArray, kt: Int, my: Int, lim: Int): Double? {
        val hh = Array(n) { p -> hs[p].map { id(it) }.toIntArray() }
        val cid = id(c)
        hh[seat] = hh[seat].filter { it != cid }.toIntArray()
        val ts = IntArray(n); val ti = IntArray(n)
        for ((i, t) in trick.withIndex()) { ts[i] = t.seat; ti[i] = id(t.c) }
        ts[trick.size] = seat; ti[trick.size] = cid
        nodes = 0; limit = lim
        return try { solve(hh, ts, ti, trick.size + 1, (seat + 1) % n, tw, kt, my, -9.0, 9.0) } catch (e: Abort) { null }
    }

    // ------------------------------------------------------------------ the hidden cards

    private fun deal(unseen: List<Card>, need: IntArray, seat: Int, voids: Array<BooleanArray>): Array<MutableList<Card>> {
        val hands = Array(n) { ArrayList<Card>() as MutableList<Card> }
        val rest = need.copyOf()
        val cards = ArrayList(unseen); java.util.Collections.shuffle(cards, rnd)
        val order = cards.sortedBy { c -> (0 until n).count { it != seat && !voids[it][c.s] } }
        for (c in order) {
            var tot = 0
            val ok = ArrayList<Int>()
            for (s in 0 until n) if (s != seat && rest[s] > 0 && !voids[s][c.s]) { ok.add(s); tot += rest[s] }
            if (ok.isEmpty()) for (s in 0 until n) if (s != seat && rest[s] > 0) { ok.add(s); tot += rest[s] }
            if (ok.isEmpty()) break
            var r = rnd.nextInt(tot)
            var pick = ok[0]
            for (s in ok) { if (r < rest[s]) { pick = s; break }; r -= rest[s] }
            hands[pick].add(c); rest[pick]--
        }
        return hands
    }

    /** how well a deal agrees with the way the others played (1 = fully) */
    private fun weightOf(hs: Array<MutableList<Card>>, s: Int, plays: List<AiPlay>): Double {
        var w = 1.0
        for (i in plays.indices) {
            val e = plays[i]; val x = e.seat
            val bc = e.bc
            if (x == s || e.len == 0 || bc == null) continue
            val hand = ArrayList<Card>(hs[x])
            for (k in i until plays.size) if (plays[k].seat == x) hand.add(plays[k].c)
            val pwin = e.bs != x && e.bs >= 0 && teamOf(e.bs) == teamOf(x)
            if (e.c.s == e.led) {
                val wins = !pwin && HokmRules.beats(e.c, bc, trump)
                if (hand.any { it.s == e.led && it.r < e.c.r && (if (wins) HokmRules.beats(it, bc, trump) else true) }) w *= 0.3
            } else if (e.c.s != trump && !pwin && hand.any { it.s == trump && HokmRules.beats(it, bc, trump) }) {
                w *= 0.2
            }
        }
        return w
    }

    // ------------------------------------------------------------------ the decision

    /**
     * the card for [seat]: [deck] = all the cards of this game, [seenIn] = the cards played so far in this round (the trick included),
     * [counts] = how many cards each seat holds, [voids] = suits a seat has shown it does not have, [plays] = the cards of this round in order
     */
    fun choose(seat: Int, myHand: List<Card>, trick: List<TC>, seenIn: BooleanArray, deck: List<Card>, counts: IntArray,
               voids: Array<BooleanArray>, tricksWon: IntArray, kt: Int, roundSize: Int, plays: List<AiPlay>): Card {
        val legal = HokmRules.legal(myHand, trick)
        if (legal.size == 1) return legal[0]
        sizeR = roundSize
        val inTrick = HashSet<Int>(); for (t in trick) inTrick.add(id(t.c))
        val inert = { x: Int, r: Int -> myHand.any { it.s == x && it.r == r } || (seenIn[x * 20 + r] && !inTrick.contains(x * 20 + r)) }
        val cand = legal.filter { c -> !legal.any { d -> d.s == c.s && d.r < c.r && (d.r + 1 until c.r).all { r -> inert(c.s, r) } } }
            .sortedBy { it.s * 20 + it.r }
        if (cand.size == 1) return cand[0]
        val unseen = deck.filter { c -> !seenIn[id(c)] && myHand.none { it.s == c.s && it.r == c.r } && trick.none { it.c.s == c.s && it.c.r == c.r } }
            .sortedBy { id(it) }
        val my = teamOf(seat)
        rnd = Random()
        val exact = myHand.size <= profile.exactCards
        var mxT = 0; for (t in 0 until teams) mxT = Math.max(mxT, tricksWon[t])
        val bamZone = kt >= 0 || (mxT >= spec.kotTricks - 2 && (0 until teams).count { tricksWon[it] > 0 } == 1)
        val budget = Engine4.BOT_MS * profile.budgetFactor * (if (bamZone) 1.5 else 1.0)
        val t0 = System.currentTimeMillis()
        val lastSeat = trick.size == n - 1
        val best0 = if (trick.isNotEmpty()) HokmRules.winnerOf(trick, trump) else null
        val partnerWins = best0 != null && best0.seat != seat && teamOf(best0.seat) == my
        val bias = { c: Card ->
            if (!lastSeat || best0 == null) 0.0 else {
                val cw = HokmRules.beats(c, best0.c, trump)
                var p = 0.0
                if (partnerWins && cw) p += 0.012
                if (partnerWins && c.s == trump && best0.c.s != trump) p += 0.012
                if (!partnerWins && !cw && c.s == trick[0].c.s && legal.any { HokmRules.beats(it, best0.c, trump) }) p += 0.012
                p
            }
        }
        val lrT = profile.hakemLR
        val score = DoubleArray(cand.size)
        var k = 0
        while (k < 4000 && ((k < Engine4.MIN_N || System.currentTimeMillis() - t0 < budget) && (k < 3 || System.currentTimeMillis() - t0 < budget * 2.5))) {
            k++
            val dealt = deal(unseen, counts, seat, voids)
            val hands = Array(n) { i -> if (i == seat) ArrayList(myHand) as MutableList<Card> else dealt[i] }
            var lr = 1.0
            if (seat != hakem && trump >= 0 && hakem in 0 until n) lr = Math.sqrt(lrT[Math.min(lrT.size - 1, hands[hakem].count { it.s == trump })])
            val w = weightOf(hands, seat, plays) * lr
            for ((ci, c) in cand.withIndex()) {
                var v: Double? = null
                if (exact) v = exactValue(hands, seat, c, trick, tricksWon, kt, my, 3500)
                if (v == null) {
                    val hs2 = Array(n) { i -> ArrayList(hands[i]) as MutableList<Card> }
                    hs2[seat].remove(c)
                    val tr = ArrayList(trick); tr.add(TC(seat, c))
                    val sn = seenIn.copyOf(); sn[id(c)] = true
                    v = rollout(hs2, tr, (seat + 1) % n, sn, tricksWon, kt, my, voids)
                }
                score[ci] += w * (v - 0.0008 * (c.r / 14.0 + (if (c.s == trump) 0.3 else 0.0)) - bias(c))
            }
        }
        var bi = 0
        for (i in cand.indices) if (score[i] > score[bi]) bi = i
        return cand[bi]
    }

    // ------------------------------------------------------------------ the trump

    private fun playOut(hands: Array<MutableList<Card>>, leader: Int, my: Int, size: Int): Double {
        sizeR = size
        val noVoids = Array(n) { BooleanArray(4) }
        return rollout(Array(n) { ArrayList(hands[it]) as MutableList<Card> }, emptyList(), leader, BooleanArray(80), IntArray(6), -1, my, noVoids)
    }

    /** the trump for the hakem [seat] who holds [first] of the cards: the same deals are played out with every suit as the trump */
    fun chooseTrump(seat: Int, first: List<Card>, deck: List<Card>, size: Int): Int {
        val unseen = deck.filter { c -> first.none { it.s == c.s && it.r == c.r } }.sortedBy { id(it) }
        val my = teamOf(seat)
        rnd = Random()
        val ens = Array(4) { sx -> forTrump(sx).also { it.scores = scores } }
        val tot = DoubleArray(4)
        val t0 = System.currentTimeMillis()
        var k = 0
        while (k < 600 && (k < 150 || System.currentTimeMillis() - t0 < Engine4.TRUMP_MS * profile.budgetFactor)) {
            val sh = ArrayList(unseen); java.util.Collections.shuffle(sh, rnd)
            val hands = Array(n) { ArrayList<Card>() as MutableList<Card> }
            hands[seat].addAll(first)
            var p = 0
            for (x in 0 until size - first.size) hands[seat].add(sh[p++])
            for (o in 0 until n) if (o != seat) for (x in 0 until size) hands[o].add(sh[p++])
            for (s in 0 until 4) tot[s] += ens[s].playOut(hands, seat, my, size)
            k++
        }
        var bestS = 0; var bestV = -1e9
        for (s in 0 until 4) {
            val v = tot[s] + trumpBias(first, s)
            if (v > bestV) { bestV = v; bestS = s }
        }
        return bestS
    }
}

// ====================================================================== the four engines

/** Three players, everybody alone: 17 tricks, 51 cards. The hand ends when one player cannot be passed any more. */
class Hok3Engine(trump: Int, hakem: Int) : HokmEngine(3, 3, trump, hakem, PROFILE) {
    override fun forTrump(t: Int): HokmEngine = Hok3Engine(t, hakem)
    companion object {
        val PROFILE = EngineProfile(
            "hokm-3", secThr = 0.55, secGain = 0.25, winRisk = 2.0, hiRisk = 2.0, voidW = 0.3, drawLen = 3, allDraw = true,
            ruffW = 5.0, hiW = 0.25, lenW = 0.0,
            hakemLR = doubleArrayOf(0.1, 0.1, 0.17, 0.46, 0.84, 1.28, 1.74, 2.2, 2.65, 2.96, 2.96, 2.96, 2.96, 2.96, 2.96, 2.96, 2.96, 2.96),
            exactCards = 5, budgetFactor = 1.0
        )
    }
}

/** Five players, everybody alone: 10 tricks, 50 cards, the hakem sees only 4 cards before he names the trump. */
class Hok5Engine(trump: Int, hakem: Int) : HokmEngine(5, 5, trump, hakem, PROFILE) {
    override fun forTrump(t: Int): HokmEngine = Hok5Engine(t, hakem)
    companion object {
        val PROFILE = EngineProfile(
            "hokm-5", secThr = 0.55, secGain = 0.25, winRisk = 2.0, hiRisk = 2.0, voidW = 0.3, drawLen = 2, allDraw = true,
            ruffW = 5.0, hiW = 0.5, lenW = 0.0,
            hakemLR = doubleArrayOf(0.1, 0.1, 0.57, 1.26, 2.01, 2.75, 3.33, 3.75, 3.75, 3.75, 3.75),
            exactCards = 3, budgetFactor = 1.0
        )
    }
}

/** Six players, two teams of three (seats 0-2-4 against 1-3-5): 8 tricks, 48 cards. Two partners may still play behind you. */
class Hok6x3Engine(trump: Int, hakem: Int) : HokmEngine(6, 62, trump, hakem, PROFILE) {
    override fun forTrump(t: Int): HokmEngine = Hok6x3Engine(t, hakem)
    companion object {
        val PROFILE = EngineProfile(
            "hokm-6x3", secThr = 0.55, secGain = 0.1, winRisk = 0.45, hiRisk = 2.0, voidW = 0.3, drawLen = 2, allDraw = true,
            ruffW = 5.0, hiW = 0.25, lenW = 1.0,
            hakemLR = doubleArrayOf(0.1, 0.34, 0.92, 1.63, 2.4, 3.09, 3.69, 3.69, 3.69),
            exactCards = 3, budgetFactor = 1.1
        )
    }
}

/** Six players, three teams of two (partners sit opposite: 0-3, 1-4, 2-5): 8 tricks, 48 cards. */
class Hok6x2Engine(trump: Int, hakem: Int) : HokmEngine(6, 63, trump, hakem, PROFILE) {
    override fun forTrump(t: Int): HokmEngine = Hok6x2Engine(t, hakem)
    companion object {
        val PROFILE = EngineProfile(
            "hokm-6x2", secThr = 0.55, secGain = 0.25, winRisk = 0.8, hiRisk = 2.0, voidW = 0.3, drawLen = 2, allDraw = true,
            ruffW = 5.0, hiW = 0.25, lenW = 1.0,
            hakemLR = doubleArrayOf(0.1, 0.34, 0.92, 1.63, 2.4, 3.09, 3.69, 3.69, 3.69),
            exactCards = 3, budgetFactor = 1.1
        )
    }
}

/** the engine of a kind of the game: 3, 5, 62 (6 players, 2 teams of 3), 63 (6 players, 3 teams of 2) */
object HokmEngines {
    @JvmStatic
    fun create(kind: Int, trump: Int, hakem: Int): HokmEngine = when (kind) {
        3 -> Hok3Engine(trump, hakem)
        5 -> Hok5Engine(trump, hakem)
        62 -> Hok6x3Engine(trump, hakem)
        else -> Hok6x2Engine(trump, hakem)
    }
}
