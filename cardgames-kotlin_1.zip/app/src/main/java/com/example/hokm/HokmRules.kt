package com.example.hokm

/**
 * The rules and the words of Hokm that every game of the program shares: the two- and four-player games (Engine4, Engine2, Flow4)
 * and the games for three, five and six players (HokmN, HokmSim). One place, so that the games cannot drift apart.
 */
object HokmRules {
    /** does card [a] beat card [b] (b was played earlier in the trick) */
    fun beats(a: Card, b: Card, trump: Int): Boolean = if (a.s == b.s) a.r > b.r else (a.s == trump && b.s != trump)

    /** the card of the trick that wins it */
    fun winnerOf(t: List<TC>, trump: Int): TC {
        var w = t[0]
        for (p in t) if (beats(p.c, w.c, trump)) w = p
        return w
    }

    /** the cards that may be played: the led suit when the hand has it, else any card */
    fun legal(h: List<Card>, trick: List<TC>): List<Card> {
        if (trick.isEmpty()) return h
        val led = trick[0].c.s
        val f = h.filter { it.s == led }
        return if (f.isNotEmpty()) f else h
    }

    /** the points of a hand: 1; kot 2 when the hakem's side wins it, 3 against the hakem's side */
    fun gain(kot: Boolean, winnerIsHakemSide: Boolean): Int = if (kot) (if (winnerIsHakemSide) 2 else 3) else 1

    fun bamName(winnerIsHakemSide: Boolean): String = if (winnerIsHakemSide) "بام" else "پر بام"

    /**
     * The words about the end of a hand from the view of a player. [mine] = the winning side is the viewer's side, [teams] = number of sides
     * (2 = "تیم شما" / "تیم حریف"; as many as players = every player alone, called "شما"), [otherName] = the name of the winning side when it is not the viewer's.
     */
    fun roundText(mine: Boolean, teams: Int, players: Int, otherName: String, bam: Boolean, bn: String, gm: Boolean, kot: Boolean, hakemSide: Boolean): String {
        val l = if (mine) (if (teams == players) "شما" else "تیم شما") else (if (teams == 2) "تیم حریف" else otherName)
        val you = mine && teams == players
        fun vb(a: String, b: String) = if (you) a else b
        return if (bam) l + " " + bn + " " + vb("کردید", "کرد") + " و بازی را " + vb("بردید", "برد") + (if (mine) "!" else ".")
            else if (gm) l + " بازی را " + vb("بردید", "برد") + (if (mine) "!" else ".")
            else l + " این دست را " + vb("بردید", "برد") + (if (kot) (if (hakemSide) " (کوت! ۲ امتیاز)" else " (حاکم‌کوت! ۳ امتیاز)") else " (۱ امتیاز)") + ". "
    }

    /** the words after a trick that did not end the hand; [tally] = the tricks of the sides, see tallyTeams */
    fun trickText(whoName: String, you: Boolean, tally: String): String = whoName + (if (you) " دست را بردید. " else " دست را برد. ") + tally

    /** told to a phone that is connected but has no place at the table when the game starts (every Hokm, every number of players) */
    const val NO_SEAT = "جایی برای شما در این بازی نیست. بازی بدون شما شروع شد و وصل می‌مانید؛ اگر میزبان شما را اضافه کند یا بازی بعدی شروع شود، وارد می‌شوید."

    /** the host pressed start and nobody has joined yet; [title] = e.g. «چهار نفره» */
    fun needPlayer(title: String): String = "برای بازی " + title + " باید دست‌کم یک بازیکن بپیوندد."

    fun tallyTeams(mine: Int, others: Int): String = "تیم شما " + mine + "، حریف " + others + "."
}
