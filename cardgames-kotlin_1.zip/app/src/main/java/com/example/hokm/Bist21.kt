package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.CheckBox
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Rules of Iranian "بیست و یک" (36 cards: 6..10, J, Q, K, A). Pure logic, no UI. */
object Bist {
    /** card values: A 11, K 4, Q 3, J 2, others their number */
    fun value(r: Int): Int = when (r) { 14 -> 11; 13 -> 4; 12 -> 3; 11 -> 2; else -> r }

    class Total(@JvmField val t: Int, @JvmField val pair: Boolean)

    /** two aces (and only two cards) count 21 */
    fun total(h: List<Card>): Total {
        val pair = h.size == 2 && h[0].r == 14 && h[1].r == 14
        var sum = 0
        for (c in h) sum += value(c.r)
        return Total(if (pair) 21 else sum, pair)
    }

    /** a tie goes to the banker; a player who burned (over 21) has already lost */
    fun playerWins(p: Int, b: Int): Boolean = p <= 21 && (b > 21 || p > b)

    fun newDeck(): MutableList<Card> {
        val d = ArrayList<Card>()
        for (s in 0 until 4) for (r in 6..14) d.add(Card(s, r))
        Cards.shuf(d)
        return d
    }
}

/**
 * The 21 game screen. It is drawn over the main menu (a full-screen overlay) and uses the app
 * settings: name, sounds, card back, table, animation speed, screen-reader mode.
 * The game itself runs on a worker thread that waits for the player's taps (like the page's async code).
 */
class Bist21(private val act: MainActivity, private val app: App) {
    private val NM21 = listOf("علی", "ندا", "رضا", "سارا", "امیر", "مینا", "کیان", "نرگس", "پویا", "هانیه")

    // ---- game options and state ----
    private var bots = 3
    private var base = 100000L
    private var minBet = 5000L
    // "تغییر ژتون": each person can have his own smallest bet (0 = the table's); the bank can change while it is played
    private val minArr = LongArray(10)
    private fun mn(s: Int): Long = if (s in 0 until 10 && minArr[s] > 0L) minArr[s] else minBet
    private var voteId = 0
    @Volatile private var voteRound: ChipVote.Round? = null
    private val chipLock = Any()
    private var keepMins = false
    /** while a chip vote is open the game waits (no bet, card or answer goes on), so the table cannot change under the vote */
    private fun waitVote() { while (voteRound != null && alive) Thread.sleep(100) }
    private val cooldownAt = HashMap<Int, Long>()
    private var side = false
    private var khabreMul = 3               // the banker may say "بانک خبره" and take the bank when it is this many times the first bank
    private var dealAll = false             // false: deal to the right-hand player and play with him, then the next; true: one card to everybody first
    private fun khabreAmt(): Long = base * khabreMul
    private val khabreMuls = listOf(2, 3, 4, 5, 10)

    private var n = 0
    private var chips = LongArray(0)
    private var names: List<String> = emptyList()
    private var bank = 0L
    private var bk = -1
    private var cur = -1
    @Volatile private var mine: MutableList<Card> = ArrayList()
    @Volatile private var bh: MutableList<Card> = ArrayList()
    private val seen = ArrayList<Card>()
    /** the totals each seat stopped on (without burning) in this game: the robot banker learns from them how that player stops */
    private val stopTot = Array(10) { IntArray(22) }
    private var reveal = false
    /** the first card of the banker is face up for everybody (the side-bet rule is on: the first cards are read out) */
    private var firstUp = false
    private var msg = ""
    private var over = false      // the game is over: only the "بازی جدید" / exit button is left (as in Hokm)

    // ---- multi-phone: role "solo" (robots only) | "host" (runs the game) | "guest" (only shows it) ----
    @JvmField var role = "solo"
    @JvmField var mySeat = 0
    @Volatile var started = false
    private val freeAt = LongArray(10)
    @JvmField var isSucc = false
    @JvmField var succRank = -1                        // guest: my place in the line of those who take over when the host drops out (as in the Hokm)
    val failMs: Long get() = 10000L + Math.max(0, succRank) * 8000L
    private var syncSnap: JSONObject? = null
    @JvmField var roomCode = ""
    private val remote = BooleanArray(10)
    private val cidOf = IntArray(10) { -1 }
    private val idOf = Array(10) { "" }
    private val ansQ = Array(10) { LinkedBlockingQueue<String>() }
    @Volatile private var askSeq = 0
    @Volatile private var curHand: MutableList<Card> = ArrayList()
    private var net: Net21? = null
    private var lastGo: JSONObject? = null

    @Volatile private var alive = false
    private var worker: Thread? = null
    private val answers = LinkedBlockingQueue<String>()

    // ---- views ----
    private val ov = FrameLayout(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)
    private lateinit var gameV: LinearLayout
    private lateinit var bankTv: TextView
    private lateinit var msgTv: TextView
    private lateinit var playersV: FrameLayout
    private lateinit var felt: LinearLayout
    private lateinit var bankerLab: TextView
    private lateinit var bankerV: com.example.hokm.FlowLayout
    private lateinit var mineLab: TextView
    private lateinit var mineV: com.example.hokm.FlowLayout
    private lateinit var ctl: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var gameScroll: ScrollView
    private lateinit var logBox: LinearLayout
    private var screen = "menu"
    private var lastMsg = ""
    private var lastMine = ""
    private var lastBank = ""
    private var lastMineN = 0
    private var lastReveal = false
    private var lastBhN = 0
    private var lastMineKey = ""
    private var lastTurnTotal = ""
    private var lastBankKey = ""
    private lateinit var deckV: ImageView
    @Volatile private var held = false
    private lateinit var holdBar: LinearLayout
    private lateinit var holdTv: TextView

    // ------------------------------------------------------------------ shell

    // ---- small UI helpers (also used by Net21) ----

    /** run on the UI thread (the game itself runs on a worker thread) */
    fun ui(f: () -> Unit) {
        act.runOnUiThread { try { f() } catch (e: Exception) { } }
    }

    fun tv(t: String, size: Float = 15f, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    /** a screen title; TalkBack treats it as a heading */
    fun heading(t: String): TextView {
        val v = tv(t, 22f, Px.tx, true)
        v.gravity = Gravity.CENTER
        v.setPadding(0, Px.dp(8), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) v.isAccessibilityHeading = true
        return v
    }

    /** the green rounded menu button */
    fun mbtn(t: String, f: () -> Unit): android.widget.Button {
        val b = app.dlg.btn(t, true, f)
        val l = LinearLayout.LayoutParams(
            Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)),
            ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    /** show one screen (menu, setup, saves, net, game) in the overlay */
    fun setScreen(name: String, v: View) {
        screen = name
        content.removeAllViews()
        content.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (name == "game") app.hideKeyboard()
    }


    fun show(start: String, ad: ((Net21) -> Unit)? = null) {
        ov.layoutDirection = View.LAYOUT_DIRECTION_RTL
        ov.setBackgroundColor(Px.bg)
        ov.isClickable = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        val sc = ScrollView(act); gameScroll = sc
        sc.isFillViewport = true
        sc.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.addView(sc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.root.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        app.menuShown(false)
        act.onBack = { back() }
        if (start == "resume") { showSaves() }
        else if (start == "net") { val nt = Net21(act, app, this); net = nt; nt.show() }
        else if (start == "adopt") { val nt = Net21(act, app, this); net = nt; ad?.invoke(nt) }
        else if (start == "blank") { }
        else showSetup()
    }

    /** closes this screen but keeps the links: the lobby has changed to another game (the other game takes the phones over) */
    fun detach() {
        stopGame()
        net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        act.onBack = { app.back() }
        act.btEvt = null
    }

    /** leave the 21 game and return to the main menu */
    fun close() {
        stopGame()
        net?.close(); net = null
        started = false
        try { act.root.removeView(ov) } catch (e: Exception) { }
        app.menuShown(true)
        app.syncBg()
        act.onBack = { app.back() }
        act.btEvt = null
        app.pageClosed()
    }

    /** does the phone with connection id [cid] have a seat in the running game */
    fun hasSeat(cid: Int): Boolean = cidOf.indexOf(cid) >= 1

    private fun back(): Boolean {
        if (screen == "net" && net?.back() == true) return true
        if (screen == "game") { backAsk(); return true }   // one step back (asks first)
        net?.leave(); close()
        return true
    }

    private fun showSaves() {
        val l = Saves.all(false)
        if (l.isEmpty()) { app.dlg.message("بازی ذخیره‌شده‌ای وجود ندارد."); close(); return }
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(heading("بازی‌های قبلی"))
        for (e in l) v.addView(mbtn(Saves.describe(e)) { saveActions(e) })
        setScreen("saves", v)
    }

    private fun saveActions(e: Saves.E) {
        app.dlg.list(Saves.describe(e), listOf(
            "ادامه بازی" to { resumeFrom(e) },
            "حذف" to { app.dlg.confirm(Msg.DEL_SAVE, { Saves.del(e.id); showSaves() }) }
        ), "بستن")
    }

    /** the setup page is built into the main menu's "بازی جدید" page (under the game type); the screen of this game opens when "شروع بازی" is pressed */
    private var embedded = false
    private fun ensureShown() { if (embedded) { embedded = false; show("blank") } }
    fun setupBody(): LinearLayout { embedded = true; return buildSetup() }

    private fun showSetup() {
        embedded = false
        val v0 = LinearLayout(act); v0.orientation = LinearLayout.VERTICAL
        v0.addView(heading("بازی جدید"))
        v0.addView(buildSetup())
        setScreen("setup", v0)
    }

    private fun buildSetup(): LinearLayout {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL
        v.addView(tv("سکه‌های شما: " + Cards.fa(Prefs.wallet), 16f, Px.GOLD, true))
        v.addView(tv("تعداد بازیکن‌ها", 16f))
        val spN = Spinner(act)
        spN.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, (2..10).map { Cards.fa(it) + " نفره" })
        spN.setSelection(0)
        spN.speakLabel("تعداد بازیکن‌ها")
        v.addView(spN, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        v.addView(tv("بانک اولیه", 16f))
        val e1 = numField(act, "بانک اولیه", base)
        v.addView(e1, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        v.addView(tv("کمترین شرط", 16f))
        val e2 = numField(act, "کمترین شرط", minBet)
        v.addView(e2, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        v.addView(tv("بانک خبره", 16f))
        val spK = Spinner(act)
        spK.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, khabreMuls.map { Cards.fa(it) + " برابر بانک اولیه" })
        spK.setSelection(khabreMuls.indexOf(khabreMul).coerceAtLeast(0))
        spK.speakLabel("مقدار بانک خبره")
        v.addView(spK, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        v.addView(tv("نحوهٔ پخش کارت", 16f))
        val spD = Spinner(act)
        spD.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, listOf("به نوبت", "اول به همه"))
        spD.setSelection(0)
        spD.speakLabel("نحوهٔ پخش کارت")
        v.addView(spD, LinearLayout.LayoutParams(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        val cb = CheckBox(act); cb.text = "شرط روی دست دیگران (خواندن)"; cb.isChecked = side
        cb.setTextColor(Px.tx)
        v.addView(cb)
        Mem.spinner("b21.n", spN); Mem.field("b21.base", e1); Mem.field("b21.min", e2)      // the choices stay when the page is opened again
        Mem.spinner("b21.k", spK); Mem.spinner("b21.d", spD); Mem.check("b21.side", cb)
        val goB = mbtn("شروع بازی") {
            app.hideKeyboard()
            val nb = Cards.num(e1.text.toString()); val nm = Cards.num(e2.text.toString())
            if (nb < 1) { app.dlg.message("بانک اولیه را به‌صورت عدد (دست‌کم ۱) تایپ کنید."); return@mbtn }
            if (nm < 1) { app.dlg.message("کمترین شرط را به‌صورت عدد (دست‌کم ۱) تایپ کنید."); return@mbtn }
            if (nm > nb) { app.dlg.message("کمترین شرط نباید از بانک اولیه بیشتر باشد."); return@mbtn }
            bots = spN.selectedItemPosition + 1; base = nb; minBet = nm; side = cb.isChecked
            khabreMul = khabreMuls[spK.selectedItemPosition]; dealAll = spD.selectedItemPosition == 1
            if (Prefs.wallet < minBet) { app.dlg.message("سکه‌های شما از کمترین شرط کمتر است. کمترین شرط را کمتر کنید."); return@mbtn }
            ensureShown()
            startNew()
        }
        v.addView(goB)
        e1.onNext(e2); e2.onDone { goB.performClick() }
        return v
    }

    // ------------------------------------------------------------------ game start / resume / save

    private fun startNew() {
        role = "solo"; mySeat = 0; remote.fill(false); held = false
        n = bots + 1
        chips = LongArray(n) { if (it == 0) Prefs.wallet else robotStart() }
        names = listOf(if (Prefs.name.isEmpty()) "شما" else Prefs.name) + Names.pickNames(bots)
        bk = -1
        startGame()
    }

    private fun resumeFrom(e: Saves.E) {
        try {
            val j = JSONObject(e.data)
            role = "solo"; mySeat = 0; remote.fill(false); held = false
            bots = j.getInt("bots"); base = j.getLong("base"); minBet = j.getLong("min"); side = j.getBoolean("side")
            khabreMul = j.optInt("khabreMul", 3); dealAll = j.optBoolean("dealAll", false)
            val c = j.getJSONArray("chips"); val nm = j.getJSONArray("names")
            n = c.length()
            chips = LongArray(n) { c.getLong(it) }
            chips[0] = Prefs.wallet
            names = List(n) { nm.getString(it) }
            bk = j.getInt("bk")
            minArr.fill(0L); j.optJSONArray("mins")?.let { a -> for (i in 0 until Math.min(10, a.length())) minArr[i] = a.optLong(i, 0L) }
            keepMins = true
            startGame()
        } catch (x: Exception) { app.dlg.message("بازی ذخیره‌شده پیدا نشد."); close() }
    }

    /** the state at the end of the last hand (a game can only be saved or handed over there) */
    private var bChips = LongArray(0)
    private var bBk = -1

    private fun soloJson(): String {
        val j = JSONObject()
        j.put("bots", bots); j.put("base", base); j.put("min", minBet); j.put("side", side); j.put("khabreMul", khabreMul); j.put("dealAll", dealAll)
        j.put("chips", JSONArray(bChips.toList())); j.put("names", JSONArray(names)); j.put("bk", bBk)
        j.put("mins", JSONArray((0 until 10).map { minArr[it] }))
        return j.toString()
    }

    /** "ذخیره" in the game menu */
    private fun manualSave() {
        try {
            val where: String
            if (role == "solo") { Saves.put("s" + System.currentTimeMillis(), false, soloJson()); where = "بازی با ربات" }
            else if (role == "host") { Saves.put("s" + System.currentTimeMillis(), true, snapshot().toString()); where = "بازی با چند گوشی" }
            else { app.dlg.list("فقط میزبان می‌تواند بازی را ذخیره کند.", listOf(), "باشه"); return }
            app.dlg.list("بازی ذخیره شد. هر وقت خواستید از «بازی‌های قبلی» در بخش «" + where + "» ادامه‌اش دهید.", listOf(), "باشه")
        } catch (e: Exception) { app.dlg.list("ذخیرهٔ بازی ممکن نشد.", listOf(), "باشه") }
    }

    private fun startGame() {
        stopGame()
        bank = 0; cur = -1; mine = ArrayList(); bh = ArrayList(); seen.clear(); reveal = false; firstUp = false; msg = ""; over = false
        bChips = chips.copyOf(); bBk = bk
        lastMsg = ""; lastMine = ""; lastBank = ""
        Spk.reset(); Sound.resetQueue()
        buildGameView()
        alive = true
        started = true
        bChips = chips.copyOf(); bBk = bk
        if (role == "host") { lastGo = null; for (q in 1 until n) if (remote[q]) sendSeat(q, goMsg(q)); syncSucc() }
        val t = Thread {
            try { loop() } catch (e: InterruptedException) { } catch (e: Exception) { }
        }
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun stopGame() {
        alive = false
        voteRound?.cancel(); voteRound = null
        worker?.interrupt()
        worker = null
    }

    // ------------------------------------------------------------------ game view

    private fun buildGameView() {
        gameV = LinearLayout(act); gameV.orientation = LinearLayout.VERTICAL
        gameV.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))

        val more = LinearLayout(act); more.orientation = LinearLayout.HORIZONTAL
        more.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val mb = TextView(act)
        mb.text = "⋮"; mb.textSize = 26f; mb.setTextColor(Color.WHITE); mb.gravity = Gravity.CENTER
        mb.background = Px.rounded(0x59000000, 20)
        mb.contentDescription = "گزینه‌های بیشتر"
        mb.isClickable = true; mb.isFocusable = true
        mb.setOnClickListener { gameMenu() }
        more.addView(mb, LinearLayout.LayoutParams(Px.dp(40), Px.dp(40)))
        gameV.addView(more)
        // the screen is laid out as in Hokm: the status line, the felt table with the players around it, the message, the buttons, the log and the hands
        val top = FlowLayout(act, Px.dp(10), Px.dp(2))
        bankTv = tv("", 16f, Px.GOLD, true)
        top.addView(bankTv)
        gameV.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin = Px.dp(6) })
        val ringBox = FrameLayout(act)
        playersV = FrameLayout(act)
        playersV.layoutDirection = View.LAYOUT_DIRECTION_LTR
        ringBox.addView(playersV, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        deckV = ImageView(act)
        val backBmp = Assets.bitmap(act, Assets.backPath(Prefs.back))
        if (backBmp != null) deckV.setImageBitmap(backBmp)
        deckV.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        ringBox.addView(deckV, FrameLayout.LayoutParams(Px.dp(46), Px.dp(64), Gravity.CENTER))
        felt = LinearLayout(act); felt.orientation = LinearLayout.VERTICAL
        felt.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        felt.addView(ringBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(if (n > 6) 290 else 230)))
        gameV.addView(felt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        applyBg()
        msgTv = tv("", 14f, Color.WHITE); msgTv.gravity = Gravity.CENTER; msgTv.minimumHeight = Px.dp(44)
        msgTv.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_NONE
        gameV.addView(msgTv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8); it.bottomMargin = Px.dp(8) })
        ctl = LinearLayout(act); ctl.orientation = LinearLayout.VERTICAL
        gameV.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        // the log as in Hokm: every line is a view of its own in a box of fixed height, at most 12 lines, each one gone after 6 seconds
        logScroll = ScrollView(act)
        logScroll.background = Px.rounded(0x11000000, 8)
        logScroll.setPadding(Px.dp(6), Px.dp(6), Px.dp(6), Px.dp(6))
        logBox = LinearLayout(act); logBox.orientation = LinearLayout.VERTICAL
        logScroll.addView(logBox)
        gameV.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Px.dp(140)).also { it.topMargin = Px.dp(8); it.bottomMargin = Px.dp(6) })
        logScroll.visibility = if (Prefs.a11y) View.VISIBLE else View.GONE
        holdBar = LinearLayout(act); holdBar.orientation = LinearLayout.VERTICAL; holdBar.visibility = View.GONE
        holdTv = tv("", 14f, 0xFFFFE36B.toInt(), true)
        holdBar.addView(holdTv)
        holdBar.addView(app.dlg.btn("ادامه بازی", true) { resumeHold() })
        gameV.addView(holdBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(8) })
        bankerLab = tv("بانکدار", 14f, 0xFFD8CDB4.toInt())
        gameV.addView(bankerLab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        bankerV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(bankerV)
        mineLab = tv("کارت‌های شما", 14f, 0xFFD8CDB4.toInt())
        gameV.addView(mineLab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = Px.dp(10) })
        mineV = FlowLayout(act, Px.dp(6), Px.dp(6))
        gameV.addView(mineV)
        lastMineN = 0; lastBhN = 0; lastMineKey = ""; lastBankKey = ""; lastReveal = false; lastTurnTotal = ""
        mineLab.isFocusable = true; bankerLab.isFocusable = true
        setScreen("game", gameV)
    }

    private fun cardView(c: Card, hidden: Boolean): View {
        val iv = ImageView(act)
        val bmp = Assets.bitmap(act, if (hidden) Assets.backPath(Prefs.back) else Assets.cardPath(c))
        if (bmp != null) iv.setImageBitmap(bmp)
        iv.tag = bmp
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.contentDescription = if (hidden) "کارت رونشده" else Cards.cname(c)
        iv.layoutParams = ViewGroup.LayoutParams(Px.dp(46), Px.dp(64))
        return iv
    }

    /** puts the players on an oval: our seat at the bottom, the others round the table */
    private fun placeRing() {
        val w = playersV.width; val h = playersV.height
        val cnt = playersV.childCount
        if (w <= 0 || h <= 0 || cnt == 0) return
        for (k in 0 until cnt) {
            val c = playersV.getChildAt(k)
            c.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            val cw = c.measuredWidth.toFloat(); val ch = c.measuredHeight.toFloat()
            val ang = Math.PI / 2 + 2 * Math.PI * k / cnt
            c.translationX = (w / 2f + (w / 2f - cw / 2f) * Math.cos(ang) - cw / 2f).toFloat()
            c.translationY = (h / 2f + (h / 2f - ch / 2f) * Math.sin(ang) - ch / 2f).toFloat()
        }
        // the deck lies beside the banker (between his seat and the middle of the table)
        if (::deckV.isInitialized) {
            var dx = 0f; var dy = 0f
            if (bk >= 0 && n > 0) {
                val kb = ((bk - mySeat) % n + n) % n
                if (kb < cnt) {
                    val bc = playersV.getChildAt(kb)
                    val bx = bc.translationX + bc.measuredWidth / 2f; val by = bc.translationY + bc.measuredHeight / 2f
                    val cx = w / 2f; val cy = h / 2f
                    val len = Math.hypot((cx - bx).toDouble(), (cy - by).toDouble()).toFloat()
                    if (len > 1f) {
                        val off = bc.measuredHeight / 2f + Px.dp(64) / 2f + Px.dp(4)
                        dx = bx + (cx - bx) / len * off - cx; dy = by + (cy - by) / len * off - cy
                    }
                }
            }
            deckV.animate().translationX(dx).translationY(dy).setDuration(Anim.ad(300L)).start()
        }
    }

    /** cards that were just dealt slide in from above */
    private fun loc(v: View): IntArray { val a = IntArray(2); v.getLocationInWindow(a); return a }

    /** new cards fly from the deck to their place and turn over there */
    private fun animNew(row: ViewGroup, prev: Int) {
        val back = Assets.bitmap(act, Assets.backPath(Prefs.back))
        for (i in prev until row.childCount) {
            val v = row.getChildAt(i)
            val iv = v as? ImageView
            val face = v.tag as? android.graphics.Bitmap
            val flip = iv != null && face != null && back != null && face !== back
            if (flip) iv!!.setImageBitmap(back)
            v.alpha = 0f
            val order = i - prev
            v.post {
                try {
                    if (!v.isAttachedToWindow || !::deckV.isInitialized) { v.alpha = 1f; if (flip) iv!!.setImageBitmap(face); return@post }
                    val sv: View = deckV
                    val a = loc(sv); val b = loc(v)
                    v.translationX = a[0] + (sv.width - v.width) / 2f - b[0]; v.translationY = a[1] + (sv.height - v.height) / 2f - b[1]
                    dealGesture(v)
                    v.scaleX = 0.7f; v.scaleY = 0.7f; v.rotation = -25f; v.alpha = 1f
                    v.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).rotation(0f)
                        .setDuration(Anim.ad(380L)).setStartDelay(Anim.ad(80L * order))
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .withEndAction {
                            if (flip) iv!!.animate().scaleX(0f).setDuration(Anim.ad(90L)).withEndAction {
                                iv.setImageBitmap(face); iv.animate().scaleX(1f).setDuration(Anim.ad(90L)).start()
                            }.start()
                        }.start()
                } catch (e: Exception) { v.alpha = 1f; if (flip) iv!!.setImageBitmap(face) }
            }
        }
    }

    /** a card flies from the deck to another player's seat (their cards are not shown, so only the movement is) */
    /** the table seat (the round cell with the face) of a player */
    private fun cellOf(seat: Int): View? {
        if (seat < 0 || n <= 0 || !::playersV.isInitialized) return null
        val k = ((seat - mySeat) % n + n) % n
        return if (k < playersV.childCount) playersV.getChildAt(k) else null
    }

    /** where dealt cards start: the banker's seat (the deck for the banker's own card) */
    private fun dealerView(forSeat: Int): View = deckV

    /** the banker's cell leans towards the player he deals to, and back */
    private fun dealGesture(to: View?) {
        val c = (if (bk >= 0) cellOf(bk) else null) ?: return
        if (to == null || to === c) return
        val a = loc(c); val b = loc(to)
        val dx = (b[0] - a[0]) * 0.12f; val dy = (b[1] - a[1]) * 0.12f
        val x0 = c.translationX; val y0 = c.translationY
        c.animate().translationX(x0 + dx).translationY(y0 + dy).setDuration(Anim.ad(110L))
            .withEndAction { c.animate().translationX(x0).translationY(y0).setDuration(Anim.ad(140L)).start() }.start()
    }

    private fun flyTo(seat: Int) {
        if (screen != "game" || seat == mySeat || !::deckV.isInitialized || n <= 0) return
        val k = (seat - mySeat + n) % n
        if (k >= playersV.childCount) return
        val target = playersV.getChildAt(k)
        val srcV: View = dealerView(seat)
        val bmp = Assets.bitmap(act, Assets.backPath(Prefs.back)) ?: return
        val w = Px.dp(34); val h = Px.dp(48)
        val iv = ImageView(act); iv.setImageBitmap(bmp)
        iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val o = loc(ov); val a = loc(srcV); val t = loc(target)
        val lp0 = FrameLayout.LayoutParams(w, h); lp0.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(iv, lp0)
        iv.x = a[0] - o[0] + (srcV.width - w) / 2f
        iv.y = a[1] - o[1] + (srcV.height - h) / 2f
        dealGesture(target)
        iv.animate().x(t[0] - o[0] + (target.width - w) / 2f).y(t[1] - o[1] + (target.height - h) / 2f).rotation(20f)
            .setDuration(Anim.ad(320L)).withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
    }

    /** a gold chip with the amount flies between a player's seat and the bank (from / to = -1 is the bank) */
    private fun flyChip(from: Int, to: Int, amount: Long) {
        if (screen != "game" || n <= 0) return
        val a: View = (if (from < 0) bankTv else cellOf(from)) ?: return
        val b: View = (if (to < 0) bankTv else cellOf(to)) ?: return
        val o = loc(ov); val pa = loc(a); val pb = loc(b)
        val sz = Px.dp(38)
        val chip = TextView(act)
        chip.text = Cards.fa(amount); chip.textSize = 11f; chip.setTextColor(0xFF222222.toInt())
        chip.setTypeface(chip.typeface, Typeface.BOLD)
        chip.gravity = Gravity.CENTER
        chip.background = Px.rounded(Px.GOLD, 19, 2, 0xFFB8860B.toInt())
        chip.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        val lp = FrameLayout.LayoutParams(sz, sz); lp.gravity = Gravity.TOP or Gravity.LEFT
        ov.addView(chip, lp)
        chip.x = pa[0] - o[0] + (a.width - sz) / 2f; chip.y = pa[1] - o[1] + (a.height - sz) / 2f
        chip.animate().x(pb[0] - o[0] + (b.width - sz) / 2f).y(pb[1] - o[1] + (b.height - sz) / 2f).scaleX(0.75f).scaleY(0.75f)
            .setDuration(Anim.ad(480L)).setInterpolator(android.view.animation.AccelerateDecelerateInterpolator())
            .withEndAction { try { ov.removeView(chip) } catch (e: Exception) { } }.start()
    }

    private fun chipFx(from: Int, to: Int, amount: Long) {
        ui { flyChip(from, to, amount) }
        if (role == "host") sendAll(JSONObject().put("t", "chip").put("a", from).put("b", to).put("m", amount))
    }

    /** a player who burned shakes his head */
    private fun shake(seat: Int) {
        val c = cellOf(seat) ?: return
        val x0 = c.translationX; val d = Px.dp(7).toFloat()
        c.animate().translationX(x0 + d).setDuration(Anim.ad(60L)).withEndAction {
            c.animate().translationX(x0 - d).setDuration(Anim.ad(90L)).withEndAction {
                c.animate().translationX(x0 + d / 2).setDuration(Anim.ad(70L)).withEndAction {
                    c.animate().translationX(x0).setDuration(Anim.ad(60L)).start()
                }.start()
            }.start()
        }.start()
    }

    /** gold coins fly between the bank (top of the screen) and a player: toPlayer = the bank pays him, else he pays the bank */
    private fun flyCoins(seat: Int, toPlayer: Boolean, amount: Long) {
        try {
            // the more money, the more coins (1 to 10)
            val unit = Math.max(minBet, base / 5)
            val cnt = Math.max(1L, Math.min(10L, (amount + unit - 1) / unit)).toInt()
            val cell = cellOf(seat) ?: return
            val o = loc(ov); val a = loc(bankTv); val c = loc(cell)
            val bx = a[0] - o[0] + bankTv.width / 2f; val by = a[1] - o[1] + bankTv.height / 2f
            val px = c[0] - o[0] + cell.width / 2f; val py = c[1] - o[1] + cell.height / 2f
            val sx = if (toPlayer) bx else px; val sy = if (toPlayer) by else py
            val ex = if (toPlayer) px else bx; val ey = if (toPlayer) py else by
            val sz = Px.dp(18)
            for (i in 0 until cnt) {
                val coin = View(act)
                coin.background = Px.rounded(Px.GOLD, 9, 2, 0xFF8A6A00.toInt())
                coin.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                val lp = FrameLayout.LayoutParams(sz, sz); lp.gravity = Gravity.TOP or Gravity.LEFT
                ov.addView(coin, lp)
                coin.x = sx - sz / 2f; coin.y = sy - sz / 2f; coin.alpha = 0f
                coin.animate().alpha(1f).x(ex - sz / 2f + (i - (cnt - 1) / 2f) * Px.dp(4)).y(ey - sz / 2f)
                    .setStartDelay(Anim.ad(60L * i)).setDuration(Anim.ad(420L))
                    .withEndAction {
                        coin.animate().alpha(0f).setStartDelay(0L).setDuration(Anim.ad(150L))
                            .withEndAction { try { ov.removeView(coin) } catch (e: Exception) { } }.start()
                    }.start()
            }
        } catch (e: Exception) { }
    }

    private fun coinFx(seat: Int, toPlayer: Boolean, amount: Long) {
        ui { flyCoins(seat, toPlayer, amount) }
        if (role == "host") sendAll(JSONObject().put("t", "coin").put("s", seat).put("w", toPlayer).put("a", amount))
    }

    private fun shakeFx(seat: Int) {
        ui { shake(seat) }
        if (role == "host") sendAll(JSONObject().put("t", "fx").put("s", seat))
    }

    /** at the end of a hand the cards on the table go back to the deck */
    private fun flyCollect(winner: Int) {
        if (screen != "game" || n <= 0) return
        if (!::deckV.isInitialized) return
        val target: View = deckV
        val o = loc(ov); val t = loc(target)
        var i = 0
        for (row in listOf<ViewGroup>(bankerV, mineV)) {
            for (j in 0 until row.childCount) {
                val c = row.getChildAt(j) as? ImageView ?: continue
                val d = c.drawable ?: continue
                val a = loc(c)
                val w = c.width; val h = c.height
                val iv = ImageView(act)
                iv.setImageDrawable(d.constantState?.newDrawable() ?: d)
                iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                val lp = FrameLayout.LayoutParams(w, h); lp.gravity = Gravity.TOP or Gravity.LEFT
                ov.addView(iv, lp)
                iv.x = (a[0] - o[0]).toFloat(); iv.y = (a[1] - o[1]).toFloat()
                c.visibility = View.INVISIBLE
                iv.animate().x(t[0] - o[0] + (target.width - w) / 2f).y(t[1] - o[1] + (target.height - h) / 2f)
                    .scaleX(0.6f).scaleY(0.6f).alpha(0f)
                    .setStartDelay(Anim.ad(70L * i)).setDuration(Anim.ad(420L))
                    .withEndAction { try { ov.removeView(iv) } catch (e: Exception) { } }.start()
                i++
            }
        }
    }

    private fun collectFx(winner: Int) {
        ui { flyCollect(winner) }
        if (role == "host") sendAll(JSONObject().put("t", "col").put("s", winner))
    }

    private fun dealTo(seat: Int) {
        ui { flyTo(seat) }
        if (role == "host") sendAll(JSONObject().put("t", "fly").put("s", seat))
    }

    /** a big gold message in the middle of the screen  */

    /** no popup any more (as in Hokm): the result is only spoken / written in the log */
    private fun bannerSeat(seat: Int, text: String) { sayTo(seat, text) }

    private fun totalText(h: List<Card>): String {
        if (h.isEmpty()) return ""
        val t = Bist.total(h)
        return " = " + Cards.fa(t.t) + (if (t.pair) " (جفت تک)" else "")
    }

    private fun handSpeech(h: List<Card>): String =
        h.joinToString("، ") { Cards.cname(it) } + ". مجموع " + Cards.fa(Bist.total(h).t)

    private fun draw() { ui { render() }; if (role == "host") pushAll() }

    private fun render() {
        if (screen != "game" || !::playersV.isInitialized) return
        bankTv.text = "بانک: " + Cards.fa(bank)
        msgTv.text = msg
        msgTv.visibility = if (Prefs.a11y || over) View.VISIBLE else View.GONE      // like Hokm: only with the accessibility option on
        if (msg.isNotEmpty() && msg != lastMsg) { lastMsg = msg; ann(msg) }
        playersV.removeAllViews()
        for (k in 0 until n) {
            val i = (mySeat + k) % n          // our own seat first, then the others in order round the table
            val isB = i == bk
            val cell = LinearLayout(act)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(Px.dp(8), Px.dp(4), Px.dp(8), Px.dp(4))
            cell.background = Px.rounded(if (isB) Px.GOLD else 0x8C000000.toInt(), 10, if (i == cur) 2 else 0, Px.GOLD)
            cell.contentDescription = names[i] + (if (isB) "، بانکدار" else "") + "، ژتون " + Cards.fa(chips[i])
            cell.isFocusable = true
            try { cell.addView(Av.view(act, names[i], 36, i == cur, i == cur)) } catch (e: Exception) { }
            val t = tv(names[i] + (if (isB) " 👑" else "") + "\n" + Cards.fa(chips[i]), 12f, if (isB) 0xFF222222.toInt() else Color.WHITE)
            t.gravity = Gravity.CENTER
            t.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            cell.addView(t)
            playersV.addView(cell, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        playersV.post { placeRing() }
        val meBank = bk == mySeat
        val bl = ArrayList(bh)
        bankerLab.text = "بانکدار" + (if (meBank) totalText(bl) else "")
        bankerLab.contentDescription = if (meBank && bl.isNotEmpty()) "کارت‌های شما به عنوان بانکدار. مجموع " + Cards.fa(Bist.total(bl).t) + (if (Bist.total(bl).pair) "، جفت تک" else "") else "بانکدار"
        val kb2 = bl.joinToString(",") { Cards.idc(it).toString() } + "|" + meBank + "|" + reveal + "|" + firstUp + "|" + Prefs.back
        if (kb2 != lastBankKey) {
            lastBankKey = kb2
            bankerV.removeAllViews()
            bl.forEachIndexed { i, c -> bankerV.addView(cardView(c, !meBank && !reveal && !(i == 0 && firstUp))) }   // every card of the banker stays face down for the others until the cards are compared
            animNew(bankerV, lastBhN)
            lastBhN = bl.size
            if (reveal && !lastReveal && !meBank && bankerV.childCount > 0) {
                val f0 = bankerV.getChildAt(0)
                f0.scaleX = 0f
                f0.animate().scaleX(1f).setDuration(Anim.ad(260L)).start()
            }
            lastReveal = reveal
        }
        val ml = ArrayList(mine)
        mineLab.text = "کارت‌های شما" + totalText(ml)
        mineLab.contentDescription = if (ml.isNotEmpty()) "کارت‌های شما. مجموع " + Cards.fa(Bist.total(ml).t) + (if (Bist.total(ml).pair) "، جفت تک" else "") else "کارت‌های شما"
        val km2 = ml.joinToString(",") { Cards.idc(it).toString() } + "|" + Prefs.back
        if (km2 != lastMineKey) {
            lastMineKey = km2
            mineV.removeAllViews()
            for (c in ml) mineV.addView(cardView(c, false))
            animNew(mineV, lastMineN)
            lastMineN = ml.size
        }
        // what the screen reader says about our hands
        val km = ml.joinToString(" ") { Cards.idc(it).toString() }
        var said = false
        if (km.isNotEmpty() && km != lastMine) { lastMine = km; said = true; ann("کارت‌های شما: " + handSpeech(ml) + ".") } else if (km.isEmpty()) lastMine = ""
        // at the start of my turn the sum is said again, even when the cards did not change (it was only said when a card arrived before)
        val tt = if (cur == mySeat && ml.isNotEmpty() && !over) cur.toString() + "|" + km else ""
        if (tt.isEmpty()) lastTurnTotal = ""
        else if (tt != lastTurnTotal) {
            lastTurnTotal = tt
            if (!said && !Prefs.a11y) ann("مجموع کارت‌های شما " + Cards.fa(Bist.total(ml).t) + (if (Bist.total(ml).pair) "، جفت تک" else ""))
        }
        val kb = if (meBank) bl.joinToString(" ") { Cards.idc(it).toString() } else ""
        if (kb.isNotEmpty() && kb != lastBank) { lastBank = kb; ann("کارت‌های شما به عنوان بانکدار: " + handSpeech(bl) + ".") } else if (kb.isEmpty()) lastBank = ""
        logScroll.visibility = if (Prefs.a11y) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ speech 

    private fun ann(t: String) {
        val d = Spk.slot(t, 0L)
        Sched.laterRaw(d) { speak(t) }
        // a guest tells the host when it will have finished speaking, so the host waits a little for it
        if (role == "guest") net?.toHost(JSONObject().put("t", "free").put("ms", Math.max(0L, Spk.end - Sched.now())))
    }

    private fun speak(t: String) {
        if (!Prefs.a11y) return
        try {
            val am = act.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!am.isEnabled) return
            @Suppress("DEPRECATION")
            logBox.announceForAccessibility(t)
        } catch (e: Exception) { }
    }

    private fun idle(): Long = if (!Prefs.a11y) 0L else Math.max(0L, Spk.end - Sched.now())

    /** the screen is small: when I must decide, the page scrolls up by itself (like a two-finger swipe) so that my cards are in view at the bottom.
     *  Only when a decision starts, so it never fights a scroll the player did himself. */
    private fun scrollToCards() {
        if (!::gameScroll.isInitialized || !::mineV.isInitialized) return
        gameScroll.post {
            try {
                if (!mineV.isShown || mineV.childCount == 0) return@post
                val a = IntArray(2); val b = IntArray(2)
                mineV.getLocationOnScreen(a); gameScroll.getLocationOnScreen(b)
                val delta = (a[1] + mineV.height + Px.dp(12)) - (b[1] + gameScroll.height)
                if (delta > 0) gameScroll.smoothScrollBy(0, delta)
            } catch (e: Exception) { }
        }
    }

    private fun focusSoon(v: View?) {
        if (v == null || !Prefs.a11y) return
        Sched.laterRaw(idle() + 50L) {
            try { v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null) } catch (e: Exception) { }
        }
    }

    /** when I must decide: the screen reader first goes to «کارت‌های شما» (it reads the sum), then, when that is read, to [v] (the button / the slider) */
    private fun focusCardsThen(v: View?) {
        if (v == null || !Prefs.a11y) return
        Sched.laterRaw(idle() + 50L) {
            try {
                val d = mineLab.contentDescription?.toString() ?: ""
                if (mine.isEmpty() || d.isEmpty()) { v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null); return@laterRaw }
                mineLab.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null)
                // same rule as everywhere else: the sum is read by the screen reader, so it takes a slot in the speech queue (Spk),
                // and the button gets focus when that reading is done, plus 50 ms
                Spk.slot(d, 0L)
                Sched.laterRaw(idle() + 50L) {
                    try { v.performAccessibilityAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS, null) } catch (e: Exception) { }
                }
            } catch (e: Exception) { }
        }
    }

    // ------------------------------------------------------------------ worker helpers (run on the game thread)

    private fun sleep(ms: Long) { Thread.sleep(Anim.ad(ms)) }
    private fun gate() {
        if (role != "host") return
        val t0 = Sched.now(); var wm = 0L
        while (alive) {
            val now = Sched.now(); var w = 0L
            for (q in 1 until n) if (remote[q] && freeAt[q] > now) w = Math.max(w, freeAt[q] - now)
            wm = Math.max(wm, w)
            val used = now - t0
            val cap = Math.min(6000.0, Math.max(700.0, wm * 0.3)).toLong()
            if (w > 0 && used < cap) Thread.sleep(Math.min(w, cap - used) + 30) else break
        }
    }

    /** floor for the pause after a shuffle: card.mp3 peaks CSO ms after its start, so the card may start that much before the shuffle (EST) ends, +50 ms margin */
    private val SHUF_MIN: Long = (Sound.EST["shuffle"] ?: 890) - Sound.CSO + 50L

    /** minMs: floor for this one pause only (after a shuffle, so the first card sound does not start over it) */
    /** how long the sound queue is still busy (the next action waits for it, as in Hokm; at most 4 s) */
    private fun soundWait(): Long = Math.max(0L, Math.min(4000L, Sound.sq() - Sched.now()))

    private fun pace(ms: Long, minMs: Long = 0L) {
        waitVote()
        Thread.sleep(Math.max(Math.max(Math.max(Anim.ad(ms), minMs), idle()), soundWait()))
        gate()
        while (held && alive) Thread.sleep(300)      // paused: waiting for the host to press "ادامه بازی"
    }

    private fun startHold(t: String) {
        held = true
        val txt = t + " بازی متوقف است. برای ادامه، دکمه‌ی «ادامه بازی» را بزنید."
        ui { holdTv.text = txt; holdBar.visibility = View.VISIBLE; ann(txt) }
        sendAll(JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
    }

    private fun resumeHold() {
        if (!held) return
        held = false
        holdBar.visibility = View.GONE
        sendAll(JSONObject().put("t", "hold").put("on", false))
        say("بازی ادامه پیدا کرد.")
    }

    /** a seat played by a person: the host himself (seat 0) or a connected guest */
    private fun isH(p: Int): Boolean = p == 0 || (role == "host" && remote[p])

    /** a log line shows for 6 seconds, and only with the accessibility option on (the same as the Hokm log) */
    private fun addLog(m: String) {
        if (!Prefs.a11y || !::logBox.isInitialized) return
        val d = tv(m, 13f, 0xFFE8DCC4.toInt())
        d.setPadding(0, Px.dp(3), 0, Px.dp(3))
        logBox.addView(d)
        Sched.laterRaw(6000) { logBox.removeView(d) }
        while (logBox.childCount > 12) logBox.removeViewAt(0)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    /** the text of a message for the player on seat [v]: he is "شما", the others are called by name (as in Hokm) */
    private fun res(m: String, v: Int): String = Who.resolve(m, v, names)

    private fun say(m: String) {
        ui { val t = res(m, 0); addLog(t); ann(t); render() }
        if (role == "host") for (s in 1 until n) if (remote[s]) sendSeat(s, JSONObject().put("t", "say").put("m", res(m, s)))
    }

    /** a line only one player hears (for example his own chips) */
    private fun sayTo(seat: Int, m: String) {
        if (seat == 0) { ui { addLog(m); ann(m); render() }; return }
        if (role == "host" && remote[seat]) sendSeat(seat, JSONObject().put("t", "say").put("m", m))
    }

    /** three card backs shuffle in the middle of the screen */
    private fun shuffleAnim() { Fx.shuffle(450, ov) }      // the same shuffle picture as Hokm

    private fun snd(name: String) {
        Sched.post { Sound.game(name) }
        if (name == "shuffle") ui { shuffleAnim() }
        if (role == "host") sendAll(JSONObject().put("t", "snd").put("n", name))
    }

    private fun sndSeat(seat: Int, name: String) {
        if (seat == 0) { Sched.post { Sound.game(name) }; return }
        if (role == "host" && remote[seat]) sendSeat(seat, JSONObject().put("t", "snd").put("n", name))
    }

    // ---- the buttons shown to whoever has to decide (this phone's player, or a guest) ----

    /** shows buttons; onPick gets the key of the tapped one. Runs on the UI thread. */
    private fun buildButtons(opts: List<Pair<String, String>>, extra: String?, onPick: (String) -> Unit) {
        ctl.removeAllViews()
        if (extra != null && extra.isNotEmpty()) ctl.addView(tv(extra, 14f, Color.WHITE))
        var first: View? = null
        for ((k, t) in opts) {
            val b = app.dlg.btn(t, true) { ctl.removeAllViews(); onPick(k) }
            ctl.addView(b)
            if (first == null) first = b
        }
        scrollToCards()
        focusCardsThen(first)
    }

    /** shows the bet slider; onPick gets "b<amount>" */
    private fun buildBet(mn: Long, mx: Long, bnk: Long, canAll: Boolean, onPick: (String) -> Unit) {
        ctl.removeAllViews()
        var amount = mn
        val lab = tv("شرط: " + Cards.fa(mn), 16f, Color.WHITE)
        ctl.addView(lab)
        val steps = Math.max(1L, Math.min(Int.MAX_VALUE.toLong(), mx / mn)).toInt()
        val sb = SeekBar(act); sb.max = steps - 1; sb.progress = 0
        sb.contentDescription = "مقدار شرط"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { amount = (p + 1).toLong() * mn; lab.text = "شرط: " + Cards.fa(amount) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        ctl.addView(sb)
        ctl.addView(app.dlg.btn("شرط می‌بندم", true) { ctl.removeAllViews(); onPick("b" + amount) })
        if (canAll) ctl.addView(app.dlg.btn("کل بانک (" + Cards.fa(bnk) + ")", true) { ctl.removeAllViews(); onPick("b" + bnk) })
        scrollToCards()
        focusCardsThen(sb)
    }

    /** this phone's player decides; blocks the game thread until he taps */
    private fun ask(opts: List<Pair<String, String>>, extra: String? = null): String {
        waitVote()
        answers.clear()
        ui { buildButtons(opts, extra) { k -> answers.offer(k) } }
        return answers.take()
    }

    private fun askBet(mx: Long): Long {
        waitVote()
        answers.clear()
        val all = chips[0] >= bank && bank >= mn(0)
        ui { buildBet(mn(0), mx, bank, all) { v -> answers.offer(v) } }
        return answers.take().substring(1).toLong()
    }

    /** waits for the answer of a guest (with the number of the question); def only when he drops out */
    private fun waitAns(seat: Int, id: Int, def: String): String {
        while (alive) {
            val a = ansQ[seat].take()
            if (a == "drop") return def
            val i = a.indexOf('|')
            if (i > 0 && a.substring(0, i) == id.toString()) return a.substring(i + 1)
        }
        return def
    }

    /** the player at [seat] decides (def = what a robot does when nobody answers) */
    private fun askSeat(seat: Int, opts: List<Pair<String, String>>, extra: String?, def: String): String {
        waitVote()
        if (seat == 0 || role != "host") return ask(opts, extra)
        if (!remote[seat]) return def
        val id = ++askSeq
        ansQ[seat].clear()
        val o = JSONArray()
        for (x in opts) o.put(JSONArray().put(x.first).put(x.second))
        sendSeat(seat, JSONObject().put("t", "ask").put("id", id).put("k", "btn").put("x", extra ?: "").put("o", o))
        return waitAns(seat, id, def)
    }

    /** the amount of a side bet (any amount from [mq] to [mxr], in steps of [mq]) */
    private fun askAmt(seat: Int, mq: Long, mxr: Long): Long {
        waitVote()
        if (seat == 0 || role != "host") { answers.clear(); ui { buildBet(mq, mxr, mxr, false) { v -> answers.offer(v) } }; return answers.take().substring(1).toLong() }
        if (!remote[seat]) return mq
        val id = ++askSeq
        ansQ[seat].clear()
        sendSeat(seat, JSONObject().put("t", "ask").put("id", id).put("k", "bet").put("mn", mq).put("mx", mxr).put("bank", mxr).put("all", false))
        val v = waitAns(seat, id, "b" + mq)
        val amt = try { v.substring(1).toLong() } catch (e: Exception) { mq }
        return Math.max(mq, Math.min(mxr, amt))
    }

    private fun askBetSeat(seat: Int, mx: Long): Long {
        waitVote()
        if (seat == 0 || role != "host") return askBet(mx)
        val m0 = mn(seat)
        if (!remote[seat]) return m0
        val id = ++askSeq
        ansQ[seat].clear()
        sendSeat(seat, JSONObject().put("t", "ask").put("id", id).put("k", "bet").put("mn", m0).put("mx", mx).put("bank", bank)
            .put("all", chips[seat] >= bank && bank >= m0))
        val v = waitAns(seat, id, "b" + m0)
        val amt = try { v.substring(1).toLong() } catch (e: Exception) { m0 }
        return Math.max(m0, Math.min(mx, amt))
    }

    private fun draw1(deck: MutableList<Card>): Card {
        if (deck.isEmpty()) {
            val f: MutableList<Card> = if (seen.isNotEmpty()) ArrayList(seen) else Bist.newDeck()
            seen.clear()
            Cards.shuf(f)
            deck.addAll(f)
            snd("shuffle")
            say("دسته دوباره بُر خورد.")
            pace(900, SHUF_MIN)
        }
        return deck.removeAt(deck.size - 1)
    }

    // ------------------------------------------------------------------ the game (runs on the host / solo thread)

    private fun loop() {
        outSeats.clear(); if (!keepMins) minArr.fill(0L); keepMins = false; cooldownAt.clear()
        for (a in stopTot) a.fill(0)
        while (alive) {
            while (held && alive) Thread.sleep(300)      // waiting for the host to press "ادامه بازی"
            if (!alive) return
            // a person who has run out of chips hears the losing song (once)
            for (s in 0 until n) if (isH(s) && chips[s] < mn(s) && outSeats.add(s)) {
                sndSeat(s, "flose"); bannerSeat(s, "سکه‌های شما تمام شد!")
                say(names[s] + " سکه‌هایش تمام شد.")
                Thread.sleep(Anim.ad(3500L))
            }
            if (chips[0] < mn(0)) {
                val q = if (role == "host") succSeat() else -1
                if (q > 0) {          // the host is out of chips: the next connected player becomes the host and the game goes on
                    say(names[0] + " سکه‌هایش تمام شد و میزبانی به " + names[q] + " منتقل می‌شود.")
                    transferTo(q)
                    return
                }
                Thread.sleep(Anim.ad(1500L))
                endGame(if (chips[0] < MIN_PLAY) "سکه‌های شما تمام شد؛ بازی تمام شد. برای ادامه باید برنامه را حذف و دوباره نصب کنید." else if (role == "solo") "سکه‌های شما تمام شد؛ بازی تمام شد." else "ژتون میزبان تمام شد؛ بازی تمام شد.")
                return
            }
            // a robot without the smallest bet is skipped from now on (his turn is passed) and the game goes on with the others
            for (s in 0 until n) if (isRobot(s) && chips[s] < mn(s) && outSeats.add(s)) say(names[s] + " ژتون کافی برای شرط‌بندی ندارد و از بازی کنار رفت.")
            val left = (0 until n).filter { !isOut(it) }
            // no person can play any more: the game is over, the robots do not play among themselves
            if (left.none { !isRobot(it) }) { endGame("هیچ بازیکن انسانی ژتون کافی ندارد؛ بازی تمام شد."); return }
            // one is left: he has won
            if (left.size <= 1) {
                val w = left.firstOrNull()
                if (w != null && isH(w)) {
                    sndSeat(w, "fwin"); bannerSeat(w, "🏆 شما برنده شدید!")
                    Thread.sleep(Anim.ad(3500L))
                    endGame(names[w] + " برنده شد؛ سکه‌های بقیه تمام شده است. بازی تمام شد.")
                } else endGame("هیچ‌کس ژتون ندارد؛ بازی تمام شد.")
                return
            }
            var b = ((if (bk < 0) n - 1 else bk) + 1) % n
            var tries = 0
            while (chips[b] < base && tries++ < n) b = (b + 1) % n
            if (chips[b] < base) { endGame("هیچ‌کس برای بانکداری ژتون ندارد؛ بازی تمام شد."); return }
            bk = b; cur = b; draw()
            if (isH(b)) {
                msg = "نوبت بانکداری " + names[b]; draw()
                if (askSeat(b, listOf("y" to "بانکدار می‌شوم", "n" to "نمی‌خواهم"), null, "y") == "n") { say(Who.n(b) + " بانکداری را " + Who.v(b, "رد کرد", "رد کردید") + "."); continue }
            }
            else if (!isH(b) && Math.random() < 0.15) { say(names[b] + " بانکداری را رد کرد."); Thread.sleep(Anim.ad(500L)); continue }
            val bs0 = synchronized(chipLock) { val x = base; chips[b] -= x; bank = x; x }
            chipFx(b, -1, bs0)
            say(Who.n(b) + " " + Who.v(b, "بانکدار شد", "بانکدار شدید") + "؛ بانک " + Cards.fa(bs0))
            // as in the guide: the banker stays until the bank is empty, or until it reaches the "بانک خبره" amount (then he finishes that round and takes it)
            while (alive) { if (round(b)) break }
            if (!alive) return
            val bk0 = bank
            chipFx(-1, b, bk0)
            if (bk0 > 0) coinFx(b, true, bk0)
            val got = synchronized(chipLock) { val x = bank; chips[b] += x; bank = 0L; x }
            say(Who.n(b) + " بانک را " + Who.v(b, "برداشت", "برداشتید") + ": " + Cards.fa(got))
            bChips = chips.copyOf(); bBk = bk
            Prefs.wallet = chips[0]                      // what he has now is what he keeps
            if (role == "host") for (q in 1 until n) if (remote[q]) sendSeat(q, JSONObject().put("t", "wal").put("v", chips[q]))
            if (role == "host") syncSucc()      // the first guest keeps the state (to take over if the host disappears); nothing is saved by itself
            draw(); pace(900)
        }
    }

    /** the game is over (a robot or everybody is out of chips): the message for everyone, and no saved game to come back to */
    private fun endGame(m: String) {
        say(m)
        if (role == "host") sendAll(JSONObject().put("t", "end"))
        showOver(m)
    }

    /** as in Hokm: when the sounds are done a button appears in the place of the choices and gets the focus (no popup) */
    private fun showOver(m: String) {
        Sound.afterSnd {
            ui {
                over = true; msg = if (Prefs.a11y) m else ""
                ctl.removeAllViews()
                val b = if (role == "solo") app.dlg.btn("بازی جدید", false) { stepBack() }
                        else if (role == "host") app.dlg.btn("بازی جدید", false) { app.hostPageAfterGame("21") }      // the same page as the first time: game type and settings
                        else app.dlg.btn("خروج از بازی", false) { net?.leave(); close() }
                ctl.addView(b)
                if (role == "host") ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
                render()
                focusSoon(b)
            }
        }
    }

    private val outSeats = HashSet<Int>()
    private fun isRobot(s: Int): Boolean = !isH(s) && idOf[s].isEmpty()
    /** out of the game: not even the smallest bet is left (a robot or a person; being short of the bank only means he cannot be the banker) */
    private fun isOut(s: Int): Boolean = chips[s] < mn(s)

    /** a robot ran out of chips: the humans hear the game-win sound of Hokm (fwin, not the usual hand win / lose), then the end message */
    private fun robotDefeat(r: Int) {
        for (s in 0 until n) if (isH(s) && chips[s] >= mn(s)) { sndSeat(s, "fwin"); bannerSeat(s, "🏆 " + names[r] + " شکست خورد!") }
        Thread.sleep(Anim.ad(3500L))
        endGame(names[r] + " سکه‌هایش تمام شد و شکست خورد؛ بازی تمام شد.")
    }

    /** a robot's first chips: never limited by the bank: whatever bank the host typed, they can have that much (at least START), and from there they can run out */
    private fun robotStart(): Long = Math.max(START, base)

    /** one round with everybody; true = the banker's turn is over (the bank is empty, it was called "خبره", or nobody can play any more) */
    private fun round(b: Int): Boolean {
        var played = 0; var ended = false
        val deck = Bist.newDeck()
        snd("shuffle"); pace(900, SHUF_MIN); seen.clear(); mine = ArrayList(); bh = ArrayList(); curHand = ArrayList()
        // "one card to everybody first": the banker deals before playing with each of them
        val pre = HashMap<Int, MutableList<Card>>()
        if (dealAll) {
            for (k in 1 until n) {
                val p = (b + k) % n
                if (!alive) return true
                if (chips[p] < mn(p)) continue
                val l: MutableList<Card> = ArrayList(); l.add(draw1(deck)); pre[p] = l
                msg = names[b] + " به " + names[p] + " کارت می‌دهد"; snd("card"); dealTo(p); draw(); pace(450)
            }
        }
        // the banker's own cards from the game before, when he won it: they stay for the next player
        var bankerHeld: MutableList<Card>? = null
        var heldShown = false      // the kept hand was shown to everybody (the banker won by comparing), so the robots know those cards
        var khabreCalled = false
        for (k in 1..n) {
            val p = (b + k) % n
            if (p == b) break
            if (!alive) return true
            if (chips[p] < mn(p)) continue
            if (bank < mn(p)) break
            cur = p; reveal = false; firstUp = false
            val ph: MutableList<Card> = pre[p] ?: ArrayList<Card>().also { it.add(draw1(deck)) }
            curHand = ph
            // the banker's cards: the ones he kept from the game before (he won it), or a new card from the deck (he lost it, or it is the first game)
            val keptCard = bankerHeld
            bankerHeld = null
            val shownBank: List<Card>? = if (keptCard != null && heldShown) ArrayList<Card>(keptCard) else null
            var bSwapped = false
            var bhand: MutableList<Card>
            var bNew: Boolean          // a card is dealt to the banker now (a new one, or the one that replaces the card he set aside)
            if (keptCard != null) { bhand = keptCard; bNew = false }
            else { bhand = ArrayList(); bhand.add(draw1(deck)); bNew = true }
            // the banker may not change a card he has just been dealt; only the card he kept unshown from the player before (who burned)
            // may be set aside for the next player, and then he takes just one other card
            if (keptCard != null && shownBank == null) {
                var setAside = -1
                if (isH(b)) {
                    bh = bhand; msg = "کارت‌های بانکدار از بازی قبل"; draw()
                    val opts = ArrayList<Pair<String, String>>()
                    opts.add("k" to "نگه می‌دارم")
                    bhand.forEachIndexed { i, c -> opts.add(i.toString() to ("کنار می‌گذارم: " + Cards.cname(c))) }
                    val k = askSeat(b, opts, "یک کارت را می‌توانید عوض کنید:", "k")
                    val ix = k.toIntOrNull()
                    if (ix != null && ix >= 0 && ix < bhand.size) setAside = ix
                } else setAside = Ai21.bankerSwapIndex(bhand, seen)
                if (setAside >= 0) {
                    // the card is set aside (hidden, out of the game) and just one other card is taken
                    val nb = ArrayList<Card>(bhand); nb.removeAt(setAside); nb.add(draw1(deck))
                    bhand = nb; bNew = true; bSwapped = true
                }
            }
            bh = bhand
            mine = if (p == 0) ph else ArrayList()
            if (pre.containsKey(p)) {
                if (bNew) { msg = names[b] + " برای بازی با " + names[p] + " کارت می‌گیرد"; snd("card"); dealTo(b) }
                else msg = names[b] + " کارت‌های خود را برای بازی با " + names[p] + " نگه داشت"
            } else {
                if (bNew) { msg = names[b] + " به " + names[p] + " کارت می‌دهد"; snd("card"); dealTo(b); dealTo(p) }
                else { msg = names[b] + " به " + names[p] + " کارت می‌دهد و کارت‌های خودش را نگه می‌دارد"; snd("card"); dealTo(p) }
            }
            draw(); pace(500)
            msg = "نوبت " + names[p] + " است."; draw()

            // the bet
            val mx = Math.min(bank, chips[p])
            var bet: Long
            if (isH(p)) bet = askBetSeat(p, mx)
            else {
                // the robot counts the cards: a small bet when the banker is ahead, a bigger one when his first card (and the cards left) give him an edge
                val m1 = mn(p)
                val edge = Ai21.firstEdge(ph[0], seen, bhand.size, null, false)
                if (edge <= 0.0) bet = Math.max(m1, Math.min(mx, m1))
                else {
                    val frac = Math.min(0.5, edge * 2.0)
                    val raw = m1.toDouble() + (mx - m1).toDouble() * frac
                    var b1 = Math.round(raw / m1) * m1
                    val capOwn = Math.max(m1, (chips[p] / 4 / m1) * m1)      // never more than a quarter of his own chips unless the edge is big
                    if (edge < 0.25 && b1 > capOwn) b1 = capOwn
                    bet = Math.max(m1, Math.min(mx, b1))
                }
                if (chips[p] >= bank && edge > 0.3 && Math.random() < 0.5) { bet = bank; say(Who.n(p) + ": کل بانک!") }
            }
            say(Who.n(p) + " " + Who.v(p, "شرط بست", "شرط بستید") + ": " + Cards.fa(bet))

            // what the robots know of the banker's hand: nothing (all his cards are hidden)
            val knownBank: List<Card>? = null      // the banker's cards stay hidden until the cards are compared
            val knownSwapped = if (shownBank != null) bSwapped else false      // a single card that was read out is his whole hand, nothing hidden in it

            // bets on this player's hand (optional rule)
            val sideQ = ArrayList<Int>(); val sideA = ArrayList<Long>()
            if (side) {
                // the rule is on: the first card of the player is read out (after his bet) so the others can read on his hand
                val c0 = ph[0]
                say(Who.n(p) + ": کارت اول " + Cards.cname(c0))
                draw()
                for (q in 0 until n) {
                    val mq = mn(q)
                    if (q == p || q == b || chips[q] < mq) continue
                    var used = 0L
                    for (a in sideA) used += a
                    val rem = bank - bet - used
                    val mxr = (Math.min(bet, Math.min(chips[q], rem)) / mq) * mq
                    if (mxr < mq) continue
                    val half = Math.max(mq, (mxr / 2 / mq) * mq)
                    var a = 0L
                    if (isH(q)) {
                        val f = askSeat(q, listOf("0" to "نمی‌خوانم", "r" to "می‌خوانم"), "روی دست " + names[p] + " بخوانید؟", "0")
                        a = if (f == "r") askAmt(q, mq, mxr) else 0L
                    } else {
                        val e = Ai21.firstEdge(c0, seen, bhand.size, knownBank, knownSwapped)
                        a = if (e > 0.05) Math.min(mxr, Math.max(mq, (mxr * Math.min(1.0, e * 2.0) / mq).toLong() * mq)) else 0L
                    }
                    if (a > 0) { sideQ.add(q); sideA.add(a); say(Who.n(q) + " روی " + Who.n(p) + " " + Cards.fa(a) + " " + Who.v(q, "خواند", "خواندید")) }
                }
            }

            // the cards are given one by one: the player may take one card, then the banker if he wants, then the player may take another, and so on.
            // Saying "enough" is final for each of them (the banker too: he must stay there). A burnt hand ends the game at once.
            var pt = Bist.total(ph).t
            var bt = Bist.total(bhand).t
            // as in the guide: the player takes his cards first (until he says "enough" or burns); only then the banker plays his hand.
            // (if the banker's replaced card burned his hand before the game started, the player has won and nothing is played)
            while (alive && bt <= 21 && pt <= 21) {
                if (turn(p, ph, deck, false, bhand.size, null, false, knownBank, knownSwapped)) pt = Bist.total(ph).t else break
            }
            if (alive && bt <= 21 && pt <= 21) {
                while (alive && bt <= 21) {
                    if (turn(b, bhand, deck, true, ph.size, if (p in 0 until 10) stopTot[p] else null, true, null, false)) bt = Bist.total(bhand).t else break
                }
            }
            if (pt <= 21 && p in 0 until 10) stopTot[p][pt]++
            val out: Boolean
            if (pt > 21) { out = false; if (isH(p)) askSeat(p, listOf("s" to "سوز"), "بیش از ۲۱ شد:", "s"); say(Who.n(p) + " " + Who.v(p, "«سوز» گفت", "«سوز» گفتید") + " (" + Cards.fa(pt) + ")."); shakeFx(p) }
            else {
                reveal = true; snd("card"); draw(); pace(500)
                if (bt > 21) shakeFx(b)
                out = Bist.playerWins(pt, bt)
                say(Who.n(p) + " " + Cards.fa(pt) + " — بانکدار " + (if (bt > 21) "سوخت" else Cards.fa(bt)) + " ← " + (if (out) Who.v(p, "برد", "بردید") else Who.v(p, "باخت", "باختید")) + " " + Cards.fa(bet))
            }
            // faces and banners
            val wn = if (out) names[p] else names[b]; val ls = if (out) names[b] else names[p]
            Sched.post { try { Av.set(wn, "joy", 3000L); Av.set(ls, if (pt > 21) "surprised" else "sad", 3000L) } catch (e: Exception) { } }
            // win / lose sound for every person involved
            for (s in 0 until n) {
                if (!isH(s)) continue
                val w: Boolean? = if (s == p) out else if (s == b) !out else if (sideQ.contains(s)) out else null
                if (w != null) { sndSeat(s, if (w) "win" else "lose"); bannerSeat(s, if (w) "بردید!" else if (s == p && pt > 21) "سوختید!" else "باختید!") }
            }
            // the cards that were shown go to the seen cards; the banker's cards, that nobody saw (the player burned), stay with him for the next player
            seen.addAll(ph)
            // when the banker wins (the player burned, or made less, or tied) his whole hand stays with him for the next player, and he may change one card;
            // when the banker loses (he burned, or the player made more) his cards go out and he is dealt a new card
            if (pt > 21) { bankerHeld = bhand; heldShown = false } else seen.addAll(bhand)      // as in the guide: only when the player burned the banker's cards stay unrevealed for the next player; after a comparison they go out
            chipFx(if (out) -1 else p, if (out) p else -1, bet)
            for (i in sideQ.indices) chipFx(if (out) -1 else sideQ[i], if (out) sideQ[i] else -1, sideA[i])
            synchronized(chipLock) {
                if (out) { chips[p] += bet; bank -= bet } else { chips[p] -= bet; bank += bet }
                for (i in sideQ.indices) {
                    if (out) { chips[sideQ[i]] += sideA[i]; bank -= sideA[i] } else { chips[sideQ[i]] -= sideA[i]; bank += sideA[i] }
                }
            }
            draw()
            played++
            coinFx(p, out, bet)
            collectFx(if (out) p else b)
            sayTo(p, "ژتون شما: " + Cards.fa(chips[p]))
            if (b != p) sayTo(b, "ژتون شما: " + Cards.fa(chips[b]))
            for (q in sideQ) sayTo(q, "ژتون شما: " + Cards.fa(chips[q]))
            pace(900)
            if (bank <= 0) { say("بانک خالی شد؛ نوبت بانکدار بعدی."); ended = true; break }
            if (!khabreCalled && bank >= khabreAmt()) {
                // the bank reached the agreed amount: the banker must announce it, shuffles the cards, finishes the round with all the others, and takes the bank at the end
                khabreCalled = true
                say("بانک خبره! بانک به " + Cards.fa(bank) + " رسید.")
                if (k < n - 1) {
                    deck.addAll(seen); seen.clear(); Cards.shuf(deck)
                    snd("shuffle"); say("ورق‌ها بُر زده شد؛ " + Who.n(b) + " " + Who.v(b, "بازی با بقیه را تمام می‌کند", "بازی با بقیه را تمام می‌کنید") + " و در پایان بانک را برمی‌دارد.")
                    pace(900, SHUF_MIN)
                }
            }
        }
        if (khabreCalled || played == 0) ended = true
        return ended
    }

    /** one player (or the banker) draws until they stop or burn; returns the total */
    /** one turn of the player or of the banker: asks (or decides) whether he takes a card, and gives him one card if he does. true = a card was given. */
    private fun turn(p: Int, hand: MutableList<Card>, deck: MutableList<Card>, isBank: Boolean, oppCards: Int, emp: IntArray?, oppStood: Boolean, shown: List<Card>?, swapped: Boolean): Boolean {
        if (!alive) return false
        val t = Bist.total(hand).t
        if (t > 21) return false
        val hit: Boolean
        val bots = if (isBank) Ai21.bankerHit(hand, seen, oppCards, emp) else Ai21.playerHit(hand, seen, oppCards, oppStood, shown, swapped)
        if (isH(p)) {
            cur = p; msg = if (isBank) "بانکدار: " + names[p] else "نوبت " + names[p] + " است."; draw()
            hit = askSeat(p, listOf("h" to "کارت بده", "s" to "بس است"), null, if (bots) "h" else "s") == "h"
        } else hit = bots
        if (!hit) return false
        var nr = false
        if (!isBank && hand.size >= 3) {
            // three-card rule: to get another card you must show one of yours, or the banker shows the new one
            if (isH(p)) {
                val opts = ArrayList<Pair<String, String>>()
                hand.forEachIndexed { i, c -> opts.add(i.toString() to Cards.cname(c)) }
                opts.add("n" to "رو نمی‌کنم")
                val k = askSeat(p, opts, "برای کارت بعدی یکی را رو کن:", "0")
                if (k == "n") nr = true else say(Who.n(p) + " " + Cards.cname(hand[Math.min(hand.size - 1, k.toIntOrNull() ?: 0)]) + " را " + Who.v(p, "رو کرد", "رو کردید") + ".")
            } else {
                val c = hand[Ai21.cardToShow(hand)]
                say(Who.n(p) + " " + Cards.cname(c) + " را " + Who.v(p, "رو کرد", "رو کردید") + ".")
            }
        }
        hand.add(draw1(deck)); snd("card"); dealTo(p)
        if (nr) say("بانکدار کارت جدید " + Who.n(p) + " را رو کرد: " + Cards.cname(hand[hand.size - 1]))
        draw(); pace(500)
        return true
    }

    // ------------------------------------------------------------------ multi-phone: the host side

    private fun sendSeat(seat: Int, j: JSONObject) {
        val cid = cidOf[seat]
        if (cid >= 0) net?.send(cid, j)
    }

    private fun sendAll(j: JSONObject) { for (s in 1 until n) if (remote[s]) sendSeat(s, j) }

    private fun goMsg(seat: Int): JSONObject {
        val nm = JSONArray(); for (x in names) nm.put(x)
        return JSONObject().put("t", "go").put("seat", seat).put("n", n).put("names", nm).put("base", base).put("min", minBet).put("side", side)
    }

    /** the picture of the table that guest [s] may see (his own hand, the banker's first card hidden) */
    private fun snapFor(s: Int): JSONObject {
        val j = JSONObject().put("t", "st").put("bank", bank).put("bk", bk).put("cur", cur).put("msg", msg).put("rev", reveal).put("f0", firstUp)
        val c = JSONArray(); for (i in 0 until n) c.put(chips[i])
        j.put("chips", c)
        val m = JSONArray()
        if (cur == s && bk != s) for (x in ArrayList(curHand)) m.put(Cards.idc(x))
        j.put("mine", m)
        val b = JSONArray()
        var i = 0
        for (x in ArrayList(bh)) { b.put(if (bk != s && !reveal && !(i == 0 && firstUp)) -1 else Cards.idc(x)); i++ }   // hidden for everybody but the banker until the cards are compared
        j.put("bh", b)
        return j
    }

    private fun pushAll() { for (s in 1 until n) if (remote[s]) sendSeat(s, snapFor(s)) }

    /** the host starts a game with the connected phones (seats 1..) and robots for the rest */
    fun startHostGame(ps: List<Net21.Peer>, botCount: Int, b: Long, m: Long, sd: Boolean, kh: Int = 3, da: Boolean = false) {
        role = "host"; mySeat = 0; held = false
        base = b; minBet = m; side = sd; khabreMul = kh; dealAll = da
        n = 1 + ps.size + botCount
        val nm = ArrayList<String>()
        nm.add(if (Prefs.name.isEmpty()) "بازیکن" else Prefs.name)
        remote.fill(false)
        for (i in ps.indices) { nm.add(ps[i].name); remote[i + 1] = true; cidOf[i + 1] = ps[i].cid; idOf[i + 1] = ps[i].id }
        var k = 0
        val pool = Names.pickNames(Names.IR_NAMES.size)
        while (nm.size < n) {
            val c = if (k < pool.size) pool[k] else "ربات " + Cards.fa(k + 1)
            k++
            if (!nm.contains(c)) nm.add(c)
        }
        names = nm
        chips = LongArray(n) { i -> if (i == 0) Prefs.wallet else if (i <= ps.size) ps[i - 1].wallet else robotStart() }
        bk = -1
        startGame()
    }

    private fun succSeat(): Int { for (q in 1 until n) if (remote[q]) return q; return -1 }

    /** everything needed to continue the game on another phone (at a round boundary) */
    private fun snapshot(): JSONObject {
        val j = JSONObject().put("n", n).put("bk", bBk).put("base", base).put("min", minBet).put("side", side).put("khabreMul", khabreMul).put("dealAll", dealAll).put("room", roomCode)
        val nm = JSONArray(); val ch = JSONArray(); val ids = JSONArray()
        for (i in 0 until n) { nm.put(names[i]); ch.put(if (i < bChips.size) bChips[i] else chips[i]); ids.put(if (i == 0) Prefs.devId() else idOf[i]) }
        j.put("names", nm).put("chips", ch).put("ids", ids)
        j.put("mins", JSONArray((0 until n).map { minArr[it] }))
        return j
    }

    /** the first connected guest is the successor: it gets the latest snapshot */
    private fun syncSucc() {
        val order = (1 until n).filter { remote[it] }
        if (order.isEmpty()) return
        val sn = snapshot()
        for ((rk, q) in order.withIndex()) sendSeat(q, JSONObject().put("t", "sync").put("snap", sn).put("rank", rk))      // each guest knows his place in the line of successors
    }

    /**
     * This phone becomes the host (the old host left, or a saved multi-phone game is loaded). [old] = the seat this phone had;
     * the seats are turned so that it becomes seat 0. The other players come back by their device id; until the host
     * presses "ادامه بازی" the game waits for them.
     */
    fun adoptHost(snap: JSONObject, old: Int, hello: String) {
        stopGame()
        val nn = snap.getInt("n")
        val on = snap.getJSONArray("names"); val oc = snap.getJSONArray("chips"); val oi = snap.getJSONArray("ids")
        val nm = Array(nn) { "" }; val ch = LongArray(nn)
        for (i in 0 until 10) { idOf[i] = ""; cidOf[i] = -1; remote[i] = false }
        for (i in 0 until nn) {
            val k = (i - old + nn) % nn
            nm[k] = on.getString(i); ch[k] = oc.getLong(i); idOf[k] = oi.getString(i)
        }
        role = "host"; mySeat = 0; n = nn
        names = nm.toList(); chips = ch
        for (i in 1 until nn) if (idOf[i].isNotEmpty()) names = names.toMutableList().also { it[i] = botName(it[i]) }      // the table shows that a robot plays the seats of those who are not back yet
        chips[0] = Prefs.wallet
        base = snap.getLong("base"); minBet = snap.getLong("min"); side = snap.getBoolean("side")
        khabreMul = snap.optInt("khabreMul", 3); dealAll = snap.optBoolean("dealAll", false)
        bk = (snap.getInt("bk") - old + nn) % nn
        minArr.fill(0L)
        snap.optJSONArray("mins")?.let { a -> for (i in 0 until Math.min(nn, a.length())) minArr[(i - old + nn) % nn] = a.optLong(i, 0L) }
        keepMins = true
        roomCode = snap.optString("room")
        isSucc = false; succRank = -1; syncSnap = null
        net?.becomeHost(roomCode, names[0])
        held = false
        startGame()
        say(hello)
        startHold("میزبانی به شما رسید.")      // as in the Hokm of 2 and 4 players: the game opens held, a robot plays for everyone who is not back
    }

    /** the connection to the host is gone and this phone is the successor */
    fun adoptFromSync() {
        val sn = syncSnap
        if (sn == null) { showReconnect(); return }
        Sched.laterRaw(1500L) {
            try { adoptHost(sn, mySeat, "میزبان قبلی قطع شد و میزبانی به شما رسید. بازیکنان به‌زودی دوباره وصل می‌شوند و تا آن موقع ربات جایشان بازی می‌کند.") } catch (e: Exception) { showReconnect() }
        }
    }

    /** a guest answered a question */
    fun onGuestMsg(cid: Int, m: JSONObject) {
        val s = cidOf.indexOf(cid)
        if (s < 1) return
        when (m.optString("t")) {
            "ans" -> ansQ[s].offer(m.optInt("id").toString() + "|" + m.optString("v"))
            "free" -> freeAt[s] = Sched.now() + m.optLong("ms")
            "cv" -> ui {
                when (m.optString("op")) {
                    "req" -> chipStart(s, m.optLong("base"), m.optLong("min"))
                    "ans" -> if (m.optInt("id") == voteId) voteRound?.answer(s, m.optBoolean("ok"))
                }
            }
            "name" -> { val v = m.optString("v").trim(); if (v.isNotEmpty()) ui { setName(s, v) } }
        }
    }

    /** a guest dropped: a robot plays his seat (with his chips) until he comes back */
    fun onGuestDrop(cid: Int) {
        val s = cidOf.indexOf(cid)
        if (s < 1) return
        remote[s] = false; cidOf[s] = -1
        ansQ[s].offer("drop")
        if (started) {
            val nm = humanName(names[s])
            names = names.toMutableList().also { it[s] = botName(nm) }      // the table shows that a robot plays this seat now
            broadcastNames()
            say(nm + Msg.DROPPED_BOT); startHold(nm + " قطع شد و ربات جای او آمد.")
        }
    }

    private fun humanName(s: String): String = s.removeSuffix(" (ربات)")
    private fun botName(s: String): String = humanName(s) + " (ربات)"

    /** a phone that sat here before says hello again: give his seat back. true when it was one of ours */
    fun onGuestHello(cid: Int, id: String): Boolean {
        if (!started || role != "host" || id.isEmpty()) return false
        for (s in 1 until n) {
            if (idOf[s] == id && !remote[s]) {
                remote[s] = true; cidOf[s] = cid
                names = names.toMutableList().also { it[s] = humanName(it[s]) }
                sendSeat(s, goMsg(s)); sendSeat(s, snapFor(s)); syncSucc(); broadcastNames()
                say(names[s] + " دوباره وصل شد و بازی را ادامه می‌دهد.")
                if (held) sendSeat(s, JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
                return true
            }
        }
        // as in the Hokm: when exactly one seat of a human who left is empty, a new phone takes it
        val vac = (1 until n).filter { !remote[it] && idOf[it].isNotEmpty() }
        val info = net?.peerInfo(cid)
        if (vac.size == 1 && info != null && info.wallet >= minBet) {
            val seat = vac[0]
            remote[seat] = true; cidOf[seat] = cid; idOf[seat] = id
            val cc = chips.copyOf(); cc[seat] = info.wallet; chips = cc
            val l = names.toMutableList(); l[seat] = uniqueName(info.name, seat); names = l
            sendSeat(seat, goMsg(seat)); sendSeat(seat, snapFor(seat))
            broadcastNames()
            if (held) sendSeat(seat, JSONObject().put("t", "hold").put("on", true).put("x", "بازی متوقف است تا میزبان («" + names[0] + "») ادامه را تأیید کند."))
            say(names[seat] + " به بازی اضافه شد و بازی را ادامه می‌دهد.")
            syncSucc()
            draw()
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ multi-phone: the guest side

    /** the host started (or we came back to) a game: show the table, no game thread here */
    private fun startGuest(m: JSONObject) {
        stopGame()
        role = "guest"; mySeat = m.getInt("seat"); n = m.getInt("n"); held = false
        val nm = m.getJSONArray("names")
        names = List(n) { nm.getString(it) }
        base = m.getLong("base"); minBet = m.getLong("min"); side = m.getBoolean("side")
        chips = LongArray(n) { base * 10 }
        bank = 0; bk = -1; cur = -1; mine = ArrayList(); bh = ArrayList(); reveal = false; firstUp = false; msg = ""; over = false
        lastMsg = ""; lastMine = ""; lastBank = ""
        Spk.reset(); Sound.resetQueue()
        buildGameView()
        started = true
    }

    private fun cardsOf(a: JSONArray): MutableList<Card> {
        val r = ArrayList<Card>()
        for (i in 0 until a.length()) { val id = a.getInt(i); r.add(if (id < 0) Card(0, 6) else Card(id / 20, id % 20)) }
        return r
    }

    /** a message from the host (runs on the UI thread) */
    fun onHostMsg(m: JSONObject) {
        try {
            when (m.optString("t")) {
                "go" -> { startGuest(m); isSucc = false; succRank = -1; syncSnap = null }
                "sync" -> { syncSnap = m.getJSONObject("snap"); isSucc = true; succRank = m.optInt("rank", 0) }
                "st" -> {
                    if (screen != "game") return
                    bank = m.getLong("bank"); bk = m.getInt("bk"); cur = m.getInt("cur"); msg = m.getString("msg"); reveal = m.getBoolean("rev"); firstUp = m.optBoolean("f0", false)
                    val c = m.getJSONArray("chips")
                    for (i in 0 until Math.min(n, c.length())) chips[i] = c.getLong(i)
                    mine = cardsOf(m.getJSONArray("mine")); bh = cardsOf(m.getJSONArray("bh"))
                    render()
                }
                "say" -> { val t = m.getString("m"); addLog(t); ann(t); render() }
                "fly" -> flyTo(m.getInt("s"))
                "coin" -> flyCoins(m.getInt("s"), m.getBoolean("w"), m.optLong("a", 0L))
                "col" -> flyCollect(m.getInt("s"))
                "chip" -> flyChip(m.getInt("a"), m.getInt("b"), m.getLong("m"))
                "fx" -> shake(m.getInt("s"))
                "wal" -> Prefs.wallet = m.optLong("v", Prefs.wallet)
                "names" -> { val a = m.getJSONArray("a"); if (a.length() == n) { names = List(n) { a.getString(it) }; render() } }
                "kick" -> { app.dlg.message("میزبان شما را از بازی حذف کرد. اگر خواستید می‌توانید دوباره وارد شوید."); net?.leave(); close() }
                "unsucc" -> { isSucc = false; succRank = -1; syncSnap = null }
                "xfer" -> ann("میزبانی به شما منتقل شد. بازیکنان به‌زودی دوباره وصل می‌شوند و تا آن موقع ربات جایشان بازی می‌کند.")
                "hold" -> { val t = m.optString("x"); if (m.optBoolean("on") && t.isNotEmpty()) { addLog(t); ann(t); render() } }
                "snd" -> { val sn = m.getString("n"); Sched.post { Sound.game(sn) }; if (sn == "shuffle") shuffleAnim() }
                "ask" -> onAsk(m)
                "cv" -> if (m.optString("op") == "cool") { coolMe = System.currentTimeMillis() + ChipVote.COOLDOWN_MS }
                else if (m.optString("op") == "ask") {
                    val id = m.optInt("id")
                    ui { ChipVote.voteDialog(act, app, m.optString("q")) { ok -> net?.toHost(JSONObject().put("t", "cv").put("op", "ans").put("id", id).put("ok", ok)) } }
                }
                "end" -> showOver("بازی تمام شد.")
            }
        } catch (e: Exception) { }
    }

    private fun onAsk(m: JSONObject) {
        if (screen != "game") return
        val id = m.getInt("id")
        if (m.getString("k") == "bet") {
            buildBet(m.getLong("mn"), m.getLong("mx"), m.getLong("bank"), m.getBoolean("all")) { v -> net?.toHost(JSONObject().put("t", "ans").put("id", id).put("v", v)) }
        } else {
            val o = m.getJSONArray("o")
            val opts = ArrayList<Pair<String, String>>()
            for (i in 0 until o.length()) { val x = o.getJSONArray(i); opts.add(x.getString(0) to x.getString(1)) }
            buildButtons(opts, m.optString("x")) { k -> net?.toHost(JSONObject().put("t", "ans").put("id", id).put("v", k)) }
        }
    }

    /** a message from the network layer, shown and read like the Hokm game's c5log + say */
    fun netNote(t: String) { ui { addLog(t); ann(t); render() } }

    /** the connection to the host dropped during a game: offer to connect again */
    fun showReconnect() {
        if (screen != "game" || role != "guest") return
        ctl.removeAllViews()
        ctl.addView(tv(Msg.CONN_LOST, 14f, Color.WHITE))
        ctl.addView(app.dlg.btn("اتصال دوباره", false) { net?.manualReconnect() })
        ctl.addView(app.dlg.btn("خروج از بازی", false) { net?.leave(); close() })
        ann(Msg.CONN_LOST)
    }

    // ------------------------------------------------------------------ تغییر ژتون (a vote while the game is played)

    private var coolMe = 0L

    private fun chipAsk() {
        val wait = Math.max(cooldownAt[mySeat] ?: 0L, coolMe) - System.currentTimeMillis()
        if (wait > 0) { app.dlg.message("بعد از رد شدن باید " + Cards.fa((wait / 1000 + 1).toInt()) + " ثانیه صبر کنید."); return }
        val curMin = mn(mySeat)
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(app.dlg.text("تغییر ژتون").also { it.setPadding(0, 0, 0, Px.dp(8)) })
        c.addView(app.dlg.text("بانک اولیهٔ فعلی: " + Cards.fa(base) + " — کمترین شرط شما: " + Cards.fa(curMin) + " — ژتون شما: " + Cards.fa(chips[mySeat]), 14f).also { it.setPadding(0, 0, 0, Px.dp(8)) })
        val e1 = numField(act, "بانک اولیهٔ تازه", base)
        val e2 = numField(act, "کمترین شرط تازه", curMin)
        c.addView(e1); c.addView(e2)
        c.addView(ChipVote.quickRow(act, app) { f -> e1.setText(Cards.fa(ChipVote.times(Cards.num(e1.text.toString()).coerceAtLeast(1L), f))); e2.setText(Cards.fa(ChipVote.times(Cards.num(e2.text.toString()).coerceAtLeast(1L), f))) })
        var d: android.app.Dialog? = null
        c.addView(app.dlg.btn("درخواست تغییر") {
            val nb = Cards.num(e1.text.toString()); val nm = Cards.num(e2.text.toString())
            if (nb < 1 || nm < 1) { app.dlg.message("مبلغ‌ها باید دست‌کم ۱ باشند."); return@btn }
            if (nb == base && nm == curMin) { app.dlg.message("چیزی عوض نشده است."); return@btn }
            if (nm > chips[mySeat]) { app.dlg.message("کمترین شرط از ژتون شما (" + Cards.fa(chips[mySeat]) + ") بیشتر است."); return@btn }
            if (nb < nm) { app.dlg.message("بانک اولیه نباید از کمترین شرط کمتر باشد."); return@btn }
            d?.dismiss()
            if (role == "guest") { net?.toHost(JSONObject().put("t", "cv").put("op", "req").put("base", nb).put("min", nm)); netNote(Msg.CHIP_SENT) }
            else chipStart(0, nb, nm)
        })
        c.addView(app.dlg.btn("بستن") { d?.dismiss() })
        d = app.dlg.custom(c)
    }

    /** host: seat [req] wants the bank [nb] and his own smallest bet [nm]. Everybody who says yes gets the new smallest bet; the bank changes with the banker's yes. Only they hear of it. */
    private fun chipStart(req: Int, nb: Long, nm: Long) {
        if (role == "guest" || over) return
        val chgBank = nb != base
        val chgMin = nm != mn(req)
        if (!chgBank && !chgMin) return
        if (nm > chips[req]) { sayTo(req, "کمترین شرط از ژتون شما بیشتر است."); return }
        if (nb < nm) { sayTo(req, "بانک اولیه نباید از کمترین شرط کمتر باشد."); return }
        if (voteRound != null) { sayTo(req, Msg.CHIP_BUSY); return }
        if (System.currentTimeMillis() < (cooldownAt[req] ?: 0L)) { sayTo(req, Msg.CHIP_WAIT); return }
        // only a smaller smallest bet for himself: nobody is asked
        if (!chgBank && nm < mn(req)) { minArr[req] = nm; sayTo(req, "کمترین شرط شما " + Cards.fa(nm) + " شد."); draw(); return }
        val humans = (0 until n).filter { isH(it) }
        val banker = bk
        val bankerHuman = banker in humans
        val voters = ArrayList<Int>()
        if (chgMin) voters.addAll(humans.filter { it != req })
        else if (chgBank && bankerHuman && banker != req) voters.add(banker)
        val bankFree = chgBank && (banker == req || !bankerHuman)      // nobody has to agree to this bank change
        if (voters.isEmpty()) { chipDone(req, nb, nm, chgBank, chgMin, banker, voters, emptyMap()); return }
        val id = ++voteId
        fun q(v: Int): String {
            val parts = ArrayList<String>()
            if (chgMin) parts.add("کمترین شرط شما هم از " + Cards.fa(mn(v)) + " به " + Cards.fa(nm) + " برسد")
            if (chgBank && v == banker && !bankFree) parts.add("بانک اولیه از " + Cards.fa(base) + " به " + Cards.fa(nb) + " برسد")
            return names[req] + " می‌خواهد " + parts.joinToString(" و ") + ". قبول دارید؟"
        }
        sayTo(req, "رأی‌گیری شروع شد.")
        val longest = voters.maxOf { q(it).length }
        voteRound = ChipVote.Round(voters, ChipVote.VOTE_MS + 1500L + longest * 50L + 2500L) { map -> ui { chipDone(req, nb, nm, chgBank, chgMin, banker, voters, map) } }
        for (v in voters) {
            if (v == 0) ui { ChipVote.voteDialog(act, app, q(0)) { ok -> voteRound?.answer(0, ok) } }
            else sendSeat(v, JSONObject().put("t", "cv").put("op", "ask").put("id", id).put("q", q(v)))
        }
        voteRound?.start()
    }

    private fun chipDone(req: Int, nb: Long, nm: Long, chgBank: Boolean, chgMin: Boolean, banker: Int, voters: List<Int>, map: Map<Int, Boolean>) {
        voteRound = null
        val acc = voters.filter { map[it] == true }
        val humans = (0 until n).filter { isH(it) }
        val bankerHuman = banker in humans
        var minOk = false; var newBase = -1L
        val inMin = ArrayList<Int>()
        if (chgMin) {
            if (voters.isEmpty() || acc.isNotEmpty()) {
                inMin.addAll(acc.filter { chips[it] >= nm })
                minArr[req] = nm; for (a in inMin) minArr[a] = nm
                minOk = true
            }
        }
        if (chgBank && (banker == req || !bankerHuman || banker in acc)) newBase = applyBank(nb)
        if (!minOk && newBase < 0) {
            cooldownAt[req] = System.currentTimeMillis() + ChipVote.COOLDOWN_MS
            if (req != 0) sendSeat(req, JSONObject().put("t", "cv").put("op", "cool"))
            sayTo(req, if (voters.isEmpty()) "تغییر ممکن نبود." else "درخواست ژتون رد شد.")
            return
        }
        val refused = voters.filter { it !in acc }.joinToString("، ") { names[it] }
        val tr = ArrayList<String>()
        if (minOk) tr.add("کمترین شرط شما " + Cards.fa(nm) + " شد" + (if (inMin.isNotEmpty()) " (با " + inMin.joinToString("، ") { names[it] } + ")" else ""))
        if (newBase >= 0) tr.add("بانک اولیه " + Cards.fa(newBase) + " شد")
        sayTo(req, tr.joinToString(" و ") + "." + (if (refused.isNotEmpty()) " " + refused + " رد کرد." else ""))
        for (a in inMin) sayTo(a, "کمترین شرط شما با " + names[req] + " " + Cards.fa(nm) + " شد.")
        if (newBase >= 0 && banker != req && bankerHuman) sayTo(banker, "بانک اولیه " + Cards.fa(newBase) + " شد.")
        draw()
    }

    /** the bank changes at once: what is on the table moves by the difference (the banker pays more or gets back). Returns the new base, -1 when it was not possible */
    private fun applyBank(nb: Long): Long = synchronized(chipLock) {
        var d = nb - base
        if (bank > 0) {
            if (d > 0) d = Math.min(d, chips[bk])
            if (bank + d < Math.max(1L, minBet)) return@synchronized -1L
            chips[bk] -= d; bank += d
        }
        if (d == 0L) return@synchronized -1L
        base += d
        base
    }

    // ------------------------------------------------------------------ the menu inside the game

    private fun applyBg() {
        val bmp = if (Prefs.bg > 0) Assets.bitmap(act, Assets.bgPath(Prefs.bg)) else null
        if (!::felt.isInitialized) return
        felt.background = if (bmp != null) CoverDrawable(bmp, 0x1F000000) else Px.rounded(Px.FELT, 16)
        felt.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, Px.dp(16).toFloat()) }
        }
        felt.clipToOutline = true
    }

    private fun gameMenu() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        if (role != "guest") items.add("بازی جدید" to { askNewGame() })
        items.add("تغییر نام" to { renameAsk() })
        if (role == "host") {
            if (freeSeats().isNotEmpty()) items.add("افزودن بازیکن" to { addAsk() })
            if (succSeat() > 0) {
                items.add("حذف بازیکن" to { removeAsk() })
                items.add("انتقال میزبانی" to { xferAsk() })
            }
        }
        if (!over) items.add("تغییر ژتون" to { chipAsk() })
        if (role != "guest") items.add("ذخیره" to { manualSave() })
        items.add(("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) to { app.a11yToggle(); if (Prefs.a11y) sayTo(0, "دسترس‌پذیر بودن برنامه روشن شد."); ui { render() } })
        items.add("سرعت انیمیشن" to { app.animSpeedAsk() })
        items.add("تنظیمات صدا" to { app.dlg.sound() })
        items.add("تنظیمات تصویر زمینه" to { app.dlg.cards("bg") { applyBg() } })
        items.add("تنظیمات پشت کارت" to { app.dlg.cards("back") { ui { render() } } })
        items.add("خروج" to { quitAsk() })
        app.dlg.list("گزینه‌های بیشتر", items)
    }

    private fun askNewGame() {
        app.dlg.confirm(Msg.NEW_ASK, {
            if (role == "host") { stopGame(); app.hostPageAfterGame("21") }      // as in Hokm: the host goes back to the room where the phones stay connected
            else stepBack()
        })
    }

    /** one step back for a game against the bots: the setup screen */
    private fun stepBack() {
        stopGame(); started = false
        close(); app.newGamePage()      // the same new-game page as the main menu's (game type and its settings)
    }

    /** the host page of the main menu uses this game: its settings and players are shown there; this game's own screen opens when the game starts */
    fun hostInPage(room: String, name: String, ps: List<HandPeer>, box: LinearLayout, plist: LinearLayout, infoTv: TextView) {
        val nt = Net21(act, app, this); net = nt
        nt.adoptHostInPage(room, name, ps, box, plist, infoTv)
    }
    fun hostStartFromPage() { net?.startFromPage() }
    fun hostState(): Triple<String, String, List<HandPeer>>? = net?.handoff()
    fun ensureHostShown() { show("blank") }

    /** a saved game chosen in the common list of saved games */
    fun resumeExternal(e: Saves.E) { show("blank"); resumeFrom(e) }
    fun resumeMultiExternal(e: Saves.E) { show("net"); net?.resumeSaved(e) }

    /** the phone's back button during a game */
    private fun backAsk() {
        if (role == "solo") { app.dlg.confirm(Msg.BACK_SOLO, { stepBack() }); return }
        val txt = if (role == "host" && succSeat() > 0) "از بازی خارج می‌شوید؟ میزبانی به بازیکن بعدی داده می‌شود."
        else if (role == "guest") Msg.LEAVE_GUEST
        else "از بازی خارج می‌شوید؟"
        app.dlg.confirm(txt, { net?.leave(); close() })
    }

    private fun quitAsk() {
        val q = if (role == "host") succSeat() else -1
        if (q > 0) {      // as in Hokm: the game is handed to a connected player and a robot plays for the host
            app.dlg.confirm("مطمئنید؟ برنامه کاملاً بسته می‌شود. میزبانی به " + names[q] + " منتقل می‌شود و ربات جای شما بازی می‌کند.", { transferTo(q, true) })
            return
        }
        val txt = "مطمئنید؟ برنامه کاملاً بسته می‌شود." +
            (if (role == "host") " بازیکن دیگری در بازی نیست و بازی تمام می‌شود."
            else if (role == "guest") " شما از بازی کنار می‌روید و ربات جای شما بازی می‌کند."
            else if (role == "solo") " بازی تا پایان دست قبل ذخیره شده است." else "")
        app.dlg.confirm(txt, {
            net?.leave()
            act.root.postDelayed({ act.bridge.exitApp() }, 500)
        })
    }

    // ---- names ----

    private fun uniqueName(nm: String, seat: Int): String {
        var x = nm; var i = 2
        while (names.indices.any { it != seat && names[it] == x }) { x = nm + " " + Cards.fa(i); i++ }
        return x
    }

    private fun broadcastNames() {
        val a = JSONArray(); for (x in names) a.put(x)
        sendAll(JSONObject().put("t", "names").put("a", a))
    }

    private fun setName(seat: Int, nm: String) {
        if (seat < 0 || seat >= names.size) return
        val l = names.toMutableList(); l[seat] = uniqueName(nm, seat); names = l
        if (role == "host") broadcastNames()
        draw()
    }

    private fun renameAsk() {
        app.dlg.nameAsk(true) { v ->
            val nm = v.trim()
            if (nm.isNotEmpty()) {
                Prefs.name = nm
                if (role == "guest") net?.toHost(JSONObject().put("t", "name").put("v", nm)) else setName(0, nm)
            }
        }
    }

    // ---- players come and go (applied at the start of the next hand) ----

    // ---- the host adds a waiting phone in the place of a robot / removes a player (like the Hokm game: the seats stay fixed) ----

    private fun freeSeats(): List<Int> { val l = ArrayList<Int>(); for (q in 1 until n) if (!remote[q]) l.add(q); return l }

    private fun addAsk() {
        if (role != "host" || !started) return
        val seats = freeSeats()
        if (seats.isEmpty()) { app.dlg.message("جای خالی نیست."); return }
        val w = net?.waiting() ?: emptyList()
        if (w.isEmpty()) {
            app.dlg.list("بازیکن جدیدی وصل نیست. از او بخواهید «به بازی دیگری می‌پیوندم» را بزند و گوشی میزبان را انتخاب کند؛ بعد «بررسی دوباره» را بزنید.",
                listOf("بررسی دوباره" to { addAsk() }))
            return
        }
        val pick = { cid: Int, nm: String ->
            if (seats.size == 1) addPlayer(cid, seats[0])
            else app.dlg.list("«" + nm + "» جای کدام بازیکن یا ربات بنشیند؟", seats.map { x -> names[x] to { addPlayer(cid, x) } })
        }
        if (w.size == 1) { pick(w[0].first, w[0].second); return }
        app.dlg.list("کدام بازیکن به بازی اضافه شود؟", w.map { p -> p.second to { pick(p.first, p.second) } })
    }

    /** the waiting phone [cid] takes the place of the robot on [seat] */
    private fun addPlayer(cid: Int, seat: Int) {
        if (role != "host" || !started || seat < 1 || seat >= n || remote[seat] || cidOf.indexOf(cid) >= 1) return
        val info = net?.peerInfo(cid) ?: return
        if (info.wallet < minBet) { app.dlg.message("«" + info.name + "» سکهٔ کافی برای کمترین شرط (" + Cards.fa(minBet) + ") ندارد و نمی‌تواند وارد بازی شود."); return }
        remote[seat] = true; cidOf[seat] = cid; idOf[seat] = info.id
        val cc = chips.copyOf(); cc[seat] = info.wallet; chips = cc
        val l = names.toMutableList(); l[seat] = uniqueName(info.name, seat); names = l
        sendSeat(seat, goMsg(seat)); sendSeat(seat, snapFor(seat))
        broadcastNames()
        say(names[seat] + " به بازی اضافه شد و بازی را ادامه می‌دهد.")
        syncSucc()
        draw()
    }

    private fun removeAsk() {
        if (role != "host" || !started) return
        val ids = ArrayList<Int>(); for (q in 1 until n) if (remote[q]) ids.add(q)
        if (ids.isEmpty()) { app.dlg.message("بازیکن دیگری با گوشی در بازی نیست."); return }
        val q = { s: Int -> app.dlg.confirm("«" + names[s] + "» از بازی حذف شود؟ ربات جای او بازی می‌کند. او می‌تواند دوباره وارد بازی شود.", { kickPlayer(s) }) }
        if (ids.size == 1) { q(ids[0]); return }
        app.dlg.list("کدام بازیکن از بازی حذف شود؟", ids.map { s -> names[s] to { q(s) } })
    }

    private fun kickPlayer(s: Int) {
        if (role != "host" || !started || s < 1 || s >= n || !remote[s]) return
        val cid = cidOf[s]; val nm = humanName(names[s])
        sendSeat(s, JSONObject().put("t", "kick"))
        Sched.laterRaw(400) { net?.dropPeer(cid) }      // as in the Hokm: the link is closed; the same phone can enter again and gets its seat back
        remote[s] = false; cidOf[s] = -1          // as in Hokm: a robot plays his seat; his id stays, so he gets the seat back when he joins again
        ansQ[s].offer("drop")
        names = names.toMutableList().also { it[s] = botName(nm) }
        broadcastNames()
        say(nm + Msg.KICKED_BOT)
        syncSucc()
        draw()
    }

    // ---- the host hands the game to a player he chooses ----

    private fun xferAsk() {
        val items = ArrayList<Pair<String, () -> Unit>>()
        for (i in 1 until n) if (remote[i]) {
            val s = i
            items.add(names[i] to { app.dlg.confirm("میزبانی همین الان به «" + names[s] + "» منتقل شود؟ بعد از آن شما بازیکن عادی هستید و تا وصل شدن دوباره‌ی بازیکن‌ها، ربات جایشان بازی می‌کند.", { transferTo(s) }) })
        }
        app.dlg.list("میزبانی به کدام بازیکن منتقل شود؟", items, "بستن")
    }

    private fun transferTo(s: Int, exitApp: Boolean = false) {
        sendAll(JSONObject().put("t", "unsucc"))
        sendSeat(s, JSONObject().put("t", "sync").put("snap", snapshot()))
        sendSeat(s, JSONObject().put("t", "xfer"))
        say("میزبانی در حال انتقال به " + names[s] + " است...")
        val rm = net?.curRoom() ?: ""
        Sched.laterRaw(1500L) {
            if (exitApp || rm.isEmpty()) { net?.leave(); close(); if (exitApp) act.bridge.exitApp() }
            else ui {      // as in the Hokm of 2 and 4 players: this phone becomes a normal player of the new host
                stopGame(); held = false
                role = "guest"; started = true; isSucc = false; succRank = -1; syncSnap = null
                net?.becomeClient(rm, if (Prefs.name.isEmpty()) "بازیکن" else Prefs.name)
                showReconnect()
            }
        }
    }

    companion object {
        /** coins a new player gets the first time he enters (and the robots get in every game) */
        const val START = 1000000L
        /** below this a player cannot even make the smallest bet: his coins are finished */
        const val MIN_PLAY = 1L
        const val BROKE = "سکه‌های شما تمام شده است و دیگر نمی‌توانید بازی کنید. برای گرفتن دوبارهٔ یک میلیون سکه باید برنامه را حذف و دوباره نصب کنید."
    }
}
