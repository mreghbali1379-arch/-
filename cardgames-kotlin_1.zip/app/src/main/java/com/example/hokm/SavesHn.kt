package com.example.hokm

import org.json.JSONArray
import org.json.JSONObject

/** Saved 3/5/6-player Hokm games, with dates: only the ones the player saves himself (nothing is saved automatically). */
object SavesHn {
    class E(@JvmField val id: String, @JvmField val t: Long, @JvmField val multi: Boolean, @JvmField val data: String)

    private fun read(): MutableList<E> {
        val r = ArrayList<E>()
        try {
            val a = JSONArray(Prefs.hnlist)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                r.add(E(o.getString("id"), o.getLong("t"), o.getBoolean("m"), o.getString("d")))
            }
        } catch (e: Exception) { }
        return r
    }

    private fun write(l: List<E>) {
        val a = JSONArray()
        for (e in l) a.put(JSONObject().put("id", e.id).put("t", e.t).put("m", e.multi).put("d", e.data))
        Prefs.hnlist = a.toString()
    }

    /** the saves of one kind, newest first */
    fun all(multi: Boolean): List<E> = read().filter { it.multi == multi }.sortedByDescending { it.t }

    fun put(id: String, multi: Boolean, data: String) {
        val l = read()
        l.removeAll { it.id == id }
        l.add(E(id, System.currentTimeMillis(), multi, data))
        // at most 12 saves of his own per kind
        val own = l.filter { it.multi == multi }.sortedBy { it.t }
        if (own.size > 12) l.remove(own[0])
        write(l)
    }

    fun del(id: String) {
        val l = read()
        l.removeAll { it.id == id }
        write(l)
    }

    fun date(t: Long): String = Cards.fa(java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.US).format(java.util.Date(t)))

    /** one line that describes a save: date, kind, number of players */
    fun describe(e: E): String {
        var n = 0
        try { n = JSONObject(e.data).getJSONArray("names").length() } catch (x: Exception) { }
        return date(e.t) + " — " + Cards.fa(n) + " بازیکن"
    }
}
