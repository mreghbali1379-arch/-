package com.example.hokm

/** a phone that is connected to the lobby of a game (kept when the lobby changes to another game) */
class HandPeer(@JvmField val cid: Int, @JvmField val name: String, @JvmField val addr: String)

/**
 * The games of the app: "hokm" (2 and 4 players), "21", "cb" (Chahar Barg / Pasur), and the Hokm of 3, 5 and 6 players:
 * "hn3", "hn5", "hn62" (two teams of three), "hn63" (three teams of two).
 */
object Kinds {
    val ids = listOf("hokm", "21", "cb", "hn3", "hn5", "hn62", "hn63")
    val names = listOf("حکم", "بیست و یک", "چهار برگ", "حکم سه نفره", "حکم پنج نفره", "حکم شش نفره، دو تیم سه نفره", "حکم شش نفره، سه تیم دو نفره")
    /** the three games of the new-game page (the Hokm types are chosen inside Hokm there) */
    val games: List<String> get() = names.take(3)
    fun index(k: String): Int = Math.max(0, ids.indexOf(k))
    fun name(k: String): String = names[index(k)]
    fun isHn(k: String): Boolean = k.startsWith("hn")
    /** the Hokm kind of an "hn" id: 3, 5, 62 or 63 (3 when it is not one) */
    fun hnKind(k: String): Int = k.removePrefix("hn").toIntOrNull() ?: 3
}
