package com.example.hokm

/**
 * One definition of Hokm for every number of players (2, 3, 4, 5 and 6).
 *
 * The two- and four-player games are the originals; the games for 3, 5 and 6 players are the same game with other numbers:
 * how many players, how many sides, how many 2s leave the pack, how many cards each player gets. Everything that the games
 * share lives here (the sides, the pack, the end of a hand, the points), so the games cannot differ from each other:
 *
 *   players | sides                    | 2s out | tricks | deal   | kot (first tricks)
 *   2       | 2 (each alone)           | 2      | 13     | (pile) | 7
 *   3       | 3 (each alone)           | 1      | 17     | 5+4+4+4| 7
 *   4       | 2 (seat % 2)             | 0      | 13     | 5+8    | 7
 *   5       | 5 (each alone)           | 2      | 10     | 4+6    | 6
 *   6 (62)  | 2 teams of three (% 2)   | 4      | 8      | 3+5    | 5
 *   6 (63)  | 3 teams of two   (% 3)   | 4      | 8      | 3+5    | 5
 *
 * 2 and 4 players: the first side with 7 tricks wins the hand (1 point); if the others have no trick at that moment it is a
 * kot and the hand goes on until another side takes a trick. 3, 5 and 6 players: the hand ends when a side has a number of
 * tricks that no other side can pass or reach earlier (its tricks >= every other side's tricks + the tricks left); when all
 * the tricks are played and sides are equal, the side that reached the number first wins.
 * In all of them: a kot is 2 points (3 against the hakem's side), all the tricks is a bam (the whole game), the first side
 * with 7 points wins the game.
 *
 * Plain Kotlin (nothing of Android) so that the rules can be tested alone.
 */
object HokmCore {
    /** tricks that win a hand, and points that win the game */
    const val TARGET = 7

    /** what a bam is worth to the bots' searches (the whole game) */
    const val BAM_VALUE = 7

    /** the shape of one kind of the game; [kind]: 2, 3, 4, 5, 62 (six players, two teams of three), 63 (six players, three teams of two) */
    class Spec internal constructor(@JvmField val kind: Int) {
        @JvmField val players: Int = if (kind > 10) kind / 10 else kind
        @JvmField val teams: Int = when (kind) { 4, 62 -> 2; 63 -> 3; else -> players }

        /** the 2s that leave the pack (fixed suits; the two-player game picks its suits by chance, so none here) */
        @JvmField val outSuits: List<Int> = when (kind) { 3 -> listOf(2); 5 -> listOf(2, 3); 62, 63 -> listOf(0, 1, 2, 3); else -> emptyList() }
        @JvmField val twosOut: Int = when (players) { 2 -> 2; 3 -> 1; 5 -> 2; 6 -> 4; else -> 0 }

        /** the tricks of a hand = the cards of each player */
        @JvmField val tricks: Int = if (players == 2) 13 else (52 - twosOut) / players

        /** the cards dealt before the hakem chooses the trump, and the cards dealt each time after it */
        @JvmField val firstSize: Int = when (players) { 5 -> 4; 6 -> 3; else -> 5 }
        @JvmField val series: Int = when (players) { 5 -> 6; 3 -> 4; 6 -> 5; else -> tricks - firstSize }

        /** 3, 5 and 6 players: the hand ends as soon as a side cannot be overtaken any more (see [roundWinnerFor]) */
        @JvmField val unbeatable: Boolean = players == 3 || players == 5 || players == 6

        /** a kot: a side wins this many of the first tricks while the others have none */
        @JvmField val kotTricks: Int = when (players) { 5 -> 6; 6 -> 5; else -> TARGET }

        fun teamOf(seat: Int): Int = when (kind) { 4, 62 -> seat % 2; 63 -> seat % 3; else -> seat }

        /** the pack of this game, in the order of suits and ranks (not shuffled) */
        fun deck(): MutableList<Card> {
            val d = ArrayList<Card>()
            for (s in 0 until 4) for (r in 2..14) if (!(r == 2 && outSuits.contains(s))) d.add(Card(s, r))
            return d
        }
    }

    private val specs = HashMap<Int, Spec>()

    @JvmStatic
    fun spec(kind: Int): Spec = synchronized(specs) { specs.getOrPut(kind) { Spec(kind) } }

    // ------------------------------------------------------------------ the end of a hand

    /** the first side that has 7 tricks, or -1 */
    @JvmStatic
    fun sevenSide(tw: IntArray, teams: Int): Int {
        for (t in 0 until teams) if (tw[t] >= TARGET) return t
        return -1
    }

    /** no side but [side] has a trick */
    @JvmStatic
    fun othersZero(tw: IntArray, teams: Int, side: Int): Boolean {
        for (t in 0 until teams) if (t != side && tw[t] != 0) return false
        return true
    }

    /** the kot side: [kt] when it is known already, else the side that has 7 tricks while the others have none, else -1 */
    @JvmStatic
    fun kotOf(tw: IntArray, teams: Int, kt: Int): Int {
        if (kt >= 0) return kt
        val s = sevenSide(tw, teams)
        return if (s >= 0 && othersZero(tw, teams, s)) s else -1
    }

    /**
     * The side that wins the hand now, or -1 while it goes on: a side has 7 tricks and another side has a trick too, or a
     * side has all the [tricks] (a bam). A side with 7 tricks and the others with none is a kot, and the hand goes on.
     */
    @JvmStatic
    fun roundWinner(tw: IntArray, teams: Int, tricks: Int): Int {
        val hs = sevenSide(tw, teams)
        if (hs < 0) return -1
        return if (!othersZero(tw, teams, hs) || tw[hs] == tricks) hs else -1
    }

    /** the kot side for any kind of the game (the kot is kept once it is made) */
    @JvmStatic
    fun kotFor(spec: Spec, tw: IntArray, kt: Int): Int {
        if (kt >= 0) return kt
        for (t in 0 until spec.teams) if (tw[t] >= spec.kotTricks && othersZero(tw, spec.teams, t)) return t
        return -1
    }

    /**
     * The side that wins the hand now (after a trick) for any kind of the game, or -1 while it goes on; [remaining] = tricks
     * still to be played. 2 and 4 players: see [roundWinner]. 3, 5 and 6 players: a bam ends it; otherwise a side that has
     * a trick-taking opponent ends it when it has at least (tricks of every other side + [remaining]), because then nobody
     * can pass it and anybody who equals it does so later. While the others have no trick at all the hand goes on (a kot,
     * and maybe a bam). When no trick is left and nobody is decided, the caller uses [fallbackWinner].
     */
    @JvmStatic
    fun roundWinnerFor(spec: Spec, tw: IntArray, remaining: Int): Int {
        val teams = spec.teams
        if (!spec.unbeatable) return roundWinner(tw, teams, spec.tricks)
        for (t in 0 until teams) if (tw[t] == spec.tricks) return t
        if (remaining <= 0) return -1
        for (l in 0 until teams) {
            if (othersZero(tw, teams, l)) continue
            var ok = true
            for (o in 0 until teams) if (o != l && tw[l] < tw[o] + remaining) { ok = false; break }
            if (ok) return l
        }
        return -1
    }

    /**
     * Nobody could be decided by the tricks above (possible with 3, 5 and 6 players): the side with the most tricks wins; when sides are equal,
     * the one that reached its number first ([reachedAt][side] = the trick at which it got its present number of tricks).
     */
    @JvmStatic
    fun fallbackWinner(tw: IntArray, teams: Int, reachedAt: IntArray): Int {
        var mx = 0
        for (t in 0 until teams) mx = Math.max(mx, tw[t])
        var best = -1
        for (t in 0 until teams) if (tw[t] == mx && (best < 0 || reachedAt[t] < reachedAt[best])) best = t
        return best
    }

    /** what a finished hand came to */
    class Result(
        @JvmField val side: Int,
        @JvmField val bam: Boolean,
        @JvmField val kot: Boolean,
        /** the winning side is the hakem's side */
        @JvmField val hakemSide: Boolean,
        /** the points that were added (a bam: the game is won whatever this is) */
        @JvmField val gain: Int,
        /** the game is over: the side has [TARGET] points */
        @JvmField val game: Boolean
    )

    /**
     * Adds the points of a hand won by [side] to [pts] and tells what it was. [tw] = tricks of the sides, [kt] = the kot side
     * (or -1), [hakemTeam] = the side of the hakem. The hakem changes in the caller: when [Result.hakemSide] is false the next
     * seat becomes the hakem.
     */
    @JvmStatic
    fun settle(pts: IntArray, side: Int, tw: IntArray, tricks: Int, kt: Int, hakemTeam: Int): Result {
        val bam = tw[side] == tricks
        val kot = bam || kt == side
        val g = HokmRules.gain(kot, side == hakemTeam)
        pts[side] += g
        if (bam) pts[side] = Math.max(pts[side], TARGET)
        return Result(side, bam, kot, side == hakemTeam, g, pts[side] >= TARGET)
    }

    // ------------------------------------------------------------------ for the bots' searches

    /**
     * Adds a trick of side [w] to [t] = (tricks of the sides..., the kot side at index [teams], -1 for none) and records
     * the kot when the side reaches 7 tricks while the others have none.
     */
    @JvmStatic
    fun advance(t: IntArray, teams: Int, w: Int) {
        t[w]++
        if (t[teams] < 0 && t[w] >= TARGET && othersZero(t, teams, w)) t[teams] = w
    }

    /**
     * The points of the hand for [team] as the bots count them: positive when [team] won it, negative when another side
     * did (a bam is [BAM_VALUE]); null while the hand is not decided.
     */
    @JvmStatic
    fun signedPoints(tw: IntArray, teams: Int, tricks: Int, kt: Int, hakemTeam: Int, team: Int): Int? {
        val w = sevenSide(tw, teams)
        if (w < 0) return null
        if (othersZero(tw, teams, w)) {
            if (tw[w] < tricks) return null
            return if (w == team) BAM_VALUE else -BAM_VALUE
        }
        val p = HokmRules.gain(kt == w, w == hakemTeam)
        return if (w == team) p else -p
    }
}
