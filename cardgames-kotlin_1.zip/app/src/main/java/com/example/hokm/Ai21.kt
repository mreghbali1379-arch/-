package com.example.hokm

/**
 * The robots' brain for "بیست و یک". Pure logic, no UI.
 *
 * A robot never looks at a hidden card: it only knows the cards it holds and the cards already shown (the [seen] list),
 * so everything that is not known is "unknown" (it includes the hidden cards of the others). From the unknown cards it
 * works out the exact chances (counting cards) and takes the choice with the best chance to win.
 *  - the player: draw or stop, by the exact chance of winning against a banker who draws up to 15, 16 or 17
 *  - the banker: draw or stop, by the chance that the player's total is not higher (a player's total is guessed from
 *    how players usually stop, and from what this very player showed in the earlier hands of this game)
 *  - the bet grows with the robot's edge (an ace or a 10 as the first card, or a deck rich in them)
 */
object Ai21 {
    /** value of rank index 0..8 (the ranks 6,7,8,9,10,J,Q,K,A) */
    private val V = intArrayOf(6, 7, 8, 9, 10, 2, 3, 4, 11)
    private const val BUST = 22

    /** a banker never changes a card he has just been dealt: no card is changed in the chances the player works out */
    const val SWAP_MAX = 0


    // how players that are not robots usually stop (chance of each final total 15..21, by the number of cards they hold)
    private val P2 = doubleArrayOf(0.0, 0.186, 0.240, 0.191, 0.161, 0.109, 0.114)
    private val P3 = doubleArrayOf(0.009, 0.169, 0.183, 0.159, 0.168, 0.148, 0.164)
    private val P4 = doubleArrayOf(0.044, 0.130, 0.164, 0.164, 0.158, 0.147, 0.193)

    /** the cards of each rank that are not known: all 4 of each, less the cards seen and the cards in [mine] */
    private fun left(seen: List<Card>, mine: List<Card>): IntArray {
        val c = IntArray(9) { 4 }
        for (x in seen) { val i = x.r - 6; if (i in 0..8) c[i]-- }
        for (x in mine) { val i = x.r - 6; if (i in 0..8) c[i]-- }
        for (i in 0 until 9) if (c[i] < 0) c[i] = 0
        return c
    }

    private fun sum(c: IntArray): Int { var t = 0; for (x in c) t += x; return t }

    // ------------------------------------------------------------------ the banker as the player sees him

    /** chance of every final total of a banker who changes a low first card and then draws while his total is under [stop] */
    private fun bankDist(c: IntArray, stop: Int): DoubleArray {
        val res = DoubleArray(23)
        val tot = sum(c)
        if (tot == 0) { res[0] = 1.0; return res }
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = c[i].toDouble() / tot
            c[i]--
            if (V[i] <= SWAP_MAX) {
                val t2 = sum(c)
                if (t2 > 0) {
                    for (j in 0 until 9) {
                        if (c[j] == 0) continue
                        val q2 = c[j].toDouble() / t2
                        c[j]--
                        bdRec(c, V[j], 1, j == 8, stop, q * q2, res)
                        c[j]++
                    }
                }
            } else bdRec(c, V[i], 1, i == 8, stop, q, res)
            c[i]++
        }
        return res
    }

    private fun bdRec(c: IntArray, t: Int, n: Int, fa: Boolean, stop: Int, p: Double, res: DoubleArray) {
        if (t > 21) { res[BUST] += p; return }
        if (t >= stop) { res[t] += p; return }
        val tot = sum(c)
        if (tot == 0) { res[t] += p; return }
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = p * c[i].toDouble() / tot
            c[i]--
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            bdRec(c, nt, n + 1, fa, stop, q, res)
            c[i]++
        }
    }

    /** the banker is not known: he may draw up to 15, 16 or 17 */
    private fun bankMix(c: IntArray): DoubleArray {
        val out = DoubleArray(23)
        for (stop in intArrayOf(15, 16, 17)) {
            val d = bankDist(c, stop)
            for (k in 0 until 23) out[k] += d[k] / 3.0
        }
        return out
    }

    /** the banker's final total given what the player can see: he holds [nb] cards (not their values), and [stood] = he has said "enough" (he stopped with exactly [nb]) */
    private fun bankCond(c: IntArray, nb: Int, stood: Boolean, stop: Int): DoubleArray? {
        val res = DoubleArray(23)
        val tot = sum(c)
        if (tot == 0) return null
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = c[i].toDouble() / tot
            c[i]--
            condRec(c, V[i], 1, i == 8, nb, stood, stop, q, res)
            c[i]++
        }
        var z = 0.0
        for (x in res) z += x
        if (z <= 0.0) return null
        for (k in 0 until 23) res[k] /= z
        return res
    }

    private fun condRec(c: IntArray, t: Int, n: Int, fa: Boolean, nb: Int, stood: Boolean, stop: Int, p: Double, res: DoubleArray) {
        val ok = if (stood) n == nb else n >= nb
        if (t > 21) { if (!stood && ok) res[BUST] += p; return }
        var end = t >= stop
        var tot = 0
        if (!end) { tot = sum(c); if (tot == 0) end = true }
        if (end) { if (ok) res[t] += p; return }
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = p * c[i].toDouble() / tot
            c[i]--
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            condRec(c, nt, n + 1, fa, nb, stood, stop, q, res)
            c[i]++
        }
    }

    private fun bankMixCond(c: IntArray, nb: Int, stood: Boolean): DoubleArray {
        if (nb <= 1 && !stood) return bankMix(c)
        val out = DoubleArray(23)
        var k = 0
        for (stop in intArrayOf(15, 16, 17)) {
            val d = bankCond(c, nb, stood, stop) ?: continue
            k++
            for (j in 0 until 23) out[j] += d[j]
        }
        if (k == 0) return bankMix(c)
        for (j in 0 until 23) out[j] /= k.toDouble()
        return out
    }

    // ---- the banker kept a hand that everybody saw (he won the game before it by comparing): the player knows those cards

    /** the banker's final total when he kept the shown hand [h] ([swapped]: he replaced one unknown card of it), has taken [extra] more hidden cards since, and [stood] = said "enough" */
    private fun bankKnown(c: IntArray, h: List<Card>, swapped: Boolean, stood: Boolean, stop: Int, extra: Int): DoubleArray? {
        val res = DoubleArray(23)
        val n = h.size
        if (n == 0) return null
        if (!swapped) {
            knownRec(c, Bist.total(h).t, n, h[0].r == 14, 0, stood, stop, extra, 1.0, res)
        } else {
            val tot = sum(c)
            if (tot == 0) return null
            for (k in 0 until n) {
                val rest = ArrayList<Card>(h)
                rest.removeAt(k)
                val rt = if (rest.isEmpty()) 0 else Bist.total(rest).t
                for (j in 0 until 9) {
                    if (c[j] == 0) continue
                    val q = (1.0 / n) * c[j].toDouble() / tot
                    c[j]--
                    val fa = if (rest.isEmpty()) j == 8 else rest[0].r == 14
                    knownRec(c, rt + V[j], n, fa, 0, stood, stop, extra, q, res)
                    c[j]++
                }
            }
        }
        var z = 0.0
        for (x in res) z += x
        if (z <= 0.0) return null
        for (i in 0 until 23) res[i] /= z
        return res
    }

    private fun knownRec(c: IntArray, t: Int, n: Int, fa: Boolean, d: Int, stood: Boolean, stop: Int, extra: Int, p: Double, res: DoubleArray) {
        val ok = if (stood) d == extra else d >= extra
        if (t > 21) { if (!stood && ok) res[BUST] += p; return }
        var end = t >= stop
        var tot = 0
        if (!end) { tot = sum(c); if (tot == 0) end = true }
        if (end) { if (ok) res[t] += p; return }
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = p * c[i].toDouble() / tot
            c[i]--
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            knownRec(c, nt, n + 1, fa, d + 1, stood, stop, extra, q, res)
            c[i]++
        }
    }

    private fun bankMixKnown(c: IntArray, h: List<Card>, swapped: Boolean, stood: Boolean, extra: Int): DoubleArray? {
        val out = DoubleArray(23)
        var k = 0
        for (stop in intArrayOf(15, 16, 17)) {
            val d = bankKnown(c, h, swapped, stood, stop, extra) ?: continue
            k++
            for (j in 0 until 23) out[j] += d[j]
        }
        if (k == 0) return null
        for (j in 0 until 23) out[j] /= k.toDouble()
        return out
    }

    /** what the player expects of the banker's final total: from the shown hand if there is one, else from the number of cards he holds */
    private fun bankModel(c: IntArray, bankerCards: Int, stood: Boolean, shown: List<Card>?, swapped: Boolean): DoubleArray {
        if (shown != null && shown.isNotEmpty()) {
            val d = bankMixKnown(c, shown, swapped, stood, Math.max(0, bankerCards - shown.size))
            if (d != null) return d
        }
        return bankMixCond(c, bankerCards, stood)
    }

    /** chance that a hand of [t] wins when the banker ends with the distribution [bd] (a tie goes to the banker) */
    private fun standP(t: Int, bd: DoubleArray): Double {
        var s = bd[BUST]
        for (k in 0 until Math.min(t, 22)) s += bd[k]
        return s
    }

    // ------------------------------------------------------------------ the player

    private fun pBest(c: IntArray, t: Int, n: Int, fa: Boolean, bd: DoubleArray): Double {
        val s = standP(t, bd)
        if (t >= 21) return s
        val tt = sum(c)
        if (tt == 0) return s
        return Math.max(s, pHit(c, t, n, fa, bd, tt))
    }

    private fun pHit(c: IntArray, t: Int, n: Int, fa: Boolean, bd: DoubleArray, tt: Int): Double {
        var h = 0.0
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            if (nt > 21) continue
            val q = c[i].toDouble() / tt
            c[i]--
            h += q * pBest(c, nt, n + 1, fa, bd)
            c[i]++
        }
        return h
    }

    /** a player holding [hand]: draw one more card? The banker holds [bankerCards] cards and [bankerStood] = he has said "enough". */
    fun playerHit(hand: List<Card>, seen: List<Card>, bankerCards: Int, bankerStood: Boolean, shown: List<Card>?, bankerSwapped: Boolean): Boolean {
        if (hand.isEmpty()) return true
        val t = Bist.total(hand).t
        if (t >= 21) return false
        val known = ArrayList<Card>(hand)
        if (shown != null) known.addAll(shown)
        val c = left(seen, known)
        val tt = sum(c)
        if (tt == 0) return false
        val bd = bankModel(c, bankerCards, bankerStood, shown, bankerSwapped)
        val s = standP(t, bd)
        val h = pHit(c, t, hand.size, hand[0].r == 14, bd, tt)
        return h > s + 1e-9
    }

    /** the edge (-1..+1, 0 = fair) of a player whose only card is [first], playing well: below 0 the banker is ahead */
    fun firstEdge(first: Card, seen: List<Card>, bankerCards: Int, shown: List<Card>?, bankerSwapped: Boolean): Double {
        val one = ArrayList<Card>(); one.add(first)
        if (shown != null) one.addAll(shown)
        val t = Bist.value(first.r)
        val c = left(seen, one)
        val tt = sum(c)
        val bd = bankModel(c, bankerCards, false, shown, bankerSwapped)
        val s = standP(t, bd)
        val h = if (tt > 0) pHit(c, t, 1, first.r == 14, bd, tt) else 0.0
        return 2.0 * Math.max(s, h) - 1.0
    }

    // ------------------------------------------------------------------ the banker

    /** chance that the player's total is [t] or less (the banker wins a tie); [pn] cards in his hand, [emp] = totals this player stopped on before */
    private fun priCdf(pn: Int, t: Int, emp: IntArray?): Double {
        val gen: Double
        if (pn <= 1) gen = if (t >= 11) 1.0 else 0.0
        else {
            val a = if (pn == 2) P2 else if (pn == 3) P3 else P4
            var s = 0.0; var all = 0.0
            for (i in 0 until 7) { all += a[i]; if (15 + i <= t) s += a[i] }
            gen = if (all > 0.0) s / all else 0.0
        }
        // a little weight for players that stop early
        val base = 0.9 * gen + 0.1 * Math.min(1.0, Math.max(0.0, (t - 11) / 10.0))
        if (emp == null) return base
        var n = 0; var le = 0
        for (k in 0 until 22) { n += emp[k]; if (k <= t) le += emp[k] }
        if (n < 4) return base
        val w = Math.min(0.7, n / (n + 25.0))
        return (1.0 - w) * base + w * (le.toDouble() / n)
    }

    private fun bBest(c: IntArray, t: Int, n: Int, fa: Boolean, pn: Int, emp: IntArray?): Double {
        val s = priCdf(pn, t, emp)
        if (t >= 21) return s
        val tt = sum(c)
        if (tt == 0) return s
        return Math.max(s, bHit(c, t, n, fa, pn, emp, tt))
    }

    private fun bHit(c: IntArray, t: Int, n: Int, fa: Boolean, pn: Int, emp: IntArray?, tt: Int): Double {
        var h = 0.0
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            if (nt > 21) continue
            val q = c[i].toDouble() / tt
            c[i]--
            h += q * bBest(c, nt, n + 1, fa, pn, emp)
            c[i]++
        }
        return h
    }

    /** the banker holding [hand] against a player who stopped with [pn] cards: draw one more card? */
    fun bankerHit(hand: List<Card>, seen: List<Card>, pn: Int, emp: IntArray?): Boolean {
        if (hand.isEmpty()) return true
        val t = Bist.total(hand).t
        if (t >= 21) return false
        val c = left(seen, hand)
        val tt = sum(c)
        if (tt == 0) return false
        val s = priCdf(pn, t, emp)
        val h = bHit(c, t, hand.size, hand[0].r == 14, pn, emp, tt)
        return h > s + 1e-9
    }

    /** the unshown cards a robot banker kept for the next player: which one to set aside (and replace by one new card)? -1 = none */
    fun bankerSwapIndex(hand: List<Card>, seen: List<Card>): Int {
        if (hand.isEmpty()) return -1
        val c = left(seen, hand)
        val tt = sum(c)
        if (tt == 0) return -1
        val pn = 3
        val now = bBest(c, Bist.total(hand).t, hand.size, hand[0].r == 14, pn, null)
        var bestI = -1
        var bestV = now + 1e-9
        for (i in hand.indices) {
            val rest = ArrayList<Card>(hand)
            rest.removeAt(i)
            val rt = if (rest.isEmpty()) 0 else Bist.total(rest).t
            var v = 0.0
            for (j in 0 until 9) {
                if (c[j] == 0) continue
                val nt = rt + V[j]
                if (nt > 21) continue
                val q = c[j].toDouble() / tt
                c[j]--
                v += q * bBest(c, nt, hand.size, false, pn, null)
                c[j]++
            }
            if (v > bestV) { bestV = v; bestI = i }
        }
        return bestI
    }

    // ------------------------------------------------------------------ small choices

    /** the card to show when a card is asked for after three: the one that tells least (the lowest) */
    fun cardToShow(hand: List<Card>): Int {
        var k = 0
        for (i in hand.indices) if (Bist.value(hand[i].r) < Bist.value(hand[k].r)) k = i
        return k
    }
}
