package com.example.hokm

/** The words that every game of the program says in the same situation (leaving, saving, connection lost, chips vote ...): one place, so that the games cannot word them differently. */
object Msg {
    const val DEL_SAVE = "این بازی ذخیره‌شده حذف شود؟"
    const val LEAVE_GUEST = "از بازی چندگوشی خارج می‌شوید؟ ربات جای شما بازی می‌کند."
    const val BACK_SOLO = "بازی فعلی از بین می‌رود. به مرحله‌ی قبل برگردیم؟"
    const val NEW_ASK = "بازی جدید شروع شود؟ بازی فعلی از بین می‌رود."
    const val CHIP_SENT = "درخواست شما برای بقیه فرستاده شد."
    const val CHIP_BUSY = "رأی‌گیری دیگری باز است. کمی بعد دوباره امتحان کنید."
    const val CHIP_WAIT = "بعد از رد شدن باید کمی صبر کنید."
    const val CHIP_MORE = "مبلغ باید از ژتون فعلی بیشتر باشد."
    const val CHIP_POOR = "ژتون شما برای این اضافی کافی نیست."
    const val CONN_LOST = "اتصال با میزبان قطع شد. تا وقتی دوباره وصل شوید ربات جای شما بازی می‌کند. در حال اتصال دوباره..."
    const val RECONN_FAIL = "اتصال دوباره ممکن نشد. می‌توانید دکمه‌ی «اتصال دوباره» را بزنید."
    const val HOST_GONE = "میزبان قبلی قطع شد. در حال اتصال به میزبان جدید..."
    const val SAVE_BAD = "بازی ذخیره‌شده خراب است."
    const val SAVED_ROBOT = "بازی ذخیره شد. هر وقت خواستید از «ایجاد بازی» ← «بازی با ربات» ← «بازی‌های قبلی» ادامه‌اش دهید."
    const val SAVED_MULTI = "بازی ذخیره شد. هر وقت خواستید از «بازی‌های قبلی» در بخش «بازی با چند گوشی» ادامه‌اش دهید."
    const val RESUMED = "بازی ذخیره‌شده ادامه پیدا کرد."
    const val DROPPED_BOT = " قطع شد و ربات تا اتصال دوباره جای او بازی می‌کند."
    const val KICKED_BOT = " از بازی حذف شد و ربات جای او بازی می‌کند."
    const val NO_OTHER = "بازیکن دیگری در بازی نیست."

    /** the stake typed is not a number or is too small */
    fun stakeNum(min: Long): String = "ژتون هر بازیکن را به‌صورت عدد و دست‌کم " + Cards.fa(min) + " تایپ کنید."

    /** the person who starts the game has not enough chips for the stake */
    fun poorSolo(have: Long, need: Long): String = "ژتون شما برای این مبلغ کافی نیست (ژتون شما: " + Cards.fa(have) + "؛ دست‌کم " + Cards.fa(need) + " لازم است). مبلغ کمتری انتخاب کنید."

    /** the host sees that a phone (or he himself) cannot pay the stake */
    fun poorHost(need: Long): String = "ژتون شما برای این مبلغ کافی نیست (دست‌کم " + Cards.fa(need) + " لازم است). مبلغ کمتری انتخاب کنید."
    fun poorOthers(names: String, need: Long): String = names + " ژتون کافی برای این مبلغ ندارد (دست‌کم " + Cards.fa(need) + " لازم است). مبلغ کمتری انتخاب کنید."

    /** a guest is told that the stake is too high for him */
    fun poorGuest(need: Long): String = "ژتون شما برای این مبلغ کافی نیست (دست‌کم " + Cards.fa(need) + " لازم است). میزبان باید مبلغ را کمتر کند."
}
