package com.example.hokm

import java.util.Random

/**
 * The strong robot of "چهار برگ" (Pasur).
 *
 * It only uses what a player at the table can see: its own hand, the table, the cards every side has taken, the scores, the surs and
 * how many cards the others hold. The cards nobody has seen yet are dealt at random to the hidden hands and to the rest of the deck
 * (many times, "determinization"); every legal move is then played out to the end of the hand against robots that play a quick greedy
 * rule, and the move with the best average result wins. The result counts the points of the hand (cards, clubs, surs) and, when the
 * game can end at the end of this hand, a bonus for winning (or a loss for losing) the game.
 * This gives card counting, sur defence and sur hunting, the clubs race and end-of-deal play without any special-case rules.
 */
internal object PTab {
    val SU = IntArray(52)
    val RK = IntArray(52)
    val PV = IntArray(52)      // points of the card itself: ace 1, jack 1, 2♣ 2, 10♦ 3
    val VL = IntArray(52)      // value for the "adds up to 11" rule (ace 1, jack/queen/king 0)

    init {
        for (s in 0 until 4) for (r in 2..14) {
            val id = s * 13 + r - 2
            SU[id] = s; RK[id] = r
            VL[id] = if (r == 14) 1 else if (r >= 11) 0 else r
            PV[id] = (if (r == 14) 1 else 0) + (if (r == 11) 1 else 0) + (if (s == 3 && r == 2) 2 else 0) + (if (s == 2 && r == 10) 3 else 0)
        }
    }

    fun idOf(c: Card): Int = c.s * 13 + (c.r - 2)
}

internal class PasurSim {
    companion object {
        const val W_CLUB = 0.6
        const val W_SUR = 5.0
        const val W_EXP = 0.45
        const val W_THROW_BASE = 0.1
        const val B_WIN = 10.0
    }

    var n = 2
    var sides = 2
    var target = 62
    val hand = Array(4) { IntArray(4) }
    val hn = IntArray(4)
    val tab = IntArray(52)
    var tn = 0
    val deck = IntArray(52)
    var dn = 0
    val pts = IntArray(4)
    val clubs = IntArray(4)
    val surs = IntArray(4)
    val score = IntArray(4)
    var takenMask = 0L
    var lastTaker = -1
    var turn = 0
    var dealer = 0

    val opt = IntArray(8192)
    private val sm = IntArray(8192)
    private val vv = IntArray(16)
    private val pp = IntArray(16)
    private val fp = IntArray(4)

    fun side(seat: Int): Int = if (n == 4) (seat and 1) else seat

    fun copyFrom(o: PasurSim) {
        n = o.n; sides = o.sides; target = o.target
        for (p in 0 until 4) { hn[p] = o.hn[p]; for (i in 0 until hn[p]) hand[p][i] = o.hand[p][i] }
        tn = o.tn; for (i in 0 until tn) tab[i] = o.tab[i]
        dn = o.dn; for (i in 0 until dn) deck[i] = o.deck[i]
        for (s in 0 until 4) { pts[s] = o.pts[s]; clubs[s] = o.clubs[s]; surs[s] = o.surs[s]; score[s] = o.score[s] }
        takenMask = o.takenMask; lastTaker = o.lastTaker; turn = o.turn; dealer = o.dealer
    }

    /** every legal capture of card [c] on the table as bit masks over the table positions; -1 when the table is too big for this search */
    fun options(c: Int, out: IntArray): Int {
        val r = PTab.RK[c]
        if (r == 11) {
            var m = 0
            for (i in 0 until tn) { val q = PTab.RK[tab[i]]; if (q != 12 && q != 13) m = m or (1 shl i) }
            if (m != 0) { out[0] = m; return 1 }
            return 0
        }
        if (r >= 12) {
            var k = 0
            for (i in 0 until tn) if (PTab.RK[tab[i]] == r) { out[k] = 1 shl i; k++ }
            return k
        }
        val tg = 11 - PTab.VL[c]
        var m = 0
        for (i in 0 until tn) {
            val q = PTab.RK[tab[i]]
            if (q <= 10 || q == 14) {
                if (m >= 12) return -1
                vv[m] = PTab.VL[tab[i]]; pp[m] = i; m++
            }
        }
        if (m == 0) return 0
        val full = (1 shl m) - 1
        sm[0] = 0
        var k = 0
        for (mask in 1..full) {
            sm[mask] = sm[mask and (mask - 1)] + vv[mask.countTrailingZeroBits()]
            if (sm[mask] % tg != 0) continue
            if (!split(mask, tg)) continue
            var tm = 0
            for (b in 0 until m) if (((mask shr b) and 1) != 0) tm = tm or (1 shl pp[b])
            out[k] = tm; k++
        }
        return k
    }

    /** can the cards in [mask] be divided into groups that each add up to [tg]? */
    private fun split(mask: Int, tg: Int): Boolean {
        if (mask == 0) return true
        val low = mask and -mask
        val rest = mask xor low
        val need = tg - vv[low.countTrailingZeroBits()]
        if (need < 0) return false
        var s = rest
        while (true) {
            if (sm[s] == need && split(rest xor s, tg)) return true
            if (s == 0) break
            s = (s - 1) and rest
        }
        return false
    }

    /** same rule as Pasur4.surKind: 0 nothing, 1 a sur, 2 a sur that cancels a sur of the opponents */
    fun surKind(sd: Int, c: Int): Int {
        if (PTab.RK[c] == 11) return 0
        if (CbRules.surLimit > 0 && score[sd] >= CbRules.surLimit) return 0
        var opp = -1
        if (CbRules.cancel) { for (s in 0 until sides) if (s != sd && surs[s] > 0) { opp = s; break } }
        if (dn > 0) return if (opp >= 0) 2 else 1
        return if (CbRules.cancel && CbRules.lastCancel && opp >= 0) 2 else 0
    }

    fun apply(seat: Int, h: Int, mask: Int) {
        val c = hand[seat][h]
        for (i in h until hn[seat] - 1) hand[seat][i] = hand[seat][i + 1]
        hn[seat]--
        if (mask == 0) { tab[tn] = c; tn++; return }
        val sd = side(seat)
        if (PTab.SU[c] == 3) clubs[sd]++
        pts[sd] += PTab.PV[c]; takenMask = takenMask or (1L shl c)
        var w = 0
        for (i in 0 until tn) {
            if (((mask shr i) and 1) != 0) {
                val x = tab[i]
                pts[sd] += PTab.PV[x]; if (PTab.SU[x] == 3) clubs[sd]++; takenMask = takenMask or (1L shl x)
            } else { tab[w] = tab[i]; w++ }
        }
        tn = w; lastTaker = seat
        if (tn == 0) {
            val k = surKind(sd, c)
            if (k == 1) surs[sd]++
            else if (k == 2) { for (s in 0 until sides) if (s != sd && surs[s] > 0) { surs[s]--; break } }
        }
    }

    fun deal() {
        for (s in 0 until n) {
            val p = (dealer + 1 + s) % n
            for (i in 0 until 4) { dn--; hand[p][hn[p]] = deck[dn]; hn[p]++ }
        }
    }

    /** moves on to the next player (dealing again when every hand is empty); false when the hand is over */
    fun advance(): Boolean {
        var empty = true
        for (p in 0 until n) if (hn[p] > 0) { empty = false; break }
        if (empty) {
            if (dn == 0) return false
            deal(); turn = (dealer + 1) % n
        } else turn = (turn + 1) % n
        return true
    }

    /** what is left on the table goes to the last player who took cards */
    fun sweepLeft() {
        if (tn > 0 && lastTaker >= 0) {
            val sd = side(lastTaker)
            for (i in 0 until tn) {
                val x = tab[i]
                pts[sd] += PTab.PV[x]; if (PTab.SU[x] == 3) clubs[sd]++; takenMask = takenMask or (1L shl x)
            }
            tn = 0
        }
    }

    /** the same counting as Pasur4.handPoints */
    fun handPoints(fin: Boolean, out: IntArray) {
        for (s in 0 until sides) out[s] = pts[s]
        var topC = 0; var topS = -1; var tie = false
        for (s in 0 until sides) {
            if (clubs[s] > topC) { topC = clubs[s]; topS = s; tie = false } else if (clubs[s] == topC) tie = true
        }
        if (topC >= 7 && !tie && topS >= 0) out[topS] += 7
        else if (n == 3 && fin) {
            if (!tie && topS >= 0) out[topS] += 7
            else if (tie) {
                var cnt = 0; var third = -1
                for (s in 0 until sides) { if (clubs[s] == topC) cnt++ else if (third < 0) third = s }
                if (cnt == 2 && third >= 0) out[third] += 7
            }
        }
        for (s in 0 until sides) out[s] += CbRules.surValue * surs[s]
    }

    // ---------------- the quick rule the robots play with inside the search ----------------

    private fun exposure(mask: Int): Double {
        var e = 0.0
        for (i in 0 until tn) if (((mask shr i) and 1) == 0) {
            val x = tab[i]; e += PTab.PV[x] + (if (PTab.SU[x] == 3) W_CLUB else 0.0)
        }
        return e
    }

    private fun throwCost(c: Int): Double {
        var k = W_THROW_BASE
        val r = PTab.RK[c]
        if (r == 11) k += 3.0
        if (PTab.SU[c] == 2 && r == 10) k += 4.0
        if (PTab.SU[c] == 3 && r == 2) k += 3.0
        if (r == 14) k += 1.2
        if (PTab.SU[c] == 3) k += W_CLUB
        return k
    }

    private fun moveScore(seat: Int, h: Int, mask: Int): Double {
        val c = hand[seat][h]
        if (mask == 0) return -throwCost(c) - W_EXP * exposure(0)
        var g = PTab.PV[c] + (if (PTab.SU[c] == 3) W_CLUB else 0.0)
        for (i in 0 until tn) if (((mask shr i) and 1) != 0) {
            val x = tab[i]; g += PTab.PV[x] + (if (PTab.SU[x] == 3) W_CLUB else 0.0)
        }
        if (mask == (1 shl tn) - 1) { if (surKind(side(seat), c) != 0) g += W_SUR }
        else g -= W_EXP * exposure(mask)
        return g
    }

    var bh = 0
    var bm = 0

    /** the greedy choice of [seat]; the result is left in bh (hand index) and bm (capture mask) */
    private fun pickGreedy(seat: Int) {
        var best = -1e18; bh = 0; bm = 0
        for (h in 0 until hn[seat]) {
            val c = hand[seat][h]
            val k = options(c, opt)
            if (k <= 0) {
                val s = moveScore(seat, h, 0)
                if (s > best) { best = s; bh = h; bm = 0 }
            } else {
                for (j in 0 until k) {
                    val m = opt[j]
                    val s = moveScore(seat, h, m)
                    if (s > best) { best = s; bh = h; bm = m }
                }
            }
        }
    }

    /** plays the hand to its end (everybody with the quick rule) and counts the last table */
    fun playOut() {
        while (advance()) { pickGreedy(turn); apply(turn, bh, bm) }
        sweepLeft()
    }

    /** how good the finished hand is for [me]: points against the others, and the game itself when this hand decides it */
    fun utility(me: Int): Double {
        handPoints(true, fp)
        val ms = side(me)
        var oth = 0.0; var cnt = 0
        for (s in 0 until sides) if (s != ms) { oth += fp[s]; cnt++ }
        var u = fp[ms] - oth / cnt
        var best = -1; var bi = -1; var tie = false
        for (s in 0 until sides) {
            val t = score[s] + fp[s]
            if (t > best) { best = t; bi = s; tie = false } else if (t == best) tie = true
        }
        if (best >= target && !tie) u += if (bi == ms) B_WIN else -B_WIN
        return u
    }
}

object PasurAI {
    /**
     * The move of the robot at [seat]: the index of the card in its hand and the table positions it takes (empty = throw it).
     * null when the search cannot be used (the caller then plays the simple rule).
     */
    fun choose(
        hands: Array<MutableList<Card>>, table: List<Card>, taken: Array<MutableList<Card>>,
        surs: IntArray, score: IntArray, deckLeft: Int, n: Int, target: Int,
        seat: Int, dealer: Int, lastTaker: Int, budgetMs: Long
    ): Pair<Int, List<Int>>? {
        if (n < 2 || n > 4 || table.size > 40 || hands[seat].isEmpty() || hands[seat].size > 4) return null
        val sides = if (n == 4) 2 else n
        val base = PasurSim()
        base.n = n; base.sides = sides; base.target = target
        for (p in 0 until n) {
            if (hands[p].size > 4) return null
            base.hn[p] = hands[p].size
        }
        for (i in hands[seat].indices) base.hand[seat][i] = PTab.idOf(hands[seat][i])
        base.tn = table.size
        for (i in table.indices) base.tab[i] = PTab.idOf(table[i])
        base.dn = deckLeft
        var known = 0L
        for (s in 0 until sides) {
            base.pts[s] = Pasur.cardPoints(taken[s]); base.clubs[s] = Pasur.clubs(taken[s])
            base.surs[s] = surs[s]; base.score[s] = score[s]
            for (c in taken[s]) known = known or (1L shl PTab.idOf(c))
        }
        base.takenMask = known
        base.lastTaker = lastTaker; base.dealer = dealer; base.turn = seat

        // every legal move of the robot (as table masks)
        val rh = IntArray(1024); val rm = IntArray(1024); var cnt = 0
        for (h in 0 until base.hn[seat]) {
            val k = base.options(base.hand[seat][h], base.opt)
            if (k < 0) return null
            if (k == 0) { rh[cnt] = h; rm[cnt] = 0; cnt++ }
            else {
                var j = 0
                while (j < k && cnt < 1024) { rh[cnt] = h; rm[cnt] = base.opt[j]; cnt++; j++ }
            }
        }
        if (cnt == 0) return null
        if (cnt > 1) {
            // the cards nobody has seen: not in my hand, not on the table, not taken
            for (i in 0 until base.tn) known = known or (1L shl base.tab[i])
            for (i in 0 until base.hn[seat]) known = known or (1L shl base.hand[seat][i])
            val u = IntArray(52); var un = 0
            for (c in 0 until 52) if (((known shr c) and 1L) == 0L) { u[un] = c; un++ }
            var need = deckLeft
            for (p in 0 until n) if (p != seat) need += base.hn[p]
            if (need != un) return null
            val tot = DoubleArray(cnt)
            val w = PasurSim()
            val rng = Random()
            var samples = 0
            val t0 = System.nanoTime()
            val budgetNs = budgetMs * 1_000_000L
            val minSamples = 24; val maxSamples = 160
            while (samples < maxSamples) {
                if (samples >= minSamples && System.nanoTime() - t0 > budgetNs) break
                for (i in un - 1 downTo 1) { val j = rng.nextInt(i + 1); val x = u[i]; u[i] = u[j]; u[j] = x }
                var pos = 0
                for (p in 0 until n) if (p != seat) { for (i in 0 until base.hn[p]) { base.hand[p][i] = u[pos]; pos++ } }
                base.dn = 0
                for (i in pos until un) { base.deck[base.dn] = u[i]; base.dn++ }
                for (m in 0 until cnt) {
                    w.copyFrom(base)
                    w.apply(seat, rh[m], rm[m])
                    w.playOut()
                    tot[m] += w.utility(seat)
                }
                samples++
            }
            var bi = 0
            for (m in 1 until cnt) if (tot[m] > tot[bi]) bi = m
            return toMove(hands[seat], table, rh[bi], rm[bi])
        }
        return toMove(hands[seat], table, rh[0], rm[0])
    }

    /** the chosen move as (card index, table indexes); checked against the real rules, null if it is not legal */
    private fun toMove(hand: List<Card>, table: List<Card>, h: Int, mask: Int): Pair<Int, List<Int>>? {
        if (h < 0 || h >= hand.size) return null
        val idx = ArrayList<Int>()
        for (i in table.indices) if (((mask shr i) and 1) != 0) idx.add(i)
        val card = hand[h]
        if (idx.isEmpty()) {
            if (Pasur.options(card, table).isNotEmpty()) return null
        } else if (!Pasur.isValid(card, table, idx)) return null
        return Pair(h, idx)
    }
}
