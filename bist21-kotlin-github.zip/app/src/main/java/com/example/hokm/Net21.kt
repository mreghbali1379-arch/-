package com.example.hokm

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import org.json.JSONObject

/**
 * The multi-phone side of the 21 game: lobby screens (host / join), the transport events of the
 * bridge (Bluetooth, Wi-Fi, Wi-Fi Direct) and the messages.
 * The host phone runs the game; guests only show the table and answer the questions they are asked.
 */
class Net21(private val act: MainActivity, private val app: App, private val g: Bist21) {
    class Peer(@JvmField val cid: Int, @JvmField var name: String, @JvmField var addr: String) {
        @JvmField var id = ""
        @JvmField var joined = false
        @JvmField var wallet = 10000
    }

    private val NETN = mapOf("bt" to "بلوتوث", "lan" to "وای‌فای (یک شبکهٔ مشترک)", "direct" to "وای‌فای مستقیم")
    private val NETH = mapOf(
        "bt" to "گوشی‌ها باید نزدیک هم باشند و بلوتوث (و در بعضی گوشی‌ها موقعیت‌مکانی) روشن باشد. نیازی به جفت‌کردن نیست.",
        "lan" to "همهٔ گوشی‌ها باید به یک شبکهٔ وای‌فای وصل باشند، مثلاً یک مودم یا هات‌اسپات یکی از گوشی‌ها.",
        "direct" to "بدون مودم؛ گوشی‌ها مستقیم به میزبان وصل می‌شوند. وای‌فای و موقعیت‌مکانی باید روشن باشد."
    )
    private val bases = listOf(500, 1000, 2000, 5000)
    private val mins = listOf(25, 50, 100)

    private val peers = LinkedHashMap<Int, Peer>()
    private val found = LinkedHashMap<String, Array<String>>()   // endpoint -> [room, name]
    private var role = "off"                                      // "host" | "client" | "off"
    private var conn = false
    private var leaving = false
    private var room = ""
    private var lastAddr = ""
    private var myName = ""
    private var netMode = Prefs.net
    private var retry: ((Boolean) -> Unit)? = null
    private var tries = 0
    private var rcN = 0
    private var screen = ""

    private var info: TextView? = null
    private var listBox: LinearLayout? = null
    private var botBar: SeekBar? = null
    private var botLab: TextView? = null
    private var spBase: Spinner? = null
    private var spMin: Spinner? = null
    private var cbSide: CheckBox? = null
    private var botsWanted = 3

    private val br get() = act.bridge

    // ------------------------------------------------------------------ plumbing

    fun show() {
        act.btEvt = { t, c, d -> onEvt(t, c, d) }
        showRoles()
    }

    /** send a message to the phone with connection id cid (0 = the host, from a guest) */
    fun send(cid: Int, j: JSONObject) {
        act.runOnUiThread { try { br.send(cid, j.toString()) } catch (e: Exception) { } }
    }

    fun toHost(j: JSONObject) { send(0, j) }

    fun close() {
        try { br.stopHost() } catch (e: Exception) { }
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        role = "off"; conn = false; peers.clear(); found.clear()
    }

    fun leave() {
        leaving = true
        if (role == "client" && conn) { try { send(0, JSONObject().put("t", "bye")) } catch (e: Exception) { } }
    }

    /** the phone's back button inside the lobby; true = handled here */
    fun back(): Boolean {
        if (role == "off") return false
        leaving = true
        close()
        showRoles()
        return true
    }

    private fun setInfo(t: String) {
        info?.text = t
        try { if (Prefs.a11y) info?.announceForAccessibility(t) } catch (e: Exception) { }
    }

    private fun column(): LinearLayout {
        val v = LinearLayout(act); v.orientation = LinearLayout.VERTICAL; v.gravity = Gravity.CENTER_HORIZONTAL
        return v
    }

    // ------------------------------------------------------------------ lobby screens

    private fun showRoles() {
        screen = "roles"; role = "off"; leaving = false
        val v = column()
        v.addView(g.heading("بازی با چند گوشی"))
        v.addView(g.mbtn("میزبان بازی می‌شوم") { startHost(false) })
        v.addView(g.mbtn("به بازی دیگری می‌پیوندم") { startJoin(false) })
        if (Saves.all(true).isNotEmpty()) v.addView(g.mbtn("بازی‌های قبلی چندگوشی (میزبان)") { showSavedMulti() })
        v.addView(g.mbtn("روش اتصال: " + (NETN[netMode] ?: "")) { netChoose() })
        val t = g.tv(NETH[netMode] ?: "", 13f)
        info = t
        v.addView(t)
        v.addView(g.mbtn("بازگشت") { g.close() })
        g.setScreen("net", v)
    }

    private fun netChoose() {
        app.dlg.list("روش اتصال", listOf(
            "بلوتوث" to { setNet("bt") },
            "وای‌فای: همهٔ گوشی‌ها به یک مودم یا هات‌اسپات وصل باشند" to { setNet("lan") },
            "وای‌فای مستقیم: بدون مودم" to { setNet("direct") }
        ))
    }

    private fun setNet(v: String) {
        netMode = v; Prefs.net = v
        try { br.setNet(v) } catch (e: Exception) { }
        showRoles()
    }

    /** permissions / Bluetooth / Wi-Fi checks; false = something is still needed (the user was told) */
    private fun ready(r: ((Boolean) -> Unit)?): Boolean {
        retry = r
        br.setNet(netMode)
        val st = br.state()
        if (st == "nogms") { setInfo("این گوشی خدمات گوگل پلی (Google Play Services) ندارد یا به‌روز نیست و اتصال نزدیک کار نمی‌کند."); return false }
        if (st == "noperm") {
            br.ensure()
            setInfo(if (netMode == "bt") "اجازه‌های درخواست‌شده (بلوتوث و دستگاه‌های نزدیک) را بدهید." else "اجازه‌های درخواست‌شده (دستگاه‌های نزدیک و موقعیت مکانی) را بدهید.")
            return false
        }
        if (st == "off") { br.enableBt(); setInfo("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن بلوتوث را بدهید."); return false }
        if (st == "locoff") { br.enableLoc(); setInfo("در پنجره‌ی باز‌شده اجازه‌ی روشن شدن موقعیت مکانی را بدهید."); return false }
        if (st == "wifioff") {
            br.enableWifi()
            setInfo("در پنجره‌ی باز‌شده وای‌فای را روشن کنید. با بستن پنجره، برنامه خودش ادامه می‌دهد.")
            return false
        }
        if (st == "nobt") { setInfo("این گوشی بلوتوث ندارد."); return false }
        retry = null; tries = 0
        return true
    }

    private fun startHost(auto: Boolean) {
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> startHost(a) }) return
        role = "host"; peers.clear(); conn = false
        myName = Prefs.name.ifEmpty { "بازیکن" }
        room = java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, myName)
        showHostLobby()
    }

    private fun showSavedMulti() {
        val l = Saves.all(true)
        screen = "saved"
        val v = column()
        v.addView(g.heading("بازی‌های قبلی چندگوشی"))
        for (e in l) v.addView(g.mbtn(Saves.describe(e)) {
            app.dlg.list(Saves.describe(e), listOf(
                "ادامه بازی (میزبان می‌شوم)" to { resumeHost(false, e) },
                "حذف" to { app.dlg.confirm("این بازی ذخیره‌شده حذف شود؟", { Saves.del(e.id); showRoles() }) }
            ), "بستن")
        })
        v.addView(g.mbtn("بازگشت") { showRoles() })
        g.setScreen("net", v)
    }

    private var resumeE: Saves.E? = null

    private fun resumeHost(auto: Boolean, e: Saves.E? = null) {
        if (e != null) resumeE = e
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> resumeHost(a) }) return
        val en = resumeE ?: return
        val sv = try { JSONObject(en.data) } catch (x: Exception) { setInfo("بازی ذخیره‌شده خراب است."); return }
        role = "host"; peers.clear(); conn = false
        myName = Prefs.name.ifEmpty { "بازیکن" }
        g.adoptHost(sv, 0, "بازی قبلی بارگذاری شد. بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند؛ وقتی وصل شدند و آماده بودید «ادامه بازی» را بزنید.")
    }

    /** this phone is the host now (the old host left): advertise the same room so the others find us again */
    fun becomeHost(rm: String, name: String) {
        try { br.stopScan() } catch (e: Exception) { }
        try { br.close() } catch (e: Exception) { }
        role = "host"; conn = false; leaving = false; peers.clear()
        myName = name; room = if (rm.isNotEmpty()) rm else java.lang.Long.toString((Math.random() * 2176782336.0).toLong() + 60466176L, 36).take(6)
        g.roomCode = room
        br.host(9, room, name)
    }

    private fun showHostLobby() {
        screen = "host"
        val v = column()
        v.addView(g.heading("میزبان: " + myName))
        v.addView(g.tv("سکه‌های شما: " + Cards.fa(Prefs.wallet), 15f, Px.GOLD, true))
        v.addView(g.tv("بقیهٔ بازیکن‌ها باید «به بازی دیگری می‌پیوندم» را بزنند و بازی «" + myName + "» را از فهرست انتخاب کنند. جاهای خالی را ربات پر می‌کند.", 14f))
        val lb = column(); listBox = lb
        v.addView(lb)
        botLab = g.tv("", 16f); v.addView(botLab)
        val sb = SeekBar(act); botBar = sb
        sb.contentDescription = "تعداد ربات‌ها"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { botsWanted = botMin() + p; botLab?.text = "تعداد ربات‌ها: " + Cards.fa(botsWanted) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        v.addView(sb)
        v.addView(g.tv("بانک اولیه", 16f))
        val s1 = Spinner(act)
        s1.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, bases.map { Cards.fa(it) })
        s1.setSelection(1); s1.speakLabel("بانک اولیه"); spBase = s1
        v.addView(s1)
        v.addView(g.tv("کمترین شرط", 16f))
        val s2 = Spinner(act)
        s2.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, mins.map { Cards.fa(it) })
        s2.setSelection(1); s2.speakLabel("کمترین شرط"); spMin = s2
        v.addView(s2)
        val cb = CheckBox(act); cb.text = "شرط روی دست دیگران (خواندن)"; cb.setTextColor(Px.tx); cbSide = cb
        v.addView(cb)
        val t = g.tv("", 13f); info = t
        v.addView(t)
        v.addView(g.mbtn("شروع بازی") { hostGo() })
        v.addView(g.mbtn("لغو") { back() })
        g.setScreen("net", v)
        refreshHost()
    }

    private fun joined(): List<Peer> = peers.values.filter { it.joined }
    private fun botMin(): Int = if (joined().isEmpty()) 1 else 0
    private fun botMax(): Int = 9 - joined().size

    private fun refreshHost() {
        if (screen != "host") return
        val ps = joined()
        val lb = listBox ?: return
        lb.removeAllViews()
        lb.addView(g.tv("بازیکن‌ها: " + myName + " (شما)" + ps.joinToString("") { "، " + it.name }, 15f))
        val sb = botBar ?: return
        val lo = botMin(); val hi = Math.max(lo, botMax())
        botsWanted = Math.max(lo, Math.min(hi, botsWanted))
        sb.max = hi - lo
        sb.progress = botsWanted - lo
        botLab?.text = "تعداد ربات‌ها: " + Cards.fa(botsWanted)
    }

    private fun hostGo() {
        val ps = joined()
        val bots = Math.max(botMin(), Math.min(botMax(), botsWanted))
        g.startHostGame(ps, bots, bases[spBase?.selectedItemPosition ?: 1], mins[spMin?.selectedItemPosition ?: 1], cbSide?.isChecked ?: false)
    }

    private fun startJoin(auto: Boolean) {
        if (!auto) { tries = 0; br.newAttempt() }
        if (!ready { a -> startJoin(a) }) return
        role = "client"; leaving = false; conn = false
        myName = Prefs.name.ifEmpty { "بازیکن" }
        found.clear()
        showJoin()
        br.scan()
    }

    private fun showJoin() {
        screen = "join"
        val v = column()
        v.addView(g.heading("بازی‌های نزدیک"))
        val lb = column(); listBox = lb
        v.addView(lb)
        val t = g.tv("", 14f); info = t
        v.addView(t)
        v.addView(g.mbtn("بازگشت") { back() })
        g.setScreen("net", v)
        refreshJoin()
    }

    private fun refreshJoin() {
        if (screen != "join") return
        val lb = listBox ?: return
        lb.removeAllViews()
        for ((ep, f) in found) lb.addView(g.mbtn(if (f[1].isEmpty()) "بازی بدون نام" else f[1]) { joinDev(ep, f[0], f[1]) })
        val n = found.size
        setInfo(if (n > 0) Cards.fa(n) + " بازی نزدیک پیدا شد." else "در حال جست‌وجو. میزبان باید «میزبان بازی می‌شوم» را باز کرده باشد.")
    }

    private fun joinDev(ep: String, rm: String, name: String) {
        room = rm
        lastAddr = if (rm.isNotEmpty()) "room:$rm" else ep
        rcN = 0
        setInfo("در حال اتصال به " + (if (name.isEmpty()) "بازی" else name) + " ...")
        br.connect(ep)
    }

    // ------------------------------------------------------------------ transport events

    fun onEvt(type: String, cid: Int, data: String) {
        when (type) {
            "conn" -> if (role == "host") {
                val pr = data.split("\u0001")
                peers[cid] = Peer(cid, pr.getOrNull(0).orEmpty().ifEmpty { "بازیکن" }, pr.getOrNull(1).orEmpty())
            }
            "found" -> if (role == "client" && !conn) {
                val pr = data.split("\u0001")
                found[pr[0]] = arrayOf(pr.getOrNull(1).orEmpty(), pr.getOrNull(2).orEmpty())
                refreshJoin()
            }
            "lost" -> if (found.remove(data) != null) refreshJoin()
            "open" -> if (role == "client") {
                br.stopScan(); conn = true; rcN = 0
                toHost(JSONObject().put("t", "hello").put("name", myName).put("id", Prefs.devId()).put("g", Prefs.gender).put("w", Prefs.wallet))
            }
            "msg" -> {
                val m = try { JSONObject(data) } catch (e: Exception) { return }
                if (role == "host") onHostSide(cid, m) else if (role == "client") onClientSide(m)
            }
            "drop" -> {
                if (role == "host") hostDrop(cid)
                else if (role == "client" && !leaving) {
                    conn = false
                    if (g.started) { if (g.isSucc) g.adoptFromSync() else { g.showReconnect(); autoReconnect() } }
                    else setInfo("اتصال برقرار نشد یا قطع شد. دوباره امتحان کنید.")
                }
            }
            "err" -> setInfo("خطا: $data")
            "perm" -> {
                val r = retry
                if (data == "1" && r != null && tries < 5) { retry = null; tries++; Sched.laterRaw(700) { r(true) } }
                else if (data == "s0") setInfo("برای ادامه باید مجوزها را در تنظیمات برنامه روشن کنید. بعد برگردید تا برنامه ادامه دهد.")
                else {
                    retry = null
                    setInfo(if (data == "1") "اجازه داده شد. دوباره دکمه را بزنید."
                    else if (data == "w0") "وای‌فای هنوز خاموش است. دوباره دکمه را بزنید و آن را روشن کنید."
                    else if (data == "l0") "موقعیت مکانی روشن نشد. دوباره دکمه را بزنید."
                    else "اجازه‌ها داده نشد. بدون آن‌ها اتصال نزدیک کار نمی‌کند.")
                }
            }
        }
    }

    private fun unique(base: String, me: Peer): String {
        var nm = base; var i = 2
        while (nm == myName || peers.values.any { it !== me && it.joined && it.name == nm }) { nm = base + " " + Cards.fa(i); i++ }
        return nm
    }

    private fun hostDrop(cid: Int) {
        peers.remove(cid)
        g.onGuestDrop(cid)
        if (!g.started) refreshHost()
    }

    private fun onHostSide(cid: Int, m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> {
                val p = peers[cid] ?: return
                p.id = m.optString("id")
                p.wallet = m.optInt("w", 0)
                if (p.wallet < Bist21.MIN_PLAY) { send(cid, JSONObject().put("t", "busy")); return }
                p.name = unique(m.optString("name").ifEmpty { "بازیکن" }, p)
                if (g.onGuestHello(cid, p.id)) { p.joined = true; return }          // a player who dropped out came back
                if (g.started) { if (g.takeSeat(cid, p.id, p.name, p.wallet)) p.joined = true else send(cid, JSONObject().put("t", "busy")); return }
                if (joined().size >= 9) { send(cid, JSONObject().put("t", "busy")); return }
                p.joined = true
                send(cid, JSONObject().put("t", "welcome").put("name", p.name))
                refreshHost()
            }
            "ans" -> g.onGuestMsg(cid, m)
            "bye" -> hostDrop(cid)
        }
    }

    private fun onClientSide(m: JSONObject) {
        when (m.optString("t")) {
            "welcome" -> waitScreen(m.optString("name"))
            "busy" -> setInfo("بازی پر است یا شروع شده است و جای خالی برای شما نیست.")
            else -> g.onHostMsg(m)
        }
    }

    private fun waitScreen(nm: String) {
        screen = "wait"
        val v = column()
        v.addView(g.heading("به بازی پیوستید"))
        val t = g.tv("نام شما در بازی: " + nm + ". منتظر شروع بازی توسط میزبان بمانید.", 15f)
        info = t
        v.addView(t)
        v.addView(g.mbtn("خروج") { back() })
        g.setScreen("net", v)
        setInfo("به بازی پیوستید. منتظر شروع بازی توسط میزبان بمانید.")
    }

    // ------------------------------------------------------------------ reconnecting a guest

    fun reconnect() {
        if (role != "client") return
        rcN++
        try { br.connect(if (lastAddr.isNotEmpty()) lastAddr else null) } catch (e: Exception) { }
    }

    private fun autoReconnect() {
        Sched.laterRaw(4000) {
            if (!conn && !leaving && g.started && role == "client" && rcN < 15) { reconnect(); autoReconnect() }
        }
    }
}
