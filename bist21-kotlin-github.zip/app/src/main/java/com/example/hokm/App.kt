package com.example.hokm

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * The main menu of the 21 game and its settings. The game itself is [Bist21] (with [Net21] for several phones);
 * it opens as an overlay over this menu.
 */
class App(private val act: MainActivity) {
    val dlg = Dialogs(act)

    private val scroll = ScrollView(act)
    private val holder = FrameLayout(act)
    private val content = LinearLayout(act)

    private var bist: Bist21? = null

    private lateinit var menuV: LinearLayout
    private lateinit var m1: LinearLayout   // main panel
    private lateinit var m3: LinearLayout   // game type: robots / several phones
    private lateinit var m5: LinearLayout   // robots: new game / previous games

    // ---------------------------------------------------------------- shell

    /** builds the menu; called once after the object is constructed (so every property is initialised) */
    fun setup() {
        Px.init(act)
        act.root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        act.root.setBackgroundColor(Px.bg)
        act.root.fitsSystemWindows = true
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Px.dp(8), Px.dp(8), Px.dp(8), Px.dp(8))
        val w = Math.min(Px.dp(520), act.resources.displayMetrics.widthPixels)
        holder.addView(content, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        scroll.isFillViewport = true
        scroll.addView(holder, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        act.root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        act.btEvt = null
        buildMenu()
        content.addView(menuV)
        Sound.onChange = null
        showMenu()
        if (Prefs.name.isEmpty() || Prefs.gender.isEmpty()) dlg.nameAsk(false) { v -> Av.GN[v] = Prefs.gender }
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)

    private fun item(t: String, f: () -> Unit): Pair<String, () -> Unit> = Pair(t, f)

    private fun tv(t: String, size: Float, color: Int = Px.tx, bold: Boolean = false): TextView {
        val v = TextView(act)
        v.text = t; v.textSize = size; v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    /** the round "⋮" button at the top corner (گزینه‌های بیشتر) */
    private fun moreButton(): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(Px.dp(4), Px.dp(2), Px.dp(4), Px.dp(4))
        val b = TextView(act)
        b.text = "⋮"; b.textSize = 26f; b.setTextColor(Color.WHITE); b.gravity = Gravity.CENTER
        b.background = Px.rounded(0x59000000, 20)
        b.contentDescription = "گزینه‌های بیشتر"
        b.isClickable = true; b.isFocusable = true
        b.setOnClickListener { moreMenu() }
        row.addView(b, lp(Px.dp(40), Px.dp(40)))
        return row
    }

    // ---------------------------------------------------------------- menu

    private fun menuBtn(t: String, f: () -> Unit): Button {
        val b = dlg.btn(t, true, f)
        val l = lp(Math.min(Px.dp(280), act.resources.displayMetrics.widthPixels - Px.dp(32)), ViewGroup.LayoutParams.WRAP_CONTENT)
        l.setMargins(0, Px.dp(8), 0, Px.dp(8)); l.gravity = Gravity.CENTER_HORIZONTAL
        b.layoutParams = l
        return b
    }

    private fun panel(): LinearLayout {
        val p = LinearLayout(act); p.orientation = LinearLayout.VERTICAL; p.gravity = Gravity.CENTER_HORIZONTAL
        return p
    }

    private fun buildMenu() {
        menuV = LinearLayout(act); menuV.orientation = LinearLayout.VERTICAL
        menuV.addView(moreButton())
        val h1 = tv("بازی بیست‌ویک", 30f, Px.tx, true); h1.gravity = Gravity.CENTER
        h1.setPadding(0, Px.dp(12), 0, Px.dp(12))
        if (android.os.Build.VERSION.SDK_INT >= 28) h1.isAccessibilityHeading = true
        menuV.addView(h1)

        m1 = panel()
        m1.addView(menuBtn("ایجاد بازی") { showCreate() })
        m1.addView(menuBtn("تنظیمات") { showSettings() })
        m1.addView(menuBtn("راهنما") { Bist21.guideDialog(dlg) })
        m1.addView(menuBtn("درباره") { dlg.about() })
        m1.addView(menuBtn("خروج") { quitAsk() })
        menuV.addView(m1)

        m3 = panel()
        m3.addView(tv("نوع بازی را انتخاب کنید:", 16f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(8), 0, Px.dp(8)) })
        m3.addView(menuBtn("بازی با ربات") { showRobot() })
        m3.addView(menuBtn("بازی با چند گوشی") { openBist("net") })
        menuV.addView(m3)

        m5 = panel()
        m5.addView(tv("بازی با ربات:", 16f).also { it.gravity = Gravity.CENTER; it.setPadding(0, Px.dp(8), 0, Px.dp(8)) })
        m5.addView(menuBtn("بازی جدید") { openBist("new") })
        m5.addView(menuBtn("بازی‌های قبلی") { openBist("resume") })
        menuV.addView(m5)
    }

    private fun panels(which: String) {
        m1.visibility = if (which == "m1") View.VISIBLE else View.GONE
        m3.visibility = if (which == "m3") View.VISIBLE else View.GONE
        m5.visibility = if (which == "m5") View.VISIBLE else View.GONE
    }

    /** the menu is taken out completely (also for TalkBack) while a game is on the screen */
    fun menuShown(on: Boolean) { scroll.visibility = if (on) View.VISIBLE else View.GONE }

    fun showMenu() {
        Sched.newGen()
        panels("m1")
    }

    private fun showCreate() { panels("m3") }
    private fun showRobot() { panels("m5") }

    /** the 21 game opens over the menu (its own back button returns here) */
    private fun openBist(start: String) {
        if (Prefs.wallet < Bist21.MIN_PLAY) { dlg.message(Bist21.BROKE); return }
        bist?.close()
        val b = Bist21(act, this)
        bist = b
        b.show(start)
    }

    // ---------------------------------------------------------------- settings

    /** the settings list, also used by the 21 game */
    fun settingsDialog() { showSettings() }

    private fun showSettings() {
        dlg.list("تنظیمات", listOf(
            item("تغییر نام") { renameAsk() },
            item("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) { a11yToggle(); showSettings() },
            item("تنظیمات صدا") { dlg.sound() },
            item("تنظیمات تصویر زمینه") { dlg.cards("bg") { } },
            item("تنظیمات پشت کارت") { dlg.cards("back") { } },
            item("سرعت انیمیشن") { animSpeedAsk() }
        ))
    }

    /** the ⋮ menu of the main menu */
    private fun moreMenu() {
        dlg.list("گزینه‌های بیشتر", listOf(
            item("تغییر نام") { renameAsk() },
            item("دسترس‌پذیر بودن برنامه: " + (if (Prefs.a11y) "روشن" else "خاموش")) { a11yToggle() },
            item("سرعت انیمیشن") { animSpeedAsk() },
            item("تنظیمات صدا") { dlg.sound() },
            item("تنظیمات تصویر زمینه") { dlg.cards("bg") { } },
            item("تنظیمات پشت کارت") { dlg.cards("back") { } }
        ))
    }

    private fun renameAsk() { dlg.nameAsk(true) { v -> Av.GN[v] = Prefs.gender } }

    private fun a11yToggle() {
        Prefs.a11y = !Prefs.a11y
        Spk.reset()
    }

    private fun animSpeedAsk() {
        fun mk(m: String, t: String) = item(t + (if (Anim.m == m) " ✓ (فعلی)" else "")) { Anim.set(m) }
        dlg.list("سرعت انیمیشن", listOf(mk("slow", "آهسته"), mk("norm", "عادی"), mk("fast", "سریع")), "بستن")
    }

    private fun quitAsk() {
        dlg.confirm("مطمئنید؟ برنامه کاملاً بسته می‌شود.", { act.bridge.exitApp() })
    }

    /** the phone's back button; true = handled */
    fun back(): Boolean {
        if (m5.visibility == View.VISIBLE) { showCreate(); return true }
        if (m3.visibility == View.VISIBLE) { showMenu(); return true }
        return false
    }
}
