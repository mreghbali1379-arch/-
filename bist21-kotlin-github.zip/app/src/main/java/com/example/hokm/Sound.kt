package com.example.hokm

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool

/** Animation speed (the page's ANI.f / ANI.m and ad()). */
object Anim {
    /** speed factor: 1 normal, 1.6 slow, 0.6 fast */
    @JvmField var f = 1.0
    var m = "norm"

    fun load() {
        when (Prefs.anim) {
            "slow" -> { f = 1.6; m = "slow" }
            "fast" -> { f = 0.6; m = "fast" }
            else -> { f = 1.0; m = "norm" }
        }
    }

    fun set(mode: String) {
        m = mode
        f = if (mode == "slow") 1.6 else if (mode == "fast") 0.6 else 1.0
        Prefs.anim = mode
    }

    /** a duration in ms scaled by the chosen speed */
    fun ad(ms: Int): Int = Math.round(ms * f).toInt()
    fun ad(ms: Long): Long = Math.round(ms * f)
    fun ad(ms: Double): Long = Math.round(ms * f)
}

/**
 * Sound effects, their timing queue and the background-music switch.
 * Ported from the page (effects and the music switch).
 * The music itself is played by MusicService (foreground service).
 */
object Sound {
    private lateinit var ctx: Context

    // ---- state (MUS of the original) ----
    @JvmField var on = true
    @JvmField var vm = 0.5   // music volume 0..1
    @JvmField var ve = 1.0   // effects volume 0..1

    /** called when volume / on-off changed so the settings screen can refresh (uiVol) */
    var onChange: (() -> Unit)? = null

    fun init(c: Context) {
        ctx = c.applicationContext
        on = Prefs.music
        vm = Prefs.volM
        ve = Prefs.volE
        Anim.load()
        try {
            pool = SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs()).build()
            val afd = ctx.assets.openFd("sounds/card.mp3")
            try { cardId = pool!!.load(afd, 1) } finally { afd.close() }
        } catch (e: Exception) { pool = null }
        musicSync()
    }

    private fun attrs(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

    // ---- playback ----
    private var pool: SoundPool? = null
    private var cardId = 0
    private val active = HashMap<String, MediaPlayer>()

    private fun EF(): Double = ve



    private fun playCard(vol: Float) {
        val p = pool ?: return
        p.play(cardId, vol, vol, 1, 0, 1f)
    }

    private fun playFile(n: String) {
        val old = active.remove(n)
        if (old != null) { try { old.stop() } catch (e: Exception) { }; try { old.release() } catch (e: Exception) { } }
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(attrs())
            val afd = ctx.assets.openFd("sounds/$n.mp3")
            try { mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) } finally { afd.close() }
            val v = EF().toFloat()
            mp.setVolume(v, v)
            mp.setOnCompletionListener { m ->
                if (active[n] === m) active.remove(n)
                try { m.release() } catch (e: Exception) { }
            }
            mp.setOnErrorListener { m, _, _ ->
                if (active[n] === m) active.remove(n)
                try { m.release() } catch (e: Exception) { }
                true
            }
            mp.prepare()
            active[n] = mp
            mp.start()
        } catch (e: Exception) {
            try { mp.release() } catch (x: Exception) { }
        }
    }

    private fun stopAll() {
        for (m in active.values) { try { m.stop() } catch (e: Exception) { }; try { m.release() } catch (e: Exception) { } }
        active.clear()
    }

    /** a plain effect for the 21 game: no banners, no faces, no table animation */
    fun plain(n: String) {
        try {
            if (!on) return
            if (n == "card") playCard(EF().toFloat()) else playFile(n)
        } catch (e: Exception) { }
    }

    // ---- music (played by MusicService) ----
    private const val MB = 1.8
    private val MG0 = 0.25 / MB

    /** perceptual volume curve of the music slider */
    fun MV(): Double {
        val v = vm
        if (v <= 0) return 0.0
        if (v <= 0.5) return v * v / MB
        return MG0 * Math.pow(1 / MG0, (v - 0.5) / 0.5)
    }

    fun musicSync() {
        try { MusicService.apply(ctx, on, MV().toFloat()) } catch (e: Exception) { }
        onChange?.invoke()
    }

    fun musicVolApply() { musicSync() }

    fun toggleMusic() {
        on = !on
        if (!on) stopAll()
        Prefs.music = on
        musicSync()
    }

    /** music slider, v = 0..100 */
    fun setVolM(v: Double) {
        vm = Math.max(0.0, Math.min(1.0, v / 100))
        Prefs.volM = vm
        musicVolApply()
        onChange?.invoke()
    }

    /** effects slider, v = 0..100 */
    fun setVolE(v: Double) {
        ve = Math.max(0.0, Math.min(1.0, v / 100))
        Prefs.volE = ve
        onChange?.invoke()
    }

    fun release() {
        stopAll()
        try { pool?.release() } catch (e: Exception) { }
        pool = null
    }
}
