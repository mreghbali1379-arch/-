package com.example.hokm

/** A playing card: s = suit (0 ♠ پیک, 1 ♥ دل, 2 ♦ خشت, 3 ♣ گشنیز), r = rank 6..14 (11 J, 12 Q, 13 K, 14 A).
 *  Identity matters (the game compares cards by reference, like the original objects), so this is a plain class. */
class Card(@JvmField val s: Int, @JvmField val r: Int)

object Cards {
    val SN = arrayOf("پیک", "دل", "خشت", "گشنیز")
    val RN = mapOf(11 to "سرباز", 12 to "بی‌بی", 13 to "شاه", 14 to "آس")

    /** Western digits -> Persian digits. */
    fun fa(n: Int): String = n.toString().map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
    fun fa(s: String): String = s.map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")

    fun lab(c: Card): String = RN[c.r] ?: fa(c.r)
    fun cname(c: Card): String = lab(c) + " " + SN[c.s]
    fun idc(c: Card): Int = c.s * 20 + c.r

    fun <T> shuf(a: MutableList<T>): MutableList<T> {
        for (i in a.size - 1 downTo 1) {
            val j = Math.floor(Math.random() * (i + 1)).toInt()
            val x = a[i]; a[i] = a[j]; a[j] = x
        }
        return a
    }
}
