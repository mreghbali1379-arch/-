package com.example.hokm

/**
 * The robots' brain for "بیست و یک". Pure logic, no UI.
 *
 * A robot never looks at a hidden card: it only knows the cards it holds and the cards already shown (the [seen] list),
 * so everything that is not known is "unknown" (it includes the hidden cards of the others). From the unknown cards it
 * works out the exact chances (counting cards) and takes the choice with the best chance to win.
 *  - the player: draw or stop, by the exact chance of winning against a banker who draws up to 15, 16 or 17
 *  - the banker: draw or stop, by the chance that the player's total is not higher (a player's total is guessed from
 *    how players usually stop, and from what this very player showed in the earlier hands of this game)
 *  - the bet grows with the robot's edge (an ace or a 10 as the first card, or a deck rich in them)
 */
object Ai21 {
    /** value of rank index 0..8 (the ranks 6,7,8,9,10,J,Q,K,A) */
    private val V = intArrayOf(6, 7, 8, 9, 10, 2, 3, 4, 11)
    private const val BUST = 22

    /** the robot banker changes his first card when its value is not more than this (as in the original game: only J and Q) */
    const val SWAP_MAX = 3

    // how players that are not robots usually stop (chance of each final total 15..21, by the number of cards they hold)
    private val P2 = doubleArrayOf(0.0, 0.186, 0.240, 0.191, 0.161, 0.109, 0.114)
    private val P3 = doubleArrayOf(0.009, 0.169, 0.183, 0.159, 0.168, 0.148, 0.164)
    private val P4 = doubleArrayOf(0.044, 0.130, 0.164, 0.164, 0.158, 0.147, 0.193)

    /** the cards of each rank that are not known: all 4 of each, less the cards seen and the cards in [mine] */
    private fun left(seen: List<Card>, mine: List<Card>): IntArray {
        val c = IntArray(9) { 4 }
        for (x in seen) { val i = x.r - 6; if (i in 0..8) c[i]-- }
        for (x in mine) { val i = x.r - 6; if (i in 0..8) c[i]-- }
        for (i in 0 until 9) if (c[i] < 0) c[i] = 0
        return c
    }

    private fun sum(c: IntArray): Int { var t = 0; for (x in c) t += x; return t }

    // ------------------------------------------------------------------ the banker as the player sees him

    /** chance of every final total of a banker who changes a low first card and then draws while his total is under [stop] */
    private fun bankDist(c: IntArray, stop: Int): DoubleArray {
        val res = DoubleArray(23)
        val tot = sum(c)
        if (tot == 0) { res[0] = 1.0; return res }
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = c[i].toDouble() / tot
            c[i]--
            if (V[i] <= SWAP_MAX) {
                val t2 = sum(c)
                if (t2 > 0) {
                    for (j in 0 until 9) {
                        if (c[j] == 0) continue
                        val q2 = c[j].toDouble() / t2
                        c[j]--
                        bdRec(c, V[j], 1, j == 8, stop, q * q2, res)
                        c[j]++
                    }
                }
            } else bdRec(c, V[i], 1, i == 8, stop, q, res)
            c[i]++
        }
        return res
    }

    private fun bdRec(c: IntArray, t: Int, n: Int, fa: Boolean, stop: Int, p: Double, res: DoubleArray) {
        if (t > 21) { res[BUST] += p; return }
        if (t >= stop) { res[t] += p; return }
        val tot = sum(c)
        if (tot == 0) { res[t] += p; return }
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val q = p * c[i].toDouble() / tot
            c[i]--
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            bdRec(c, nt, n + 1, fa, stop, q, res)
            c[i]++
        }
    }

    /** the banker is not known: he may draw up to 15, 16 or 17 */
    private fun bankMix(c: IntArray): DoubleArray {
        val out = DoubleArray(23)
        for (stop in intArrayOf(15, 16, 17)) {
            val d = bankDist(c, stop)
            for (k in 0 until 23) out[k] += d[k] / 3.0
        }
        return out
    }

    /** chance that a hand of [t] wins when the banker ends with the distribution [bd] (a tie goes to the banker) */
    private fun standP(t: Int, bd: DoubleArray): Double {
        var s = bd[BUST]
        for (k in 0 until Math.min(t, 22)) s += bd[k]
        return s
    }

    // ------------------------------------------------------------------ the player

    private fun pBest(c: IntArray, t: Int, n: Int, fa: Boolean, bd: DoubleArray): Double {
        val s = standP(t, bd)
        if (t >= 21) return s
        val tt = sum(c)
        if (tt == 0) return s
        return Math.max(s, pHit(c, t, n, fa, bd, tt))
    }

    private fun pHit(c: IntArray, t: Int, n: Int, fa: Boolean, bd: DoubleArray, tt: Int): Double {
        var h = 0.0
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            if (nt > 21) continue
            val q = c[i].toDouble() / tt
            c[i]--
            h += q * pBest(c, nt, n + 1, fa, bd)
            c[i]++
        }
        return h
    }

    /** a player holding [hand]: draw one more card? */
    fun playerHit(hand: List<Card>, seen: List<Card>): Boolean {
        if (hand.isEmpty()) return true
        val t = Bist.total(hand).t
        if (t >= 21) return false
        val c = left(seen, hand)
        val tt = sum(c)
        if (tt == 0) return false
        val bd = bankMix(c)
        val s = standP(t, bd)
        val h = pHit(c, t, hand.size, hand[0].r == 14, bd, tt)
        return h > s + 1e-9
    }

    /** the edge (-1..+1, 0 = fair) of a player whose only card is [first], playing well: below 0 the banker is ahead */
    fun firstEdge(first: Card, seen: List<Card>): Double {
        val one = ArrayList<Card>(); one.add(first)
        val t = Bist.value(first.r)
        val c = left(seen, one)
        val tt = sum(c)
        val bd = bankMix(c)
        val s = standP(t, bd)
        val h = if (tt > 0) pHit(c, t, 1, first.r == 14, bd, tt) else 0.0
        return 2.0 * Math.max(s, h) - 1.0
    }

    // ------------------------------------------------------------------ the banker

    /** chance that the player's total is [t] or less (the banker wins a tie); [pn] cards in his hand, [emp] = totals this player stopped on before */
    private fun priCdf(pn: Int, t: Int, emp: IntArray?): Double {
        val gen: Double
        if (pn <= 1) gen = if (t >= 11) 1.0 else 0.0
        else {
            val a = if (pn == 2) P2 else if (pn == 3) P3 else P4
            var s = 0.0; var all = 0.0
            for (i in 0 until 7) { all += a[i]; if (15 + i <= t) s += a[i] }
            gen = if (all > 0.0) s / all else 0.0
        }
        // a little weight for players that stop early
        val base = 0.9 * gen + 0.1 * Math.min(1.0, Math.max(0.0, (t - 11) / 10.0))
        if (emp == null) return base
        var n = 0; var le = 0
        for (k in 0 until 22) { n += emp[k]; if (k <= t) le += emp[k] }
        if (n < 4) return base
        val w = Math.min(0.7, n / (n + 25.0))
        return (1.0 - w) * base + w * (le.toDouble() / n)
    }

    private fun bBest(c: IntArray, t: Int, n: Int, fa: Boolean, pn: Int, emp: IntArray?): Double {
        val s = priCdf(pn, t, emp)
        if (t >= 21) return s
        val tt = sum(c)
        if (tt == 0) return s
        return Math.max(s, bHit(c, t, n, fa, pn, emp, tt))
    }

    private fun bHit(c: IntArray, t: Int, n: Int, fa: Boolean, pn: Int, emp: IntArray?, tt: Int): Double {
        var h = 0.0
        for (i in 0 until 9) {
            if (c[i] == 0) continue
            val nt = if (n == 1 && fa && i == 8) 21 else t + V[i]
            if (nt > 21) continue
            val q = c[i].toDouble() / tt
            c[i]--
            h += q * bBest(c, nt, n + 1, fa, pn, emp)
            c[i]++
        }
        return h
    }

    /** the banker holding [hand] against a player who stopped with [pn] cards: draw one more card? */
    fun bankerHit(hand: List<Card>, seen: List<Card>, pn: Int, emp: IntArray?): Boolean {
        if (hand.isEmpty()) return true
        val t = Bist.total(hand).t
        if (t >= 21) return false
        val c = left(seen, hand)
        val tt = sum(c)
        if (tt == 0) return false
        val s = priCdf(pn, t, emp)
        val h = bHit(c, t, hand.size, hand[0].r == 14, pn, emp, tt)
        return h > s + 1e-9
    }

    /** the robot banker's first card: change it? (same rule as before: only a J or a Q) */
    fun bankerSwap(first: Card): Boolean = Bist.value(first.r) <= SWAP_MAX

    // ------------------------------------------------------------------ small choices

    /** the card to show when a card is asked for after three: the one that tells least (the lowest) */
    fun cardToShow(hand: List<Card>): Int {
        var k = 0
        for (i in hand.indices) if (Bist.value(hand[i].r) < Bist.value(hand[k].r)) k = i
        return k
    }
}
