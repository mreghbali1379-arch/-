package com.example.hokm;

/**
 * Decisions of the 21 robot (no Android, no UI: plain arithmetic, so it can be tested on a computer; see tests/Bist21Sim.java).
 *
 * Everything works on "unknown cards": u[i] = how many cards of value VALS[i] the decider has NOT seen (not on the table
 * as gone cards, not in his own hand). The robot counts cards, so the numbers change during the game.
 *
 * A result is an expected profit per unit of the bet (-1 = loses it, +1 = wins it, a tie loses for the player).
 *
 *  - the player takes a card when the expected profit of taking it (and playing on in the best way, up to 4 more cards) is bigger than of standing;
 *    the banker is assumed to take cards below 17;
 *  - the bet follows the expected profit of the first card (half Kelly), so a good first card gets a big bet and a bad one the smallest;
 *  - the banker decides with a model of what the player holds (he took m cards, he stood), and may put a kept card aside when
 *    the average of a new card is better.
 */
public final class Bist21AI {
    private Bist21AI() { }

    /** values of the 9 kinds of card: J 2, Q 3, K 4, 6, 7, 8, 9, 10, A 11 (sorted) */
    public static final int[] VALS = {2, 3, 4, 6, 7, 8, 9, 10, 11};

    /** index of a card value in VALS (value of Bist.value) */
    public static int idx(int value) {
        switch (value) {
            case 2: return 0; case 3: return 1; case 4: return 2;
            case 11: return 8;
            default: return value - 3;      // 6..10 -> 3..7
        }
    }

    /** a fresh count array: 4 cards of each kind */
    public static int[] fullCounts() {
        int[] u = new int[9];
        for (int i = 0; i < 9; i++) u[i] = 4;
        return u;
    }

    static int sum(int[] u) { int s = 0; for (int x : u) s += x; return s; }

    // ------------------------------------------------------------------ the banker model (what a player expects of the banker)

    private static final int[] P5 = {1, 5, 25, 125, 625, 3125, 15625, 78125, 390625};

    /** distribution of the banker's final total when he takes cards below [hitBelow]: index 0..21 = the total, 22 = burned */
    public static double[] bankerDist(int[] u, int hitBelow) {
        int[] c = u.clone();
        return bankerDfs(0, 0, true, c, sum(c), hitBelow, 0, new java.util.HashMap<Integer, double[]>());
    }

    // the state is fixed by the cards taken so far (key), so the same state reached in another order is computed once
    private static double[] bankerDfs(int t, int n, boolean allAces, int[] u, int total, int hitBelow, int key, java.util.HashMap<Integer, double[]> memo) {
        double[] have = memo.get(key);
        if (have != null) return have;
        double[] out = new double[23];
        if (n == 2 && allAces) out[21] = 1;
        else if (t > 21) out[22] = 1;
        else if (n >= 1 && t >= hitBelow) out[t] = 1;
        else if (total <= 0) out[Math.min(t, 21)] = 1;
        else {
            for (int i = 0; i < 9; i++) {
                if (u[i] == 0) continue;
                double pr = (double) u[i] / total;
                u[i]--;
                double[] ch = bankerDfs(t + VALS[i], n + 1, allAces && VALS[i] == 11, u, total - 1, hitBelow, key + P5[i], memo);
                u[i]++;
                for (int k = 0; k < 23; k++) out[k] += pr * ch[k];
            }
        }
        memo.put(key, out);
        return out;
    }

    // ------------------------------------------------------------------ the player

    /** cum[t] = probability that the banker ends below t or burns (player total t wins); ties are lost */
    private static double[] winTable(double[] bd) {
        double[] w = new double[23];
        double acc = bd[22];
        for (int t = 0; t <= 22; t++) { w[t] = acc; if (t <= 21) acc += bd[t]; }
        return w;
    }

    private static double pv(int t, int n, boolean aa, int[] u, int total, double[] win, int depth, int key, java.util.HashMap<Integer, Double> memo) {
        Double have = memo.get(key);
        if (have != null) return have;
        double stand = 2 * win[t] - 1;
        double res = stand;
        if (depth > 0 && total > 0 && t < 21) res = Math.max(stand, pvHit(t, n, aa, u, total, win, depth, key, memo));
        memo.put(key, res);
        return res;
    }

    /** expected profit of taking one more card now (and playing on in the best way) */
    private static double pvHit(int t, int n, boolean aa, int[] u, int total, double[] win, int depth, int key, java.util.HashMap<Integer, Double> memo) {
        double hit = 0;
        for (int i = 0; i < 9; i++) {
            if (u[i] == 0) continue;
            double pr = (double) u[i] / total;
            int v = VALS[i], nt; boolean naa = false;
            if (n == 1 && aa && v == 11) { nt = 21; naa = true; } else nt = t + v;
            if (nt > 21) { hit -= pr; continue; }
            u[i]--;
            hit += pr * pv(nt, n + 1, naa, u, total - 1, win, depth - 1, key + P5[i], memo);
            u[i]++;
        }
        return hit;
    }

    /** the robot player holds [total] with [n] cards (aa: the one card is an ace); u = cards he has not seen. True = take a card. */
    public static boolean playerHit(int total, int n, boolean aa, int[] u) { return playerHit(total, n, aa, u, 17); }

    /** the same with the banker assumed to take cards below [hitBelow] (14..17) */
    public static boolean playerHit(int total, int n, boolean aa, int[] u, int hitBelow) {
        if (total >= 21) return false;
        double[] win = winTable(bankerDist(u, hitBelow));
        double stand = 2 * win[total] - 1;
        double hit = pvHit(total, n, aa, u.clone(), sum(u), win, 4, 0, new java.util.HashMap<Integer, Double>());
        return hit > stand + 1e-9;
    }

    /** expected profit per unit of the bet of a player whose first card is worth [firstValue] (u without that card) */
    public static double firstCardEdge(int firstValue, int[] u) { return firstCardEdge(firstValue, u, 17); }

    public static double firstCardEdge(int firstValue, int[] u, int hitBelow) {
        double[] win = winTable(bankerDist(u, hitBelow));
        return pv(firstValue, 1, firstValue == 11, u.clone(), sum(u), win, 5, 0, new java.util.HashMap<Integer, Double>());
    }

    /**
     * The robot's bet: half Kelly of his chips by the expected profit of the first card; the smallest bet when the edge is not positive.
     * [mn] the smallest bet, [mx] the biggest allowed (bank and chips).
     */
    public static long bet(double edge, long chips, long mn, long mx) {
        if (mx < mn) return mn;
        double f = edge > 0 ? 0.5 * edge : 0.0;
        long raw = Math.round(f * (double) chips / mn) * mn;
        if (edge > 0.30 && raw < mx / 2 / mn * mn) raw = mx / 2 / mn * mn;     // a very good card: at least half of what he may bet
        return Math.max(mn, Math.min(mx, raw));
    }

    /** the side bet of a robot on another player's hand with a first card worth [firstValue]: 0 = no bet, else the amount (multiple of [mq], at most [mxr]) */
    public static long sideBet(int firstValue, int[] u, long chips, long mq, long mxr) {
        if (mxr < mq) return 0;
        double e = firstCardEdge(firstValue, u);
        if (e < 0.10) return 0;
        long raw = Math.round(0.5 * e * (double) chips / mq) * mq;
        return Math.max(mq, Math.min(mxr, raw));
    }

    // ------------------------------------------------------------------ the banker

    /**
     * distribution of the final total (0..21) of a player who is not burned, as the banker sees it: the player took [m] cards (0 = not known)
     * and stood, and plays with a threshold of 14..17 (averaged); [first] = his first card when it is known (0 = not known)
     */
    public static double[] playerDist(int[] u, int m, int first) {
        double[] acc = new double[22];
        int used = 0;
        for (int tp = 14; tp <= 17; tp++) {
            int[] c = u.clone();
            double[] d;
            java.util.HashMap<Integer, double[]> memo = new java.util.HashMap<Integer, double[]>();
            if (first > 0) {
                int fi = idx(first);
                if (c[fi] <= 0) continue;
                c[fi]--;
                d = playerDfs(first, 1, first == 11, c, sum(c), tp, m, 0, memo);
            } else d = playerDfs(0, 0, true, c, sum(c), tp, m, 0, memo);
            double s = 0; for (double x : d) s += x;
            if (s > 1e-12) { for (int i = 0; i < 22; i++) acc[i] += d[i] / s; used++; }
        }
        if (used == 0) {
            if (m != 0) return playerDist(u, 0, first);
            double[] flat = new double[22]; flat[17] = 1; return flat;
        }
        for (int i = 0; i < 22; i++) acc[i] /= used;
        return acc;
    }

    private static double[] playerDfs(int t, int n, boolean allAces, int[] u, int total, int tp, int m, int key, java.util.HashMap<Integer, double[]> memo) {
        double[] have = memo.get(key);
        if (have != null) return have;
        double[] out = new double[22];
        if (n == 2 && allAces) { if (m == 0 || m == 2) out[21] = 1; }
        else if (t > 21) { }
        else if (n >= 1 && t >= tp) { if (m == 0 || m == n) out[t] = 1; }
        else if (total <= 0) { }
        else if (m != 0 && n >= m) { }           // he has m cards and stood below the threshold: not this model
        else {
            for (int i = 0; i < 9; i++) {
                if (u[i] == 0) continue;
                double pr = (double) u[i] / total;
                u[i]--;
                double[] ch = playerDfs(t + VALS[i], n + 1, allAces && VALS[i] == 11, u, total - 1, tp, m, key + P5[i], memo);
                u[i]++;
                for (int k = 0; k < 22; k++) out[k] += pr * ch[k];
            }
        }
        memo.put(key, out);
        return out;
    }

    private static double bv(int t, int n, boolean aa, int[] u, int total, double[] dpCum, int depth, int key, java.util.HashMap<Integer, Double> memo) {
        if (t > 21) return -1;
        Double have = memo.get(key);
        if (have != null) return have;
        double stand = 2 * dpCum[t] - 1;                 // the banker wins when the player's total is <= his (a tie is his)
        double res = stand;
        if (depth > 0 && total > 0 && t < 21) res = Math.max(stand, bvHit(t, n, aa, u, total, dpCum, depth, key, memo));
        memo.put(key, res);
        return res;
    }

    private static double bvHit(int t, int n, boolean aa, int[] u, int total, double[] dpCum, int depth, int key, java.util.HashMap<Integer, Double> memo) {
        double hit = 0;
        for (int i = 0; i < 9; i++) {
            if (u[i] == 0) continue;
            double pr = (double) u[i] / total;
            int v = VALS[i], nt; boolean naa = false;
            if (n == 1 && aa && v == 11) { nt = 21; naa = true; } else nt = t + v;
            if (nt > 21) { hit -= pr; continue; }
            u[i]--;
            hit += pr * bv(nt, n + 1, naa, u, total - 1, dpCum, depth - 1, key + P5[i], memo);
            u[i]++;
        }
        return hit;
    }

    private static double[] cum(double[] dp) {
        double[] c = new double[22];
        double a = 0;
        for (int t = 0; t < 22; t++) { a += dp[t]; c[t] = a; }
        return c;
    }

    /** the robot banker holds [t] with [n] cards; the player took [m] cards and stood (first: his first card if shown, else 0). True = take a card. */
    public static boolean bankerHit(int t, int n, boolean aa, int[] u, int m, int first) {
        if (t >= 21) return false;
        double[] dc = cum(playerDist(u, m, first));
        double stand = 2 * dc[t] - 1;
        double hit = bvHit(t, n, aa, u.clone(), sum(u), dc, 4, 0, new java.util.HashMap<Integer, Double>());
        return hit > stand + 1e-9;
    }

    /** value of starting with a first card [v] as the banker (before the player's play is known) */
    private static double bankerStartValue(int v, int[] u, double[] dc) {
        return bv(v, 1, v == 11, u.clone(), sum(u), dc, 4, 0, new java.util.HashMap<Integer, Double>());
    }

    /** the banker keeps an unrevealed card worth [kept]; true = put it aside for one new card (u = unseen cards without the kept one) */
    public static boolean bankerSwap(int kept, int[] u) {
        int total = sum(u);
        if (total <= 0) return false;
        double[] dc = cum(playerDist(u, 0, 0));
        double keep = bankerStartValue(kept, u, dc);
        double avg = 0;
        int[] c = u.clone();
        for (int i = 0; i < 9; i++) {
            if (c[i] == 0) continue;
            double pr = (double) c[i] / total;
            c[i]--;
            avg += pr * bankerStartValue(VALS[i], c, dc);
            c[i]++;
        }
        return avg > keep + 0.005;
    }

    /** the card to show for the three-card rule: the least informative one (the smallest value); returns its index in the hand values */
    public static int cardToShow(int[] handValues) {
        int b = 0;
        for (int i = 1; i < handValues.length; i++) if (handValues[i] < handValues[b]) b = i;
        return b;
    }
}
