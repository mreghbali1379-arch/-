package com.example.hokm

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The small policy network of the four-player robot (Engine4).
 *
 * It was trained outside the app (folder ml/ of the project) on the decisions of a strong Monte-Carlo teacher and answers one
 * question in a few microseconds: "how likely is each legal card to be the best one here?". Engine4.choose uses the answer
 * as a prior beside its own Monte-Carlo values (and may skip the candidates the net finds hopeless), so the search spends
 * its deals where they matter. Without the weight file (assets/hokm4_policy.bin) or with [enabled] = false the robot plays
 * exactly as before.
 *
 * Plain Kotlin and no library: sparse binary input -> hidden 1 (ReLU) -> hidden 2 (ReLU) -> 52 logits.
 * The input is built by [features]; the same function exists in C++ (ml/hokm.cpp, encode) and the two must stay identical
 * (BrainTest checks them with the vectors that `hokm vec` writes).
 *
 * Card number = suit * 13 + (rank - 2), suit 0..3 as everywhere in the app, rank 2..14.
 */
object Brain4 {
    const val NB = 282   // binary inputs
    const val ND = 5     // dense inputs

    /** the switch (settings could set it); the net is used only when it is loaded as well */
    @JvmField @Volatile var enabled = true

    private var h1 = 0
    private var h2 = 0
    private var w1 = FloatArray(0)
    private var b1 = FloatArray(0)
    private var w2 = FloatArray(0)
    private var b2 = FloatArray(0)
    private var w3 = FloatArray(0)
    private var b3 = FloatArray(0)

    @Volatile var ready = false
        private set

    /** reads assets/hokm4_policy.bin; any problem leaves the net off */
    fun load(ctx: Context) {
        ready = try {
            val bytes = ctx.applicationContext.assets.open("hokm4_policy.bin").use { it.readBytes() }
            parse(bytes)
        } catch (e: Exception) {
            false
        }
    }

    /** the file format of ml/train.py: "HKN1", 5 ints (NB, ND, H1, H2, 52), then the float32 weights (little endian) */
    fun parse(bytes: ByteArray): Boolean {
        try {
            if (bytes.size < 24) return false
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            if (bytes[0] != 'H'.code.toByte() || bytes[1] != 'K'.code.toByte() || bytes[2] != 'N'.code.toByte() || bytes[3] != '1'.code.toByte()) return false
            val nb = bb.getInt(4); val nd = bb.getInt(8); val a = bb.getInt(12); val b = bb.getInt(16); val no = bb.getInt(20)
            if (nb != NB || nd != ND || no != 52 || a !in 1..256 || b !in 1..128) return false
            val need = 24L + 4L * ((NB + ND) * a + a + a * b + b + b * 52 + 52)
            if (bytes.size.toLong() != need) return false
            bb.position(24)
            val fb = bb.asFloatBuffer()
            val nw1 = FloatArray((NB + ND) * a); fb.get(nw1)
            val nb1 = FloatArray(a); fb.get(nb1)
            val nw2 = FloatArray(a * b); fb.get(nw2)
            val nb2 = FloatArray(b); fb.get(nb2)
            val nw3 = FloatArray(b * 52); fb.get(nw3)
            val nb3 = FloatArray(52); fb.get(nb3)
            h1 = a; h2 = b; w1 = nw1; b1 = nb1; w2 = nw2; b2 = nb2; w3 = nw3; b3 = nb3
            return true
        } catch (e: Exception) {
            return false
        }
    }

    /** logits of the 52 cards for the sparse input [idx] (first [n] entries are the active binary inputs) and the dense inputs */
    fun forward(idx: IntArray, n: Int, dense: FloatArray): FloatArray {
        val a = h1; val b = h2
        val x1 = FloatArray(a)
        for (j in 0 until a) x1[j] = b1[j]
        for (i in 0 until n) {
            val o = idx[i] * a
            for (j in 0 until a) x1[j] += w1[o + j]
        }
        for (d in 0 until ND) {
            val v = dense[d]
            if (v != 0f) {
                val o = (NB + d) * a
                for (j in 0 until a) x1[j] += v * w1[o + j]
            }
        }
        for (j in 0 until a) if (x1[j] < 0f) x1[j] = 0f
        val x2 = FloatArray(b)
        for (j in 0 until b) x2[j] = b2[j]
        for (i in 0 until a) {
            val v = x1[i]
            if (v == 0f) continue
            val o = i * b
            for (j in 0 until b) x2[j] += v * w2[o + j]
        }
        for (j in 0 until b) if (x2[j] < 0f) x2[j] = 0f
        val out = FloatArray(52)
        for (k in 0 until 52) out[k] = b3[k]
        for (i in 0 until b) {
            val v = x2[i]
            if (v == 0f) continue
            val o = i * 52
            for (k in 0 until 52) out[k] += v * w3[o + k]
        }
        return out
    }

    private fun cid(c: Card): Int = c.s * 13 + (c.r - 2)

    /** the sparse input of the state for the player [s] who is to move (the same as encode() of ml/hokm.cpp); returns the number of active inputs */
    fun features(e: Engine4, s: Int, idx: IntArray, dense: FloatArray): Int {
        var n = 0
        for (c in e.H[s]) idx[n++] = cid(c)
        var inTrick = 0L
        for (t in e.trick) inTrick = inTrick or (1L shl cid(t.c))
        for (id in e.seen) {
            val c = (id / 20) * 13 + (id % 20 - 2)
            if ((inTrick shr c) and 1L == 0L) idx[n++] = 52 + c
        }
        for (t in e.trick) {
            val j = (t.seat - s + 4) % 4
            idx[n++] = 104 + (j - 1) * 52 + cid(t.c)
        }
        if (e.trump >= 0) idx[n++] = 260 + e.trump
        idx[n++] = 264 + (e.hakem - s + 4) % 4
        for (j in 1..3) {
            val q = (s + j) % 4
            for (x in e.voids[q]) idx[n++] = 268 + (j - 1) * 4 + x
        }
        val me = s % 2
        if (e.kt == me) idx[n++] = 280 else if (e.kt == 1 - me) idx[n++] = 281
        dense[0] = e.tk[me] / 13f
        dense[1] = e.tk[1 - me] / 13f
        dense[2] = e.H[s].size / 13f
        dense[3] = Math.min(7, e.sc[me]) / 7f
        dense[4] = Math.min(7, e.sc[1 - me]) / 7f
        return n
    }

    /**
     * The net's probability for every candidate of Engine4.choose: [cand] = the candidates (the lowest card of each run of equal
     * cards), [legal] = all the legal cards. A candidate gets the probability of its whole run (the legal cards of its suit from it
     * up to the next candidate of the suit), because the net is trained to spread its mass over equal cards.
     * Null when the net is not available.
     */
    fun priors(e: Engine4, s: Int, legal: List<Card>, cand: List<Card>): DoubleArray? {
        if (!enabled || !ready) return null
        try {
            val idx = IntArray(320)
            val dense = FloatArray(ND)
            val n = features(e, s, idx, dense)
            val out = forward(idx, n, dense)
            var mx = -Float.MAX_VALUE
            for (c in legal) mx = Math.max(mx, out[cid(c)])
            val ex = DoubleArray(52)
            var z = 0.0
            for (c in legal) { val x = Math.exp((out[cid(c)] - mx).toDouble()); ex[cid(c)] = x; z += x }
            if (!(z > 0.0)) return null
            val p = DoubleArray(cand.size)
            for ((k, c) in cand.withIndex()) {
                var nxt = Int.MAX_VALUE
                for (d in cand) if (d.s == c.s && d.r > c.r && d.r < nxt) nxt = d.r
                var m = 0.0
                for (l in legal) if (l.s == c.s && l.r >= c.r && l.r < nxt) m += ex[cid(l)]
                p[k] = m / z
            }
            return p
        } catch (e2: Exception) {
            return null
        }
    }
}
