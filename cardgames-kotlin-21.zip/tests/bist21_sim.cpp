// 21 game robots: old (bust rule), simple rules ("hit below 16", ace bets), and Ai21.kt (exact probabilities).
// Rules as Bist21.kt: 36 cards, rank index 0..8 = 6,7,8,9,10,J,Q,K,A with values 6,7,8,9,10,2,3,4,11; two aces = 21 (two cards only); burn > 21;
// tie to the banker; the player gets ONE card, bets, then draws; a burned player leaves the banker his unrevealed card for the next player.
// A round: bank = 1000, minimum bet 50, P players in turn, the cards of finished hands are seen by everybody. Results are in chips per hand.
// g++ -O2 -std=c++17 -o bist21_sim bist21_sim.cpp && ./bist21_sim [rounds]
#include <bits/stdc++.h>
using namespace std;
static const int V[9] = {6, 7, 8, 9, 10, 2, 3, 4, 11};
static const int ACE = 8;
typedef vector<int> Hand;
static mt19937_64 rng(1);

static int total(const Hand& h) { if (h.size() == 2 && h[0] == ACE && h[1] == ACE) return 21; int t = 0; for (int r : h) t += V[r]; return t; }

struct Counts { int c[9]; int sum() const { int s = 0; for (int i = 0; i < 9; i++) s += c[i]; return s; } };
static Counts leftOf(const vector<int>& seen, const Hand& mine) {
    Counts k; for (int i = 0; i < 9; i++) k.c[i] = 4;
    for (int r : seen) k.c[r]--; for (int r : mine) k.c[r]--;
    for (int i = 0; i < 9; i++) if (k.c[i] < 0) k.c[i] = 0;
    return k;
}
static double bustP(const Hand& h, const vector<int>& seen) {
    Counts k = leftOf(seen, h); int t = total(h); int tot = k.sum(), bad = 0;
    for (int i = 0; i < 9; i++) if (t + V[i] > 21) bad += k.c[i];
    return tot == 0 ? 1.0 : (double)bad / tot;
}

// ------------------------------------------------------------------ Ai21.kt (ported line by line)
static int SWAP_MAX = 3;           // as in Ai21: the banker is modelled as changing a first card of value <= 3 (-1 = no such model)
static const double P2[7] = {0.0, 0.186, 0.240, 0.191, 0.161, 0.109, 0.114};
static const double P3[7] = {0.009, 0.169, 0.183, 0.159, 0.168, 0.148, 0.164};
static const double P4[7] = {0.044, 0.130, 0.164, 0.164, 0.158, 0.147, 0.193};
static const int BUST = 22;
typedef array<double, 23> Dist;
static void bdRec(Counts& c, int t, int n, bool fa, int stop, double p, Dist& res) {
    if (t > 21) { res[BUST] += p; return; }
    if (t >= stop) { res[t] += p; return; }
    int tot = c.sum(); if (tot == 0) { res[t] += p; return; }
    for (int i = 0; i < 9; i++) {
        if (c.c[i] == 0) continue;
        double q = p * c.c[i] / tot; c.c[i]--;
        int nt = (n == 1 && fa && i == 8) ? 21 : t + V[i];
        bdRec(c, nt, n + 1, fa, stop, q, res); c.c[i]++;
    }
}
static Dist bankDist(Counts c, int stop) {
    Dist res; res.fill(0.0); int tot = c.sum(); if (tot == 0) { res[0] = 1.0; return res; }
    for (int i = 0; i < 9; i++) {
        if (c.c[i] == 0) continue;
        double q = (double)c.c[i] / tot; c.c[i]--;
        if (V[i] <= SWAP_MAX) {
            int t2 = c.sum();
            if (t2 > 0) for (int j = 0; j < 9; j++) { if (c.c[j] == 0) continue; double q2 = (double)c.c[j] / t2; c.c[j]--; bdRec(c, V[j], 1, j == 8, stop, q * q2, res); c.c[j]++; }
        } else bdRec(c, V[i], 1, i == 8, stop, q, res);
        c.c[i]++;
    }
    return res;
}
static Dist bankMix(const Counts& c) {
    Dist out; out.fill(0.0);
    for (int stop : {15, 16, 17}) { Dist d = bankDist(c, stop); for (int k = 0; k < 23; k++) out[k] += d[k] / 3.0; }
    return out;
}
static double standP(int t, const Dist& bd) { double s = bd[BUST]; for (int k = 0; k < min(t, 22); k++) s += bd[k]; return s; }
static double pBest(Counts& c, int t, int n, bool fa, const Dist& bd);
static double pHit(Counts& c, int t, int n, bool fa, const Dist& bd, int tt) {
    double h = 0;
    for (int i = 0; i < 9; i++) {
        if (c.c[i] == 0) continue;
        int nt = (n == 1 && fa && i == 8) ? 21 : t + V[i]; if (nt > 21) continue;
        double q = (double)c.c[i] / tt; c.c[i]--; h += q * pBest(c, nt, n + 1, fa, bd); c.c[i]++;
    }
    return h;
}
static double pBest(Counts& c, int t, int n, bool fa, const Dist& bd) {
    double s = standP(t, bd); if (t >= 21) return s;
    int tt = c.sum(); if (tt == 0) return s;
    return max(s, pHit(c, t, n, fa, bd, tt));
}
static bool aiPlayerHit(const Hand& hand, const vector<int>& seen) {
    if (hand.empty()) return true; int t = total(hand); if (t >= 21) return false;
    Counts c = leftOf(seen, hand); int tt = c.sum(); if (tt == 0) return false;
    Dist bd = bankMix(c); double s = standP(t, bd); double h = pHit(c, t, hand.size(), hand[0] == ACE, bd, tt);
    return h > s + 1e-9;
}
static double aiFirstEdge(int first, const vector<int>& seen) {
    Hand one = {first}; int t = V[first]; Counts c = leftOf(seen, one); int tt = c.sum(); Dist bd = bankMix(c);
    double s = standP(t, bd); double h = tt > 0 ? pHit(c, t, 1, first == ACE, bd, tt) : 0.0;
    return 2.0 * max(s, h) - 1.0;
}
static double priCdf(int pn, int t, const int* emp) {
    double gen;
    if (pn <= 1) gen = t >= 11 ? 1.0 : 0.0;
    else { const double* a = pn == 2 ? P2 : pn == 3 ? P3 : P4; double s = 0, all = 0; for (int i = 0; i < 7; i++) { all += a[i]; if (15 + i <= t) s += a[i]; } gen = all > 0 ? s / all : 0.0; }
    double base = 0.9 * gen + 0.1 * min(1.0, max(0.0, (t - 11) / 10.0));
    if (!emp) return base;
    int n = 0, le = 0; for (int k = 0; k < 22; k++) { n += emp[k]; if (k <= t) le += emp[k]; }
    if (n < 4) return base;
    double w = min(0.7, n / (n + 25.0)); return (1.0 - w) * base + w * ((double)le / n);
}
static double bBest(Counts& c, int t, int n, bool fa, int pn, const int* emp);
static double bHit(Counts& c, int t, int n, bool fa, int pn, const int* emp, int tt) {
    double h = 0;
    for (int i = 0; i < 9; i++) {
        if (c.c[i] == 0) continue;
        int nt = (n == 1 && fa && i == 8) ? 21 : t + V[i]; if (nt > 21) continue;
        double q = (double)c.c[i] / tt; c.c[i]--; h += q * bBest(c, nt, n + 1, fa, pn, emp); c.c[i]++;
    }
    return h;
}
static double bBest(Counts& c, int t, int n, bool fa, int pn, const int* emp) {
    double s = priCdf(pn, t, emp); if (t >= 21) return s;
    int tt = c.sum(); if (tt == 0) return s;
    return max(s, bHit(c, t, n, fa, pn, emp, tt));
}
static bool aiBankerHit(const Hand& hand, const vector<int>& seen, int pn, const int* emp) {
    if (hand.empty()) return true; int t = total(hand); if (t >= 21) return false;
    Counts c = leftOf(seen, hand); int tt = c.sum(); if (tt == 0) return false;
    double s = priCdf(pn, t, emp); double h = bHit(c, t, hand.size(), hand[0] == ACE, pn, emp, tt);
    return h > s + 1e-9;
}

// ------------------------------------------------------------------ strategies
enum PlayS { P_OLD, P_RULE, P_AI };
enum BankS { B_OLD, B_RULE, B_AI };
enum BetS { BET_OLD, BET_FLAT, BET_ACE, BET_AI, BET_E00, BET_E05, BET_E10, BET_E15 };
static const long MN = 50, BANK0 = 1000, CHIPS = 30000;

static bool playerHit(PlayS s, const Hand& h, const vector<int>& seen) {
    int t = total(h); if (t >= 21) return false;
    if (s == P_OLD) return bustP(h, seen) < 0.42;
    if (s == P_RULE) return t < 16;
    return aiPlayerHit(h, seen);
}
static bool bankerHit(BankS s, const Hand& h, const vector<int>& seen, int pn, const int* emp, bool big) {
    int t = total(h); if (t >= 21) return false;
    if (s == B_OLD) return bustP(h, seen) < 0.5;
    if (s == B_RULE) return t < (big ? 18 : 16);
    return aiBankerHit(h, seen, pn, emp);
}
static long betOf(BetS s, int first, const vector<int>& seen, long bank, long chips) {
    long mx = min(bank, chips), m1 = MN;
    if (s == BET_FLAT) return m1;
    if (s == BET_OLD) {
        double hi = V[first] >= 10 ? 1.6 : 1.0; double u = uniform_real_distribution<double>(0, 1)(rng);
        double raw = m1 * (1 + u * ((double)bank / m1 / 4) * hi);
        long b = max(m1, min(mx, (long)llround(raw / m1) * m1));
        if (chips >= bank && first == ACE && uniform_real_distribution<double>(0, 1)(rng) < 0.4) b = bank;
        return b;
    }
    if (s == BET_ACE) {
        long want = first == ACE ? min(m1 * 8, chips / 5) : m1; long b = max(m1, min(mx, (want / m1) * m1));
        if (first == ACE && chips >= 2 * bank && bank >= m1 && uniform_real_distribution<double>(0, 1)(rng) < 0.5) b = bank;
        return b;
    }
    if (s >= BET_E00) {      // the simple size rule (8 minimum bets, at most a fifth of the chips) but chosen by the counted edge of the first card
        double thr = s == BET_E00 ? 0.0 : s == BET_E05 ? 0.05 : s == BET_E10 ? 0.10 : 0.15;
        double e = aiFirstEdge(first, seen); long want = e > thr ? min(m1 * 8, chips / 5) : m1;
        return max(m1, min(mx, (want / m1) * m1));
    }
    double edge = aiFirstEdge(first, seen); long b;
    if (edge <= 0.0) b = max(m1, min(mx, m1));
    else {
        double frac = min(0.5, edge * 2.0); double raw = (double)m1 + (double)(mx - m1) * frac;
        long b1 = (long)llround(raw / m1) * m1; long capOwn = max(m1, (chips / 4 / m1) * m1);
        if (edge < 0.25 && b1 > capOwn) b1 = capOwn; b = max(m1, min(mx, b1));
    }
    if (chips >= bank && edge > 0.3 && uniform_real_distribution<double>(0, 1)(rng) < 0.5) b = bank;
    return b;
}

struct Cfg { PlayS ps; BetS bs; BankS ks; int swapMax; bool freshSwap; };

int main(int argc, char** argv) {
    int rounds = argc > 1 ? atoi(argv[1]) : 2000; int P = 4;
    struct Row { const char* name; Cfg cfg; int aiModelSwap; };
    vector<Row> rows = {
        {"RULE players + ace bets vs old banker",      {P_RULE, BET_ACE, B_OLD, 3, false}, 3},
        {"RULE players + edge>0.00 bets vs old banker",{P_RULE, BET_E00, B_OLD, 3, false}, 3},
        {"RULE players + edge>0.05 bets vs old banker",{P_RULE, BET_E05, B_OLD, 3, false}, 3},
        {"RULE players + edge>0.10 bets vs old banker",{P_RULE, BET_E10, B_OLD, 3, false}, 3},
        {"RULE players + edge>0.15 bets vs old banker",{P_RULE, BET_E15, B_OLD, 3, false}, 3},
        {"RULE players + ace bets vs AI banker",       {P_RULE, BET_ACE, B_AI, 3, false}, 3},
        {"RULE players + edge>0.05 bets vs AI banker", {P_RULE, BET_E05, B_AI, 3, false}, 3},
        {"RULE players + edge>0.10 bets vs AI banker", {P_RULE, BET_E10, B_AI, 3, false}, 3},
        {"RULE players + edge>0.15 bets vs AI banker", {P_RULE, BET_E15, B_AI, 3, false}, 3},
        {"RULE players + ace bets vs AI banker swap<=7",{P_RULE, BET_ACE, B_AI, 7, false}, 3},
        {"RULE players + ace bets vs AI banker swap none",{P_RULE, BET_ACE, B_AI, 0, false}, 3},
        {"AI players flat vs old banker, model swap 3",{P_AI, BET_FLAT, B_OLD, 3, false}, 3},
        {"AI players flat vs old banker, model swap none",{P_AI, BET_FLAT, B_OLD, 3, false}, -1},
        {"AI players flat vs AI banker, model swap none",{P_AI, BET_FLAT, B_AI, 3, false}, -1},
        {"AI players flat vs AI banker, model swap 3", {P_AI, BET_FLAT, B_AI, 3, false}, 3},
        {"RULE players flat vs AI banker",             {P_RULE, BET_FLAT, B_AI, 3, false}, 3},
    };
    for (auto& row : rows) {
        rng.seed(12345);
        const Cfg& cfg = row.cfg; SWAP_MAX = row.aiModelSwap;
        double sum = 0, sum2 = 0; long hands = 0; double bankerSum = 0;
        int stopTot[10][22]; memset(stopTot, 0, sizeof stopTot);
        vector<double> perRound;
        for (int r = 0; r < rounds; r++) {
            vector<int> deck; for (int i = 0; i < 9; i++) for (int k = 0; k < 4; k++) deck.push_back(i);
            shuffle(deck.begin(), deck.end(), rng);
            vector<int> seen; long bank = BANK0; Hand kept; bool haveKept = false; long chips[10]; for (int i = 0; i < 10; i++) chips[i] = CHIPS;
            double roundSum = 0;
            for (int p = 0; p < P; p++) {
                if (deck.size() < 12 || bank < MN) break;
                Hand ph = {deck.back()}; deck.pop_back();
                Hand bh;
                if (haveKept) { bh = kept; if ((V[bh[0]] <= cfg.swapMax)) { bh = {deck.back()}; deck.pop_back(); } }
                else { bh = {deck.back()}; deck.pop_back(); }
                haveKept = false;
                long bet = betOf(cfg.bs, ph[0], seen, bank, chips[p]);
                bool big = bet >= 4 * MN;
                while (total(ph) < 21 && !deck.empty() && playerHit(cfg.ps, ph, seen)) { ph.push_back(deck.back()); deck.pop_back(); }
                int tp = total(ph); long res;
                if (tp > 21) { seen.insert(seen.end(), ph.begin(), ph.end()); res = -bet; kept = bh; haveKept = true; }
                else {
                    stopTot[p][tp]++;
                    while (total(bh) < 21 && !deck.empty() && bankerHit(cfg.ks, bh, seen, ph.size(), stopTot[p], big)) { bh.push_back(deck.back()); deck.pop_back(); }
                    int tb = total(bh); seen.insert(seen.end(), ph.begin(), ph.end()); seen.insert(seen.end(), bh.begin(), bh.end());
                    res = (tb > 21 || tp > tb) ? bet : -bet;
                }
                bank -= res; chips[p] += res; roundSum += res; hands++;
            }
            perRound.push_back(roundSum); sum += roundSum; sum2 += roundSum * roundSum;
        }
        double m = sum / rounds, sd = sqrt(max(0.0, sum2 / rounds - m * m));
        printf("  %-42s players win %+8.1f chips per round (%+.3f per hand)  +- %.1f\n", row.name, m, sum / hands, sd / sqrt((double)rounds));
        fflush(stdout);
    }
}
