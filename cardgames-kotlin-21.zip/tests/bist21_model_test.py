#!/usr/bin/env python3
"""Model of the 21 game round (Bist21.kt: round / play / draw1) after the changes, with scenario tests and random invariant checks.
The model follows the Kotlin code step by step (same order of draws, carried banker card, aside pile, khabre, side bets).
It is NOT the Kotlin code: it checks the design of the rules; the Kotlin build still has to be run on a device.
Run:  python3 tests/bist21_model_test.py
"""
import random, sys

VAL = {14: 11, 13: 4, 12: 3, 11: 2}
def value(r): return VAL.get(r, r)
def total(h):
    pair = len(h) == 2 and h[0][1] == 14 and h[1][1] == 14
    return 21 if pair else sum(value(c[1]) for c in h)
def player_wins(p, b): return p <= 21 and (b > 21 or p > b)
def new_deck(rng):
    d = [(s, r) for s in range(4) for r in range(6, 15)]; rng.shuffle(d); return d

class Table:
    """policy(seat, kind, state) -> answer; kinds: bet, hit, swap, khabre, side, show"""
    def __init__(self, n, chips, base, mn, side, kh_mul, deal_all, rng, policy, deck=None):
        self.n, self.chips, self.base, self.mn = n, list(chips), base, mn
        self.side, self.kh, self.deal_all, self.rng, self.policy = side, kh_mul, deal_all, rng, policy
        self.bank = 0; self.seen = []; self.aside = []; self.deck = deck if deck is not None else new_deck(rng)
        self.live = {}            # cards in hands: name -> list
        self.khabre_on = False; self.log = []; self.reshuffles = 0
        self.played = []          # seats played with, in order
        self.fixed_deck = deck is not None

    def all_cards(self):
        out = list(self.deck) + self.seen + self.aside
        for l in self.live.values(): out += l
        return out

    def draw1(self):
        if not self.deck:
            pool = list(self.seen + self.aside)
            assert pool, 'deck and seen both empty'
            self.seen.clear(); self.aside.clear(); self.rng.shuffle(pool); self.deck.extend(pool); self.reshuffles += 1
        return self.deck.pop()

    def play(self, p, hand, is_bank, key):
        while True:
            t = total(hand)
            if t > 21: return t
            if self.policy(p, 'hit', (hand, is_bank, self)) != 'h': return t
            nr = False
            if not is_bank and len(hand) >= 3:
                nr = self.policy(p, 'show', hand) == 'n'
            hand.append(self.draw1()); self.live[key] = hand
            if nr: self.log.append(('banker shows', hand[-1]))

    def round(self, b):
        n = self.n
        self.bank = self.base; self.chips[b] -= self.base
        self.seen = []; self.aside = []; self.khabre_on = False; self.live = {}
        carried = None; pre = {}
        if self.deal_all:
            for k in range(1, n):
                p = (b + k) % n
                if self.chips[p] < self.mn: continue
                pre[p] = [self.draw1()]; self.live[('pre', p)] = pre[p]
        for k in range(1, n):
            p = (b + k) % n
            if self.chips[p] < self.mn: continue
            if self.bank < self.mn: break
            pre_dealt = p in pre
            if pre_dealt:
                ph = pre.pop(p); self.live.pop(('pre', p), None)
            else:
                ph = [self.draw1()]
            self.live['ph'] = ph
            kept = carried; carried = None
            if kept is not None: self.live.pop('carried', None)
            bhand = kept if kept is not None else [self.draw1()]
            self.live['bh'] = bhand
            if kept is not None and self.policy(b, 'swap', (bhand, self)) == 'w':   # only a kept (unrevealed) card may be put aside
                self.aside.append(bhand[0]); bhand = [self.draw1()]; self.live['bh'] = bhand
                self.log.append(('swap', p))
            self.played.append((p, 'kept' if kept is not None else 'new'))
            mx = min(self.bank, self.chips[p])
            bet = self.policy(p, 'bet', (mx, self))
            assert self.mn <= bet <= mx, (bet, mx)
            side_q = []; side_a = []
            if self.side:
                for q in range(n):
                    if q == p or q == b or self.chips[q] < self.mn: continue
                    used = sum(side_a); rem = self.bank - bet - used
                    mxr = (min(bet, self.chips[q], rem) // self.mn) * self.mn
                    if mxr < self.mn: continue
                    a = self.policy(q, 'side', (mxr, self))
                    assert 0 <= a <= mxr
                    if a > 0: side_q.append(q); side_a.append(a)
            pt = self.play(p, ph, False, 'ph')
            if pt > 21:
                out = False; carried = bhand; self.live['carried'] = bhand; self.live.pop('bh', None)
            else:
                bt = self.play(b, bhand, True, 'bh')
                out = player_wins(pt, bt)
                self.seen.extend(bhand); self.live.pop('bh', None)
            self.seen.extend(ph); self.live.pop('ph', None)
            if out: self.chips[p] += bet; self.bank -= bet
            else: self.chips[p] -= bet; self.bank += bet
            for q, a in zip(side_q, side_a):
                if out: self.chips[q] += a; self.bank -= a
                else: self.chips[q] -= a; self.bank += a
            self.last = dict(p=p, pt=pt, out=out, bet=bet, side=list(zip(side_q, side_a)))
            self.hist = getattr(self, 'hist', []) + [(p, pt, out, bet, list(zip(side_q, side_a)))]
            if self.bank <= 0: break
            if not self.khabre_on and self.bank >= self.base * self.kh and k < n - 1:
                if self.policy(b, 'khabre', self) == 'y':
                    self.khabre_on = True
                    pool = list(self.deck) + self.seen + self.aside          # the banker shuffles: gone + aside cards go back into the deck
                    self.seen = []; self.aside = []; self.rng.shuffle(pool); self.deck = pool; self.shuffled_at_khabre = True
        # (leftover pre cards / carried card stay live until the round ends; the next round has a new deck)
        got = self.bank; self.chips[b] += got; self.bank = 0
        return got

def check(cond, msg):
    if not cond: raise AssertionError(msg)

def fixed_policy(**kw):
    def pol(seat, kind, st):
        f = kw.get(kind)
        if f is None:
            return {'hit': 's', 'swap': 'k', 'khabre': 'n', 'show': '0', 'side': 0, 'bet': st[0] if kind == 'bet' else 0}[kind] if kind != 'bet' else st[1] and 0 or 0
        return f(seat, st) if callable(f) else f
    return pol

def rigged(order):
    """deck whose draws come out in the given order (deck.pop takes the last element)"""
    rest = [(s, r) for s in range(4) for r in range(6, 15) if (s, r) not in order]
    return rest + list(reversed(order))

results = []
def test(name):
    def deco(f):
        try: f(); results.append((name, 'OK'))
        except AssertionError as e: results.append((name, 'FAIL: %s' % e))
        return f
    return deco

C = lambda r, s=0: (s, r)

def make(deck_order, pol, n=3, chips=None, side=False, deal_all=False, kh=3, base=1000, mn=50, seed=1):
    chips = chips or [10000] * n
    return Table(n, chips, base, mn, side, kh, deal_all, random.Random(seed), pol, rigged(deck_order))

def pol(**kw):
    d = dict(hit=lambda s, st: 's', swap=lambda s, st: 'k', khabre=lambda s, st: 'n', show=lambda s, st: '0', side=lambda s, st: 0,
             bet=lambda s, st: st[0] if False else 100)
    d.update(kw)
    return lambda seat, kind, st: d[kind](seat, st) if callable(d[kind]) else d[kind]

# Draw order in round(): the player's first card, then the banker's first card (if he has none kept), then hits in the order they happen.
@test('win: player 20 beats banker 18 and takes the bet from the bank')
def _():
    t = make([C(10, 1), C(8, 0), C(10, 2), C(10, 3)], pol(hit=lambda s, st: 'h' if (s == 1 and total(st[0]) < 20) or (s == 0 and total(st[0]) < 18) else 's'), n=2)
    t.round(0)
    p, pt, out, bet, _ = t.hist[0]
    check(pt == 20 and out, ('player total', pt, out))
    check(t.chips[1] == 10100 and t.chips[0] == 9900, t.chips)

@test('loss: player 17 loses to banker 19')
def _():
    t = make([C(10, 1), C(9, 0), C(7, 1), C(10, 2)], pol(hit=lambda s, st: 'h' if (s == 1 and total(st[0]) < 17) or (s == 0 and total(st[0]) < 19) else 's'), n=2)
    t.round(0)
    p, pt, out, bet, _ = t.hist[0]
    check(pt == 17 and not out, (pt, out))
    check(t.chips[1] == 9900 and t.chips[0] == 10100, t.chips)

@test('burn: player over 21 loses, banker never plays')
def _():
    t = make([C(10, 1), C(8, 0), C(9, 1), C(13, 1)], pol(hit=lambda s, st: 'h' if s == 1 else 's'), n=2)
    t.round(0)
    p, pt, out, bet, _ = t.hist[0]
    check(pt == 23 and not out, (pt, out))
    check(t.chips[1] == 9900, t.chips)

@test('tie goes to the banker; both 21 -> banker; two aces count 21 only with two cards')
def _():
    check(not player_wins(18, 18) and not player_wins(21, 21) and player_wins(19, 18) and player_wins(10, 23) and not player_wins(22, 10), 'playerWins')
    check(total([C(14), C(14, 1)]) == 21 and total([C(14), C(14, 1), C(6)]) == 28, 'two aces')
    t = make([C(10, 1), C(10, 0), C(8, 1), C(8, 2)], pol(hit=lambda s, st: 'h' if total(st[0]) < 18 else 's'), n=2)
    t.round(0)
    check(t.hist[0][1] == 18 and not t.hist[0][2], 'tie 18-18 must go to the banker')

@test('banker keeps the unrevealed card for the next player after a burn (it is not dealt again)')
def _():
    order = [C(10, 1), C(9, 0), C(11, 1), C(12, 1), C(13, 1), C(14, 1), C(7, 2)]
    t = make(order, pol(hit=lambda s, st: 'h' if s == 1 else 's'), n=3)
    t.round(0)
    check(t.hist[0][1] > 21, 'player 1 must burn')
    check(t.played == [(1, 'new'), (2, 'kept')], t.played)
    check(t.hist[1][1] == 7 and not t.hist[1][2], ('player 2 faced the kept 9 and lost', t.hist[1]))
    check(len(t.all_cards()) == 36 and len(set(t.all_cards())) == 36, 'cards conserved')

@test('banker swap: only a kept card can be put aside, once, for exactly one other card; a fresh card cannot')
def _():
    order = [C(10, 1), C(9, 0), C(11, 1), C(12, 1), C(13, 1), C(14, 1), C(7, 2), C(10, 3)]
    t = make(order, pol(hit=lambda s, st: 'h' if s == 1 else 's', swap=lambda s, st: 'w'), n=3)
    t.round(0)
    check(t.log.count(('swap', 1)) == 0, 'no swap for the first player (fresh card)')
    check(t.log.count(('swap', 2)) == 1, t.log)
    check(C(9, 0) in t.aside and C(9, 0) not in t.deck, 'the kept card must be aside, not in the deck')
    check(C(10, 3) in t.seen, 'the replacement card is the banker card that was played')
    check(len(t.all_cards()) == 36 and len(set(t.all_cards())) == 36, 'cards conserved')
    # a fresh card is never offered for a swap
    t2 = make([C(8, 1), C(6, 0), C(10, 2)], pol(swap=lambda s, st: 'w'), n=2)
    t2.round(0)
    check(t2.log == [] and C(6, 0) in t2.seen, 'fresh card stays')

@test('aside cards come back only when the deck is shuffled again')
def _():
    t = make([C(8, 1)], pol(), n=2)
    t.deck = []; t.seen = [C(7, 1)]; t.aside = [C(6, 0)]
    c = t.draw1()
    check(c in (C(7, 1), C(6, 0)) and t.reshuffles == 1 and len(t.deck) == 1 and not t.aside and not t.seen, 'reshuffle pool = seen + aside')

KH_DECK = [C(7, 1), C(10, 0), C(7, 2), C(10, 1), C(7, 3), C(10, 2)]
@test('khabre: the banker still plays with everybody, then takes the whole bank')
def _():
    t = make(KH_DECK, pol(bet=lambda s, st: st[0], khabre=lambda s, st: 'y'), n=4, chips=[20000] * 4, kh=3)
    t.round(0)
    check(t.khabre_on, 'khabre must be on')
    check(getattr(t, 'shuffled_at_khabre', False), 'the banker shuffles when he says khabre')
    check(len(t.all_cards()) == 36 and len(set(t.all_cards())) == 36, 'cards conserved after the shuffle')
    check([x[0] for x in t.hist] == [1, 2, 3], ('all players must be played with', [x[0] for x in t.hist]))
    check(t.bank == 0 and sum(t.chips) == 80000, t.chips)
    # after the shuffle the cards of player 3 are random, so only the first two results are fixed (bets 1000 and 2000 lost)
    check(t.chips[1] == 19000 and t.chips[2] == 18000, t.chips)

@test('khabre not said: the round goes on exactly the same way')
def _():
    t = make(KH_DECK, pol(bet=lambda s, st: st[0], khabre=lambda s, st: 'n'), n=4, chips=[20000] * 4)
    t.round(0)
    check(not t.khabre_on and [x[0] for x in t.hist] == [1, 2, 3], 'all played')

@test('side bet: follows the owner of the hand, independent of the main bet, chips conserved')
def _():
    for owner_wins in (True, False):
        if owner_wins:
            order = [C(10, 1), C(8, 0), C(10, 2)]
            hit = lambda s, st: 'h' if (s == 1 and total(st[0]) < 20) else 's'
        else:
            order = [C(10, 1), C(10, 0)]
            hit = lambda s, st: 's'
        snap = {}
        def bet(s, st):
            T = st[1]
            if T.played[-1][0] == 2 and 'x' not in snap: snap['x'] = list(T.chips)
            return min(400, st[0])
        t = make(order, pol(hit=hit, bet=bet, side=lambda s, st: 300 if st[1].played[-1][0] == 1 else 0), n=3, side=True)
        t.round(0)
        p, pt, out, bet_, sd = t.hist[0]
        check(out == owner_wins, ('owner result', out, owner_wins))
        check(sd == [(2, 300)], ('side bet placed', sd))
        after = snap['x']       # chips right after the first player was settled (banker staked 1000)
        if out: check(after[1] == 10400 and after[2] == 10300, (out, after))
        else: check(after[1] == 9600 and after[2] == 9700, (out, after))
        check(sum(t.chips) == 30000, 'chips conserved')

@test('side bet is limited by own chips (and by the main bet and what the bank can pay)')
def _():
    caps = []
    def side(s, st): caps.append(st[0]); return st[0]
    t = make([C(10, 1), C(9, 0), C(8, 2)], pol(bet=lambda s, st: min(400, st[0]), side=side), n=3, chips=[10000, 10000, 120], side=True)
    t.round(0)
    check(caps and caps[0] == 100, caps)         # 120 chips -> 100 (a multiple of the minimum bet 50)
    t2 = make([C(10, 1), C(9, 0), C(8, 2)], pol(bet=lambda s, st: min(950, st[0]), side=side), n=3, chips=[10000, 10000, 10000], side=True)
    caps.clear(); t2.round(0)
    check(not caps or caps[0] <= 50, caps)       # bank 1000, bet 950: the bank can pay only 50 more

@test('both dealing methods keep the turn order (right-hand player first, then on) and conserve the cards')
def _():
    for da in (False, True):
        t = make([C(10), C(9, 1), C(8, 2), C(7, 3), C(6, 1), C(6, 2), C(6, 3)], pol(), n=4, deal_all=da)
        t.round(0)
        check([x[0] for x in t.hist] == [1, 2, 3], (da, [x[0] for x in t.hist]))
        check(len(t.all_cards()) == 36 and len(set(t.all_cards())) == 36, 'cards conserved')

# ---------------------------------------------------------------- random games with invariants
def random_policy(rng):
    def f(seat, kind, st):
        if kind == 'hit': return 'h' if rng.random() < 0.55 else 's'
        if kind == 'swap': return 'w' if rng.random() < 0.3 else 'k'
        if kind == 'show': return 'n' if rng.random() < 0.3 else '0'
        if kind == 'khabre': return 'y' if rng.random() < 0.6 else 'n'
        if kind == 'side':
            return (st[0] // st[1].mn) * st[1].mn if rng.random() < 0.5 else 0
        if kind == 'bet':
            mx, T = st; return max(T.mn, (rng.randint(T.mn, mx) // T.mn) * T.mn)
    return f

@test('random rounds (both deal methods, 2..10 players, side bets on/off): cards and chips conserved, no negative chips, khabre never cuts the round short')
def _():
    rng = random.Random(7); rounds = 0; kh_rounds = 0; kept_cards = 0; swaps = 0; reshuffles = 0
    for it in range(6000):
        n = rng.randint(2, 10); base = rng.choice([1000, 2000, 5000]); mn = rng.choice([50, 100, 500])
        chips = [rng.randint(mn, 40000) for _ in range(n)]
        t = Table(n, chips, base, mn, rng.random() < 0.5, rng.choice([2, 3, 4, 5, 10]), rng.random() < 0.5, rng, random_policy(rng))
        b = rng.randrange(n)
        if t.chips[b] < base: continue
        total_before = sum(t.chips)
        t.round(b)
        rounds += 1
        check(sum(t.chips) == total_before, 'chips not conserved')
        check(min(t.chips) >= 0, ('negative chips', t.chips))
        check(t.bank == 0, 'bank must be taken')
        allc = t.all_cards()
        check(len(allc) == 36 and len(set(allc)) == 36, ('cards', len(allc), len(set(allc))))
        if t.khabre_on:
            kh_rounds += 1
            # everybody who could still bet at that time must have been played with: the last played seat is the last eligible seat before the end
            order = [(b + k) % n for k in range(1, n)]
            played = [h[0] for h in t.hist]
            check(played == [p for p in order if p in played], 'turn order broken')
        kept_cards += sum(1 for x in t.played if x[1] == 'kept'); swaps += sum(1 for x in t.log if x[0] == 'swap'); reshuffles += t.reshuffles
    print('   random rounds: %d, with khabre: %d, kept banker cards: %d, swaps: %d, reshuffles: %d' % (rounds, kh_rounds, kept_cards, swaps, reshuffles))
    check(kh_rounds > 100 and kept_cards > 100 and swaps > 100, 'the random run did not reach the special paths')

if __name__ == '__main__':
    bad = 0
    for name, r in results:
        print(('PASS ' if r == 'OK' else 'FAIL ') + name + ('' if r == 'OK' else '\n      ' + r)); bad += r != 'OK'
    print('\n%d tests, %d failed' % (len(results), bad))
    sys.exit(1 if bad else 0)
