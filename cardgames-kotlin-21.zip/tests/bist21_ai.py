#!/usr/bin/env python3
"""Old and new robot of the 21 game (Python mirror, same formulas as Ai21.kt) and a match harness on the rules model of
bist21_model_test.py. The new robot never looks at hidden cards: it counts the cards that have gone, models the banker and the
other players from what is public, and chooses by expected value.
Run:  python3 tests/bist21_ai.py [rounds]
"""
import random, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from bist21_model_test import Table, total, value, VAL

VALS = [2, 3, 4, 6, 7, 8, 9, 10, 11]
TB = 17            # the banker is modelled as standing on 17 or more (by the players)
KELLY = 0.5        # fraction of the Kelly bet
SIDE_MIN_EV = 0.05
MC_TRIALS = 100
MIN_FINAL = 12     # a player who stands has (almost always) at least this

# ------------------------------------------------------------------ shared maths
def pool_counts(known):
    cnt = {r: 4 for r in range(6, 15)}
    for (_, r) in known:
        if cnt[r] > 0: cnt[r] -= 1
    return cnt

def q_of(cnt):
    q = [0.0] * 12; tot = 0
    for r, c in cnt.items(): q[value(r)] += c; tot += c
    if tot == 0: return [0.0, 0.0] + [1.0 / 9 if v in VALS else 0.0 for v in range(2, 12)]
    return [x / tot for x in q]

def banker_final(q):
    """distribution of the banker's final total when he draws up to TB or more: index 17..21, 22 = burns"""
    d = [0.0] * 23; d[0] = 1.0; res = [0.0] * 23
    for t in range(0, TB):
        if d[t] == 0: continue
        for v in VALS:
            p = d[t] * q[v]; nt = t + v
            if nt >= TB: res[min(nt, 22)] += p
            else: d[nt] += p
    return res

def player_tables(q, res):
    win = lambda t: res[22] + sum(res[k] for k in range(0, t))      # a tie is the banker's
    V = [0.0] * 23; hit = [False] * 23
    for t in range(21, 0, -1):
        stand = 2 * win(t) - 1
        h = sum(q[v] * (-1.0 if t + v > 21 else V[t + v]) for v in VALS)
        V[t] = max(stand, h); hit[t] = h > stand
    return V, hit, win

def player_hit_and_ev(hand, known):
    """(hit?, EV per unit of the hand played optimally from here) for a player holding [hand]"""
    q = q_of(pool_counts(known)); res = banker_final(q); V, hit, win = player_tables(q, res)
    t = total(hand)
    if len(hand) == 1 and hand[0][1] == 14:
        # a second ace makes 21 (two aces), not a burn
        h = sum(q[v] * ((2 * win(21) - 1) if v == 11 else (-1.0 if t + v > 21 else V[t + v])) for v in VALS)
        stand = 2 * win(t) - 1
        return h > stand, max(h, stand)
    if t > 21: return False, -1.0
    return hit[t], V[t]

def opp_dist(n_p, first, known, rng, trials=MC_TRIALS):
    """what the banker believes about the final total of a player who stopped with n_p cards (first card public when [first])"""
    cnt = pool_counts(known)
    if first is not None and cnt[first[1]] > 0: cnt[first[1]] -= 1
    ranks = [r for r in cnt for _ in range(cnt[r])]
    res = [0.0] * 23; got = 0
    for _ in range(trials):
        pool = ranks[:]
        t = 0; ok = True; hand_n = 0
        if first is not None: t = value(first[1]); hand_n = 1
        pre = 0
        while hand_n < n_p:
            if not pool: ok = False; break
            pre = t
            r = pool.pop(rng.randrange(len(pool))); t += value(r); hand_n += 1
        if not ok or t > 21: continue
        if n_p >= 2 and (pre >= TB or t < MIN_FINAL): continue
        res[t] += 1; got += 1
    if got == 0:
        return None
    return [x / got for x in res]

def banker_hits(hand, known, n_p, first, rng):
    t = total(hand)
    if t > 21: return False
    q = q_of(pool_counts(known))
    pd = opp_dist(n_p, first, known, rng)
    if pd is None: return t < TB
    cum = [0.0] * 23; s = 0.0
    for k in range(0, 22): s += pd[k]; cum[k] = s
    W = [0.0] * 23
    for tt in range(21, 0, -1):
        stand = cum[tt]
        h = sum(q[v] * (0.0 if tt + v > 21 else W[tt + v]) for v in VALS)
        W[tt] = max(stand, h)
    if len(hand) == 1 and hand[0][1] == 14:
        h = sum(q[v] * (W[21] if v == 11 else (0.0 if t + v > 21 else W[t + v])) for v in VALS)
        return h > cum[t]
    h = sum(q[v] * (0.0 if t + v > 21 else W[t + v]) for v in VALS)
    return h > cum[t]

def banker_card_value(card_value_t, known, rng, n_p=2):
    q = q_of(pool_counts(known)); pd = opp_dist(n_p, None, known, rng)
    if pd is None: return 0.5
    cum = [0.0] * 23; s = 0.0
    for k in range(0, 22): s += pd[k]; cum[k] = s
    W = [0.0] * 23
    for tt in range(21, 0, -1):
        W[tt] = max(cum[tt], sum(q[v] * (0.0 if tt + v > 21 else W[tt + v]) for v in VALS))
    return W, q

# ------------------------------------------------------------------ policies
def old_policy(rng):
    def bust(hand, seen):
        known = set(seen) | set(hand); t = total(hand); tot = bad = 0
        for s in range(4):
            for r in range(6, 15):
                if (s, r) in known: continue
                tot += 1; bad += t + value(r) > 21
        return 1.0 if tot == 0 else bad / tot
    def f(seat, kind, st):
        if kind == 'hit':
            hand, is_bank, T = st
            return 'h' if bust(hand, T.seen) < (0.5 if is_bank else 0.42) else 's'
        if kind == 'swap': return 'w' if value(st[0][0][1]) <= 3 else 'k'
        if kind == 'show': return '0'
        if kind == 'khabre': return 'y'
        if kind == 'bet':
            mx, T = st; ph = T.live['ph']; m1 = T.mn
            hi = 1.6 if value(ph[0][1]) >= 10 else 1.0
            raw = m1 * (1 + rng.random() * (T.bank / m1 / 4) * hi)
            bet = max(m1, min(mx, int(raw / m1 + 0.5) * m1))
            if T.chips[seat] >= T.bank and ph[0][1] == 14 and rng.random() < 0.4: bet = T.bank
            return bet
        if kind == 'side':
            mxr, T = st; ph = T.live['ph']; mq = T.mn
            half = max(mq, (mxr // 2 // mq) * mq)
            return half if value(ph[0][1]) >= 10 and rng.random() < 0.5 else 0
    return f

def new_policy(rng, use=('hit', 'bet', 'side', 'swap')):
    old = old_policy(rng)
    def f(seat, kind, st):
        if kind == 'hit' and 'hit' in use:
            hand, is_bank, T = st
            known = list(T.seen) + list(hand)
            if is_bank:
                cur = T.cur
                return 'h' if banker_hits(hand, known, cur['n_p'], cur['first'] if T.side else None, rng) else 's'
            return 'h' if player_hit_and_ev(hand, known)[0] else 's'
        if kind == 'bet' and 'bet' in use:
            mx, T = st; ph = T.live['ph']; m1 = T.mn
            ev = player_hit_and_ev([ph[0]], list(T.seen) + [ph[0]])[1]
            if ev <= 0: return m1
            bet = int(KELLY * ev * T.chips[seat] / m1) * m1
            return max(m1, min(mx, bet))
        if kind == 'side' and 'side' in use:
            mxr, T = st; ph = T.live['ph']; mq = T.mn
            ev = player_hit_and_ev([ph[0]], list(T.seen) + [ph[0]])[1]
            if ev < SIDE_MIN_EV: return 0
            a = int(KELLY * ev * T.chips[seat] / mq) * mq
            return max(0, min(mxr, a))
        if kind == 'swap' and 'swap' in use:
            bhand, T = st
            known = list(T.seen) + list(bhand)
            W, q = banker_card_value(None, list(T.seen), rng)
            mine = W[total(bhand)] if total(bhand) <= 21 else 0.0
            avg = sum(q[v] * W[v] for v in VALS)
            return 'w' if mine < avg else 'k'
        return old(seat, kind, st)
    return f

# ------------------------------------------------------------------ match harness
class T2(Table):
    """the model Table, plus what the new robot may see: the number of cards of the player the banker plays with and his public first card"""
    def play(self, p, hand, is_bank, key):
        if is_bank:
            ph = self.live.get('ph')
            self.cur = dict(n_p=len(ph), first=ph[0])
        return Table.play(self, p, hand, is_bank, key)

def experiment(pols, rounds, seed, role, n=5, side=True, deal_all=False, base=1000, mn=50, chips0=20000):
    """profit of seat 2 per round; role 'player': the banker rotates over the other seats, 'banker': seat 2 is the banker every round"""
    rng = random.Random(seed); xs = []
    others = [0, 1, 3, 4]
    for it in range(rounds):
        b = 2 if role == 'banker' else others[it % 4]
        pol = lambda seat, kind, st: pols[seat](seat, kind, st)
        t = T2(n, [chips0] * n, base, mn, side, 3, deal_all, rng, pol)
        before = t.chips[2]; t.round(b); xs.append(t.chips[2] - before)
    m = sum(xs) / len(xs); var = sum((x - m) ** 2 for x in xs) / len(xs)
    return m, (var / len(xs)) ** 0.5

if __name__ == '__main__' and not (len(sys.argv) > 2 and sys.argv[2] == 'iso'):
    R = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    which = sys.argv[2] if len(sys.argv) > 2 else 'all'
    base = [old_policy(random.Random(20 + i)) for i in range(5)]
    configs = [('old (control)', None), ('new: hit', ('hit',)), ('new: bet', ('bet',)), ('new: side', ('side',)), ('new: swap', ('swap',)),
               ('new: all', ('hit', 'bet', 'side', 'swap'))]
    for role in ('player', 'banker'):
        if which not in ('all', role): continue
        for label, use in configs:
            pols = list(base)
            if use: pols[2] = new_policy(random.Random(99), use)
            m, se = experiment(pols, R, 1, role)
            print('%-8s %-16s seat 2 profit per round: %+8.1f  +- %.1f' % (role, label, m, se), flush=True)

def fixed_bets(pol, mn=50):
    """every bet is the minimum and there are no side bets: isolates the play (hit / stand / swap) from the sizing of the bets"""
    def f(seat, kind, st):
        if kind == 'bet': return mn
        if kind == 'side': return 0
        return pol(seat, kind, st)
    return f

def isolated(R, role, use_new, seed=3):
    base = [fixed_bets(old_policy(random.Random(20 + i))) for i in range(5)]
    if use_new: base[2] = fixed_bets(new_policy(random.Random(99), use_new))
    # the new robot's side/bet parts are off in this test (fixed bets); side rule off too
    return experiment(base, R, seed, role, side=False)

if len(sys.argv) > 2 and sys.argv[2] == 'iso':
    R = int(sys.argv[1])
    for role in ('player', 'banker'):
        for label, use in [('old', None), ('new hit', ('hit',)), ('new swap', ('swap',))] if role == 'banker' else [('old', None), ('new hit', ('hit',))]:
            m, se = isolated(R, role, use)
            print('ISO %-7s %-9s profit per hand (units of 50): %+.4f +- %.4f' % (role, label, m / 50, se / 50), flush=True)
