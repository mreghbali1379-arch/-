import com.example.hokm.Bist21AI;
import java.util.*;

/**
 * Plays rounds of 21 (the rules of Bist21.kt after the changes: kept banker card, khabre with a shuffle) with robots of two kinds and measures the profit.
 * OLD = the robot as it was (take a card while the chance to burn is under 42% / 50% for the banker, random bets, swap a kept card worth <= 3).
 * NEW = Bist21AI (expected-value search with card counting).  A "feature mask" turns the new parts on one by one.
 *
 * Build and run (from the project folder):
 *   java -m jdk.compiler/com.sun.tools.javac.Main -d /tmp/out app/src/main/java/com/example/hokm/Bist21AI.java tests/Bist21Sim.java
 *   java -cp /tmp/out Bist21Sim [rounds]
 */
public class Bist21Sim {
    static final int HIT = 1, BET = 2, BHIT = 4, SWAP = 8;
    static final int[] CV = {6, 7, 8, 9, 10, 2, 3, 4, 11};      // value of a card id % 9
    static Random rnd = new Random(12345);
    static int betMode = 0;          // 0 = Bist21AI.bet, 1..5 = variants (see betOf)
    static int theta = 17;           // the banker's take-a-card limit the new player assumes
    static boolean sideOn = false;
    static int SIDE = 16;

    static int val(int id) { return CV[id % 9]; }
    static boolean ace(int id) { return id % 9 == 8; }

    static int total(List<Integer> h) {
        if (h.size() == 2 && ace(h.get(0)) && ace(h.get(1))) return 21;
        int s = 0; for (int c : h) s += val(c); return s;
    }

    static class T {
        int n; long[] chips; int[] flags; long base = 1000, mn = 50; int khMul = 3;
        List<Integer> deck = new ArrayList<>(), seen = new ArrayList<>(), aside = new ArrayList<>();
        long bank; boolean khabre;
        int draw() {
            if (deck.isEmpty()) {
                List<Integer> pool = new ArrayList<>(seen); pool.addAll(aside); seen.clear(); aside.clear();
                Collections.shuffle(pool, rnd); deck.addAll(pool);
            }
            return deck.remove(deck.size() - 1);
        }
        /** counts of the cards the decider has not seen: all minus gone minus his own cards */
        int[] unknown(List<Integer>... mine) {
            int[] u = Bist21AI.fullCounts();
            for (int c : seen) u[Bist21AI.idx(val(c))]--;
            for (List<Integer> h : mine) for (int c : h) u[Bist21AI.idx(val(c))]--;
            return u;
        }
    }

    static double bustOld(T t, List<Integer> hand) {
        int[] u = t.unknown(hand);
        int tot = 0, bad = 0, tt = total(hand);
        for (int i = 0; i < 9; i++) { tot += u[i]; if (tt + Bist21AI.VALS[i] > 21) bad += u[i]; }
        return tot == 0 ? 1.0 : (double) bad / tot;
    }

    static boolean hit(T t, int seat, List<Integer> hand, boolean isBank, int otherCards) {
        int tt = total(hand);
        if (tt >= 21) return false;
        boolean aa = hand.size() == 1 && ace(hand.get(0));
        if (isBank) {
            if ((t.flags[seat] & BHIT) != 0) return Bist21AI.bankerHit(tt, hand.size(), aa, t.unknown(hand), otherCards, 0);
            return bustOld(t, hand) < 0.5;
        }
        if ((t.flags[seat] & HIT) != 0) return Bist21AI.playerHit(tt, hand.size(), aa, t.unknown(hand), theta);
        return bustOld(t, hand) < 0.42;
    }

    static long betOf(T t, int p, List<Integer> ph, long mx) {
        long m1 = t.mn;
        if ((t.flags[p] & BET) != 0) {
            int first = ph.get(0);
            double edge = Bist21AI.firstCardEdge(val(first), t.unknown(ph), theta);
            double f;
            switch (betMode) {
                case 1: f = Math.max(0, Math.min(1, edge / 0.25)); break;
                case 2: f = Math.max(0, Math.min(1, edge / 0.5)); break;
                case 3: f = edge > 0.10 ? 1 : 0; break;
                case 4: f = 0; break;
                case 5: f = edge > 0.05 ? 1 : 0; break;
                case 6: f = edge > 0.0 ? 1 : 0; break;
                case 7: f = edge > 0.20 ? 1 : 0; break;
                default: return Bist21AI.bet(edge, t.chips[p], m1, mx);
            }
            return Math.max(m1, Math.min(mx, m1 + Math.round(f * (mx - m1) / m1) * m1));
        }
        double hi = val(ph.get(0)) >= 10 ? 1.6 : 1.0;
        double raw = m1 * (1 + rnd.nextDouble() * ((double) t.bank / m1 / 4) * hi);
        long bet = Math.max(m1, Math.min(mx, Math.round(raw / m1) * m1));
        if (t.chips[p] >= t.bank && ace(ph.get(0)) && rnd.nextDouble() < 0.4) bet = t.bank;
        return bet;
    }

    // per-seat statistics: [seat][0 = as player, 1 = as banker] -> sum, sum of squares, count
    static double[][][] st;

    static void round(T t, int b) {
        int n = t.n;
        long[] before = t.chips.clone();
        t.deck.clear(); t.seen.clear(); t.aside.clear(); t.khabre = false;
        for (int i = 0; i < 36; i++) t.deck.add(i);
        Collections.shuffle(t.deck, rnd);
        t.bank = t.base; t.chips[b] -= t.base;
        List<Integer> carried = null;
        for (int k = 1; k < n; k++) {
            int p = (b + k) % n;
            if (t.chips[p] < t.mn) continue;
            if (t.bank < t.mn) break;
            long cp = t.chips[p];
            List<Integer> ph = new ArrayList<>(); ph.add(t.draw());
            List<Integer> kept = carried; carried = null;
            List<Integer> bh = kept != null ? kept : new ArrayList<>(Arrays.asList(t.draw()));
            if (kept != null) {
                boolean swap;
                if ((t.flags[b] & SWAP) != 0) swap = Bist21AI.bankerSwap(val(bh.get(0)), t.unknown(bh));
                else swap = val(bh.get(0)) <= 3;
                if (swap) { t.aside.add(bh.get(0)); bh = new ArrayList<>(Arrays.asList(t.draw())); }
            }
            long mx = Math.min(t.bank, t.chips[p]);
            long bet = betOf(t, p, ph, mx);
            List<Integer> sq = new ArrayList<>(); List<Long> sa = new ArrayList<>();
            if (sideOn) {
                int c0 = ph.get(0);
                for (int q = 0; q < n; q++) {
                    long mq = t.mn;
                    if (q == p || q == b || t.chips[q] < mq) continue;
                    long used = 0; for (long x : sa) used += x;
                    long rem = t.bank - bet - used;
                    long mxr = (Math.min(bet, Math.min(t.chips[q], rem)) / mq) * mq;
                    if (mxr < mq) continue;
                    long half = Math.max(mq, (mxr / 2 / mq) * mq), a2 = 0;
                    if ((t.flags[q] & SIDE) != 0) {
                        int[] u = Bist21AI.fullCounts();
                        for (int c : t.seen) u[Bist21AI.idx(val(c))]--;
                        u[Bist21AI.idx(val(c0))]--;
                        a2 = Bist21AI.sideBet(val(c0), u, t.chips[q], mq, mxr);
                    } else if (val(c0) >= 10 && rnd.nextDouble() < 0.5) a2 = half;
                    if (a2 > 0) { sq.add(q); sa.add(a2); }
                }
            }
            // the player plays
            while (hit(t, p, ph, false, 0)) ph.add(t.draw());
            int pt = total(ph);
            boolean win;
            if (pt > 21) { win = false; carried = bh; }
            else {
                while (hit(t, b, bh, true, ph.size())) bh.add(t.draw());
                int bt = total(bh);
                win = bt > 21 || pt > bt;
                t.seen.addAll(bh);
            }
            t.seen.addAll(ph);
            if (win) { t.chips[p] += bet; t.bank -= bet; } else { t.chips[p] -= bet; t.bank += bet; }
            for (int i = 0; i < sq.size(); i++) {
                int q = sq.get(i); long a2 = sa.get(i);
                if (win) { t.chips[q] += a2; t.bank -= a2; } else { t.chips[q] -= a2; t.bank += a2; }
                double dq = win ? a2 : -a2;
                st[q][2][0] += dq; st[q][2][1] += dq * dq; st[q][2][2] += 1;
            }
            double d = t.chips[p] - cp;
            st[p][0][0] += d; st[p][0][1] += d * d; st[p][0][2] += 1;
            if (t.bank <= 0) break;
            if (!t.khabre && t.bank >= t.base * t.khMul && k < n - 1) {
                t.khabre = true;
                List<Integer> pool = new ArrayList<>(t.deck); pool.addAll(t.seen); pool.addAll(t.aside);
                t.seen.clear(); t.aside.clear(); t.deck.clear(); Collections.shuffle(pool, rnd); t.deck.addAll(pool);
            }
        }
        t.chips[b] += t.bank; t.bank = 0;
        double d = t.chips[b] - before[b];
        st[b][1][0] += d; st[b][1][1] += d * d; st[b][1][2] += 1;
    }

    static void report(String name, int seat, int rounds) {
        double[] p = st[seat][0], b = st[seat][1];
        double mp = p[0] / p[2], sp = Math.sqrt(Math.max(0, p[1] / p[2] - mp * mp) / p[2]);
        double mb = b[0] / b[2], sb = Math.sqrt(Math.max(0, b[1] / b[2] - mb * mb) / b[2]);
        double[] sd = st[seat][2];
        if (sd[2] > 0) { double ms = sd[0] / sd[2], ss = Math.sqrt(Math.max(0, sd[1] / sd[2] - ms * ms) / sd[2]); System.out.printf("%-34s side bets %8.1f +- %5.1f per bet (%d bets)%n", "", ms, 1.96 * ss, (long) sd[2]); }
        System.out.printf("%-34s as player %8.1f +- %5.1f (%d hands)   as banker %8.1f +- %6.1f (%d rounds)%n", name, mp, 1.96 * sp, (long) p[2], mb, 1.96 * sb, (long) b[2]);
    }

    static void run(String name, int seat0Flags, int othersFlags, int players, int rounds, long seed) {
        rnd = new Random(seed);
        T t = new T(); t.n = players; t.chips = new long[players]; t.flags = new int[players];
        Arrays.fill(t.chips, 100000000L);
        for (int i = 0; i < players; i++) t.flags[i] = i == 0 ? seat0Flags : othersFlags;
        st = new double[players][3][3];
        for (int r = 0; r < rounds; r++) round(t, r % players);
        report(name, 0, rounds);
    }

    public static void main(String[] a) {
        String what = a.length > 0 ? a[0] : "basic";
        int rounds = a.length > 1 ? Integer.parseInt(a[1]) : 40000;
        int players = 4;
        int ALL = HIT | BET | BHIT | SWAP;
        if (what.equals("basic")) {
            System.out.println("profit per hand in chips (bank 1000, smallest bet 50), seat 0 against three OLD robots, " + rounds + " rounds each");
            run("OLD (control)", 0, 0, players, rounds, 1);
            run("NEW take-a-card only", HIT, 0, players, rounds, 1);
            run("NEW bets only", BET, 0, players, rounds, 1);
            run("NEW banker play only", BHIT, 0, players, rounds, 1);
            run("NEW banker swap only", SWAP, 0, players, rounds, 1);
            run("NEW all", ALL, 0, players, rounds, 1);
            System.out.println("\nall robots NEW (stability check)");
            run("NEW all vs NEW all", ALL, ALL, players, rounds / 2, 2);
        } else if (what.equals("bets")) {
            System.out.println("bet size rules, new bets only, " + rounds + " rounds each");
            String[] nm = {"half Kelly (AI.bet)", "proportional edge/0.25", "proportional edge/0.5", "max when edge>0.10", "always smallest", "max when edge>0.05", "max when edge>0", "max when edge>0.20"};
            int[] modes = {0, 1, 2, 3, 4, 5, 6, 7};
            for (int m : modes) { betMode = m; run(nm[m], BET, 0, players, rounds, 7); }
        } else if (what.equals("theta")) {
            System.out.println("what the new player assumes about the banker (OLD bankers really stand around 15), bets+take-a-card, " + rounds + " rounds each");
            for (int th : new int[]{17, 16, 15, 14}) { theta = th; run("assumed banker limit " + th, BET | HIT, 0, players, rounds, 9); }
        } else if (what.equals("side")) {
            sideOn = true;
            System.out.println("side bets (rule on), seat 0 robot, others OLD, " + rounds + " rounds each");
            run("OLD side bets", 0, 0, players, rounds, 5);
            run("NEW side bets", SIDE, 0, players, rounds, 5);
        }
    }
}
