#!/usr/bin/env python3
"""Prototype + measurement of the 21 robot.
old bot : hit while P(bust on the next card) < 0.42 (player) / 0.5 (banker), counting the cards that have gone
new bot : counts cards (pool = what is not seen and not in my hand) and decides by expectimax:
          player  : stand/hit by the exact win probability against the banker's final-total distribution computed from the pool
          banker  : stand/hit by the win probability against the distribution of what a player who stood with n cards holds
Rules (as in the app): 36 cards 6..A, J=2 Q=3 K=4 A=11, exactly two aces = 21, over 21 burns, a tie goes to the banker.
"""
import random, sys, itertools, functools
RANKS = list(range(6, 15))
def val(r): return {14: 11, 13: 4, 12: 3, 11: 2}.get(r, r)
VALS = [val(r) for r in RANKS]            # index 0..8 -> value
ACE = 8                                   # index of the ace

def total(h):
    if len(h) == 2 and h[0] == 14 and h[1] == 14: return 21
    return sum(val(r) for r in h)

def nxt(t, n, ace1, i):
    """state after drawing rank index i: (t, n, ace1) with ace1 = the hand is exactly one ace"""
    if n == 1 and ace1 and i == ACE: return 21, 2, False
    return t + VALS[i], n + 1, (n == 0 and i == ACE)

# ------------------------------------------------------------------ the old bot
def old_bust(h, seen):
    known = list(seen) + list(h)
    cnt = {r: 4 for r in RANKS}
    for r in known: cnt[r] -= 1
    tot = sum(max(0, c) for c in cnt.values()); t = total(h)
    bad = sum(max(0, cnt[r]) for r in RANKS if t + val(r) > 21)
    return 1.0 if tot == 0 else bad / tot
def old_hit(h, seen, is_bank, np_=None): return old_bust(h, seen) < (0.5 if is_bank else 0.42)

# ------------------------------------------------------------------ the new bot
def pool_of(seen, hand):
    p = [4] * 9
    for r in list(seen) + list(hand):
        p[r - 6] -= 1
    return tuple(max(0, x) for x in p)

def take(pool, i):
    l = list(pool); l[i] -= 1; return tuple(l)

BANKER_MODEL_STAND = 17          # how the player's model assumes a banker plays

@functools.lru_cache(maxsize=None)
def bank_dist(t, n, ace1, pool):
    """distribution of the banker's final total (index 0..21, 22 = burned) from state, drawing from pool, standing on >= BANKER_MODEL_STAND"""
    out = [0.0] * 23
    if t > 21: out[22] = 1.0; return tuple(out)
    if t >= BANKER_MODEL_STAND or sum(pool) == 0: out[t] = 1.0; return tuple(out)
    N = sum(pool)
    for i in range(9):
        if pool[i]:
            w = pool[i] / N; t2, n2, a2 = nxt(t, n, ace1, i); d = bank_dist(t2, n2, a2, take(pool, i))
            for k in range(23): out[k] += w * d[k]
    return tuple(out)

def p_stand(t, bd):
    """win probability when standing on t against the banker distribution (ties go to the banker)"""
    return bd[22] + sum(bd[:t])

def player_value(t, n, ace1, pool, bd, memo):
    key = (t, n, ace1, pool)
    if key in memo: return memo[key]
    st = p_stand(t, bd)
    if t >= 21 or sum(pool) == 0: memo[key] = (st, False); return memo[key]
    N = sum(pool); hit = 0.0
    for i in range(9):
        if pool[i]:
            t2, n2, a2 = nxt(t, n, ace1, i)
            if t2 <= 21: hit += pool[i] / N * player_value(t2, n2, a2, take(pool, i), bd, memo)[0]
    r = (hit, True) if hit > st + 1e-12 else (st, False)
    memo[key] = r; return r

def new_player_hit(h, seen):
    pool = pool_of(seen, h)
    bd = bank_dist(0, 0, False, pool)
    t, n, a1 = 0, 0, False
    for r in h: t, n, a1 = nxt(t, n, a1, r - 6)
    return player_value(t, n, a1, pool, bd, {})[1]

def player_win_prob(h, seen):
    pool = pool_of(seen, h)
    bd = bank_dist(0, 0, False, pool)
    t, n, a1 = 0, 0, False
    for r in h: t, n, a1 = nxt(t, n, a1, r - 6)
    return player_value(t, n, a1, pool, bd, {})[0]

# what a player who stood with n cards holds (filled by the simulation, see main)
PLAYER_D = {2: None, 3: None, 4: None, 5: None}
def default_D():
    d = [0.0] * 22
    for t in range(14, 22): d[t] = 1.0 / 8
    return d

def new_bank_hit(h, seen, np_, other_known=()):
    D = PLAYER_D.get(min(5, max(2, np_))) or default_D()
    pool = pool_of(seen, h)
    # P(player total <= x) for the player who stood
    cum = [0.0] * 23; s = 0.0
    for x in range(22): s += D[x]; cum[x] = s
    tot = s if s > 0 else 1.0
    memo = {}
    def stand(t): return cum[t] / tot if t <= 21 else 0.0
    def val_(t, n, a1, pl):
        key = (t, n, a1, pl)
        if key in memo: return memo[key]
        st = stand(t)
        if t >= 21 or sum(pl) == 0: memo[key] = (st, False); return memo[key]
        N = sum(pl); hit = 0.0
        for i in range(9):
            if pl[i]:
                t2, n2, a2 = nxt(t, n, a1, i)
                if t2 <= 21: hit += pl[i] / N * val_(t2, n2, a2, take(pl, i))[0]
        r = (hit, True) if hit > st + 1e-12 else (st, False)
        memo[key] = r; return r
    t, n, a1 = 0, 0, False
    for r in h: t, n, a1 = nxt(t, n, a1, r - 6)
    return val_(t, n, a1, pool)[1]

# ------------------------------------------------------------------ the simulator
class Sim:
    def __init__(self, rng, player_ai, banker_ai, nplayers=3, collect=None):
        self.rng, self.pa, self.ba, self.np, self.collect = rng, player_ai, banker_ai, nplayers, collect

    def round(self, stats):
        rng = self.rng
        deck = [r for r in RANKS for _ in range(4)]; rng.shuffle(deck)
        seen = []; carried = None
        def draw():
            nonlocal deck, seen
            if not deck:
                deck = list(seen); seen = []; rng.shuffle(deck)
            return deck.pop()
        for k in range(self.np):
            ph = [draw()]
            bh = carried if carried is not None else [draw()]; carried = None
            # the player
            while True:
                t = total(ph)
                if t > 21: break
                hit = (new_player_hit(ph, seen) if self.pa == 'new' else old_hit(ph, seen, False))
                if not hit: break
                ph.append(draw())
            pt = total(ph)
            if pt > 21:
                carried = bh; res = -1
            else:
                if self.collect is not None: self.collect.setdefault(min(5, len(ph)), []).append(pt)
                while True:
                    t = total(bh)
                    if t > 21: break
                    hit = (new_bank_hit(bh, seen, len(ph)) if self.ba == 'new' else old_hit(bh, seen, True))
                    if not hit: break
                    bh.append(draw())
                bt = total(bh)
                res = 1 if (bt > 21 or pt > bt) else -1
                seen.extend(bh)
            seen.extend(ph)
            stats['n'] += 1; stats['sum'] += res
            if res > 0: stats['win'] += 1
        bank_dist.cache_clear()

def run(pa, ba, rounds, seed, collect=None):
    rng = random.Random(seed); st = dict(n=0, sum=0, win=0)
    s = Sim(rng, pa, ba, 3, collect)
    for _ in range(rounds): s.round(st)
    return st['sum'] / st['n'], st['win'] / st['n'], st['n']

def collect_D(R, S):
    global BANKER_MODEL_STAND
    BANKER_MODEL_STAND = S; bank_dist.cache_clear()
    col = {}
    run('new', 'old', R, 1, col)
    for k in (2, 3, 4, 5):
        xs = col.get(k, []); d = [0.0] * 22
        for x in xs: d[x] += 1
        t = sum(d) or 1
        PLAYER_D[k] = [x / t for x in d]

if __name__ == '__main__':
    import json
    R = int(sys.argv[1]); out = open(sys.argv[2], 'a')
    collect_D(4000, 16)
    for (pa, ba, S) in [('old', 'old', 16), ('new', 'old', 15), ('new', 'old', 16), ('new', 'old', 17), ('old', 'new', 16), ('new', 'new', 15), ('new', 'new', 16), ('new', 'new', 17)]:
        BANKER_MODEL_STAND = S; bank_dist.cache_clear()
        ev, wr, n = run(pa, ba, R, 5)
        out.write('player=%s banker=%s model-stand=%d : player EV %+.4f (se %.4f) win rate %.4f (%d hands)\n' % (pa, ba, S, ev, (1 - ev * ev) ** 0.5 / n ** 0.5, wr, n)); out.flush()
