#!/usr/bin/env python3
"""NOTE: superseded by bist21_sim.cpp (real bank and bets, and the exact robot Ai21.kt). This file is the first, simpler study (thresholds, ace bets).

21 game: the robots.  Same rules as Bist21.kt (36 cards, J,Q,K = 2,3,4, 6..10, ace 11, two aces = 21 only with two cards, burn over 21,
a tie goes to the banker).  A round = one banker, P players, one fresh deck; the player gets ONE card, bets, then decides on more cards, then the banker plays
(unless the player burned: then the banker keeps his unrevealed card for the next player).  Cards of finished hands are seen by everybody.

OLD robot (the code in Bist21.kt):  hit while the chance that the next card burns is below 0.42 (player) / 0.5 (banker).
NEW robot: Monte-Carlo expected value of "stand" against "one more card, then go on by the threshold rule", with card counting, where
 - the player models the banker as the robot banker (he does not see the banker's hidden card, it is drawn from the unseen cards),
 - the banker does not see the player's cards, only how many there are: he weighs the possible hands by how likely the player would have stopped there.
Usage:  python3 tests/bist21_bot_sim.py [rounds]
"""
import random, math, sys

VALS = [2, 3, 4, 6, 7, 8, 9, 10, 11]
IDX = {v: i for i, v in enumerate(VALS)}
def total(h):
    if len(h) == 2 and h[0] == 11 and h[1] == 11: return 21
    return sum(h)
def fresh(): return [v for v in VALS for _ in range(4)]

def counts_of(known):
    c = [4] * 9
    for v in known: c[IDX[v]] -= 1
    return c

def bust_c(t, c):
    tot = sum(c)
    if tot == 0: return 1.0
    return sum(c[i] for i, v in enumerate(VALS) if t + v > 21) / tot

# ---------------------------------------------------------------- the OLD robot
def old_player_hit(hand, seen, rng): return total(hand) < 21 and bust_c(total(hand), counts_of(seen + hand)) < 0.42
def old_banker_hit(hand, seen, kp, rng, big=False): return total(hand) < 21 and bust_c(total(hand), counts_of(seen + hand)) < 0.5

# ---------------------------------------------------------------- the NEW robot
N_MC = 120
PLAYER_CONT = 15           # after one more card the player goes on by "stand from this total"
BANKER_CONT = 15
BANKER_THR = 0             # 0: the player models the old robot banker; 16: the new banker (hits below 16)

def banker_robot_play(bh, seen, perm, idx):
    """the robot banker (old rule) plays on from perm[idx:]; returns (total, next index)"""
    b = list(bh)
    if BANKER_THR:        # the new banker: hit while below the threshold
        while total(b) < BANKER_THR and idx < len(perm):
            b.append(perm[idx]); idx += 1
        return total(b), idx
    while total(b) < 21 and idx < len(perm) and bust_c(total(b), counts_of(seen + b)) < 0.5:
        b.append(perm[idx]); idx += 1
    return total(b), idx

def new_player_hit(hand, seen, rng, n=N_MC):
    t = total(hand)
    if t >= 21: return False
    pool = fresh()
    for v in seen + hand: pool.remove(v)
    if len(pool) < 4: return old_player_hit(hand, seen, rng)
    d = 0.0
    for _ in range(n):
        perm = rng.sample(pool, min(len(pool), 12))
        bt, _ = banker_robot_play([perm[0]], seen, perm, 1)                 # stand now
        s = 1 if (bt > 21 or t > bt) else -1
        h = hand + [perm[1]]; idx = 2                                         # one more card, then the threshold rule
        while total(h) < PLAYER_CONT and idx < len(perm): h.append(perm[idx]); idx += 1
        ht = total(h)
        if ht > 21: x = -1
        else:
            bt, _ = banker_robot_play([perm[0]], seen, perm, idx)
            x = 1 if (bt > 21 or ht > bt) else -1
        d += x - s
    return d > 0

def player_weight(ph, seen):
    """how likely a robot/human player is to have stopped with these cards: hit at every earlier state, stand at the end (soft, humans make mistakes)"""
    w = 1.0
    for k in range(1, len(ph) + 1):
        pre = ph[:k]
        if total(pre) > 21: return 0.0
        wants = old_player_hit(pre, seen, None)
        if k < len(ph): w *= 0.9 if wants else 0.1
        else: w *= 0.1 if wants else 0.9
    return w

def new_banker_hit(hand, seen, kp, rng, n=N_MC):
    tb = total(hand)
    if tb >= 21: return False
    pool = fresh()
    for v in seen + hand: pool.remove(v)
    if len(pool) < kp + 3: return old_banker_hit(hand, seen, kp, rng)
    ws = es = eh = 0.0
    for _ in range(n):
        perm = rng.sample(pool, min(len(pool), 12))
        ph = perm[:kp]
        tp = total(ph)
        if tp > 21: continue
        w = player_weight(ph, seen)
        if w == 0: continue
        es += w * (1 if tb >= tp else -1)
        b = hand + [perm[kp]]; idx = kp + 1
        while total(b) < BANKER_CONT and idx < len(perm): b.append(perm[idx]); idx += 1
        bt = total(b)
        eh += w * (1 if (bt <= 21 and bt >= tp) else -1)
        ws += w
    return ws > 0 and eh > es

# ---------------------------------------------------------------- a round
def play_hand(player_hit, banker_hit, deck, seen, rng, kept):
    ph = [deck.pop()]
    bh = kept if kept else [deck.pop()]
    while total(ph) < 21 and deck and player_hit(ph, seen, rng):
        ph.append(deck.pop())
    tp = total(ph)
    if tp > 21:
        seen.extend(ph)
        return -1, bh
    while total(bh) < 21 and deck and banker_hit(bh, seen, len(ph), rng):
        bh.append(deck.pop())
    tb = total(bh)
    seen.extend(ph); seen.extend(bh)
    return (1 if (tb > 21 or tp > tb) else -1), None

def run_rounds(rounds, P, pl_hit, bk_hit, seed):
    rng = random.Random(seed); mc = random.Random(seed + 999)
    sp = sp2 = 0.0; n = 0
    for _ in range(rounds):
        deck = fresh(); rng.shuffle(deck); seen = []; kept = None
        for _p in range(P):
            if len(deck) < 12: break
            r, kept = play_hand(pl_hit, bk_hit, deck, seen, mc, kept)
            sp += r; sp2 += r * r; n += 1
    m = sp / n
    return m, math.sqrt(max(0, sp2 / n - m * m) / n), n

# ---------------------------------------------------------------- the FINAL robot (what is built into Bist21.kt)
# The Monte-Carlo robot above (new_player_hit / new_banker_hit) was measured too: counting and one-step look-ahead gave nothing beyond these simple rules
# (a coordinate search over counting thresholds improved less than 0.004), so the app uses the rules, which are fast and easy to check.
FINAL_THR = 16
def final_player_hit(hand, seen, rng): return total(hand) < FINAL_THR
BANKER_BIG_THR = 18         # against a big bet (an ace first card is likely) the banker plays on to 18
def final_banker_hit(hand, seen, kp, rng, big=False): return total(hand) < (BANKER_BIG_THR if big else FINAL_THR)
def final_bet_mult(first, seen): return 8 if first == 11 else 1         # an ace as first card is the only profitable one: bet up to 8 times the minimum
def final_swap(card): return card <= 7                                    # a kept unrevealed banker card of value 2,3,4,6,7 is put aside for one other card
def old_swap(card): return card <= 3
def flat_bet(first, seen): return 1

def play_round(P, pl_hit, bk_hit, bet_mult, swap, deck, seen, rng):
    """one banker round with the kept-card rule; returns (player chips won, number of hands)"""
    kept = None; won = 0.0; n = 0; aside = []
    for _p in range(P):
        if len(deck) < 12: break
        ph = [deck.pop()]
        if kept is not None:
            if swap(kept[0]): aside.append(kept[0]); bh = [deck.pop()]
            else: bh = kept
        else: bh = [deck.pop()]
        kept = None
        m = bet_mult(ph[0], seen)
        while total(ph) < 21 and deck and pl_hit(ph, seen, rng): ph.append(deck.pop())
        tp = total(ph)
        if tp > 21:
            seen.extend(ph); won -= m; kept = bh; n += 1; continue
        while total(bh) < 21 and deck and bk_hit(bh, seen, len(ph), rng, m >= 4): bh.append(deck.pop())
        tb = total(bh); seen.extend(ph); seen.extend(bh)
        won += m if (tb > 21 or tp > tb) else -m; n += 1
    return won, n

def bench(rounds, P, pl_hit, bk_hit, bet_mult, swap, seed=11):
    rng = random.Random(seed); mc = random.Random(seed + 999)
    xs = []
    for _ in range(rounds):
        deck = fresh(); rng.shuffle(deck)
        w, n = play_round(P, pl_hit, bk_hit, bet_mult, swap, deck, [], mc)
        xs.append((w, n))
    tw = sum(w for w, n in xs); tn = sum(n for w, n in xs)
    m = tw / tn
    var = sum((w - m * n) ** 2 for w, n in xs) / max(1, len(xs)) / (tn / len(xs)) ** 2 / len(xs)
    return m, math.sqrt(var)

if __name__ == '__main__':
    rounds = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
    P = 4
    print('chips won by the PLAYER per hand (min bet = 1), %d rounds of %d players, the same deals in every line' % (rounds, P))
    print('  old = hit while the chance to burn < 0.42 (player) / 0.5 (banker), random bets, swap a kept card of value <= 3')
    print('  new = hit below %d (both), ace first card -> bet 8x the minimum, banker plays on to %d against a big bet, swap a kept card of value <= 7' % (FINAL_THR, BANKER_BIG_THR))
    old = dict(pl=old_player_hit, bk=old_banker_hit, bet=flat_bet, sw=old_swap)
    new = dict(pl=final_player_hit, bk=final_banker_hit, bet=final_bet_mult, sw=final_swap)
    rows = [('old players vs old banker', old['pl'], old['bk'], flat_bet, old['sw']),
            ('NEW players vs old banker (play only)', new['pl'], old['bk'], flat_bet, old['sw']),
            ('NEW players vs old banker (+ aces bet)', new['pl'], old['bk'], new['bet'], old['sw']),
            ('old players vs NEW banker', old['pl'], new['bk'], flat_bet, new['sw']),
            ('old players vs NEW banker (swap rule only)', old['pl'], old['bk'], flat_bet, new['sw']),
            ('NEW players vs NEW banker', new['pl'], new['bk'], new['bet'], new['sw'])]
    for name, pl, bk, bt, sw in rows:
        m, se = bench(rounds, P, pl, bk, bt, sw)
        print('  %-44s %+.4f +- %.4f' % (name, m, se), flush=True)
