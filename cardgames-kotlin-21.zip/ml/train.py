#!/usr/bin/env python3
"""Trains the 4-player Hokm policy net on the data of `hokm gen` (numpy only) and writes the HKN1 weight file.

record = 282 u8 binary features | 5 f32 dense | u64 legal mask | 52 f32 target   (518 bytes, little endian)
net    = sparse binary+dense input -> H1 relu -> H2 relu -> 52 logits (masked softmax over the legal cards)
file   = "HKN1", int32 NB, ND, H1, H2, 52, then float32: W1[(NB+ND)*H1], b1, W2[H1*H2], b2, W3[H2*52], b3 (row-major, input-major)
"""
import sys, struct, time, argparse
import numpy as np

NB, ND = 282, 5
REC = NB + ND * 4 + 8 + 52 * 4

def load(paths):
    X, D, M, T = [], [], [], []
    for p in paths:
        raw = np.fromfile(p, dtype=np.uint8)
        n = raw.size // REC
        raw = raw[: n * REC].reshape(n, REC)
        X.append(raw[:, :NB].astype(np.float32))
        D.append(np.ascontiguousarray(raw[:, NB:NB + ND * 4]).view('<f4').reshape(n, ND))
        m = np.ascontiguousarray(raw[:, NB + ND * 4:NB + ND * 4 + 8]).view('<u8').reshape(n)
        M.append(((m[:, None] >> np.arange(52, dtype=np.uint64)[None, :]) & 1).astype(np.float32))
        T.append(np.ascontiguousarray(raw[:, NB + ND * 4 + 8:]).view('<f4').reshape(n, 52))
    return np.concatenate(X), np.concatenate(D), np.concatenate(M), np.concatenate(T)

def init(H1, H2, rng):
    def he(i, o): return (rng.standard_normal((i, o)) * np.sqrt(2.0 / i)).astype(np.float32)
    return {'W1': he(NB + ND, H1), 'b1': np.zeros(H1, np.float32), 'W2': he(H1, H2), 'b2': np.zeros(H2, np.float32),
            'W3': (he(H2, 52) * 0.3), 'b3': np.zeros(52, np.float32)}

def forward(P, X):
    z1 = X @ P['W1'] + P['b1']; h1 = np.maximum(z1, 0)
    z2 = h1 @ P['W2'] + P['b2']; h2 = np.maximum(z2, 0)
    return z1, h1, z2, h2, h2 @ P['W3'] + P['b3']

def masked_softmax(z, mask):
    z = np.where(mask > 0, z, -1e9)
    z = z - z.max(1, keepdims=True)
    e = np.exp(z) * mask
    return e / e.sum(1, keepdims=True)

def evaluate(P, X, M, T):
    out = []
    for i in range(0, len(X), 4096):
        out.append(forward(P, X[i:i + 4096])[4])
    z = np.concatenate(out)
    p = masked_softmax(z, M)
    ce = -(T * np.log(p + 1e-9)).sum(1).mean()
    top1 = (np.argmax(np.where(M > 0, z, -1e9), 1) == np.argmax(T, 1)).mean()
    # mass the net puts on the teacher's best card group
    return ce, top1

def save(P, path, H1, H2):
    with open(path, 'wb') as f:
        f.write(b'HKN1'); f.write(struct.pack('<5i', NB, ND, H1, H2, 52))
        for k in ['W1', 'b1', 'W2', 'b2', 'W3', 'b3']:
            f.write(np.ascontiguousarray(P[k], dtype='<f4').tobytes())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('data', nargs='+'); ap.add_argument('--out', default='hokm4_policy.bin')
    ap.add_argument('--h1', type=int, default=128); ap.add_argument('--h2', type=int, default=64)
    ap.add_argument('--epochs', type=int, default=30); ap.add_argument('--bs', type=int, default=256)
    ap.add_argument('--lr', type=float, default=2e-3); ap.add_argument('--wd', type=float, default=1e-6)
    ap.add_argument('--init', default=None)
    a = ap.parse_args()
    rng = np.random.default_rng(3)
    X, D, M, T = load(a.data)
    X = np.concatenate([X, D], 1)
    n = len(X); nv = min(20000, n // 10)
    perm = rng.permutation(n); vi, ti = perm[:nv], perm[nv:]
    Xv, Mv, Tv = X[vi], M[vi], T[vi]; Xt, Mt, Tt = X[ti], M[ti], T[ti]
    print(f'{n} samples, {len(ti)} train, {nv} validation', flush=True)
    P = init(a.h1, a.h2, rng)
    m = {k: np.zeros_like(v) for k, v in P.items()}; v2 = {k: np.zeros_like(v) for k, v in P.items()}
    step = 0; steps_total = a.epochs * (len(ti) // a.bs)
    t0 = time.time()
    for ep in range(a.epochs):
        idx = rng.permutation(len(ti))
        for b in range(0, len(idx) - a.bs + 1, a.bs):
            j = idx[b:b + a.bs]
            x, mk, tg = Xt[j], Mt[j], Tt[j]
            z1, h1, z2, h2, z3 = forward(P, x)
            p = masked_softmax(z3, mk)
            g3 = (p - tg) / a.bs
            G = {'W3': h2.T @ g3, 'b3': g3.sum(0)}
            gh2 = g3 @ P['W3'].T; gz2 = gh2 * (z2 > 0)
            G['W2'] = h1.T @ gz2; G['b2'] = gz2.sum(0)
            gh1 = gz2 @ P['W2'].T; gz1 = gh1 * (z1 > 0)
            G['W1'] = x.T @ gz1; G['b1'] = gz1.sum(0)
            step += 1
            lr = a.lr * 0.5 * (1 + np.cos(np.pi * step / steps_total))
            for k in P:
                g = G[k] + a.wd * P[k]
                m[k] = 0.9 * m[k] + 0.1 * g; v2[k] = 0.999 * v2[k] + 0.001 * g * g
                P[k] -= lr * (m[k] / (1 - 0.9 ** step)) / (np.sqrt(v2[k] / (1 - 0.999 ** step)) + 1e-8)
        ce, t1 = evaluate(P, Xv, Mv, Tv)
        print(f'epoch {ep + 1:2d}  val CE {ce:.4f}  val top1 {t1:.4f}  {time.time() - t0:.0f}s', flush=True)
    save(P, a.out, a.h1, a.h2)
    print('saved', a.out)

if __name__ == '__main__':
    main()
