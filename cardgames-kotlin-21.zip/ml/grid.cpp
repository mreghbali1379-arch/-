#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
struct Rng { u64 a, b; Rng(u64 s = 1) { a = sm(s); b = sm(a); } static u64 sm(u64 x) { x += 0x9E3779B97F4A7C15ULL; x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL; x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL; return x ^ (x >> 31); }
    u64 next() { u64 s1 = a, s0 = b; a = s0; s1 ^= s1 << 23; b = s1 ^ s0 ^ (s1 >> 18) ^ (s0 >> 5); return b + s0; }
    double uni() { return (next() >> 11) * (1.0 / 9007199254740992.0); } int below(int n) { return (int)(uni() * n); } };
static inline int val(int r) { return r == 14 ? 11 : r == 13 ? 4 : r == 12 ? 3 : r == 11 ? 2 : r; }
int main() {
    Rng g(5); long N = 300000;
    printf("player EV (rows: player stands at >= Tp) vs banker stands at >= Tb (columns), infinite deck, 2-ace rule ignored\n     ");
    for (int Tb = 13; Tb <= 19; Tb++) printf("  Tb=%d ", Tb); printf("\n");
    for (int Tp = 12; Tp <= 19; Tp++) {
        printf("Tp=%d", Tp);
        for (int Tb = 13; Tb <= 19; Tb++) {
            double s = 0;
            for (long i = 0; i < N; i++) {
                int ranks[9] = {6, 7, 8, 9, 10, 11, 12, 13, 14};
                auto dr = [&]() { return val(ranks[g.below(9)]); };
                int p = dr(); while (p < Tp) p += dr();
                if (p > 21) { s -= 1; continue; }
                int b = dr(); while (b < Tb) b += dr();
                s += (b > 21 || p > b) ? 1 : -1;
            }
            printf(" %+.3f", s / N);
        }
        printf("\n");
    }
}
