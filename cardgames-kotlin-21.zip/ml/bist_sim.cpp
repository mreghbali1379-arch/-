// Strength lab for the 21 robot. Rank counts only (suits do not matter in this game).
// old = the logic of Bist21.kt before (hit while the burn chance < 0.42 as player / < 0.5 as banker)
// mc  = Monte-Carlo expected value with card counting (what Brain21 will do)
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
struct Rng { u64 a, b; Rng(u64 s = 1) { a = sm(s); b = sm(a); } static u64 sm(u64 x) { x += 0x9E3779B97F4A7C15ULL; x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL; x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL; return x ^ (x >> 31); }
    u64 next() { u64 s1 = a, s0 = b; a = s0; s1 ^= s1 << 23; b = s1 ^ s0 ^ (s1 >> 18) ^ (s0 >> 5); return b + s0; }
    double uni() { return (next() >> 11) * (1.0 / 9007199254740992.0); } int below(int n) { return (int)(uni() * n); } };

static inline int val(int r) { return r == 14 ? 11 : r == 13 ? 4 : r == 12 ? 3 : r == 11 ? 2 : r; }
struct Hand { int sum = 0, n = 0, aces = 0;
    void add(int r) { sum += val(r); n++; if (r == 14) aces++; }
    int total() const { return (n == 2 && aces == 2) ? 21 : sum; } };
struct Pool { int c[15] = {0}; int n = 0;
    void full() { for (int r = 6; r <= 14; r++) c[r] = 4; n = 36; }
    void rem(int r) { c[r]--; n--; }
    int draw(Rng& g) { int k = g.below(n); for (int r = 6; r <= 14; r++) { if (k < c[r]) { c[r]--; n--; return r; } k -= c[r]; } return 14; } };

static inline bool pwins(int p, int b) { return p <= 21 && (b > 21 || p > b); }

// banker plays from hand h until total >= T (stands on 21 or more)
static int bankPlay(Hand h, Pool& pl, int T, Rng& g) { while (h.total() < T && h.total() <= 21 && pl.n > 0) h.add(pl.draw(g)); return h.total(); }

// -------- old logic
static double burnProb(const Hand& h, const Pool& unseen) {
    int t = h.total(), bad = 0; for (int r = 6; r <= 14; r++) if (t + val(r) > 21) bad += unseen.c[r];
    return unseen.n ? (double)bad / unseen.n : 1.0;
}
static bool oldHit(const Hand& h, const Pool& unseen, bool bank) { return burnProb(h, unseen) < (bank ? 0.5 : 0.42); }

// -------- Monte-Carlo strategies
struct Mc { int N = 300; int Tc = 15; int TbModel = 16; int TcBank = 17; int TpLo = 14; int TpSpan = 5; };

// player: is it better to take one more card (then follow the continuation rule) than to stand? unseen = pool without the player's cards
static bool mcPlayerHit(const Hand& h, const Pool& unseen, const Mc& m, Rng& g) {
    if (h.total() >= 21) return false;
    double ws = 0, wh = 0;
    for (int i = 0; i < m.N; i++) {
        Pool p = unseen; Hand b0;
        { // stand
            Pool q = p; Hand b; b.add(q.draw(g)); int bt = bankPlay(b, q, 15 + g.below(3), g); ws += pwins(h.total(), bt);
        }
        { // hit once, continue with the rule
            Pool q = p; Hand x = h; x.add(q.draw(g));
            while (x.total() < m.Tc && x.total() <= 21 && q.n > 1) x.add(q.draw(g));
            if (x.total() > 21) continue;
            Hand b; b.add(q.draw(g)); int bt = bankPlay(b, q, 15 + g.below(3), g); wh += pwins(x.total(), bt);
        }
    }
    return wh > ws;
}

// banker: hit or stand, knowing the player's number of cards (he did not burn); unseen = pool without the banker's cards
static bool mcBankerHit(const Hand& bh, const Pool& unseen, int kPlayer, const Mc& m, Rng& g) {
    if (bh.total() >= 21) return false;
    double ws = 0, wh = 0; int ok = 0, tries = 0;
    while (ok < m.N && tries < m.N * 30) {
        tries++;
        Pool q = unseen; Hand p; int Tp = m.TpLo + g.below(m.TpSpan);
        p.add(q.draw(g)); p.add(q.draw(g));
        while (p.total() < Tp && p.total() <= 21 && q.n > 2) p.add(q.draw(g));
        if (p.n != kPlayer || p.total() > 21) continue;
        ok++;
        ws += bh.total() >= p.total();
        Pool r = q; Hand x = bh; x.add(r.draw(g));
        int bt = bankPlay(x, r, m.TcBank, g); wh += (bt <= 21 && bt >= p.total());
        (void)bt;
    }
    if (ok == 0) return bh.total() < 17;
    return wh > ws;
}

// -------- betting (chips: bank 1000, minimum bet 50, as the app defaults)
static double BANK = 1000, MINB = 50;
static double oldBet(int firstRank, Rng& g) {
    double hi = val(firstRank) >= 10 ? 1.6 : 1.0;
    if (firstRank == 14 && g.uni() < 0.4) return BANK;                       // chips >= bank assumed
    double raw = MINB * (1 + g.uni() * (BANK / MINB / 4) * hi);
    return max(MINB, min(BANK, round(raw / MINB) * MINB));
}
// win chance of the player with this first card (continuation: stand >= 15), banker 15..17 mixture, counted pool
static double mcFirstWin(int firstRank, const Pool& unseenAfterFirst, int N, Rng& g) {
    double w = 0;
    for (int i = 0; i < N; i++) {
        Pool q = unseenAfterFirst; Hand p; p.add(firstRank);
        while (p.total() < 15 && p.total() <= 21) p.add(q.draw(g));
        if (p.total() > 21) continue;
        Hand b; b.add(q.draw(g)); int bt = bankPlay(b, q, 15 + g.below(3), g); w += pwins(p.total(), bt);
    }
    return w / N;
}
static int BETMODE = 0;     // 0 = old random sizing, 1 = by edge
static double newBet(double winP) {
    double e = 2 * winP - 1;
    if (e < -0.06) return MINB;
    int u = 1 + (int)floor((e + 0.06) / 0.04);                  // edge -0.06 -> 1 unit, 0 -> 2, +0.1 -> 5, ...
    return min(BANK, MINB * min(u, 20));
}

// -------- the table
enum { OLD, MC };
struct Res { double sum = 0; long n = 0; double sum2 = 0; void add(double x) { sum += x; sum2 += x * x; n++; } double mean() const { return sum / n; } double se() const { double m = mean(); return sqrt(max(0.0, sum2 / n - m * m) / n); } };

// one round with 3 players (seats 1..3) and a banker; returns per-player results (+1 win / -1 loss times bet)
// who[0] = banker kind, who[1..3] = player kinds
static void round3(int bankKind, const int* playerKind, const double* bets, double* out, Rng& g, const Mc& m) {
    Pool deck; deck.full(); Pool seen; // seen cards counted as removed from `unseen`
    Pool unseenAll; unseenAll.full();
    for (int s = 0; s < 3; s++) {
        // dealing
        int pr = deck.draw(g); Hand ph; ph.add(pr);
        int br = deck.draw(g); Hand bh; bh.add(br);
        Pool uP = unseenAll; uP.rem(pr);                       // what the player cannot see: banker's card is in uP
        // player plays
        while (ph.total() < 21) {
            bool hit = playerKind[s] == OLD ? oldHit(ph, uP, false) : mcPlayerHit(ph, uP, m, g);
            if (!hit) break;
            int x = deck.draw(g); ph.add(x); uP.rem(x);
        }
        int pt = ph.total(); bool out_; int bt = -1;
        if (pt > 21) out_ = false;
        else {
            Pool uB = unseenAll; uB.rem(br);
            while (bh.total() < 21) {
                bool hit = bankKind == OLD ? oldHit(bh, uB, true) : mcBankerHit(bh, uB, ph.n, m, g);
                if (!hit) break;
                int x = deck.draw(g); bh.add(x); uB.rem(x);
            }
            bt = bh.total(); out_ = pwins(pt, bt);
        }
        out[s] = (out_ ? 1 : -1) * bets[s];
        // cards gone: player's hand, and the banker's when he played
        // (rank counts: remove from the common unseen pool)
        // reconstruct hands by ranks: we only kept totals, so rebuild through the deck-draw log
        // (handled below through the logged lists)
        // -- simple approach: track the ranks in vectors
        (void)bt;
        // placeholder to keep the structure; real removal is done in the loop version round3b
    }
}

// version with explicit rank lists so the cards gone are removed from the counting pool
static double bets_used[3];
static void round3b(int bankKind, const int* playerKind, const double* bets, double* out, Rng& g, const Mc& m, int nPlayers = 3) {
    Pool deck; deck.full(); Pool unseenAll; unseenAll.full();
    for (int s = 0; s < nPlayers; s++) {
        vector<int> pl, bl;
        int pr = deck.draw(g); pl.push_back(pr); Hand ph; ph.add(pr);
        int br = deck.draw(g); bl.push_back(br); Hand bh; bh.add(br);
        Pool uP = unseenAll; uP.rem(pr);
        double bet = BETMODE == 0 ? 1.0 : (BETMODE == 1 ? oldBet(pr, g) : newBet(mcFirstWin(pr, uP, 200, g)));
        bets_used[s] = bet;
        while (ph.total() < 21) {
            bool hit = playerKind[s] == OLD ? oldHit(ph, uP, false) : mcPlayerHit(ph, uP, m, g);
            if (!hit) break;
            int x = deck.draw(g); ph.add(x); pl.push_back(x); uP.rem(x);
        }
        int pt = ph.total(); bool win;
        if (pt > 21) win = false;
        else {
            Pool uB = unseenAll; uB.rem(br);
            while (bh.total() < 21) {
                bool hit = bankKind == OLD ? oldHit(bh, uB, true) : mcBankerHit(bh, uB, ph.n, m, g);
                if (!hit) break;
                int x = deck.draw(g); bh.add(x); bl.push_back(x); uB.rem(x);
            }
            win = pwins(pt, bh.total());
        }
        out[s] = (win ? 1 : -1) * bet;
        for (int r : pl) unseenAll.rem(r);
        if (pt <= 21) for (int r : bl) unseenAll.rem(r);
        if (deck.n < 8) break;
    }
}

int main(int argc, char** argv) {
    long N = argc > 1 ? atol(argv[1]) : 20000; int mcN = argc > 2 ? atoi(argv[2]) : 200;
    Mc m; m.N = mcN; Rng g(12345); if (argc > 3) m.TcBank = atoi(argv[3]); if (argc > 4) m.TpLo = atoi(argv[4]); if (argc > 5) m.TpSpan = atoi(argv[5]); int only = argc > 6 ? atoi(argv[6]) : -1;
    struct Case { const char* name; int bank; int p[3]; };
    Case cs[] = {
        {"old banker vs old players (reference)", OLD, {OLD, OLD, OLD}},
        {"old banker vs MC players", OLD, {MC, MC, MC}},
        {"MC banker vs old players", MC, {OLD, OLD, OLD}},
        {"MC banker vs MC players", MC, {MC, MC, MC}},
    };
    if (argc > 7) {   // chips per hand with real bets: old robot vs new robot, as players and as banker
        struct K { const char* name; int bank, pk, bm; };
        K ks[] = {{"old robot players vs old banker (baseline)", OLD, OLD, 1}, {"new robot players vs old banker", OLD, MC, 2},
                  {"old robot players vs new banker", MC, OLD, 1}, {"new robot players vs new banker", MC, MC, 2}};
        for (auto& k : ks) {
            BETMODE = k.bm; Res rp; double betSum = 0; long hands = 0;
            for (long i = 0; i < N; i++) {
                int pk[3] = {k.pk, k.pk, k.pk}; double bets[3] = {1, 1, 1}, out[3] = {0, 0, 0};
                round3b(k.bank, pk, bets, out, g, m);
                for (int s2 = 0; s2 < 3; s2++) { rp.add(out[s2]); betSum += bets_used[s2]; hands++; }
            }
            printf("%-44s players %+7.2f chips/hand (se %.2f)  banker %+7.2f   avg bet %.0f\n", k.name, rp.mean(), rp.se(), -rp.mean(), betSum / hands);
            fflush(stdout);
        }
        return 0;
    }
    int ci = -1;
    for (auto& c : cs) {
        ci++; if (only >= 0 && ci != only && ci != only + 1) continue;
        Res rp, rb;
        for (long i = 0; i < N; i++) {
            double bets[3] = {1, 1, 1}, out[3] = {0, 0, 0};
            round3b(c.bank, c.p, bets, out, g, m);
            for (int s = 0; s < 3; s++) { rp.add(out[s]); rb.add(-out[s]); }
        }
        printf("%-42s player EV per hand %+.4f (se %.4f)   banker EV %+.4f\n", c.name, rp.mean(), rp.se(), rb.mean());
        fflush(stdout);
    }
    return 0;
}
