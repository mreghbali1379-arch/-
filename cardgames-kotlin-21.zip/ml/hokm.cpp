// Fast C++ port of Engine4 (four-player Hokm) for training and measuring a policy network.
// Same rules, same Monte-Carlo bot (sampling with voids, weightOf, HK_LR, rp rollouts, LV/MW values, trump choice).
// NOT ported: the exact endgame search (the app uses it when a bot holds <= 5 cards; here both sides use the same MC there).
//
// modes:
//   gen   : self-play, label decisions of the first 8 tricks with a strong MC teacher, write a dataset
//   eval  : duplicate hands / games between two bot specs
//   vec   : write test vectors (state features + net logits) for the Kotlin port
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

static inline int SU(int c) { return c / 13; }
static inline int RK(int c) { return c % 13 + 2; }
static inline u64 BIT(int c) { return 1ULL << c; }
static const u64 SUITM[4] = {0x1FFFULL, 0x1FFFULL << 13, 0x1FFFULL << 26, 0x1FFFULL << 39};
static inline int pc(u64 m) { return __builtin_popcountll(m); }

struct Rng {
    u64 a, b;
    Rng(u64 s = 1) { seed(s); }
    static u64 sm(u64 x) { x += 0x9E3779B97F4A7C15ULL; x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL; x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL; return x ^ (x >> 31); }
    void seed(u64 s) { a = sm(s); b = sm(a ^ 0x9E3779B97F4A7C15ULL); if (!a && !b) a = 1; }
    u64 next() { u64 s1 = a, s0 = b; a = s0; s1 ^= s1 << 23; b = s1 ^ s0 ^ (s1 >> 18) ^ (s0 >> 5); return b + s0; }
    double uni() { return (next() >> 11) * (1.0 / 9007199254740992.0); }
    int below(int n) { return (int)(uni() * n); }
};

static const double HK_LR[14] = {0.15, 0.2, 0.3, 0.78, 1.37, 2.0, 2.6, 3.1, 3.5, 4.0, 3.0, 2.0, 1.5, 1.5};
static double MW[8][8];
static double LV[15];
static void initMW() {
    for (int a = 0; a < 8; a++) for (int b = 0; b < 8; b++) MW[a][b] = a >= 7 ? 1.0 : 0.0;
    for (int a = 6; a >= 0; a--) for (int b = 6; b >= 0; b--) MW[a][b] = 0.5 * MW[a + 1][b] + 0.5 * MW[a][b + 1];
}
static void setLV(int me, const int* sc) {
    int a = min(7, sc[me]), b = min(7, sc[1 - me]);
    for (int p = -7; p <= 7; p++) {
        double vv = p > 0 ? MW[min(7, a + p)][b] : p < 0 ? MW[a][min(7, b - p)] : MW[a][b];
        LV[p + 7] = vv + 0.004 * p;
    }
}

static inline bool beats(int c, int b, int trump) { return SU(c) == SU(b) ? RK(c) > RK(b) : SU(c) == trump; }
static inline int vOf(int c, int trump) { return RK(c) + (SU(c) == trump ? 100 : 0); }
static inline int bestIdx(const int* tc, int tn, int trump) { int b = 0; for (int i = 0; i < tn; i++) if (beats(tc[i], tc[b], trump)) b = i; return b; }

static inline void adv(int* t, int w) { t[w]++; if (t[2] < 0 && t[w] >= 7 && t[1 - w] == 0) t[2] = w; }
// points of the hand for team (signed); ok=false while undecided
static inline int signedPts(const int* t, int hakemTeam, int team, bool& ok) {
    int w = -1; for (int tm = 0; tm < 2; tm++) if (t[tm] >= 7) { w = tm; break; }
    if (w < 0) { ok = false; return 0; }
    ok = true;
    if (t[1 - w] == 0) { if (t[w] < 13) { ok = false; return 0; } return w == team ? 7 : -7; }
    int p = (t[2] == w) ? (w == hakemTeam ? 2 : 3) : 1;
    return w == team ? p : -p;
}

static int rp(u64 hand, int seat, int trump, const int* tc, const int* ts, int tn) {
    int led = tn ? SU(tc[0]) : -1;
    u64 L = hand;
    if (led >= 0) { u64 f = hand & SUITM[led]; if (f) L = f; }
    if (tn == 0) {
        int b = -1, bv = -99;
        for (u64 m = hand; m; m &= m - 1) { int c = __builtin_ctzll(m); int vv = RK(c) + (SU(c) == trump ? -50 : 0); if (vv > bv) { bv = vv; b = c; } }
        return b;
    }
    int bi = bestIdx(tc, tn, trump); int bc = tc[bi], bs = ts[bi];
    int lc = -1, lv = 1 << 30;
    for (u64 m = L; m; m &= m - 1) { int c = __builtin_ctzll(m); int v = vOf(c, trump); if (v < lv) { lv = v; lc = c; } }
    if ((bs & 1) == (seat & 1)) return lc;
    int w = -1, wv = 1 << 30;
    for (u64 m = L; m; m &= m - 1) { int c = __builtin_ctzll(m); if (beats(c, bc, trump)) { int v = vOf(c, trump); if (v < wv) { wv = v; w = c; } } }
    return w >= 0 ? w : lc;
}

struct Play { int seat, card, len, led, bs, bc; };
struct G {
    u64 H[4] = {0, 0, 0, 0};
    int trump = -1, hakem = 0, turn = 0;
    int tc[4], ts[4], tn = 0;
    int tk[2] = {0, 0}, sc[2] = {0, 0}, kt = -1;
    u64 seen = 0; int voids[4] = {0, 0, 0, 0};
    vector<Play> plays;
    u64 trickMask() const { u64 m = 0; for (int i = 0; i < tn; i++) m |= BIT(tc[i]); return m; }
};

static void doPlay(G& g, int s, int c) {
    int bs = -1, bc = -1;
    if (g.tn) { int bi = bestIdx(g.tc, g.tn, g.trump); bs = g.ts[bi]; bc = g.tc[bi]; }
    g.plays.push_back({s, c, g.tn, g.tn ? SU(g.tc[0]) : -1, bs, bc});
    if (g.tn && SU(c) != SU(g.tc[0])) g.voids[s] |= 1 << SU(g.tc[0]);
    g.seen |= BIT(c); g.H[s] &= ~BIT(c);
    g.tc[g.tn] = c; g.ts[g.tn] = s; g.tn++;
}

static u64 legalMask(const G& g, int s) {
    u64 h = g.H[s];
    if (g.tn == 0) return h;
    u64 f = h & SUITM[SU(g.tc[0])];
    return f ? f : h;
}

// full hand from the start with rp (used by the trump choice)
static double fullHand(const u64* h0, int hk, int trump, int hakem) {
    u64 hh[4]; memcpy(hh, h0, sizeof hh);
    int t[3] = {0, 0, -1}; int tc[4], ts[4], tn = 0; int turn = hk;
    while (true) {
        if (tn == 4) {
            int w = ts[bestIdx(tc, 4, trump)]; adv(t, w & 1); tn = 0; turn = w;
            bool ok; int p = signedPts(t, hakem & 1, hk & 1, ok); if (ok) return LV[p + 7];
        }
        int c = rp(hh[turn], turn, trump, tc, ts, tn);
        hh[turn] &= ~BIT(c); tc[tn] = c; ts[tn] = turn; tn++;
        if (tn < 4) turn = (turn + 1) % 4;
    }
}

static int chooseTrump(int hk, u64 mine, int hakem, const int* sc, Rng& r, int n = 150) {
    setLV(hk & 1, sc);
    int un[52], nun = 0; for (int c = 0; c < 52; c++) if (!(mine & BIT(c))) un[nun++] = c;
    double s3[4] = {0, 0, 0, 0};
    for (int k = 0; k < n; k++) {
        int pool[52]; memcpy(pool, un, sizeof(int) * nun);
        for (int i = nun - 1; i > 0; i--) { int j = r.below(i + 1); swap(pool[i], pool[j]); }
        u64 hs[4] = {0, 0, 0, 0}; int p = 0;
        for (int o = 0; o < 4; o++) { int take = o == hk ? 8 : 13; if (o == hk) hs[o] = mine; for (int x = 0; x < take; x++) hs[o] |= BIT(pool[p++]); }
        for (int x = 0; x < 4; x++) s3[x] += fullHand(hs, hk, x, hakem);
    }
    int b = 0; for (int x = 1; x < 4; x++) if (s3[x] > s3[b]) b = x;
    return b;
}

static double rollout(const u64* h0, int s, int c, const G& g) {
    u64 hh[4]; memcpy(hh, h0, sizeof hh); hh[s] &= ~BIT(c);
    int t[3] = {g.tk[0], g.tk[1], g.kt};
    int tc[4], ts[4], tn = g.tn; for (int i = 0; i < tn; i++) { tc[i] = g.tc[i]; ts[i] = g.ts[i]; }
    tc[tn] = c; ts[tn] = s; tn++;
    int turn = (s + 1) % 4; int tr = g.trump; int hkt = g.hakem & 1; int me = s & 1;
    bool ok;
    while (true) {
        if (tn == 4) {
            int w = ts[bestIdx(tc, 4, tr)]; adv(t, w & 1); tn = 0; turn = w;
            int p = signedPts(t, hkt, me, ok); if (ok) return LV[p + 7];
        }
        if (hh[turn] == 0) break;
        int x = rp(hh[turn], turn, tr, tc, ts, tn);
        hh[turn] &= ~BIT(x); tc[tn] = x; ts[tn] = turn; tn++;
        if (tn < 4) turn = (turn + 1) % 4;
    }
    int p = signedPts(t, hkt, me, ok);
    return LV[(ok ? p : 0) + 7];
}

static bool sampleWorld(const G& g, int s, const int* un, int nun, u64* hs, bool useVoids, Rng& r) {
    for (int at = 0; at < (useVoids ? 8 : 1); at++) {
        int need[4] = {0, 0, 0, 0}; for (int o = 0; o < 4; o++) if (o != s) need[o] = pc(g.H[o]);
        for (int o = 0; o < 4; o++) hs[o] = 0; hs[s] = g.H[s];
        int cards[52], al[52]; memcpy(cards, un, sizeof(int) * nun);
        for (int i = nun - 1; i > 0; i--) { int j = r.below(i + 1); swap(cards[i], cards[j]); }
        for (int i = 0; i < nun; i++) {
            int m = 0; for (int o = 0; o < 4; o++) if (o != s && !(useVoids && ((g.voids[o] >> SU(cards[i])) & 1))) m |= 1 << o;
            al[i] = m;
        }
        int ord[52], no = 0;
        if (useVoids) { for (int k = 1; k <= 3; k++) for (int i = 0; i < nun; i++) if (__builtin_popcount(al[i]) == k) ord[no++] = i; }
        else for (int i = 0; i < nun; i++) ord[no++] = i;
        bool ok = true;
        for (int q = 0; q < no; q++) {
            int i = ord[q]; int tot = 0;
            for (int o = 0; o < 4; o++) if (((al[i] >> o) & 1) && need[o] > 0) tot += need[o];
            if (tot <= 0) { ok = false; break; }
            double rr = r.uni() * tot; int pk = -1;
            for (int o = 0; o < 4; o++) if (((al[i] >> o) & 1) && need[o] > 0) { rr -= need[o]; if (rr < 0) { pk = o; break; } }
            if (pk < 0) for (int o = 0; o < 4; o++) if (((al[i] >> o) & 1) && need[o] > 0) { pk = o; break; }
            hs[pk] |= BIT(cards[i]); need[pk]--;
        }
        if (ok) return true;
    }
    return false;
}

static double weightOf(const G& g, const u64* hs, int s) {
    double w = 1.0; int n = g.plays.size();
    for (int i = 0; i < n; i++) {
        const Play& e = g.plays[i]; int X = e.seat;
        if (X == s || e.len == 0) continue;
        u64 hand = hs[X]; for (int k = i; k < n; k++) if (g.plays[k].seat == X) hand |= BIT(g.plays[k].card);
        bool pwin = (X + 2) % 4 == e.bs;
        if (SU(e.card) == e.led) {
            bool wins = !pwin && beats(e.card, e.bc, g.trump);
            bool any = false;
            for (u64 m = hand & SUITM[e.led]; m; m &= m - 1) { int c = __builtin_ctzll(m); if (RK(c) < RK(e.card) && (wins ? beats(c, e.bc, g.trump) : true)) { any = true; break; } }
            if (any) w *= 0.3;
        } else if (SU(e.card) != g.trump && !pwin) {
            bool any = false;
            for (u64 m = hand & SUITM[g.trump]; m; m &= m - 1) { int c = __builtin_ctzll(m); if (beats(c, e.bc, g.trump)) { any = true; break; } }
            if (any) w *= 0.2;
        }
    }
    return w;
}

// ------------------------------------------------------------------ the network
static const int NB = 282, ND = 5;
struct Net {
    int H1 = 0, H2 = 0, NO = 52;
    vector<float> W1, b1, W2, b2, W3, b3;
    bool load(const char* fn) {
        FILE* f = fopen(fn, "rb"); if (!f) return false;
        char mg[4]; int hd[5];
        if (fread(mg, 1, 4, f) != 4 || memcmp(mg, "HKN1", 4) || fread(hd, 4, 5, f) != 5) { fclose(f); return false; }
        if (hd[0] != NB || hd[1] != ND || hd[4] != 52) { fclose(f); return false; }
        H1 = hd[2]; H2 = hd[3];
        W1.resize((NB + ND) * H1); b1.resize(H1); W2.resize(H1 * H2); b2.resize(H2); W3.resize(H2 * 52); b3.resize(52);
        bool ok = fread(W1.data(), 4, W1.size(), f) == W1.size() && fread(b1.data(), 4, b1.size(), f) == b1.size() &&
                  fread(W2.data(), 4, W2.size(), f) == W2.size() && fread(b2.data(), 4, b2.size(), f) == b2.size() &&
                  fread(W3.data(), 4, W3.size(), f) == W3.size() && fread(b3.data(), 4, b3.size(), f) == b3.size();
        fclose(f); return ok;
    }
    void forward(const int* idx, int n, const float* dense, float* out) const {
        float h1[256], h2[128];
        for (int j = 0; j < H1; j++) h1[j] = b1[j];
        for (int i = 0; i < n; i++) { const float* w = &W1[(size_t)idx[i] * H1]; for (int j = 0; j < H1; j++) h1[j] += w[j]; }
        for (int d = 0; d < ND; d++) { float v = dense[d]; if (v != 0) { const float* w = &W1[(size_t)(NB + d) * H1]; for (int j = 0; j < H1; j++) h1[j] += v * w[j]; } }
        for (int j = 0; j < H1; j++) if (h1[j] < 0) h1[j] = 0;
        for (int j = 0; j < H2; j++) h2[j] = b2[j];
        for (int i = 0; i < H1; i++) { float v = h1[i]; if (v == 0) continue; const float* w = &W2[(size_t)i * H2]; for (int j = 0; j < H2; j++) h2[j] += v * w[j]; }
        for (int j = 0; j < H2; j++) if (h2[j] < 0) h2[j] = 0;
        for (int k = 0; k < 52; k++) out[k] = b3[k];
        for (int i = 0; i < H2; i++) { float v = h2[i]; if (v == 0) continue; const float* w = &W3[(size_t)i * 52]; for (int k = 0; k < 52; k++) out[k] += v * w[k]; }
    }
};

// features of the state for the player s who is to move (the cards of s are not yet in the trick)
static void encode(const G& g, int s, int* idx, int& n, float* dense, uint8_t* bin /*optional NB bytes*/) {
    n = 0;
    auto put = [&](int i) { idx[n++] = i; };
    for (u64 m = g.H[s]; m; m &= m - 1) put(__builtin_ctzll(m));
    u64 tm = g.trickMask();
    for (u64 m = g.seen & ~tm; m; m &= m - 1) put(52 + __builtin_ctzll(m));
    for (int i = 0; i < g.tn; i++) { int j = (g.ts[i] - s + 4) % 4; put(104 + (j - 1) * 52 + g.tc[i]); }
    if (g.trump >= 0) put(260 + g.trump);
    put(264 + (g.hakem - s + 4) % 4);
    for (int j = 1; j <= 3; j++) { int q = (s + j) % 4; for (int x = 0; x < 4; x++) if ((g.voids[q] >> x) & 1) put(268 + (j - 1) * 4 + x); }
    int me = s & 1;
    if (g.kt == me) put(280); else if (g.kt == 1 - me) put(281);
    dense[0] = g.tk[me] / 13.0f; dense[1] = g.tk[1 - me] / 13.0f; dense[2] = pc(g.H[s]) / 13.0f;
    dense[3] = min(7, g.sc[me]) / 7.0f; dense[4] = min(7, g.sc[1 - me]) / 7.0f;
    if (bin) { memset(bin, 0, NB); for (int i = 0; i < n; i++) bin[idx[i]] = 1; }
}

// ------------------------------------------------------------------ the decision
struct Cfg {
    int S = 24;          // samples
    int net = 0;         // 1 = fuse the policy prior (first 8 tricks only)
    double beta = 0.0;   // weight of log(prior)
    int topK = 0;        // keep only the K best candidates by prior (0 = all)
    int pol = 0;         // 1 = play the net's best card, no search (first 8 tricks)
    int minCards = 6;    // net is used when the bot holds at least this many cards
};
struct Info { int nc = 0; int cand[13]; double mean[13]; int grp[13][13]; int gn[13]; double prior[13]; };

static int decide(const G& g, int s, const Net* net, const Cfg& cfg, Rng& rng, Info* info = nullptr) {
    u64 L = legalMask(g, s);
    if (pc(L) == 1) return __builtin_ctzll(L);
    setLV(s & 1, g.sc);
    u64 inert = g.H[s] | (g.seen & ~g.trickMask());
    int cand[13], nc = 0;
    for (u64 m = L; m; m &= m - 1) {
        int c = __builtin_ctzll(m); bool dom = false;
        for (u64 m2 = L & SUITM[SU(c)]; m2; m2 &= m2 - 1) {
            int d = __builtin_ctzll(m2); if (d >= c) break;
            int len = c - d - 1; u64 mask = (len == 0) ? 0 : ((1ULL << len) - 1);
            if (((inert >> (d + 1)) & mask) == mask) { dom = true; break; }
        }
        if (!dom) cand[nc++] = c;
    }
    sort(cand, cand + nc, [&](int a, int b) { return vOf(a, g.trump) < vOf(b, g.trump); });
    if (nc == 1 && !info) return cand[0];
    // groups: legal cards of the suit from cand up to (not including) the next cand of the suit
    int gn[13], grp[13][13];
    for (int k = 0; k < nc; k++) {
        int c = cand[k]; int nxt = 1 << 20;
        for (int q = 0; q < nc; q++) if (SU(cand[q]) == SU(c) && cand[q] > c && cand[q] < nxt) nxt = cand[q];
        gn[k] = 0;
        for (u64 m = L & SUITM[SU(c)]; m; m &= m - 1) { int x = __builtin_ctzll(m); if (x >= c && x < nxt) grp[k][gn[k]++] = x; }
    }
    double prior[13]; for (int k = 0; k < nc; k++) prior[k] = 1.0 / nc;
    bool useNet = net && (cfg.net || cfg.pol) && pc(g.H[s]) >= cfg.minCards;
    if (useNet) {
        int idx[300], n; float dense[ND], out[52]; encode(g, s, idx, n, dense, nullptr);
        net->forward(idx, n, dense, out);
        float mx = -1e30f; for (u64 m = L; m; m &= m - 1) mx = max(mx, out[__builtin_ctzll(m)]);
        double Z = 0; double e[52];
        for (u64 m = L; m; m &= m - 1) { int c = __builtin_ctzll(m); e[c] = exp((double)(out[c] - mx)); Z += e[c]; }
        for (int k = 0; k < nc; k++) { double p = 0; for (int q = 0; q < gn[k]; q++) p += e[grp[k][q]]; prior[k] = p / Z; }
    }
    if (info) { info->nc = nc; for (int k = 0; k < nc; k++) { info->cand[k] = cand[k]; info->gn[k] = gn[k]; info->prior[k] = prior[k]; for (int q = 0; q < gn[k]; q++) info->grp[k][q] = grp[k][q]; } }
    if (cfg.pol && useNet) { int b = 0; for (int k = 1; k < nc; k++) if (prior[k] > prior[b]) b = k; return cand[b]; }
    // keep the K best by prior
    int use[13], nu = nc; for (int k = 0; k < nc; k++) use[k] = k;
    if (useNet && cfg.topK > 0 && nc > cfg.topK) {
        sort(use, use + nc, [&](int a, int b) { return prior[a] > prior[b]; });
        nu = cfg.topK; sort(use, use + nu);
    }
    int un[52], nun = 0;
    for (int c = 0; c < 52; c++) if (!(g.seen & BIT(c)) && !(g.H[s] & BIT(c))) un[nun++] = c;
    int tot = 0; for (int o = 0; o < 4; o++) if (o != s) tot += pc(g.H[o]);
    if (tot != nun) { if (info) info->nc = 0; return cand[0]; }
    bool lastSeat = g.tn == 3; int bb = -1, bs = -1; bool pw = false;
    if (g.tn) { int bi = bestIdx(g.tc, g.tn, g.trump); bb = g.tc[bi]; bs = g.ts[bi]; pw = bs == (s + 2) % 4; }
    bool anyBeat = false; if (lastSeat) for (u64 m = L; m; m &= m - 1) if (beats(__builtin_ctzll(m), bb, g.trump)) { anyBeat = true; break; }
    double sc2[13] = {0}; double W = 0;
    int samples = cfg.S;
    for (int k = 0; k < samples; k++) {
        u64 hs[4];
        if (!sampleWorld(g, s, un, nun, hs, true, rng) && !sampleWorld(g, s, un, nun, hs, false, rng)) return cand[0];
        double lr = 1.0;
        if (s != g.hakem && g.trump >= 0) lr = HK_LR[min(13, pc(hs[g.hakem] & SUITM[g.trump]))];
        double w = weightOf(g, hs, s) * lr; W += w;
        for (int q = 0; q < nu; q++) {
            int i = use[q]; int c = cand[i];
            double vv = rollout(hs, s, c, g);
            double bias = 0;
            if (lastSeat) {
                bool cw = beats(c, bb, g.trump);
                if (pw && cw) bias += 0.012;
                if (pw && SU(c) == g.trump && SU(bb) != g.trump) bias += 0.012;
                if (!pw && !cw && SU(c) == SU(g.tc[0]) && anyBeat) bias += 0.012;
            }
            sc2[i] += w * (vv - 0.0008 * (RK(c) / 14.0 + (SU(c) == g.trump ? 0.3 : 0.0)) - bias);
        }
    }
    int bi = -1; double bv = -1e30;
    for (int q = 0; q < nu; q++) {
        int i = use[q]; double m = W > 0 ? sc2[i] / W : 0;
        if (info) info->mean[i] = m;
        double v = m + ((useNet && cfg.net) ? cfg.beta * log(prior[i] + 1e-9) : 0.0);
        if (v > bv) { bv = v; bi = i; }
    }
    return cand[bi];
}

// ------------------------------------------------------------------ hands and games
struct Bot { Cfg cfg; const Net* net = nullptr; };

struct Deal { int hakem; u64 hand[4]; int trump; };

static Deal makeDeal(Rng& r, int hakem, const int* sc) {
    Deal d; d.hakem = hakem;
    int deck[52]; for (int i = 0; i < 52; i++) deck[i] = i;
    for (int i = 51; i > 0; i--) { int j = r.below(i + 1); swap(deck[i], deck[j]); }
    for (int o = 0; o < 4; o++) d.hand[o] = 0;
    u64 first = 0; for (int i = 0; i < 5; i++) first |= BIT(deck[i]);
    d.trump = chooseTrump(hakem, first, hakem, sc, r);
    d.hand[hakem] = first; int p = 5;
    for (int x = 0; x < 8; x++) d.hand[hakem] |= BIT(deck[p++]);
    for (int o = 0; o < 4; o++) if (o != hakem) for (int x = 0; x < 13; x++) d.hand[o] |= BIT(deck[p++]);
    return d;
}

static void startHand(G& g, const Deal& d, const int* sc) {
    g = G(); g.hakem = d.hakem; g.trump = d.trump; g.turn = d.hakem;
    for (int o = 0; o < 4; o++) g.H[o] = d.hand[o];
    g.sc[0] = sc[0]; g.sc[1] = sc[1];
}

// plays one hand; returns the winning side (with kot/bam info in pts: signed for team 0)
struct HandRes { int side; bool bam, kot; int gain; };
typedef function<int(const G&, int)> Mover;

static HandRes playHand(G& g, Mover mv) {
    while (true) {
        int s = g.turn;
        int c = mv(g, s);
        doPlay(g, s, c);
        if (g.tn < 4) { g.turn = (s + 1) % 4; continue; }
        int w = g.ts[bestIdx(g.tc, 4, g.trump)];
        g.tk[w & 1]++; g.tn = 0; g.turn = w;
        // kotOf
        if (g.kt < 0) { for (int t = 0; t < 2; t++) if (g.tk[t] >= 7 && g.tk[1 - t] == 0) { g.kt = t; break; } }
        int hs = -1; for (int t = 0; t < 2; t++) if (g.tk[t] >= 7) { hs = t; break; }
        if (hs >= 0 && (g.tk[1 - hs] != 0 || g.tk[hs] == 13)) {
            bool bam = g.tk[hs] == 13; bool kot = bam || g.kt == hs;
            int gain = kot ? (hs == (g.hakem & 1) ? 2 : 3) : 1;
            return {hs, bam, kot, bam ? 7 : gain};
        }
    }
}

static Mover botMover(const Bot& b, Rng& rng) {
    return [&b, &rng](const G& g, int s) { return decide(g, s, b.net, b.cfg, rng); };
}

static Cfg parseCfg(const string& sp) {
    Cfg c; stringstream ss(sp); string tok;
    while (getline(ss, tok, ',')) {
        size_t e = tok.find('='); if (e == string::npos) continue;
        string k = tok.substr(0, e); double v = atof(tok.c_str() + e + 1);
        if (k == "S") c.S = (int)v; else if (k == "net") c.net = (int)v; else if (k == "beta") c.beta = v;
        else if (k == "topK") c.topK = (int)v; else if (k == "pol") c.pol = (int)v; else if (k == "minCards") c.minCards = (int)v;
    }
    return c;
}

static map<string, string> parseArgs(int argc, char** argv) {
    map<string, string> m;
    for (int i = 2; i < argc; i++) { string a = argv[i]; size_t e = a.find('='); if (e != string::npos) m[a.substr(0, e)] = a.substr(e + 1); }
    return m;
}

// ------------------------------------------------------------------ gen
#pragma pack(push, 1)
struct Rec { uint8_t bin[NB]; float dense[ND]; u64 mask; float target[52]; };
#pragma pack(pop)

static int cmdGen(map<string, string>& a) {
    long hands = atol(a.count("hands") ? a["hands"].c_str() : "1000");
    int teacherS = atoi(a.count("S") ? a["S"].c_str() : "250");
    double tau = atof(a.count("tau") ? a["tau"].c_str() : "0.03");
    double eps = atof(a.count("eps") ? a["eps"].c_str() : "0.15");
    u64 seed = strtoull(a.count("seed") ? a["seed"].c_str() : "1", 0, 10);
    string out = a.count("out") ? a["out"] : "data.bin";
    string netf = a.count("net") ? a["net"] : "";
    int cheapS = atoi(a.count("cheapS") ? a["cheapS"].c_str() : "24");
    Net net; bool haveNet = false; if (!netf.empty()) { haveNet = net.load(netf.c_str()); if (!haveNet) { fprintf(stderr, "cannot load net\n"); return 1; } }
    // with a net the teacher fuses the prior of the previous round (expert iteration): beta, topK from args
    Cfg teacher; teacher.S = teacherS; if (haveNet) { teacher.net = 1; teacher.beta = atof(a.count("beta") ? a["beta"].c_str() : "0.05"); teacher.topK = atoi(a.count("topK") ? a["topK"].c_str() : "0"); }
    Cfg cheap; cheap.S = cheapS;
    FILE* f = fopen(out.c_str(), "wb"); if (!f) return 1;
    Rng rng(seed); long nrec = 0; auto t0 = chrono::steady_clock::now();
    for (long h = 0; h < hands; h++) {
        int sc[2] = {0, 0};
        if (rng.uni() < 0.6) { sc[0] = rng.below(7); sc[1] = rng.below(7); }
        int hk = rng.below(4);
        Deal d = makeDeal(rng, hk, sc);
        G g; startHand(g, d, sc);
        Mover mv = [&](const G& gg, int s) -> int {
            int cnt = pc(gg.H[s]);
            if (cnt >= 6) {
                Info info; int c = decide(gg, s, haveNet ? &net : nullptr, teacher, rng, &info);
                if (info.nc >= 2) {
                    // soft target from the teacher's mean values (fused with the prior when a net is used)
                    double v[13], mx = -1e30;
                    for (int k = 0; k < info.nc; k++) { v[k] = info.mean[k] + (haveNet ? teacher.beta * log(info.prior[k] + 1e-9) : 0.0); mx = max(mx, v[k]); }
                    double Z = 0, p[13]; for (int k = 0; k < info.nc; k++) { p[k] = exp((v[k] - mx) / tau); Z += p[k]; }
                    Rec r; memset(&r, 0, sizeof r); int idx[300], n; encode(gg, s, idx, n, r.dense, r.bin);
                    r.mask = legalMask(gg, s);
                    for (int k = 0; k < info.nc; k++) for (int q = 0; q < info.gn[k]; q++) r.target[info.grp[k][q]] = (float)(p[k] / Z / info.gn[k]);
                    fwrite(&r, sizeof r, 1, f); nrec++;
                    if (rng.uni() < eps) { double rr = rng.uni() * Z; for (int k = 0; k < info.nc; k++) { rr -= p[k]; if (rr < 0) return info.cand[k]; } }
                }
                return c;
            }
            return decide(gg, s, nullptr, cheap, rng);
        };
        playHand(g, mv);
        if ((h + 1) % 100 == 0) {
            double el = chrono::duration<double>(chrono::steady_clock::now() - t0).count();
            fprintf(stderr, "hands %ld  records %ld  %.0fs\n", h + 1, nrec, el);
        }
    }
    fclose(f); fprintf(stderr, "done: %ld records\n", nrec);
    return 0;
}

// ------------------------------------------------------------------ eval
static int cmdEval(map<string, string>& a) {
    long N = atol(a.count("hands") ? a["hands"].c_str() : "500");
    u64 seed = strtoull(a.count("seed") ? a["seed"].c_str() : "7", 0, 10);
    string mode = a.count("mode") ? a["mode"] : "hand";   // hand | game
    Bot A, B; A.cfg = parseCfg(a.count("A") ? a["A"] : "S=24"); B.cfg = parseCfg(a.count("B") ? a["B"] : "S=24");
    Net net; bool haveNet = false; if (a.count("net")) { haveNet = net.load(a["net"].c_str()); if (!haveNet) { fprintf(stderr, "cannot load net\n"); return 1; } }
    if (haveNet) { A.net = &net; B.net = &net; }
    Rng rngA(seed * 2 + 1), rngB(seed * 2 + 2), rngD(seed * 2 + 3);
    auto t0 = chrono::steady_clock::now();
    double sum = 0, sum2 = 0; long cnt = 0; long wins = 0, losses = 0;
    for (long i = 0; i < N; i++) {
        if (mode == "hand") {
            int sc[2] = {0, 0}; int hk = rngD.below(4);
            Deal d = makeDeal(rngD, hk, sc);
            double dup = 0;
            for (int o = 0; o < 2; o++) {   // o=0: A on seats 0,2 ; o=1: A on seats 1,3
                G g; startHand(g, d, sc);
                Mover mv = [&](const G& gg, int s) -> int { bool isA = ((s & 1) == o); return isA ? decide(gg, s, A.net, A.cfg, rngA) : decide(gg, s, B.net, B.cfg, rngB); };
                HandRes r = playHand(g, mv);
                int aTeam = o; double p = r.gain; double sg = (r.side == aTeam) ? p : -p;
                dup += sg; if (sg > 0) wins++; else losses++;
            }
            sum += dup; sum2 += dup * dup; cnt++;
        } else {
            // a whole game to 7, the same deals in both orientations
            double res = 0;
            for (int o = 0; o < 2; o++) {
                Rng rd(seed * 1000003 + i);
                int sc[2] = {0, 0}; int hk = rd.below(4); int guard = 0;
                while (sc[0] < 7 && sc[1] < 7 && guard++ < 60) {
                    Deal d = makeDeal(rd, hk, sc);
                    G g; startHand(g, d, sc);
                    Mover mv = [&](const G& gg, int s) -> int { bool isA = ((s & 1) == o); return isA ? decide(gg, s, A.net, A.cfg, rngA) : decide(gg, s, B.net, B.cfg, rngB); };
                    HandRes r = playHand(g, mv);
                    sc[r.side] += r.gain; if (r.bam) sc[r.side] = max(sc[r.side], 7);
                    if (r.side != (hk & 1)) hk = (hk + 1) % 4;
                }
                bool aw = sc[o] >= 7;
                res += aw ? 1 : -1; if (aw) wins++; else losses++;
            }
            sum += res; sum2 += res * res; cnt++;
        }
        if ((i + 1) % 50 == 0) {
            double m = sum / cnt, sd = sqrt(max(0.0, sum2 / cnt - m * m)); double el = chrono::duration<double>(chrono::steady_clock::now() - t0).count();
            fprintf(stderr, "%ld  dup-mean %.4f  se %.4f  A-wins %ld / %ld  %.0fs\n", i + 1, m, sd / sqrt((double)cnt), wins, wins + losses, el);
        }
    }
    double m = sum / cnt, sd = sqrt(max(0.0, sum2 / cnt - m * m));
    printf("mode=%s N=%ld  A=[%s] B=[%s]\n  duplicate mean (A minus B) = %.4f +- %.4f (95%%: %.4f)  A wins %ld of %ld (%.1f%%)\n",
           mode.c_str(), cnt, a.count("A") ? a["A"].c_str() : "", a.count("B") ? a["B"].c_str() : "", m, sd / sqrt((double)cnt), 1.96 * sd / sqrt((double)cnt),
           wins, wins + losses, 100.0 * wins / max(1L, wins + losses));
    return 0;
}

// ------------------------------------------------------------------ test vectors for the Kotlin port
static int cmdVec(map<string, string>& a) {
    Net net; if (!net.load(a["net"].c_str())) { fprintf(stderr, "cannot load net\n"); return 1; }
    int count = atoi(a.count("n") ? a["n"].c_str() : "12"); Rng rng(99);
    FILE* f = fopen(a.count("out") ? a["out"].c_str() : "vectors.txt", "w");
    // one line per state: seat trump hakem tk0 tk1 sc0 sc1 kt | hands(4 masks) seen voids(4) trick(n, seat:card ...) | n idx... | dense | logits
    int made = 0;
    while (made < count) {
        int sc[2] = {rng.below(7), rng.below(7)}; Deal d = makeDeal(rng, rng.below(4), sc);
        G g; startHand(g, d, sc);
        int stopAt = rng.below(30); int steps = 0; Cfg cheap; cheap.S = 4;
        Mover mv = [&](const G& gg, int s) -> int { if (steps++ == stopAt) throw s; return decide(gg, s, nullptr, cheap, rng); };
        try { playHand(g, mv); continue; } catch (int s) {
            int idx[300], n; float dense[ND], out[52]; encode(g, s, idx, n, dense, nullptr); net.forward(idx, n, dense, out);
            fprintf(f, "S %d T %d HK %d TK %d %d SC %d %d KT %d\n", s, g.trump, g.hakem, g.tk[0], g.tk[1], g.sc[0], g.sc[1], g.kt);
            fprintf(f, "H %llu %llu %llu %llu SEEN %llu VOIDS %d %d %d %d\n", g.H[0], g.H[1], g.H[2], g.H[3], g.seen, g.voids[0], g.voids[1], g.voids[2], g.voids[3]);
            fprintf(f, "TRICK %d", g.tn); for (int i = 0; i < g.tn; i++) fprintf(f, " %d:%d", g.ts[i], g.tc[i]); fprintf(f, "\n");
            fprintf(f, "IDX %d", n); for (int i = 0; i < n; i++) fprintf(f, " %d", idx[i]); fprintf(f, "\n");
            fprintf(f, "DENSE"); for (int i = 0; i < ND; i++) fprintf(f, " %.9g", dense[i]); fprintf(f, "\n");
            fprintf(f, "OUT"); for (int i = 0; i < 52; i++) fprintf(f, " %.9g", out[i]); fprintf(f, "\n");
            made++;
        }
    }
    fclose(f); return 0;
}

int main(int argc, char** argv) {
    initMW();
    if (argc < 2) { fprintf(stderr, "usage: hokm gen|eval|vec key=value...\n"); return 1; }
    string m = argv[1]; auto a = parseArgs(argc, argv);
    if (m == "gen") return cmdGen(a);
    if (m == "eval") return cmdEval(a);
    if (m == "vec") return cmdVec(a);
    return 1;
}
