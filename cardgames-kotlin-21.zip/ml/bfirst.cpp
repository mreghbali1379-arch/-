#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
struct Rng { u64 a, b; Rng(u64 s = 1) { a = sm(s); b = sm(a); } static u64 sm(u64 x) { x += 0x9E3779B97F4A7C15ULL; x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL; x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL; return x ^ (x >> 31); }
    u64 next() { u64 s1 = a, s0 = b; a = s0; s1 ^= s1 << 23; b = s1 ^ s0 ^ (s1 >> 18) ^ (s0 >> 5); return b + s0; }
    double uni() { return (next() >> 11) * (1.0 / 9007199254740992.0); } int below(int n) { return (int)(uni() * n); } };
int main() {
    Rng g(3); long N = 2000000; int V[9] = {6, 7, 8, 9, 10, 2, 3, 4, 11}; double all = 0;
    for (int fc = 0; fc < 9; fc++) {
        double s = 0;
        for (long i = 0; i < N; i++) {
            auto dr = [&]() { return V[g.below(9)]; };
            int Tp = 13 + g.below(5); int p = dr(); while (p < Tp) p += dr();
            if (p > 21) { s += 1; continue; }
            int b = V[fc]; while (b < 17) b += dr();
            s += (b > 21 || p > b) ? -1 : 1;
        }
        printf("banker first card value %2d : banker EV %+.3f\n", V[fc], s / N); all += s / N / 9;
    }
    printf("average over a fresh card: %+.3f\n", all);
}
